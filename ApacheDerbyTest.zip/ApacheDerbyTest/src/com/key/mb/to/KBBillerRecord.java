package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBBillerRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBBillerRecord.class.getName());

  public String currappstatus;

  public String institutionid;

  public String makerlastcmt;

  public String modifiedat;

  public String madeby;

  public String adminlastcmt;

  public String billeracno;

  public String billertype;

  public String madeat;

  public String checkerlastcmt;

  public String rstatus;

  public String createdat;

  public String checkedat;

  public String createdby;

  public String checkedby;

  public String modifiedby;

  public String id;

  public String billername;

  public String getCurrappstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(currappstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(currappstatus);
    }
    else {
      return currappstatus;
    }
  }

  public String getInstitutionid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(institutionid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(institutionid);
    }
    else {
      return institutionid;
    }
  }

  public String getMakerlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(makerlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(makerlastcmt);
    }
    else {
      return makerlastcmt;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getMadeby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(madeby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(madeby);
    }
    else {
      return madeby;
    }
  }

  public String getAdminlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(adminlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(adminlastcmt);
    }
    else {
      return adminlastcmt;
    }
  }

  public String getBilleracno() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(billeracno);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(billeracno);
    }
    else {
      return billeracno;
    }
  }

  public String getBillertype() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(billertype);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(billertype);
    }
    else {
      return billertype;
    }
  }

  public String getMadeat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(madeat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(madeat);
    }
    else {
      return madeat;
    }
  }

  public String getCheckerlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkerlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkerlastcmt);
    }
    else {
      return checkerlastcmt;
    }
  }

  public String getRstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rstatus);
    }
    else {
      return rstatus;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getCheckedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkedat);
    }
    else {
      return checkedat;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getCheckedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkedby);
    }
    else {
      return checkedby;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public String getBillername() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(billername);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(billername);
    }
    else {
      return billername;
    }
  }

  public void setCurrappstatus(String value) {
    currappstatus = value;
  }

  public void setInstitutionid(String value) {
    institutionid = value;
  }

  public void setMakerlastcmt(String value) {
    makerlastcmt = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setMadeby(String value) {
    madeby = value;
  }

  public void setAdminlastcmt(String value) {
    adminlastcmt = value;
  }

  public void setBilleracno(String value) {
    billeracno = value;
  }

  public void setBillertype(String value) {
    billertype = value;
  }

  public void setMadeat(String value) {
    madeat = value;
  }

  public void setCheckerlastcmt(String value) {
    checkerlastcmt = value;
  }

  public void setRstatus(String value) {
    rstatus = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setCheckedat(String value) {
    checkedat = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setCheckedby(String value) {
    checkedby = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void setBillername(String value) {
    billername = value;
  }

  public void loadContent(KBBillerRecord inputRecord) {
    setCurrappstatus(inputRecord.getCurrappstatus());
    setInstitutionid(inputRecord.getInstitutionid());
    setMakerlastcmt(inputRecord.getMakerlastcmt());
    setModifiedat(inputRecord.getModifiedat());
    setMadeby(inputRecord.getMadeby());
    setAdminlastcmt(inputRecord.getAdminlastcmt());
    setBilleracno(inputRecord.getBilleracno());
    setBillertype(inputRecord.getBillertype());
    setMadeat(inputRecord.getMadeat());
    setCheckerlastcmt(inputRecord.getCheckerlastcmt());
    setRstatus(inputRecord.getRstatus());
    setCreatedat(inputRecord.getCreatedat());
    setCheckedat(inputRecord.getCheckedat());
    setCreatedby(inputRecord.getCreatedby());
    setCheckedby(inputRecord.getCheckedby());
    setModifiedby(inputRecord.getModifiedby());
    setId(inputRecord.getId());
    setBillername(inputRecord.getBillername());
  }

  public void loadNonNullContent(KBBillerRecord inputRecord) {
    if (StringUtils.hasChanged(getCurrappstatus(), inputRecord.getCurrappstatus())) {
      setCurrappstatus(StringUtils.noNull(inputRecord.getCurrappstatus()));
    }
    if (StringUtils.hasChanged(getInstitutionid(), inputRecord.getInstitutionid())) {
      setInstitutionid(StringUtils.noNull(inputRecord.getInstitutionid()));
    }
    if (StringUtils.hasChanged(getMakerlastcmt(), inputRecord.getMakerlastcmt())) {
      setMakerlastcmt(StringUtils.noNull(inputRecord.getMakerlastcmt()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getMadeby(), inputRecord.getMadeby())) {
      setMadeby(StringUtils.noNull(inputRecord.getMadeby()));
    }
    if (StringUtils.hasChanged(getAdminlastcmt(), inputRecord.getAdminlastcmt())) {
      setAdminlastcmt(StringUtils.noNull(inputRecord.getAdminlastcmt()));
    }
    if (StringUtils.hasChanged(getBilleracno(), inputRecord.getBilleracno())) {
      setBilleracno(StringUtils.noNull(inputRecord.getBilleracno()));
    }
    if (StringUtils.hasChanged(getBillertype(), inputRecord.getBillertype())) {
      setBillertype(StringUtils.noNull(inputRecord.getBillertype()));
    }
    if (StringUtils.hasChanged(getMadeat(), inputRecord.getMadeat())) {
      setMadeat(StringUtils.noNull(inputRecord.getMadeat()));
    }
    if (StringUtils.hasChanged(getCheckerlastcmt(), inputRecord.getCheckerlastcmt())) {
      setCheckerlastcmt(StringUtils.noNull(inputRecord.getCheckerlastcmt()));
    }
    if (StringUtils.hasChanged(getRstatus(), inputRecord.getRstatus())) {
      setRstatus(StringUtils.noNull(inputRecord.getRstatus()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getCheckedat(), inputRecord.getCheckedat())) {
      setCheckedat(StringUtils.noNull(inputRecord.getCheckedat()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getCheckedby(), inputRecord.getCheckedby())) {
      setCheckedby(StringUtils.noNull(inputRecord.getCheckedby()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
    if (StringUtils.hasChanged(getBillername(), inputRecord.getBillername())) {
      setBillername(StringUtils.noNull(inputRecord.getBillername()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("currappstatus",StringUtils.noNull(currappstatus));
    obj.put("institutionid",StringUtils.noNull(institutionid));
    obj.put("makerlastcmt",StringUtils.noNull(makerlastcmt));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("madeby",StringUtils.noNull(madeby));
    obj.put("adminlastcmt",StringUtils.noNull(adminlastcmt));
    obj.put("billeracno",StringUtils.noNull(billeracno));
    obj.put("billertype",StringUtils.noNull(billertype));
    obj.put("madeat",StringUtils.noNull(madeat));
    obj.put("checkerlastcmt",StringUtils.noNull(checkerlastcmt));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("checkedat",StringUtils.noNull(checkedat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("checkedby",StringUtils.noNull(checkedby));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("billername",StringUtils.noNull(billername));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    currappstatus = StringUtils.getValueFromJSONObject(obj, "currappstatus");
    institutionid = StringUtils.getValueFromJSONObject(obj, "institutionid");
    makerlastcmt = StringUtils.getValueFromJSONObject(obj, "makerlastcmt");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    madeby = StringUtils.getValueFromJSONObject(obj, "madeby");
    adminlastcmt = StringUtils.getValueFromJSONObject(obj, "adminlastcmt");
    billeracno = StringUtils.getValueFromJSONObject(obj, "billeracno");
    billertype = StringUtils.getValueFromJSONObject(obj, "billertype");
    madeat = StringUtils.getValueFromJSONObject(obj, "madeat");
    checkerlastcmt = StringUtils.getValueFromJSONObject(obj, "checkerlastcmt");
    rstatus = StringUtils.getValueFromJSONObject(obj, "rstatus");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    checkedat = StringUtils.getValueFromJSONObject(obj, "checkedat");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    checkedby = StringUtils.getValueFromJSONObject(obj, "checkedby");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    id = StringUtils.getValueFromJSONObject(obj, "id");
    billername = StringUtils.getValueFromJSONObject(obj, "billername");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("currappstatus",StringUtils.noNull(currappstatus));
    obj.put("institutionid",StringUtils.noNull(institutionid));
    obj.put("makerlastcmt",StringUtils.noNull(makerlastcmt));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("madeby",StringUtils.noNull(madeby));
    obj.put("adminlastcmt",StringUtils.noNull(adminlastcmt));
    obj.put("billeracno",StringUtils.noNull(billeracno));
    obj.put("billertype",StringUtils.noNull(billertype));
    obj.put("madeat",StringUtils.noNull(madeat));
    obj.put("checkerlastcmt",StringUtils.noNull(checkerlastcmt));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("checkedat",StringUtils.noNull(checkedat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("checkedby",StringUtils.noNull(checkedby));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("billername",StringUtils.noNull(billername));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("currappstatus");
    columnList.add("institutionid");
    columnList.add("makerlastcmt");
    columnList.add("modifiedat");
    columnList.add("madeby");
    columnList.add("adminlastcmt");
    columnList.add("billeracno");
    columnList.add("billertype");
    columnList.add("madeat");
    columnList.add("checkerlastcmt");
    columnList.add("rstatus");
    columnList.add("createdat");
    columnList.add("checkedat");
    columnList.add("createdby");
    columnList.add("checkedby");
    columnList.add("modifiedby");
    columnList.add("id");
    columnList.add("billername");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "currappstatus:" + currappstatus +"institutionid:" + institutionid +"makerlastcmt:" + makerlastcmt +"modifiedat:" + modifiedat +"madeby:" + madeby +"adminlastcmt:" + adminlastcmt +"billeracno:" + billeracno +"billertype:" + billertype +"madeat:" + madeat +"checkerlastcmt:" + checkerlastcmt +"rstatus:" + rstatus +"createdat:" + createdat +"checkedat:" + checkedat +"createdby:" + createdby +"checkedby:" + checkedby +"modifiedby:" + modifiedby +"id:" + id +"billername:" + billername +"";
  }
}
