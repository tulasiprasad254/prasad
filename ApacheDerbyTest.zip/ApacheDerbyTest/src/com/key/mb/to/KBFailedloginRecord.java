package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBFailedloginRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBFailedloginRecord.class.getName());

  public String createdat;

  public String createdby;

  public String modifiedat;

  public String modifiedby;

  public String id;

  public String source;

  public String email;

  public String username;

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public String getSource() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(source);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(source);
    }
    else {
      return source;
    }
  }

  public String getEmail() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(email);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(email);
    }
    else {
      return email;
    }
  }

  public String getUsername() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(username);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(username);
    }
    else {
      return username;
    }
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void setSource(String value) {
    source = value;
  }

  public void setEmail(String value) {
    email = value;
  }

  public void setUsername(String value) {
    username = value;
  }

  public void loadContent(KBFailedloginRecord inputRecord) {
    setCreatedat(inputRecord.getCreatedat());
    setCreatedby(inputRecord.getCreatedby());
    setModifiedat(inputRecord.getModifiedat());
    setModifiedby(inputRecord.getModifiedby());
    setId(inputRecord.getId());
    setSource(inputRecord.getSource());
    setEmail(inputRecord.getEmail());
    setUsername(inputRecord.getUsername());
  }

  public void loadNonNullContent(KBFailedloginRecord inputRecord) {
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
    if (StringUtils.hasChanged(getSource(), inputRecord.getSource())) {
      setSource(StringUtils.noNull(inputRecord.getSource()));
    }
    if (StringUtils.hasChanged(getEmail(), inputRecord.getEmail())) {
      setEmail(StringUtils.noNull(inputRecord.getEmail()));
    }
    if (StringUtils.hasChanged(getUsername(), inputRecord.getUsername())) {
      setUsername(StringUtils.noNull(inputRecord.getUsername()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("source",StringUtils.noNull(source));
    obj.put("email",StringUtils.noNull(email));
    obj.put("username",StringUtils.noNull(username));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    id = StringUtils.getValueFromJSONObject(obj, "id");
    source = StringUtils.getValueFromJSONObject(obj, "source");
    email = StringUtils.getValueFromJSONObject(obj, "email");
    username = StringUtils.getValueFromJSONObject(obj, "username");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("source",StringUtils.noNull(source));
    obj.put("email",StringUtils.noNull(email));
    obj.put("username",StringUtils.noNull(username));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("createdat");
    columnList.add("createdby");
    columnList.add("modifiedat");
    columnList.add("modifiedby");
    columnList.add("id");
    columnList.add("source");
    columnList.add("email");
    columnList.add("username");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "createdat:" + createdat +"createdby:" + createdby +"modifiedat:" + modifiedat +"modifiedby:" + modifiedby +"id:" + id +"source:" + source +"email:" + email +"username:" + username +"";
  }
}
