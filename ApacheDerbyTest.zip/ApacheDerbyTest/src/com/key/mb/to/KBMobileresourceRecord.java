package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBMobileresourceRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBMobileresourceRecord.class.getName());

  public String extn3;

  public String extn2;

  public String extn1;

  public String code;

  public String modifiedat;

  public String language;

  public String resourcetype;

  public String contenttype;

  public String restype;

  public String createdat;

  public String createdby;

  public String actionid;

  public String modifiedby;

  public String id;

  public String text;

  public String contentlength;

  public String status;

  public String getExtn3() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(extn3);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(extn3);
    }
    else {
      return extn3;
    }
  }

  public String getExtn2() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(extn2);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(extn2);
    }
    else {
      return extn2;
    }
  }

  public String getExtn1() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(extn1);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(extn1);
    }
    else {
      return extn1;
    }
  }

  public String getCode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(code);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(code);
    }
    else {
      return code;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getLanguage() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(language);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(language);
    }
    else {
      return language;
    }
  }

  public String getResourcetype() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(resourcetype);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(resourcetype);
    }
    else {
      return resourcetype;
    }
  }

  public String getContenttype() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(contenttype);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(contenttype);
    }
    else {
      return contenttype;
    }
  }

  public String getRestype() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(restype);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(restype);
    }
    else {
      return restype;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getActionid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(actionid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(actionid);
    }
    else {
      return actionid;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public String getText() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(text);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(text);
    }
    else {
      return text;
    }
  }

  public String getContentlength() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(contentlength);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(contentlength);
    }
    else {
      return contentlength;
    }
  }

  public String getStatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(status);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(status);
    }
    else {
      return status;
    }
  }

  public void setExtn3(String value) {
    extn3 = value;
  }

  public void setExtn2(String value) {
    extn2 = value;
  }

  public void setExtn1(String value) {
    extn1 = value;
  }

  public void setCode(String value) {
    code = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setLanguage(String value) {
    language = value;
  }

  public void setResourcetype(String value) {
    resourcetype = value;
  }

  public void setContenttype(String value) {
    contenttype = value;
  }

  public void setRestype(String value) {
    restype = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setActionid(String value) {
    actionid = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void setText(String value) {
    text = value;
  }

  public void setContentlength(String value) {
    contentlength = value;
  }

  public void setStatus(String value) {
    status = value;
  }

  public void loadContent(KBMobileresourceRecord inputRecord) {
    setExtn3(inputRecord.getExtn3());
    setExtn2(inputRecord.getExtn2());
    setExtn1(inputRecord.getExtn1());
    setCode(inputRecord.getCode());
    setModifiedat(inputRecord.getModifiedat());
    setLanguage(inputRecord.getLanguage());
    setResourcetype(inputRecord.getResourcetype());
    setContenttype(inputRecord.getContenttype());
    setRestype(inputRecord.getRestype());
    setCreatedat(inputRecord.getCreatedat());
    setCreatedby(inputRecord.getCreatedby());
    setActionid(inputRecord.getActionid());
    setModifiedby(inputRecord.getModifiedby());
    setId(inputRecord.getId());
    setText(inputRecord.getText());
    setContentlength(inputRecord.getContentlength());
    setStatus(inputRecord.getStatus());
  }

  public void loadNonNullContent(KBMobileresourceRecord inputRecord) {
    if (StringUtils.hasChanged(getExtn3(), inputRecord.getExtn3())) {
      setExtn3(StringUtils.noNull(inputRecord.getExtn3()));
    }
    if (StringUtils.hasChanged(getExtn2(), inputRecord.getExtn2())) {
      setExtn2(StringUtils.noNull(inputRecord.getExtn2()));
    }
    if (StringUtils.hasChanged(getExtn1(), inputRecord.getExtn1())) {
      setExtn1(StringUtils.noNull(inputRecord.getExtn1()));
    }
    if (StringUtils.hasChanged(getCode(), inputRecord.getCode())) {
      setCode(StringUtils.noNull(inputRecord.getCode()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getLanguage(), inputRecord.getLanguage())) {
      setLanguage(StringUtils.noNull(inputRecord.getLanguage()));
    }
    if (StringUtils.hasChanged(getResourcetype(), inputRecord.getResourcetype())) {
      setResourcetype(StringUtils.noNull(inputRecord.getResourcetype()));
    }
    if (StringUtils.hasChanged(getContenttype(), inputRecord.getContenttype())) {
      setContenttype(StringUtils.noNull(inputRecord.getContenttype()));
    }
    if (StringUtils.hasChanged(getRestype(), inputRecord.getRestype())) {
      setRestype(StringUtils.noNull(inputRecord.getRestype()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getActionid(), inputRecord.getActionid())) {
      setActionid(StringUtils.noNull(inputRecord.getActionid()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
    if (StringUtils.hasChanged(getText(), inputRecord.getText())) {
      setText(StringUtils.noNull(inputRecord.getText()));
    }
    if (StringUtils.hasChanged(getContentlength(), inputRecord.getContentlength())) {
      setContentlength(StringUtils.noNull(inputRecord.getContentlength()));
    }
    if (StringUtils.hasChanged(getStatus(), inputRecord.getStatus())) {
      setStatus(StringUtils.noNull(inputRecord.getStatus()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("extn3",StringUtils.noNull(extn3));
    obj.put("extn2",StringUtils.noNull(extn2));
    obj.put("extn1",StringUtils.noNull(extn1));
    obj.put("code",StringUtils.noNull(code));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("language",StringUtils.noNull(language));
    obj.put("resourcetype",StringUtils.noNull(resourcetype));
    obj.put("contenttype",StringUtils.noNull(contenttype));
    obj.put("restype",StringUtils.noNull(restype));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("actionid",StringUtils.noNull(actionid));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("text",StringUtils.noNull(text));
    obj.put("contentlength",StringUtils.noNull(contentlength));
    obj.put("status",StringUtils.noNull(status));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    extn3 = StringUtils.getValueFromJSONObject(obj, "extn3");
    extn2 = StringUtils.getValueFromJSONObject(obj, "extn2");
    extn1 = StringUtils.getValueFromJSONObject(obj, "extn1");
    code = StringUtils.getValueFromJSONObject(obj, "code");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    language = StringUtils.getValueFromJSONObject(obj, "language");
    resourcetype = StringUtils.getValueFromJSONObject(obj, "resourcetype");
    contenttype = StringUtils.getValueFromJSONObject(obj, "contenttype");
    restype = StringUtils.getValueFromJSONObject(obj, "restype");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    actionid = StringUtils.getValueFromJSONObject(obj, "actionid");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    id = StringUtils.getValueFromJSONObject(obj, "id");
    text = StringUtils.getValueFromJSONObject(obj, "text");
    contentlength = StringUtils.getValueFromJSONObject(obj, "contentlength");
    status = StringUtils.getValueFromJSONObject(obj, "status");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("extn3",StringUtils.noNull(extn3));
    obj.put("extn2",StringUtils.noNull(extn2));
    obj.put("extn1",StringUtils.noNull(extn1));
    obj.put("code",StringUtils.noNull(code));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("language",StringUtils.noNull(language));
    obj.put("resourcetype",StringUtils.noNull(resourcetype));
    obj.put("contenttype",StringUtils.noNull(contenttype));
    obj.put("restype",StringUtils.noNull(restype));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("actionid",StringUtils.noNull(actionid));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("text",StringUtils.noNull(text));
    obj.put("contentlength",StringUtils.noNull(contentlength));
    obj.put("status",StringUtils.noNull(status));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("extn3");
    columnList.add("extn2");
    columnList.add("extn1");
    columnList.add("code");
    columnList.add("modifiedat");
    columnList.add("language");
    columnList.add("resourcetype");
    columnList.add("contenttype");
    columnList.add("restype");
    columnList.add("createdat");
    columnList.add("createdby");
    columnList.add("actionid");
    columnList.add("modifiedby");
    columnList.add("id");
    columnList.add("text");
    columnList.add("contentlength");
    columnList.add("status");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "extn3:" + extn3 +"extn2:" + extn2 +"extn1:" + extn1 +"code:" + code +"modifiedat:" + modifiedat +"language:" + language +"resourcetype:" + resourcetype +"contenttype:" + contenttype +"restype:" + restype +"createdat:" + createdat +"createdby:" + createdby +"actionid:" + actionid +"modifiedby:" + modifiedby +"id:" + id +"text:" + text +"contentlength:" + contentlength +"status:" + status +"";
  }
}
