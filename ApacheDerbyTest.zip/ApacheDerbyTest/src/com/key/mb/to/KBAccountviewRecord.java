package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBAccountviewRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBAccountviewRecord.class.getName());

  public String currappstatus;

  public String accnum;

  public String institutionid;

  public String makerlastcmt;

  public String modifiedat;

  public String cname;

  public String statusname;

  public String madeby;

  public String adminlastcmt;

  public String madeat;

  public String checkerlastcmt;

  public String iname;

  public String rstatus;

  public String createdat;

  public String checkedat;

  public String createdby;

  public String blockedflag;

  public String checkedby;

  public String custid;

  public String currappstatusname;

  public String alias;

  public String currency;

  public String modifiedby;

  public String id;

  public String getCurrappstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(currappstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(currappstatus);
    }
    else {
      return currappstatus;
    }
  }

  public String getAccnum() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(accnum);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(accnum);
    }
    else {
      return accnum;
    }
  }

  public String getInstitutionid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(institutionid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(institutionid);
    }
    else {
      return institutionid;
    }
  }

  public String getMakerlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(makerlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(makerlastcmt);
    }
    else {
      return makerlastcmt;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getCname() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(cname);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(cname);
    }
    else {
      return cname;
    }
  }

  public String getStatusname() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(statusname);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(statusname);
    }
    else {
      return statusname;
    }
  }

  public String getMadeby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(madeby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(madeby);
    }
    else {
      return madeby;
    }
  }

  public String getAdminlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(adminlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(adminlastcmt);
    }
    else {
      return adminlastcmt;
    }
  }

  public String getMadeat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(madeat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(madeat);
    }
    else {
      return madeat;
    }
  }

  public String getCheckerlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkerlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkerlastcmt);
    }
    else {
      return checkerlastcmt;
    }
  }

  public String getIname() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(iname);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(iname);
    }
    else {
      return iname;
    }
  }

  public String getRstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rstatus);
    }
    else {
      return rstatus;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getCheckedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkedat);
    }
    else {
      return checkedat;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getBlockedflag() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(blockedflag);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(blockedflag);
    }
    else {
      return blockedflag;
    }
  }

  public String getCheckedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkedby);
    }
    else {
      return checkedby;
    }
  }

  public String getCustid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(custid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(custid);
    }
    else {
      return custid;
    }
  }

  public String getCurrappstatusname() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(currappstatusname);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(currappstatusname);
    }
    else {
      return currappstatusname;
    }
  }

  public String getAlias() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(alias);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(alias);
    }
    else {
      return alias;
    }
  }

  public String getCurrency() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(currency);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(currency);
    }
    else {
      return currency;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public void setCurrappstatus(String value) {
    currappstatus = value;
  }

  public void setAccnum(String value) {
    accnum = value;
  }

  public void setInstitutionid(String value) {
    institutionid = value;
  }

  public void setMakerlastcmt(String value) {
    makerlastcmt = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setCname(String value) {
    cname = value;
  }

  public void setStatusname(String value) {
    statusname = value;
  }

  public void setMadeby(String value) {
    madeby = value;
  }

  public void setAdminlastcmt(String value) {
    adminlastcmt = value;
  }

  public void setMadeat(String value) {
    madeat = value;
  }

  public void setCheckerlastcmt(String value) {
    checkerlastcmt = value;
  }

  public void setIname(String value) {
    iname = value;
  }

  public void setRstatus(String value) {
    rstatus = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setCheckedat(String value) {
    checkedat = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setBlockedflag(String value) {
    blockedflag = value;
  }

  public void setCheckedby(String value) {
    checkedby = value;
  }

  public void setCustid(String value) {
    custid = value;
  }

  public void setCurrappstatusname(String value) {
    currappstatusname = value;
  }

  public void setAlias(String value) {
    alias = value;
  }

  public void setCurrency(String value) {
    currency = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void loadContent(KBAccountviewRecord inputRecord) {
    setCurrappstatus(inputRecord.getCurrappstatus());
    setAccnum(inputRecord.getAccnum());
    setInstitutionid(inputRecord.getInstitutionid());
    setMakerlastcmt(inputRecord.getMakerlastcmt());
    setModifiedat(inputRecord.getModifiedat());
    setCname(inputRecord.getCname());
    setStatusname(inputRecord.getStatusname());
    setMadeby(inputRecord.getMadeby());
    setAdminlastcmt(inputRecord.getAdminlastcmt());
    setMadeat(inputRecord.getMadeat());
    setCheckerlastcmt(inputRecord.getCheckerlastcmt());
    setIname(inputRecord.getIname());
    setRstatus(inputRecord.getRstatus());
    setCreatedat(inputRecord.getCreatedat());
    setCheckedat(inputRecord.getCheckedat());
    setCreatedby(inputRecord.getCreatedby());
    setBlockedflag(inputRecord.getBlockedflag());
    setCheckedby(inputRecord.getCheckedby());
    setCustid(inputRecord.getCustid());
    setCurrappstatusname(inputRecord.getCurrappstatusname());
    setAlias(inputRecord.getAlias());
    setCurrency(inputRecord.getCurrency());
    setModifiedby(inputRecord.getModifiedby());
    setId(inputRecord.getId());
  }

  public void loadNonNullContent(KBAccountviewRecord inputRecord) {
    if (StringUtils.hasChanged(getCurrappstatus(), inputRecord.getCurrappstatus())) {
      setCurrappstatus(StringUtils.noNull(inputRecord.getCurrappstatus()));
    }
    if (StringUtils.hasChanged(getAccnum(), inputRecord.getAccnum())) {
      setAccnum(StringUtils.noNull(inputRecord.getAccnum()));
    }
    if (StringUtils.hasChanged(getInstitutionid(), inputRecord.getInstitutionid())) {
      setInstitutionid(StringUtils.noNull(inputRecord.getInstitutionid()));
    }
    if (StringUtils.hasChanged(getMakerlastcmt(), inputRecord.getMakerlastcmt())) {
      setMakerlastcmt(StringUtils.noNull(inputRecord.getMakerlastcmt()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getCname(), inputRecord.getCname())) {
      setCname(StringUtils.noNull(inputRecord.getCname()));
    }
    if (StringUtils.hasChanged(getStatusname(), inputRecord.getStatusname())) {
      setStatusname(StringUtils.noNull(inputRecord.getStatusname()));
    }
    if (StringUtils.hasChanged(getMadeby(), inputRecord.getMadeby())) {
      setMadeby(StringUtils.noNull(inputRecord.getMadeby()));
    }
    if (StringUtils.hasChanged(getAdminlastcmt(), inputRecord.getAdminlastcmt())) {
      setAdminlastcmt(StringUtils.noNull(inputRecord.getAdminlastcmt()));
    }
    if (StringUtils.hasChanged(getMadeat(), inputRecord.getMadeat())) {
      setMadeat(StringUtils.noNull(inputRecord.getMadeat()));
    }
    if (StringUtils.hasChanged(getCheckerlastcmt(), inputRecord.getCheckerlastcmt())) {
      setCheckerlastcmt(StringUtils.noNull(inputRecord.getCheckerlastcmt()));
    }
    if (StringUtils.hasChanged(getIname(), inputRecord.getIname())) {
      setIname(StringUtils.noNull(inputRecord.getIname()));
    }
    if (StringUtils.hasChanged(getRstatus(), inputRecord.getRstatus())) {
      setRstatus(StringUtils.noNull(inputRecord.getRstatus()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getCheckedat(), inputRecord.getCheckedat())) {
      setCheckedat(StringUtils.noNull(inputRecord.getCheckedat()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getBlockedflag(), inputRecord.getBlockedflag())) {
      setBlockedflag(StringUtils.noNull(inputRecord.getBlockedflag()));
    }
    if (StringUtils.hasChanged(getCheckedby(), inputRecord.getCheckedby())) {
      setCheckedby(StringUtils.noNull(inputRecord.getCheckedby()));
    }
    if (StringUtils.hasChanged(getCustid(), inputRecord.getCustid())) {
      setCustid(StringUtils.noNull(inputRecord.getCustid()));
    }
    if (StringUtils.hasChanged(getCurrappstatusname(), inputRecord.getCurrappstatusname())) {
      setCurrappstatusname(StringUtils.noNull(inputRecord.getCurrappstatusname()));
    }
    if (StringUtils.hasChanged(getAlias(), inputRecord.getAlias())) {
      setAlias(StringUtils.noNull(inputRecord.getAlias()));
    }
    if (StringUtils.hasChanged(getCurrency(), inputRecord.getCurrency())) {
      setCurrency(StringUtils.noNull(inputRecord.getCurrency()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("currappstatus",StringUtils.noNull(currappstatus));
    obj.put("accnum",StringUtils.noNull(accnum));
    obj.put("institutionid",StringUtils.noNull(institutionid));
    obj.put("makerlastcmt",StringUtils.noNull(makerlastcmt));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("cname",StringUtils.noNull(cname));
    obj.put("statusname",StringUtils.noNull(statusname));
    obj.put("madeby",StringUtils.noNull(madeby));
    obj.put("adminlastcmt",StringUtils.noNull(adminlastcmt));
    obj.put("madeat",StringUtils.noNull(madeat));
    obj.put("checkerlastcmt",StringUtils.noNull(checkerlastcmt));
    obj.put("iname",StringUtils.noNull(iname));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("checkedat",StringUtils.noNull(checkedat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("blockedflag",StringUtils.noNull(blockedflag));
    obj.put("checkedby",StringUtils.noNull(checkedby));
    obj.put("custid",StringUtils.noNull(custid));
    obj.put("currappstatusname",StringUtils.noNull(currappstatusname));
    obj.put("alias",StringUtils.noNull(alias));
    obj.put("currency",StringUtils.noNull(currency));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    currappstatus = StringUtils.getValueFromJSONObject(obj, "currappstatus");
    accnum = StringUtils.getValueFromJSONObject(obj, "accnum");
    institutionid = StringUtils.getValueFromJSONObject(obj, "institutionid");
    makerlastcmt = StringUtils.getValueFromJSONObject(obj, "makerlastcmt");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    cname = StringUtils.getValueFromJSONObject(obj, "cname");
    statusname = StringUtils.getValueFromJSONObject(obj, "statusname");
    madeby = StringUtils.getValueFromJSONObject(obj, "madeby");
    adminlastcmt = StringUtils.getValueFromJSONObject(obj, "adminlastcmt");
    madeat = StringUtils.getValueFromJSONObject(obj, "madeat");
    checkerlastcmt = StringUtils.getValueFromJSONObject(obj, "checkerlastcmt");
    iname = StringUtils.getValueFromJSONObject(obj, "iname");
    rstatus = StringUtils.getValueFromJSONObject(obj, "rstatus");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    checkedat = StringUtils.getValueFromJSONObject(obj, "checkedat");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    blockedflag = StringUtils.getValueFromJSONObject(obj, "blockedflag");
    checkedby = StringUtils.getValueFromJSONObject(obj, "checkedby");
    custid = StringUtils.getValueFromJSONObject(obj, "custid");
    currappstatusname = StringUtils.getValueFromJSONObject(obj, "currappstatusname");
    alias = StringUtils.getValueFromJSONObject(obj, "alias");
    currency = StringUtils.getValueFromJSONObject(obj, "currency");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    id = StringUtils.getValueFromJSONObject(obj, "id");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("currappstatus",StringUtils.noNull(currappstatus));
    obj.put("accnum",StringUtils.noNull(accnum));
    obj.put("institutionid",StringUtils.noNull(institutionid));
    obj.put("makerlastcmt",StringUtils.noNull(makerlastcmt));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("cname",StringUtils.noNull(cname));
    obj.put("statusname",StringUtils.noNull(statusname));
    obj.put("madeby",StringUtils.noNull(madeby));
    obj.put("adminlastcmt",StringUtils.noNull(adminlastcmt));
    obj.put("madeat",StringUtils.noNull(madeat));
    obj.put("checkerlastcmt",StringUtils.noNull(checkerlastcmt));
    obj.put("iname",StringUtils.noNull(iname));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("checkedat",StringUtils.noNull(checkedat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("blockedflag",StringUtils.noNull(blockedflag));
    obj.put("checkedby",StringUtils.noNull(checkedby));
    obj.put("custid",StringUtils.noNull(custid));
    obj.put("currappstatusname",StringUtils.noNull(currappstatusname));
    obj.put("alias",StringUtils.noNull(alias));
    obj.put("currency",StringUtils.noNull(currency));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("currappstatus");
    columnList.add("accnum");
    columnList.add("institutionid");
    columnList.add("makerlastcmt");
    columnList.add("modifiedat");
    columnList.add("cname");
    columnList.add("statusname");
    columnList.add("madeby");
    columnList.add("adminlastcmt");
    columnList.add("madeat");
    columnList.add("checkerlastcmt");
    columnList.add("iname");
    columnList.add("rstatus");
    columnList.add("createdat");
    columnList.add("checkedat");
    columnList.add("createdby");
    columnList.add("blockedflag");
    columnList.add("checkedby");
    columnList.add("custid");
    columnList.add("currappstatusname");
    columnList.add("alias");
    columnList.add("currency");
    columnList.add("modifiedby");
    columnList.add("id");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "currappstatus:" + currappstatus +"accnum:" + accnum +"institutionid:" + institutionid +"makerlastcmt:" + makerlastcmt +"modifiedat:" + modifiedat +"cname:" + cname +"statusname:" + statusname +"madeby:" + madeby +"adminlastcmt:" + adminlastcmt +"madeat:" + madeat +"checkerlastcmt:" + checkerlastcmt +"iname:" + iname +"rstatus:" + rstatus +"createdat:" + createdat +"checkedat:" + checkedat +"createdby:" + createdby +"blockedflag:" + blockedflag +"checkedby:" + checkedby +"custid:" + custid +"currappstatusname:" + currappstatusname +"alias:" + alias +"currency:" + currency +"modifiedby:" + modifiedby +"id:" + id +"";
  }
}
