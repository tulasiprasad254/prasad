package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBMobilejsonrequestRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBMobilejsonrequestRecord.class.getName());

  public String rstatus;

  public String langcode;

  public String createdat;

  public String createdby;

  public String modifiedat;

  public String actionid;

  public String rdata;

  public String modifiedby;

  public String id;

  public String sessionid;

  public String getRstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rstatus);
    }
    else {
      return rstatus;
    }
  }

  public String getLangcode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(langcode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(langcode);
    }
    else {
      return langcode;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getActionid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(actionid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(actionid);
    }
    else {
      return actionid;
    }
  }

  public String getRdata() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rdata);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rdata);
    }
    else {
      return rdata;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public String getSessionid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(sessionid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(sessionid);
    }
    else {
      return sessionid;
    }
  }

  public void setRstatus(String value) {
    rstatus = value;
  }

  public void setLangcode(String value) {
    langcode = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setActionid(String value) {
    actionid = value;
  }

  public void setRdata(String value) {
    rdata = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void setSessionid(String value) {
    sessionid = value;
  }

  public void loadContent(KBMobilejsonrequestRecord inputRecord) {
    setRstatus(inputRecord.getRstatus());
    setLangcode(inputRecord.getLangcode());
    setCreatedat(inputRecord.getCreatedat());
    setCreatedby(inputRecord.getCreatedby());
    setModifiedat(inputRecord.getModifiedat());
    setActionid(inputRecord.getActionid());
    setRdata(inputRecord.getRdata());
    setModifiedby(inputRecord.getModifiedby());
    setId(inputRecord.getId());
    setSessionid(inputRecord.getSessionid());
  }

  public void loadNonNullContent(KBMobilejsonrequestRecord inputRecord) {
    if (StringUtils.hasChanged(getRstatus(), inputRecord.getRstatus())) {
      setRstatus(StringUtils.noNull(inputRecord.getRstatus()));
    }
    if (StringUtils.hasChanged(getLangcode(), inputRecord.getLangcode())) {
      setLangcode(StringUtils.noNull(inputRecord.getLangcode()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getActionid(), inputRecord.getActionid())) {
      setActionid(StringUtils.noNull(inputRecord.getActionid()));
    }
    if (StringUtils.hasChanged(getRdata(), inputRecord.getRdata())) {
      setRdata(StringUtils.noNull(inputRecord.getRdata()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
    if (StringUtils.hasChanged(getSessionid(), inputRecord.getSessionid())) {
      setSessionid(StringUtils.noNull(inputRecord.getSessionid()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("langcode",StringUtils.noNull(langcode));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("actionid",StringUtils.noNull(actionid));
    obj.put("rdata",StringUtils.noNull(rdata));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("sessionid",StringUtils.noNull(sessionid));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    rstatus = StringUtils.getValueFromJSONObject(obj, "rstatus");
    langcode = StringUtils.getValueFromJSONObject(obj, "langcode");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    actionid = StringUtils.getValueFromJSONObject(obj, "actionid");
    rdata = StringUtils.getValueFromJSONObject(obj, "rdata");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    id = StringUtils.getValueFromJSONObject(obj, "id");
    sessionid = StringUtils.getValueFromJSONObject(obj, "sessionid");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("langcode",StringUtils.noNull(langcode));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("actionid",StringUtils.noNull(actionid));
    obj.put("rdata",StringUtils.noNull(rdata));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("sessionid",StringUtils.noNull(sessionid));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("rstatus");
    columnList.add("langcode");
    columnList.add("createdat");
    columnList.add("createdby");
    columnList.add("modifiedat");
    columnList.add("actionid");
    columnList.add("rdata");
    columnList.add("modifiedby");
    columnList.add("id");
    columnList.add("sessionid");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "rstatus:" + rstatus +"langcode:" + langcode +"createdat:" + createdat +"createdby:" + createdby +"modifiedat:" + modifiedat +"actionid:" + actionid +"rdata:" + rdata +"modifiedby:" + modifiedby +"id:" + id +"sessionid:" + sessionid +"";
  }
}
