package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBMessagetemplateRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBMessagetemplateRecord.class.getName());

  public String template;

  public String rstatus;

  public String createdat;

  public String createdby;

  public String templatesubj;

  public String modifiedat;

  public String modifiedby;

  public String id;

  public String templatecode;

  public String getTemplate() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(template);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(template);
    }
    else {
      return template;
    }
  }

  public String getRstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rstatus);
    }
    else {
      return rstatus;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getTemplatesubj() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(templatesubj);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(templatesubj);
    }
    else {
      return templatesubj;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public String getTemplatecode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(templatecode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(templatecode);
    }
    else {
      return templatecode;
    }
  }

  public void setTemplate(String value) {
    template = value;
  }

  public void setRstatus(String value) {
    rstatus = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setTemplatesubj(String value) {
    templatesubj = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void setTemplatecode(String value) {
    templatecode = value;
  }

  public void loadContent(KBMessagetemplateRecord inputRecord) {
    setTemplate(inputRecord.getTemplate());
    setRstatus(inputRecord.getRstatus());
    setCreatedat(inputRecord.getCreatedat());
    setCreatedby(inputRecord.getCreatedby());
    setTemplatesubj(inputRecord.getTemplatesubj());
    setModifiedat(inputRecord.getModifiedat());
    setModifiedby(inputRecord.getModifiedby());
    setId(inputRecord.getId());
    setTemplatecode(inputRecord.getTemplatecode());
  }

  public void loadNonNullContent(KBMessagetemplateRecord inputRecord) {
    if (StringUtils.hasChanged(getTemplate(), inputRecord.getTemplate())) {
      setTemplate(StringUtils.noNull(inputRecord.getTemplate()));
    }
    if (StringUtils.hasChanged(getRstatus(), inputRecord.getRstatus())) {
      setRstatus(StringUtils.noNull(inputRecord.getRstatus()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getTemplatesubj(), inputRecord.getTemplatesubj())) {
      setTemplatesubj(StringUtils.noNull(inputRecord.getTemplatesubj()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
    if (StringUtils.hasChanged(getTemplatecode(), inputRecord.getTemplatecode())) {
      setTemplatecode(StringUtils.noNull(inputRecord.getTemplatecode()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("template",StringUtils.noNull(template));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("templatesubj",StringUtils.noNull(templatesubj));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("templatecode",StringUtils.noNull(templatecode));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    template = StringUtils.getValueFromJSONObject(obj, "template");
    rstatus = StringUtils.getValueFromJSONObject(obj, "rstatus");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    templatesubj = StringUtils.getValueFromJSONObject(obj, "templatesubj");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    id = StringUtils.getValueFromJSONObject(obj, "id");
    templatecode = StringUtils.getValueFromJSONObject(obj, "templatecode");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("template",StringUtils.noNull(template));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("templatesubj",StringUtils.noNull(templatesubj));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("templatecode",StringUtils.noNull(templatecode));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("template");
    columnList.add("rstatus");
    columnList.add("createdat");
    columnList.add("createdby");
    columnList.add("templatesubj");
    columnList.add("modifiedat");
    columnList.add("modifiedby");
    columnList.add("id");
    columnList.add("templatecode");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "template:" + template +"rstatus:" + rstatus +"createdat:" + createdat +"createdby:" + createdby +"templatesubj:" + templatesubj +"modifiedat:" + modifiedat +"modifiedby:" + modifiedby +"id:" + id +"templatecode:" + templatecode +"";
  }
}
