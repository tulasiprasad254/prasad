package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBMobilemenumapRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBMobilemenumapRecord.class.getName());

  public String ftext;

  public String overridecode;

  public String ffldtype;

  public String menutype;

  public String fseq;

  public String lang2msg;

  public String fsesscont;

  public String ffldcode;

  public String parentid;

  public String lang4msg;

  public String langcode;

  public String createdby;

  public String actionid;

  public String ussd;

  public String id;

  public String newsess;

  public String extn4;

  public String extn3;

  public String extn2;

  public String extn1;

  public String accesscode;

  public String modifiedat;

  public String wap;

  public String fconttype;

  public String lang3msg;

  public String fwidth;

  public String activeflag;

  public String screenid;

  public String rstatus;

  public String createdat;

  public String ffldlen;

  public String fheight;

  public String modifiedby;

  public String serviceid;

  public String contentlength;

  public String getFtext() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(ftext);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(ftext);
    }
    else {
      return ftext;
    }
  }

  public String getOverridecode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(overridecode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(overridecode);
    }
    else {
      return overridecode;
    }
  }

  public String getFfldtype() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(ffldtype);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(ffldtype);
    }
    else {
      return ffldtype;
    }
  }

  public String getMenutype() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(menutype);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(menutype);
    }
    else {
      return menutype;
    }
  }

  public String getFseq() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(fseq);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(fseq);
    }
    else {
      return fseq;
    }
  }

  public String getLang2msg() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(lang2msg);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(lang2msg);
    }
    else {
      return lang2msg;
    }
  }

  public String getFsesscont() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(fsesscont);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(fsesscont);
    }
    else {
      return fsesscont;
    }
  }

  public String getFfldcode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(ffldcode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(ffldcode);
    }
    else {
      return ffldcode;
    }
  }

  public String getParentid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(parentid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(parentid);
    }
    else {
      return parentid;
    }
  }

  public String getLang4msg() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(lang4msg);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(lang4msg);
    }
    else {
      return lang4msg;
    }
  }

  public String getLangcode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(langcode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(langcode);
    }
    else {
      return langcode;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getActionid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(actionid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(actionid);
    }
    else {
      return actionid;
    }
  }

  public String getUssd() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(ussd);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(ussd);
    }
    else {
      return ussd;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public String getNewsess() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(newsess);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(newsess);
    }
    else {
      return newsess;
    }
  }

  public String getExtn4() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(extn4);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(extn4);
    }
    else {
      return extn4;
    }
  }

  public String getExtn3() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(extn3);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(extn3);
    }
    else {
      return extn3;
    }
  }

  public String getExtn2() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(extn2);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(extn2);
    }
    else {
      return extn2;
    }
  }

  public String getExtn1() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(extn1);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(extn1);
    }
    else {
      return extn1;
    }
  }

  public String getAccesscode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(accesscode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(accesscode);
    }
    else {
      return accesscode;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getWap() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(wap);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(wap);
    }
    else {
      return wap;
    }
  }

  public String getFconttype() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(fconttype);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(fconttype);
    }
    else {
      return fconttype;
    }
  }

  public String getLang3msg() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(lang3msg);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(lang3msg);
    }
    else {
      return lang3msg;
    }
  }

  public String getFwidth() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(fwidth);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(fwidth);
    }
    else {
      return fwidth;
    }
  }

  public String getActiveflag() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(activeflag);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(activeflag);
    }
    else {
      return activeflag;
    }
  }

  public String getScreenid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(screenid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(screenid);
    }
    else {
      return screenid;
    }
  }

  public String getRstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rstatus);
    }
    else {
      return rstatus;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getFfldlen() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(ffldlen);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(ffldlen);
    }
    else {
      return ffldlen;
    }
  }

  public String getFheight() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(fheight);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(fheight);
    }
    else {
      return fheight;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getServiceid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(serviceid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(serviceid);
    }
    else {
      return serviceid;
    }
  }

  public String getContentlength() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(contentlength);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(contentlength);
    }
    else {
      return contentlength;
    }
  }

  public void setFtext(String value) {
    ftext = value;
  }

  public void setOverridecode(String value) {
    overridecode = value;
  }

  public void setFfldtype(String value) {
    ffldtype = value;
  }

  public void setMenutype(String value) {
    menutype = value;
  }

  public void setFseq(String value) {
    fseq = value;
  }

  public void setLang2msg(String value) {
    lang2msg = value;
  }

  public void setFsesscont(String value) {
    fsesscont = value;
  }

  public void setFfldcode(String value) {
    ffldcode = value;
  }

  public void setParentid(String value) {
    parentid = value;
  }

  public void setLang4msg(String value) {
    lang4msg = value;
  }

  public void setLangcode(String value) {
    langcode = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setActionid(String value) {
    actionid = value;
  }

  public void setUssd(String value) {
    ussd = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void setNewsess(String value) {
    newsess = value;
  }

  public void setExtn4(String value) {
    extn4 = value;
  }

  public void setExtn3(String value) {
    extn3 = value;
  }

  public void setExtn2(String value) {
    extn2 = value;
  }

  public void setExtn1(String value) {
    extn1 = value;
  }

  public void setAccesscode(String value) {
    accesscode = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setWap(String value) {
    wap = value;
  }

  public void setFconttype(String value) {
    fconttype = value;
  }

  public void setLang3msg(String value) {
    lang3msg = value;
  }

  public void setFwidth(String value) {
    fwidth = value;
  }

  public void setActiveflag(String value) {
    activeflag = value;
  }

  public void setScreenid(String value) {
    screenid = value;
  }

  public void setRstatus(String value) {
    rstatus = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setFfldlen(String value) {
    ffldlen = value;
  }

  public void setFheight(String value) {
    fheight = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setServiceid(String value) {
    serviceid = value;
  }

  public void setContentlength(String value) {
    contentlength = value;
  }

  public void loadContent(KBMobilemenumapRecord inputRecord) {
    setFtext(inputRecord.getFtext());
    setOverridecode(inputRecord.getOverridecode());
    setFfldtype(inputRecord.getFfldtype());
    setMenutype(inputRecord.getMenutype());
    setFseq(inputRecord.getFseq());
    setLang2msg(inputRecord.getLang2msg());
    setFsesscont(inputRecord.getFsesscont());
    setFfldcode(inputRecord.getFfldcode());
    setParentid(inputRecord.getParentid());
    setLang4msg(inputRecord.getLang4msg());
    setLangcode(inputRecord.getLangcode());
    setCreatedby(inputRecord.getCreatedby());
    setActionid(inputRecord.getActionid());
    setUssd(inputRecord.getUssd());
    setId(inputRecord.getId());
    setNewsess(inputRecord.getNewsess());
    setExtn4(inputRecord.getExtn4());
    setExtn3(inputRecord.getExtn3());
    setExtn2(inputRecord.getExtn2());
    setExtn1(inputRecord.getExtn1());
    setAccesscode(inputRecord.getAccesscode());
    setModifiedat(inputRecord.getModifiedat());
    setWap(inputRecord.getWap());
    setFconttype(inputRecord.getFconttype());
    setLang3msg(inputRecord.getLang3msg());
    setFwidth(inputRecord.getFwidth());
    setActiveflag(inputRecord.getActiveflag());
    setScreenid(inputRecord.getScreenid());
    setRstatus(inputRecord.getRstatus());
    setCreatedat(inputRecord.getCreatedat());
    setFfldlen(inputRecord.getFfldlen());
    setFheight(inputRecord.getFheight());
    setModifiedby(inputRecord.getModifiedby());
    setServiceid(inputRecord.getServiceid());
    setContentlength(inputRecord.getContentlength());
  }

  public void loadNonNullContent(KBMobilemenumapRecord inputRecord) {
    if (StringUtils.hasChanged(getFtext(), inputRecord.getFtext())) {
      setFtext(StringUtils.noNull(inputRecord.getFtext()));
    }
    if (StringUtils.hasChanged(getOverridecode(), inputRecord.getOverridecode())) {
      setOverridecode(StringUtils.noNull(inputRecord.getOverridecode()));
    }
    if (StringUtils.hasChanged(getFfldtype(), inputRecord.getFfldtype())) {
      setFfldtype(StringUtils.noNull(inputRecord.getFfldtype()));
    }
    if (StringUtils.hasChanged(getMenutype(), inputRecord.getMenutype())) {
      setMenutype(StringUtils.noNull(inputRecord.getMenutype()));
    }
    if (StringUtils.hasChanged(getFseq(), inputRecord.getFseq())) {
      setFseq(StringUtils.noNull(inputRecord.getFseq()));
    }
    if (StringUtils.hasChanged(getLang2msg(), inputRecord.getLang2msg())) {
      setLang2msg(StringUtils.noNull(inputRecord.getLang2msg()));
    }
    if (StringUtils.hasChanged(getFsesscont(), inputRecord.getFsesscont())) {
      setFsesscont(StringUtils.noNull(inputRecord.getFsesscont()));
    }
    if (StringUtils.hasChanged(getFfldcode(), inputRecord.getFfldcode())) {
      setFfldcode(StringUtils.noNull(inputRecord.getFfldcode()));
    }
    if (StringUtils.hasChanged(getParentid(), inputRecord.getParentid())) {
      setParentid(StringUtils.noNull(inputRecord.getParentid()));
    }
    if (StringUtils.hasChanged(getLang4msg(), inputRecord.getLang4msg())) {
      setLang4msg(StringUtils.noNull(inputRecord.getLang4msg()));
    }
    if (StringUtils.hasChanged(getLangcode(), inputRecord.getLangcode())) {
      setLangcode(StringUtils.noNull(inputRecord.getLangcode()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getActionid(), inputRecord.getActionid())) {
      setActionid(StringUtils.noNull(inputRecord.getActionid()));
    }
    if (StringUtils.hasChanged(getUssd(), inputRecord.getUssd())) {
      setUssd(StringUtils.noNull(inputRecord.getUssd()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
    if (StringUtils.hasChanged(getNewsess(), inputRecord.getNewsess())) {
      setNewsess(StringUtils.noNull(inputRecord.getNewsess()));
    }
    if (StringUtils.hasChanged(getExtn4(), inputRecord.getExtn4())) {
      setExtn4(StringUtils.noNull(inputRecord.getExtn4()));
    }
    if (StringUtils.hasChanged(getExtn3(), inputRecord.getExtn3())) {
      setExtn3(StringUtils.noNull(inputRecord.getExtn3()));
    }
    if (StringUtils.hasChanged(getExtn2(), inputRecord.getExtn2())) {
      setExtn2(StringUtils.noNull(inputRecord.getExtn2()));
    }
    if (StringUtils.hasChanged(getExtn1(), inputRecord.getExtn1())) {
      setExtn1(StringUtils.noNull(inputRecord.getExtn1()));
    }
    if (StringUtils.hasChanged(getAccesscode(), inputRecord.getAccesscode())) {
      setAccesscode(StringUtils.noNull(inputRecord.getAccesscode()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getWap(), inputRecord.getWap())) {
      setWap(StringUtils.noNull(inputRecord.getWap()));
    }
    if (StringUtils.hasChanged(getFconttype(), inputRecord.getFconttype())) {
      setFconttype(StringUtils.noNull(inputRecord.getFconttype()));
    }
    if (StringUtils.hasChanged(getLang3msg(), inputRecord.getLang3msg())) {
      setLang3msg(StringUtils.noNull(inputRecord.getLang3msg()));
    }
    if (StringUtils.hasChanged(getFwidth(), inputRecord.getFwidth())) {
      setFwidth(StringUtils.noNull(inputRecord.getFwidth()));
    }
    if (StringUtils.hasChanged(getActiveflag(), inputRecord.getActiveflag())) {
      setActiveflag(StringUtils.noNull(inputRecord.getActiveflag()));
    }
    if (StringUtils.hasChanged(getScreenid(), inputRecord.getScreenid())) {
      setScreenid(StringUtils.noNull(inputRecord.getScreenid()));
    }
    if (StringUtils.hasChanged(getRstatus(), inputRecord.getRstatus())) {
      setRstatus(StringUtils.noNull(inputRecord.getRstatus()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getFfldlen(), inputRecord.getFfldlen())) {
      setFfldlen(StringUtils.noNull(inputRecord.getFfldlen()));
    }
    if (StringUtils.hasChanged(getFheight(), inputRecord.getFheight())) {
      setFheight(StringUtils.noNull(inputRecord.getFheight()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getServiceid(), inputRecord.getServiceid())) {
      setServiceid(StringUtils.noNull(inputRecord.getServiceid()));
    }
    if (StringUtils.hasChanged(getContentlength(), inputRecord.getContentlength())) {
      setContentlength(StringUtils.noNull(inputRecord.getContentlength()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("ftext",StringUtils.noNull(ftext));
    obj.put("overridecode",StringUtils.noNull(overridecode));
    obj.put("ffldtype",StringUtils.noNull(ffldtype));
    obj.put("menutype",StringUtils.noNull(menutype));
    obj.put("fseq",StringUtils.noNull(fseq));
    obj.put("lang2msg",StringUtils.noNull(lang2msg));
    obj.put("fsesscont",StringUtils.noNull(fsesscont));
    obj.put("ffldcode",StringUtils.noNull(ffldcode));
    obj.put("parentid",StringUtils.noNull(parentid));
    obj.put("lang4msg",StringUtils.noNull(lang4msg));
    obj.put("langcode",StringUtils.noNull(langcode));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("actionid",StringUtils.noNull(actionid));
    obj.put("ussd",StringUtils.noNull(ussd));
    obj.put("id",StringUtils.noNull(id));
    obj.put("newsess",StringUtils.noNull(newsess));
    obj.put("extn4",StringUtils.noNull(extn4));
    obj.put("extn3",StringUtils.noNull(extn3));
    obj.put("extn2",StringUtils.noNull(extn2));
    obj.put("extn1",StringUtils.noNull(extn1));
    obj.put("accesscode",StringUtils.noNull(accesscode));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("wap",StringUtils.noNull(wap));
    obj.put("fconttype",StringUtils.noNull(fconttype));
    obj.put("lang3msg",StringUtils.noNull(lang3msg));
    obj.put("fwidth",StringUtils.noNull(fwidth));
    obj.put("activeflag",StringUtils.noNull(activeflag));
    obj.put("screenid",StringUtils.noNull(screenid));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("ffldlen",StringUtils.noNull(ffldlen));
    obj.put("fheight",StringUtils.noNull(fheight));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("serviceid",StringUtils.noNull(serviceid));
    obj.put("contentlength",StringUtils.noNull(contentlength));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    ftext = StringUtils.getValueFromJSONObject(obj, "ftext");
    overridecode = StringUtils.getValueFromJSONObject(obj, "overridecode");
    ffldtype = StringUtils.getValueFromJSONObject(obj, "ffldtype");
    menutype = StringUtils.getValueFromJSONObject(obj, "menutype");
    fseq = StringUtils.getValueFromJSONObject(obj, "fseq");
    lang2msg = StringUtils.getValueFromJSONObject(obj, "lang2msg");
    fsesscont = StringUtils.getValueFromJSONObject(obj, "fsesscont");
    ffldcode = StringUtils.getValueFromJSONObject(obj, "ffldcode");
    parentid = StringUtils.getValueFromJSONObject(obj, "parentid");
    lang4msg = StringUtils.getValueFromJSONObject(obj, "lang4msg");
    langcode = StringUtils.getValueFromJSONObject(obj, "langcode");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    actionid = StringUtils.getValueFromJSONObject(obj, "actionid");
    ussd = StringUtils.getValueFromJSONObject(obj, "ussd");
    id = StringUtils.getValueFromJSONObject(obj, "id");
    newsess = StringUtils.getValueFromJSONObject(obj, "newsess");
    extn4 = StringUtils.getValueFromJSONObject(obj, "extn4");
    extn3 = StringUtils.getValueFromJSONObject(obj, "extn3");
    extn2 = StringUtils.getValueFromJSONObject(obj, "extn2");
    extn1 = StringUtils.getValueFromJSONObject(obj, "extn1");
    accesscode = StringUtils.getValueFromJSONObject(obj, "accesscode");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    wap = StringUtils.getValueFromJSONObject(obj, "wap");
    fconttype = StringUtils.getValueFromJSONObject(obj, "fconttype");
    lang3msg = StringUtils.getValueFromJSONObject(obj, "lang3msg");
    fwidth = StringUtils.getValueFromJSONObject(obj, "fwidth");
    activeflag = StringUtils.getValueFromJSONObject(obj, "activeflag");
    screenid = StringUtils.getValueFromJSONObject(obj, "screenid");
    rstatus = StringUtils.getValueFromJSONObject(obj, "rstatus");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    ffldlen = StringUtils.getValueFromJSONObject(obj, "ffldlen");
    fheight = StringUtils.getValueFromJSONObject(obj, "fheight");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    serviceid = StringUtils.getValueFromJSONObject(obj, "serviceid");
    contentlength = StringUtils.getValueFromJSONObject(obj, "contentlength");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("ftext",StringUtils.noNull(ftext));
    obj.put("overridecode",StringUtils.noNull(overridecode));
    obj.put("ffldtype",StringUtils.noNull(ffldtype));
    obj.put("menutype",StringUtils.noNull(menutype));
    obj.put("fseq",StringUtils.noNull(fseq));
    obj.put("lang2msg",StringUtils.noNull(lang2msg));
    obj.put("fsesscont",StringUtils.noNull(fsesscont));
    obj.put("ffldcode",StringUtils.noNull(ffldcode));
    obj.put("parentid",StringUtils.noNull(parentid));
    obj.put("lang4msg",StringUtils.noNull(lang4msg));
    obj.put("langcode",StringUtils.noNull(langcode));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("actionid",StringUtils.noNull(actionid));
    obj.put("ussd",StringUtils.noNull(ussd));
    obj.put("id",StringUtils.noNull(id));
    obj.put("newsess",StringUtils.noNull(newsess));
    obj.put("extn4",StringUtils.noNull(extn4));
    obj.put("extn3",StringUtils.noNull(extn3));
    obj.put("extn2",StringUtils.noNull(extn2));
    obj.put("extn1",StringUtils.noNull(extn1));
    obj.put("accesscode",StringUtils.noNull(accesscode));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("wap",StringUtils.noNull(wap));
    obj.put("fconttype",StringUtils.noNull(fconttype));
    obj.put("lang3msg",StringUtils.noNull(lang3msg));
    obj.put("fwidth",StringUtils.noNull(fwidth));
    obj.put("activeflag",StringUtils.noNull(activeflag));
    obj.put("screenid",StringUtils.noNull(screenid));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("ffldlen",StringUtils.noNull(ffldlen));
    obj.put("fheight",StringUtils.noNull(fheight));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("serviceid",StringUtils.noNull(serviceid));
    obj.put("contentlength",StringUtils.noNull(contentlength));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("ftext");
    columnList.add("overridecode");
    columnList.add("ffldtype");
    columnList.add("menutype");
    columnList.add("fseq");
    columnList.add("lang2msg");
    columnList.add("fsesscont");
    columnList.add("ffldcode");
    columnList.add("parentid");
    columnList.add("lang4msg");
    columnList.add("langcode");
    columnList.add("createdby");
    columnList.add("actionid");
    columnList.add("ussd");
    columnList.add("id");
    columnList.add("newsess");
    columnList.add("extn4");
    columnList.add("extn3");
    columnList.add("extn2");
    columnList.add("extn1");
    columnList.add("accesscode");
    columnList.add("modifiedat");
    columnList.add("wap");
    columnList.add("fconttype");
    columnList.add("lang3msg");
    columnList.add("fwidth");
    columnList.add("activeflag");
    columnList.add("screenid");
    columnList.add("rstatus");
    columnList.add("createdat");
    columnList.add("ffldlen");
    columnList.add("fheight");
    columnList.add("modifiedby");
    columnList.add("serviceid");
    columnList.add("contentlength");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "ftext:" + ftext +"overridecode:" + overridecode +"ffldtype:" + ffldtype +"menutype:" + menutype +"fseq:" + fseq +"lang2msg:" + lang2msg +"fsesscont:" + fsesscont +"ffldcode:" + ffldcode +"parentid:" + parentid +"lang4msg:" + lang4msg +"langcode:" + langcode +"createdby:" + createdby +"actionid:" + actionid +"ussd:" + ussd +"id:" + id +"newsess:" + newsess +"extn4:" + extn4 +"extn3:" + extn3 +"extn2:" + extn2 +"extn1:" + extn1 +"accesscode:" + accesscode +"modifiedat:" + modifiedat +"wap:" + wap +"fconttype:" + fconttype +"lang3msg:" + lang3msg +"fwidth:" + fwidth +"activeflag:" + activeflag +"screenid:" + screenid +"rstatus:" + rstatus +"createdat:" + createdat +"ffldlen:" + ffldlen +"fheight:" + fheight +"modifiedby:" + modifiedby +"serviceid:" + serviceid +"contentlength:" + contentlength +"";
  }
}
