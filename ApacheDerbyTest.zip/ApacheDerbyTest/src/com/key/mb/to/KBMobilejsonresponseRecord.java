package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBMobilejsonresponseRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBMobilejsonresponseRecord.class.getName());

  public String rstatus;

  public String createdat;

  public String controllist;

  public String createdby;

  public String modifiedat;

  public String requestid;

  public String modifiedby;

  public String id;

  public String sessionid;

  public String direction;

  public String getRstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rstatus);
    }
    else {
      return rstatus;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getControllist() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(controllist);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(controllist);
    }
    else {
      return controllist;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getRequestid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(requestid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(requestid);
    }
    else {
      return requestid;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public String getSessionid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(sessionid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(sessionid);
    }
    else {
      return sessionid;
    }
  }

  public String getDirection() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(direction);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(direction);
    }
    else {
      return direction;
    }
  }

  public void setRstatus(String value) {
    rstatus = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setControllist(String value) {
    controllist = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setRequestid(String value) {
    requestid = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void setSessionid(String value) {
    sessionid = value;
  }

  public void setDirection(String value) {
    direction = value;
  }

  public void loadContent(KBMobilejsonresponseRecord inputRecord) {
    setRstatus(inputRecord.getRstatus());
    setCreatedat(inputRecord.getCreatedat());
    setControllist(inputRecord.getControllist());
    setCreatedby(inputRecord.getCreatedby());
    setModifiedat(inputRecord.getModifiedat());
    setRequestid(inputRecord.getRequestid());
    setModifiedby(inputRecord.getModifiedby());
    setId(inputRecord.getId());
    setSessionid(inputRecord.getSessionid());
    setDirection(inputRecord.getDirection());
  }

  public void loadNonNullContent(KBMobilejsonresponseRecord inputRecord) {
    if (StringUtils.hasChanged(getRstatus(), inputRecord.getRstatus())) {
      setRstatus(StringUtils.noNull(inputRecord.getRstatus()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getControllist(), inputRecord.getControllist())) {
      setControllist(StringUtils.noNull(inputRecord.getControllist()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getRequestid(), inputRecord.getRequestid())) {
      setRequestid(StringUtils.noNull(inputRecord.getRequestid()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
    if (StringUtils.hasChanged(getSessionid(), inputRecord.getSessionid())) {
      setSessionid(StringUtils.noNull(inputRecord.getSessionid()));
    }
    if (StringUtils.hasChanged(getDirection(), inputRecord.getDirection())) {
      setDirection(StringUtils.noNull(inputRecord.getDirection()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("controllist",StringUtils.noNull(controllist));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("requestid",StringUtils.noNull(requestid));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("sessionid",StringUtils.noNull(sessionid));
    obj.put("direction",StringUtils.noNull(direction));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    rstatus = StringUtils.getValueFromJSONObject(obj, "rstatus");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    controllist = StringUtils.getValueFromJSONObject(obj, "controllist");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    requestid = StringUtils.getValueFromJSONObject(obj, "requestid");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    id = StringUtils.getValueFromJSONObject(obj, "id");
    sessionid = StringUtils.getValueFromJSONObject(obj, "sessionid");
    direction = StringUtils.getValueFromJSONObject(obj, "direction");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("controllist",StringUtils.noNull(controllist));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("requestid",StringUtils.noNull(requestid));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("sessionid",StringUtils.noNull(sessionid));
    obj.put("direction",StringUtils.noNull(direction));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("rstatus");
    columnList.add("createdat");
    columnList.add("controllist");
    columnList.add("createdby");
    columnList.add("modifiedat");
    columnList.add("requestid");
    columnList.add("modifiedby");
    columnList.add("id");
    columnList.add("sessionid");
    columnList.add("direction");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "rstatus:" + rstatus +"createdat:" + createdat +"controllist:" + controllist +"createdby:" + createdby +"modifiedat:" + modifiedat +"requestid:" + requestid +"modifiedby:" + modifiedby +"id:" + id +"sessionid:" + sessionid +"direction:" + direction +"";
  }
}
