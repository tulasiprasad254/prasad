package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBChargetyperangeRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBChargetyperangeRecord.class.getName());

  public String currappstatus;

  public String makerlastcmt;

  public String modifiedat;

  public String chargevalue2;

  public String madeby;

  public String adminlastcmt;

  public String chargetypeid;

  public String madeat;

  public String checkerlastcmt;

  public String rstatus;

  public String chargetypecode;

  public String createdat;

  public String rangeto;

  public String checkedat;

  public String createdby;

  public String checkedby;

  public String modifiedby;

  public String id;

  public String serviceid;

  public String rangefrom;

  public String chargevalue;

  public String getCurrappstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(currappstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(currappstatus);
    }
    else {
      return currappstatus;
    }
  }

  public String getMakerlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(makerlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(makerlastcmt);
    }
    else {
      return makerlastcmt;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getChargevalue2() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(chargevalue2);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(chargevalue2);
    }
    else {
      return chargevalue2;
    }
  }

  public String getMadeby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(madeby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(madeby);
    }
    else {
      return madeby;
    }
  }

  public String getAdminlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(adminlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(adminlastcmt);
    }
    else {
      return adminlastcmt;
    }
  }

  public String getChargetypeid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(chargetypeid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(chargetypeid);
    }
    else {
      return chargetypeid;
    }
  }

  public String getMadeat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(madeat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(madeat);
    }
    else {
      return madeat;
    }
  }

  public String getCheckerlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkerlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkerlastcmt);
    }
    else {
      return checkerlastcmt;
    }
  }

  public String getRstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rstatus);
    }
    else {
      return rstatus;
    }
  }

  public String getChargetypecode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(chargetypecode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(chargetypecode);
    }
    else {
      return chargetypecode;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getRangeto() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rangeto);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rangeto);
    }
    else {
      return rangeto;
    }
  }

  public String getCheckedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkedat);
    }
    else {
      return checkedat;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getCheckedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkedby);
    }
    else {
      return checkedby;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public String getServiceid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(serviceid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(serviceid);
    }
    else {
      return serviceid;
    }
  }

  public String getRangefrom() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rangefrom);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rangefrom);
    }
    else {
      return rangefrom;
    }
  }

  public String getChargevalue() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(chargevalue);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(chargevalue);
    }
    else {
      return chargevalue;
    }
  }

  public void setCurrappstatus(String value) {
    currappstatus = value;
  }

  public void setMakerlastcmt(String value) {
    makerlastcmt = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setChargevalue2(String value) {
    chargevalue2 = value;
  }

  public void setMadeby(String value) {
    madeby = value;
  }

  public void setAdminlastcmt(String value) {
    adminlastcmt = value;
  }

  public void setChargetypeid(String value) {
    chargetypeid = value;
  }

  public void setMadeat(String value) {
    madeat = value;
  }

  public void setCheckerlastcmt(String value) {
    checkerlastcmt = value;
  }

  public void setRstatus(String value) {
    rstatus = value;
  }

  public void setChargetypecode(String value) {
    chargetypecode = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setRangeto(String value) {
    rangeto = value;
  }

  public void setCheckedat(String value) {
    checkedat = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setCheckedby(String value) {
    checkedby = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void setServiceid(String value) {
    serviceid = value;
  }

  public void setRangefrom(String value) {
    rangefrom = value;
  }

  public void setChargevalue(String value) {
    chargevalue = value;
  }

  public void loadContent(KBChargetyperangeRecord inputRecord) {
    setCurrappstatus(inputRecord.getCurrappstatus());
    setMakerlastcmt(inputRecord.getMakerlastcmt());
    setModifiedat(inputRecord.getModifiedat());
    setChargevalue2(inputRecord.getChargevalue2());
    setMadeby(inputRecord.getMadeby());
    setAdminlastcmt(inputRecord.getAdminlastcmt());
    setChargetypeid(inputRecord.getChargetypeid());
    setMadeat(inputRecord.getMadeat());
    setCheckerlastcmt(inputRecord.getCheckerlastcmt());
    setRstatus(inputRecord.getRstatus());
    setChargetypecode(inputRecord.getChargetypecode());
    setCreatedat(inputRecord.getCreatedat());
    setRangeto(inputRecord.getRangeto());
    setCheckedat(inputRecord.getCheckedat());
    setCreatedby(inputRecord.getCreatedby());
    setCheckedby(inputRecord.getCheckedby());
    setModifiedby(inputRecord.getModifiedby());
    setId(inputRecord.getId());
    setServiceid(inputRecord.getServiceid());
    setRangefrom(inputRecord.getRangefrom());
    setChargevalue(inputRecord.getChargevalue());
  }

  public void loadNonNullContent(KBChargetyperangeRecord inputRecord) {
    if (StringUtils.hasChanged(getCurrappstatus(), inputRecord.getCurrappstatus())) {
      setCurrappstatus(StringUtils.noNull(inputRecord.getCurrappstatus()));
    }
    if (StringUtils.hasChanged(getMakerlastcmt(), inputRecord.getMakerlastcmt())) {
      setMakerlastcmt(StringUtils.noNull(inputRecord.getMakerlastcmt()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getChargevalue2(), inputRecord.getChargevalue2())) {
      setChargevalue2(StringUtils.noNull(inputRecord.getChargevalue2()));
    }
    if (StringUtils.hasChanged(getMadeby(), inputRecord.getMadeby())) {
      setMadeby(StringUtils.noNull(inputRecord.getMadeby()));
    }
    if (StringUtils.hasChanged(getAdminlastcmt(), inputRecord.getAdminlastcmt())) {
      setAdminlastcmt(StringUtils.noNull(inputRecord.getAdminlastcmt()));
    }
    if (StringUtils.hasChanged(getChargetypeid(), inputRecord.getChargetypeid())) {
      setChargetypeid(StringUtils.noNull(inputRecord.getChargetypeid()));
    }
    if (StringUtils.hasChanged(getMadeat(), inputRecord.getMadeat())) {
      setMadeat(StringUtils.noNull(inputRecord.getMadeat()));
    }
    if (StringUtils.hasChanged(getCheckerlastcmt(), inputRecord.getCheckerlastcmt())) {
      setCheckerlastcmt(StringUtils.noNull(inputRecord.getCheckerlastcmt()));
    }
    if (StringUtils.hasChanged(getRstatus(), inputRecord.getRstatus())) {
      setRstatus(StringUtils.noNull(inputRecord.getRstatus()));
    }
    if (StringUtils.hasChanged(getChargetypecode(), inputRecord.getChargetypecode())) {
      setChargetypecode(StringUtils.noNull(inputRecord.getChargetypecode()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getRangeto(), inputRecord.getRangeto())) {
      setRangeto(StringUtils.noNull(inputRecord.getRangeto()));
    }
    if (StringUtils.hasChanged(getCheckedat(), inputRecord.getCheckedat())) {
      setCheckedat(StringUtils.noNull(inputRecord.getCheckedat()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getCheckedby(), inputRecord.getCheckedby())) {
      setCheckedby(StringUtils.noNull(inputRecord.getCheckedby()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
    if (StringUtils.hasChanged(getServiceid(), inputRecord.getServiceid())) {
      setServiceid(StringUtils.noNull(inputRecord.getServiceid()));
    }
    if (StringUtils.hasChanged(getRangefrom(), inputRecord.getRangefrom())) {
      setRangefrom(StringUtils.noNull(inputRecord.getRangefrom()));
    }
    if (StringUtils.hasChanged(getChargevalue(), inputRecord.getChargevalue())) {
      setChargevalue(StringUtils.noNull(inputRecord.getChargevalue()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("currappstatus",StringUtils.noNull(currappstatus));
    obj.put("makerlastcmt",StringUtils.noNull(makerlastcmt));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("chargevalue2",StringUtils.noNull(chargevalue2));
    obj.put("madeby",StringUtils.noNull(madeby));
    obj.put("adminlastcmt",StringUtils.noNull(adminlastcmt));
    obj.put("chargetypeid",StringUtils.noNull(chargetypeid));
    obj.put("madeat",StringUtils.noNull(madeat));
    obj.put("checkerlastcmt",StringUtils.noNull(checkerlastcmt));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("chargetypecode",StringUtils.noNull(chargetypecode));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("rangeto",StringUtils.noNull(rangeto));
    obj.put("checkedat",StringUtils.noNull(checkedat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("checkedby",StringUtils.noNull(checkedby));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("serviceid",StringUtils.noNull(serviceid));
    obj.put("rangefrom",StringUtils.noNull(rangefrom));
    obj.put("chargevalue",StringUtils.noNull(chargevalue));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    currappstatus = StringUtils.getValueFromJSONObject(obj, "currappstatus");
    makerlastcmt = StringUtils.getValueFromJSONObject(obj, "makerlastcmt");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    chargevalue2 = StringUtils.getValueFromJSONObject(obj, "chargevalue2");
    madeby = StringUtils.getValueFromJSONObject(obj, "madeby");
    adminlastcmt = StringUtils.getValueFromJSONObject(obj, "adminlastcmt");
    chargetypeid = StringUtils.getValueFromJSONObject(obj, "chargetypeid");
    madeat = StringUtils.getValueFromJSONObject(obj, "madeat");
    checkerlastcmt = StringUtils.getValueFromJSONObject(obj, "checkerlastcmt");
    rstatus = StringUtils.getValueFromJSONObject(obj, "rstatus");
    chargetypecode = StringUtils.getValueFromJSONObject(obj, "chargetypecode");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    rangeto = StringUtils.getValueFromJSONObject(obj, "rangeto");
    checkedat = StringUtils.getValueFromJSONObject(obj, "checkedat");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    checkedby = StringUtils.getValueFromJSONObject(obj, "checkedby");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    id = StringUtils.getValueFromJSONObject(obj, "id");
    serviceid = StringUtils.getValueFromJSONObject(obj, "serviceid");
    rangefrom = StringUtils.getValueFromJSONObject(obj, "rangefrom");
    chargevalue = StringUtils.getValueFromJSONObject(obj, "chargevalue");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("currappstatus",StringUtils.noNull(currappstatus));
    obj.put("makerlastcmt",StringUtils.noNull(makerlastcmt));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("chargevalue2",StringUtils.noNull(chargevalue2));
    obj.put("madeby",StringUtils.noNull(madeby));
    obj.put("adminlastcmt",StringUtils.noNull(adminlastcmt));
    obj.put("chargetypeid",StringUtils.noNull(chargetypeid));
    obj.put("madeat",StringUtils.noNull(madeat));
    obj.put("checkerlastcmt",StringUtils.noNull(checkerlastcmt));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("chargetypecode",StringUtils.noNull(chargetypecode));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("rangeto",StringUtils.noNull(rangeto));
    obj.put("checkedat",StringUtils.noNull(checkedat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("checkedby",StringUtils.noNull(checkedby));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("serviceid",StringUtils.noNull(serviceid));
    obj.put("rangefrom",StringUtils.noNull(rangefrom));
    obj.put("chargevalue",StringUtils.noNull(chargevalue));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("currappstatus");
    columnList.add("makerlastcmt");
    columnList.add("modifiedat");
    columnList.add("chargevalue2");
    columnList.add("madeby");
    columnList.add("adminlastcmt");
    columnList.add("chargetypeid");
    columnList.add("madeat");
    columnList.add("checkerlastcmt");
    columnList.add("rstatus");
    columnList.add("chargetypecode");
    columnList.add("createdat");
    columnList.add("rangeto");
    columnList.add("checkedat");
    columnList.add("createdby");
    columnList.add("checkedby");
    columnList.add("modifiedby");
    columnList.add("id");
    columnList.add("serviceid");
    columnList.add("rangefrom");
    columnList.add("chargevalue");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "currappstatus:" + currappstatus +"makerlastcmt:" + makerlastcmt +"modifiedat:" + modifiedat +"chargevalue2:" + chargevalue2 +"madeby:" + madeby +"adminlastcmt:" + adminlastcmt +"chargetypeid:" + chargetypeid +"madeat:" + madeat +"checkerlastcmt:" + checkerlastcmt +"rstatus:" + rstatus +"chargetypecode:" + chargetypecode +"createdat:" + createdat +"rangeto:" + rangeto +"checkedat:" + checkedat +"createdby:" + createdby +"checkedby:" + checkedby +"modifiedby:" + modifiedby +"id:" + id +"serviceid:" + serviceid +"rangefrom:" + rangefrom +"chargevalue:" + chargevalue +"";
  }
}
