package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBFullstmttempRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBFullstmttempRecord.class.getName());

  public String amount;

  public String product;

  public String address;

  public String clientid;

  public String tvalue;

  public String reportid;

  public String branch2;

  public String modifiedat;

  public String clearbalance;

  public String operator;

  public String rstatus;

  public String accountid;

  public String createdat;

  public String effects;

  public String tdate;

  public String createdby;

  public String ttype;

  public String name;

  public String branch1;

  public String currency;

  public String modifiedby;

  public String id;

  public String particulars;

  public String getAmount() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(amount);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(amount);
    }
    else {
      return amount;
    }
  }

  public String getProduct() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(product);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(product);
    }
    else {
      return product;
    }
  }

  public String getAddress() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(address);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(address);
    }
    else {
      return address;
    }
  }

  public String getClientid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(clientid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(clientid);
    }
    else {
      return clientid;
    }
  }

  public String getTvalue() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(tvalue);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(tvalue);
    }
    else {
      return tvalue;
    }
  }

  public String getReportid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(reportid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(reportid);
    }
    else {
      return reportid;
    }
  }

  public String getBranch2() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(branch2);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(branch2);
    }
    else {
      return branch2;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getClearbalance() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(clearbalance);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(clearbalance);
    }
    else {
      return clearbalance;
    }
  }

  public String getOperator() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(operator);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(operator);
    }
    else {
      return operator;
    }
  }

  public String getRstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rstatus);
    }
    else {
      return rstatus;
    }
  }

  public String getAccountid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(accountid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(accountid);
    }
    else {
      return accountid;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getEffects() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(effects);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(effects);
    }
    else {
      return effects;
    }
  }

  public String getTdate() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(tdate);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(tdate);
    }
    else {
      return tdate;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getTtype() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(ttype);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(ttype);
    }
    else {
      return ttype;
    }
  }

  public String getName() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(name);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(name);
    }
    else {
      return name;
    }
  }

  public String getBranch1() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(branch1);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(branch1);
    }
    else {
      return branch1;
    }
  }

  public String getCurrency() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(currency);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(currency);
    }
    else {
      return currency;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public String getParticulars() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(particulars);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(particulars);
    }
    else {
      return particulars;
    }
  }

  public void setAmount(String value) {
    amount = value;
  }

  public void setProduct(String value) {
    product = value;
  }

  public void setAddress(String value) {
    address = value;
  }

  public void setClientid(String value) {
    clientid = value;
  }

  public void setTvalue(String value) {
    tvalue = value;
  }

  public void setReportid(String value) {
    reportid = value;
  }

  public void setBranch2(String value) {
    branch2 = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setClearbalance(String value) {
    clearbalance = value;
  }

  public void setOperator(String value) {
    operator = value;
  }

  public void setRstatus(String value) {
    rstatus = value;
  }

  public void setAccountid(String value) {
    accountid = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setEffects(String value) {
    effects = value;
  }

  public void setTdate(String value) {
    tdate = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setTtype(String value) {
    ttype = value;
  }

  public void setName(String value) {
    name = value;
  }

  public void setBranch1(String value) {
    branch1 = value;
  }

  public void setCurrency(String value) {
    currency = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void setParticulars(String value) {
    particulars = value;
  }

  public void loadContent(KBFullstmttempRecord inputRecord) {
    setAmount(inputRecord.getAmount());
    setProduct(inputRecord.getProduct());
    setAddress(inputRecord.getAddress());
    setClientid(inputRecord.getClientid());
    setTvalue(inputRecord.getTvalue());
    setReportid(inputRecord.getReportid());
    setBranch2(inputRecord.getBranch2());
    setModifiedat(inputRecord.getModifiedat());
    setClearbalance(inputRecord.getClearbalance());
    setOperator(inputRecord.getOperator());
    setRstatus(inputRecord.getRstatus());
    setAccountid(inputRecord.getAccountid());
    setCreatedat(inputRecord.getCreatedat());
    setEffects(inputRecord.getEffects());
    setTdate(inputRecord.getTdate());
    setCreatedby(inputRecord.getCreatedby());
    setTtype(inputRecord.getTtype());
    setName(inputRecord.getName());
    setBranch1(inputRecord.getBranch1());
    setCurrency(inputRecord.getCurrency());
    setModifiedby(inputRecord.getModifiedby());
    setId(inputRecord.getId());
    setParticulars(inputRecord.getParticulars());
  }

  public void loadNonNullContent(KBFullstmttempRecord inputRecord) {
    if (StringUtils.hasChanged(getAmount(), inputRecord.getAmount())) {
      setAmount(StringUtils.noNull(inputRecord.getAmount()));
    }
    if (StringUtils.hasChanged(getProduct(), inputRecord.getProduct())) {
      setProduct(StringUtils.noNull(inputRecord.getProduct()));
    }
    if (StringUtils.hasChanged(getAddress(), inputRecord.getAddress())) {
      setAddress(StringUtils.noNull(inputRecord.getAddress()));
    }
    if (StringUtils.hasChanged(getClientid(), inputRecord.getClientid())) {
      setClientid(StringUtils.noNull(inputRecord.getClientid()));
    }
    if (StringUtils.hasChanged(getTvalue(), inputRecord.getTvalue())) {
      setTvalue(StringUtils.noNull(inputRecord.getTvalue()));
    }
    if (StringUtils.hasChanged(getReportid(), inputRecord.getReportid())) {
      setReportid(StringUtils.noNull(inputRecord.getReportid()));
    }
    if (StringUtils.hasChanged(getBranch2(), inputRecord.getBranch2())) {
      setBranch2(StringUtils.noNull(inputRecord.getBranch2()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getClearbalance(), inputRecord.getClearbalance())) {
      setClearbalance(StringUtils.noNull(inputRecord.getClearbalance()));
    }
    if (StringUtils.hasChanged(getOperator(), inputRecord.getOperator())) {
      setOperator(StringUtils.noNull(inputRecord.getOperator()));
    }
    if (StringUtils.hasChanged(getRstatus(), inputRecord.getRstatus())) {
      setRstatus(StringUtils.noNull(inputRecord.getRstatus()));
    }
    if (StringUtils.hasChanged(getAccountid(), inputRecord.getAccountid())) {
      setAccountid(StringUtils.noNull(inputRecord.getAccountid()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getEffects(), inputRecord.getEffects())) {
      setEffects(StringUtils.noNull(inputRecord.getEffects()));
    }
    if (StringUtils.hasChanged(getTdate(), inputRecord.getTdate())) {
      setTdate(StringUtils.noNull(inputRecord.getTdate()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getTtype(), inputRecord.getTtype())) {
      setTtype(StringUtils.noNull(inputRecord.getTtype()));
    }
    if (StringUtils.hasChanged(getName(), inputRecord.getName())) {
      setName(StringUtils.noNull(inputRecord.getName()));
    }
    if (StringUtils.hasChanged(getBranch1(), inputRecord.getBranch1())) {
      setBranch1(StringUtils.noNull(inputRecord.getBranch1()));
    }
    if (StringUtils.hasChanged(getCurrency(), inputRecord.getCurrency())) {
      setCurrency(StringUtils.noNull(inputRecord.getCurrency()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
    if (StringUtils.hasChanged(getParticulars(), inputRecord.getParticulars())) {
      setParticulars(StringUtils.noNull(inputRecord.getParticulars()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("amount",StringUtils.noNull(amount));
    obj.put("product",StringUtils.noNull(product));
    obj.put("address",StringUtils.noNull(address));
    obj.put("clientid",StringUtils.noNull(clientid));
    obj.put("tvalue",StringUtils.noNull(tvalue));
    obj.put("reportid",StringUtils.noNull(reportid));
    obj.put("branch2",StringUtils.noNull(branch2));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("clearbalance",StringUtils.noNull(clearbalance));
    obj.put("operator",StringUtils.noNull(operator));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("accountid",StringUtils.noNull(accountid));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("effects",StringUtils.noNull(effects));
    obj.put("tdate",StringUtils.noNull(tdate));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("ttype",StringUtils.noNull(ttype));
    obj.put("name",StringUtils.noNull(name));
    obj.put("branch1",StringUtils.noNull(branch1));
    obj.put("currency",StringUtils.noNull(currency));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("particulars",StringUtils.noNull(particulars));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    amount = StringUtils.getValueFromJSONObject(obj, "amount");
    product = StringUtils.getValueFromJSONObject(obj, "product");
    address = StringUtils.getValueFromJSONObject(obj, "address");
    clientid = StringUtils.getValueFromJSONObject(obj, "clientid");
    tvalue = StringUtils.getValueFromJSONObject(obj, "tvalue");
    reportid = StringUtils.getValueFromJSONObject(obj, "reportid");
    branch2 = StringUtils.getValueFromJSONObject(obj, "branch2");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    clearbalance = StringUtils.getValueFromJSONObject(obj, "clearbalance");
    operator = StringUtils.getValueFromJSONObject(obj, "operator");
    rstatus = StringUtils.getValueFromJSONObject(obj, "rstatus");
    accountid = StringUtils.getValueFromJSONObject(obj, "accountid");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    effects = StringUtils.getValueFromJSONObject(obj, "effects");
    tdate = StringUtils.getValueFromJSONObject(obj, "tdate");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    ttype = StringUtils.getValueFromJSONObject(obj, "ttype");
    name = StringUtils.getValueFromJSONObject(obj, "name");
    branch1 = StringUtils.getValueFromJSONObject(obj, "branch1");
    currency = StringUtils.getValueFromJSONObject(obj, "currency");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    id = StringUtils.getValueFromJSONObject(obj, "id");
    particulars = StringUtils.getValueFromJSONObject(obj, "particulars");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("amount",StringUtils.noNull(amount));
    obj.put("product",StringUtils.noNull(product));
    obj.put("address",StringUtils.noNull(address));
    obj.put("clientid",StringUtils.noNull(clientid));
    obj.put("tvalue",StringUtils.noNull(tvalue));
    obj.put("reportid",StringUtils.noNull(reportid));
    obj.put("branch2",StringUtils.noNull(branch2));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("clearbalance",StringUtils.noNull(clearbalance));
    obj.put("operator",StringUtils.noNull(operator));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("accountid",StringUtils.noNull(accountid));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("effects",StringUtils.noNull(effects));
    obj.put("tdate",StringUtils.noNull(tdate));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("ttype",StringUtils.noNull(ttype));
    obj.put("name",StringUtils.noNull(name));
    obj.put("branch1",StringUtils.noNull(branch1));
    obj.put("currency",StringUtils.noNull(currency));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("particulars",StringUtils.noNull(particulars));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("amount");
    columnList.add("product");
    columnList.add("address");
    columnList.add("clientid");
    columnList.add("tvalue");
    columnList.add("reportid");
    columnList.add("branch2");
    columnList.add("modifiedat");
    columnList.add("clearbalance");
    columnList.add("operator");
    columnList.add("rstatus");
    columnList.add("accountid");
    columnList.add("createdat");
    columnList.add("effects");
    columnList.add("tdate");
    columnList.add("createdby");
    columnList.add("ttype");
    columnList.add("name");
    columnList.add("branch1");
    columnList.add("currency");
    columnList.add("modifiedby");
    columnList.add("id");
    columnList.add("particulars");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "amount:" + amount +"product:" + product +"address:" + address +"clientid:" + clientid +"tvalue:" + tvalue +"reportid:" + reportid +"branch2:" + branch2 +"modifiedat:" + modifiedat +"clearbalance:" + clearbalance +"operator:" + operator +"rstatus:" + rstatus +"accountid:" + accountid +"createdat:" + createdat +"effects:" + effects +"tdate:" + tdate +"createdby:" + createdby +"ttype:" + ttype +"name:" + name +"branch1:" + branch1 +"currency:" + currency +"modifiedby:" + modifiedby +"id:" + id +"particulars:" + particulars +"";
  }
}
