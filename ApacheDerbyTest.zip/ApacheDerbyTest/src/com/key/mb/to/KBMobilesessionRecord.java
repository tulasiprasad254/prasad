package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBMobilesessionRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBMobilesessionRecord.class.getName());

  public String rstatus;

  public String createdat;

  public String cifno;

  public String mobileid;

  public String createdby;

  public String modifiedat;

  public String lastacc;

  public String modifiedby;

  public String id;

  public String sessionid;

  public String getRstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rstatus);
    }
    else {
      return rstatus;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getCifno() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(cifno);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(cifno);
    }
    else {
      return cifno;
    }
  }

  public String getMobileid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(mobileid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(mobileid);
    }
    else {
      return mobileid;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getLastacc() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(lastacc);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(lastacc);
    }
    else {
      return lastacc;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public String getSessionid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(sessionid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(sessionid);
    }
    else {
      return sessionid;
    }
  }

  public void setRstatus(String value) {
    rstatus = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setCifno(String value) {
    cifno = value;
  }

  public void setMobileid(String value) {
    mobileid = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setLastacc(String value) {
    lastacc = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void setSessionid(String value) {
    sessionid = value;
  }

  public void loadContent(KBMobilesessionRecord inputRecord) {
    setRstatus(inputRecord.getRstatus());
    setCreatedat(inputRecord.getCreatedat());
    setCifno(inputRecord.getCifno());
    setMobileid(inputRecord.getMobileid());
    setCreatedby(inputRecord.getCreatedby());
    setModifiedat(inputRecord.getModifiedat());
    setLastacc(inputRecord.getLastacc());
    setModifiedby(inputRecord.getModifiedby());
    setId(inputRecord.getId());
    setSessionid(inputRecord.getSessionid());
  }

  public void loadNonNullContent(KBMobilesessionRecord inputRecord) {
    if (StringUtils.hasChanged(getRstatus(), inputRecord.getRstatus())) {
      setRstatus(StringUtils.noNull(inputRecord.getRstatus()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getCifno(), inputRecord.getCifno())) {
      setCifno(StringUtils.noNull(inputRecord.getCifno()));
    }
    if (StringUtils.hasChanged(getMobileid(), inputRecord.getMobileid())) {
      setMobileid(StringUtils.noNull(inputRecord.getMobileid()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getLastacc(), inputRecord.getLastacc())) {
      setLastacc(StringUtils.noNull(inputRecord.getLastacc()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
    if (StringUtils.hasChanged(getSessionid(), inputRecord.getSessionid())) {
      setSessionid(StringUtils.noNull(inputRecord.getSessionid()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("cifno",StringUtils.noNull(cifno));
    obj.put("mobileid",StringUtils.noNull(mobileid));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("lastacc",StringUtils.noNull(lastacc));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("sessionid",StringUtils.noNull(sessionid));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    rstatus = StringUtils.getValueFromJSONObject(obj, "rstatus");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    cifno = StringUtils.getValueFromJSONObject(obj, "cifno");
    mobileid = StringUtils.getValueFromJSONObject(obj, "mobileid");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    lastacc = StringUtils.getValueFromJSONObject(obj, "lastacc");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    id = StringUtils.getValueFromJSONObject(obj, "id");
    sessionid = StringUtils.getValueFromJSONObject(obj, "sessionid");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("cifno",StringUtils.noNull(cifno));
    obj.put("mobileid",StringUtils.noNull(mobileid));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("lastacc",StringUtils.noNull(lastacc));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("sessionid",StringUtils.noNull(sessionid));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("rstatus");
    columnList.add("createdat");
    columnList.add("cifno");
    columnList.add("mobileid");
    columnList.add("createdby");
    columnList.add("modifiedat");
    columnList.add("lastacc");
    columnList.add("modifiedby");
    columnList.add("id");
    columnList.add("sessionid");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "rstatus:" + rstatus +"createdat:" + createdat +"cifno:" + cifno +"mobileid:" + mobileid +"createdby:" + createdby +"modifiedat:" + modifiedat +"lastacc:" + lastacc +"modifiedby:" + modifiedby +"id:" + id +"sessionid:" + sessionid +"";
  }
}
