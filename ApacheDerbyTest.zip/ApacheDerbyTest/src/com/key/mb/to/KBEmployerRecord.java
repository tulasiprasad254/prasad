package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBEmployerRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBEmployerRecord.class.getName());

  public String currappstatus;

  public String institutionid;

  public String makerlastcmt;

  public String modifiedat;

  public String madeby;

  public String adminlastcmt;

  public String madeat;

  public String checkerlastcmt;

  public String rstatus;

  public String createdat;

  public String employerid;

  public String otherinfo;

  public String checkedat;

  public String createdby;

  public String checkedby;

  public String employername;

  public String modifiedby;

  public String id;

  public String getCurrappstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(currappstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(currappstatus);
    }
    else {
      return currappstatus;
    }
  }

  public String getInstitutionid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(institutionid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(institutionid);
    }
    else {
      return institutionid;
    }
  }

  public String getMakerlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(makerlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(makerlastcmt);
    }
    else {
      return makerlastcmt;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getMadeby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(madeby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(madeby);
    }
    else {
      return madeby;
    }
  }

  public String getAdminlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(adminlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(adminlastcmt);
    }
    else {
      return adminlastcmt;
    }
  }

  public String getMadeat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(madeat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(madeat);
    }
    else {
      return madeat;
    }
  }

  public String getCheckerlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkerlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkerlastcmt);
    }
    else {
      return checkerlastcmt;
    }
  }

  public String getRstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rstatus);
    }
    else {
      return rstatus;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getEmployerid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(employerid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(employerid);
    }
    else {
      return employerid;
    }
  }

  public String getOtherinfo() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(otherinfo);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(otherinfo);
    }
    else {
      return otherinfo;
    }
  }

  public String getCheckedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkedat);
    }
    else {
      return checkedat;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getCheckedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkedby);
    }
    else {
      return checkedby;
    }
  }

  public String getEmployername() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(employername);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(employername);
    }
    else {
      return employername;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public void setCurrappstatus(String value) {
    currappstatus = value;
  }

  public void setInstitutionid(String value) {
    institutionid = value;
  }

  public void setMakerlastcmt(String value) {
    makerlastcmt = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setMadeby(String value) {
    madeby = value;
  }

  public void setAdminlastcmt(String value) {
    adminlastcmt = value;
  }

  public void setMadeat(String value) {
    madeat = value;
  }

  public void setCheckerlastcmt(String value) {
    checkerlastcmt = value;
  }

  public void setRstatus(String value) {
    rstatus = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setEmployerid(String value) {
    employerid = value;
  }

  public void setOtherinfo(String value) {
    otherinfo = value;
  }

  public void setCheckedat(String value) {
    checkedat = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setCheckedby(String value) {
    checkedby = value;
  }

  public void setEmployername(String value) {
    employername = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void loadContent(KBEmployerRecord inputRecord) {
    setCurrappstatus(inputRecord.getCurrappstatus());
    setInstitutionid(inputRecord.getInstitutionid());
    setMakerlastcmt(inputRecord.getMakerlastcmt());
    setModifiedat(inputRecord.getModifiedat());
    setMadeby(inputRecord.getMadeby());
    setAdminlastcmt(inputRecord.getAdminlastcmt());
    setMadeat(inputRecord.getMadeat());
    setCheckerlastcmt(inputRecord.getCheckerlastcmt());
    setRstatus(inputRecord.getRstatus());
    setCreatedat(inputRecord.getCreatedat());
    setEmployerid(inputRecord.getEmployerid());
    setOtherinfo(inputRecord.getOtherinfo());
    setCheckedat(inputRecord.getCheckedat());
    setCreatedby(inputRecord.getCreatedby());
    setCheckedby(inputRecord.getCheckedby());
    setEmployername(inputRecord.getEmployername());
    setModifiedby(inputRecord.getModifiedby());
    setId(inputRecord.getId());
  }

  public void loadNonNullContent(KBEmployerRecord inputRecord) {
    if (StringUtils.hasChanged(getCurrappstatus(), inputRecord.getCurrappstatus())) {
      setCurrappstatus(StringUtils.noNull(inputRecord.getCurrappstatus()));
    }
    if (StringUtils.hasChanged(getInstitutionid(), inputRecord.getInstitutionid())) {
      setInstitutionid(StringUtils.noNull(inputRecord.getInstitutionid()));
    }
    if (StringUtils.hasChanged(getMakerlastcmt(), inputRecord.getMakerlastcmt())) {
      setMakerlastcmt(StringUtils.noNull(inputRecord.getMakerlastcmt()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getMadeby(), inputRecord.getMadeby())) {
      setMadeby(StringUtils.noNull(inputRecord.getMadeby()));
    }
    if (StringUtils.hasChanged(getAdminlastcmt(), inputRecord.getAdminlastcmt())) {
      setAdminlastcmt(StringUtils.noNull(inputRecord.getAdminlastcmt()));
    }
    if (StringUtils.hasChanged(getMadeat(), inputRecord.getMadeat())) {
      setMadeat(StringUtils.noNull(inputRecord.getMadeat()));
    }
    if (StringUtils.hasChanged(getCheckerlastcmt(), inputRecord.getCheckerlastcmt())) {
      setCheckerlastcmt(StringUtils.noNull(inputRecord.getCheckerlastcmt()));
    }
    if (StringUtils.hasChanged(getRstatus(), inputRecord.getRstatus())) {
      setRstatus(StringUtils.noNull(inputRecord.getRstatus()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getEmployerid(), inputRecord.getEmployerid())) {
      setEmployerid(StringUtils.noNull(inputRecord.getEmployerid()));
    }
    if (StringUtils.hasChanged(getOtherinfo(), inputRecord.getOtherinfo())) {
      setOtherinfo(StringUtils.noNull(inputRecord.getOtherinfo()));
    }
    if (StringUtils.hasChanged(getCheckedat(), inputRecord.getCheckedat())) {
      setCheckedat(StringUtils.noNull(inputRecord.getCheckedat()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getCheckedby(), inputRecord.getCheckedby())) {
      setCheckedby(StringUtils.noNull(inputRecord.getCheckedby()));
    }
    if (StringUtils.hasChanged(getEmployername(), inputRecord.getEmployername())) {
      setEmployername(StringUtils.noNull(inputRecord.getEmployername()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("currappstatus",StringUtils.noNull(currappstatus));
    obj.put("institutionid",StringUtils.noNull(institutionid));
    obj.put("makerlastcmt",StringUtils.noNull(makerlastcmt));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("madeby",StringUtils.noNull(madeby));
    obj.put("adminlastcmt",StringUtils.noNull(adminlastcmt));
    obj.put("madeat",StringUtils.noNull(madeat));
    obj.put("checkerlastcmt",StringUtils.noNull(checkerlastcmt));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("employerid",StringUtils.noNull(employerid));
    obj.put("otherinfo",StringUtils.noNull(otherinfo));
    obj.put("checkedat",StringUtils.noNull(checkedat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("checkedby",StringUtils.noNull(checkedby));
    obj.put("employername",StringUtils.noNull(employername));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    currappstatus = StringUtils.getValueFromJSONObject(obj, "currappstatus");
    institutionid = StringUtils.getValueFromJSONObject(obj, "institutionid");
    makerlastcmt = StringUtils.getValueFromJSONObject(obj, "makerlastcmt");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    madeby = StringUtils.getValueFromJSONObject(obj, "madeby");
    adminlastcmt = StringUtils.getValueFromJSONObject(obj, "adminlastcmt");
    madeat = StringUtils.getValueFromJSONObject(obj, "madeat");
    checkerlastcmt = StringUtils.getValueFromJSONObject(obj, "checkerlastcmt");
    rstatus = StringUtils.getValueFromJSONObject(obj, "rstatus");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    employerid = StringUtils.getValueFromJSONObject(obj, "employerid");
    otherinfo = StringUtils.getValueFromJSONObject(obj, "otherinfo");
    checkedat = StringUtils.getValueFromJSONObject(obj, "checkedat");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    checkedby = StringUtils.getValueFromJSONObject(obj, "checkedby");
    employername = StringUtils.getValueFromJSONObject(obj, "employername");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    id = StringUtils.getValueFromJSONObject(obj, "id");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("currappstatus",StringUtils.noNull(currappstatus));
    obj.put("institutionid",StringUtils.noNull(institutionid));
    obj.put("makerlastcmt",StringUtils.noNull(makerlastcmt));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("madeby",StringUtils.noNull(madeby));
    obj.put("adminlastcmt",StringUtils.noNull(adminlastcmt));
    obj.put("madeat",StringUtils.noNull(madeat));
    obj.put("checkerlastcmt",StringUtils.noNull(checkerlastcmt));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("employerid",StringUtils.noNull(employerid));
    obj.put("otherinfo",StringUtils.noNull(otherinfo));
    obj.put("checkedat",StringUtils.noNull(checkedat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("checkedby",StringUtils.noNull(checkedby));
    obj.put("employername",StringUtils.noNull(employername));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("currappstatus");
    columnList.add("institutionid");
    columnList.add("makerlastcmt");
    columnList.add("modifiedat");
    columnList.add("madeby");
    columnList.add("adminlastcmt");
    columnList.add("madeat");
    columnList.add("checkerlastcmt");
    columnList.add("rstatus");
    columnList.add("createdat");
    columnList.add("employerid");
    columnList.add("otherinfo");
    columnList.add("checkedat");
    columnList.add("createdby");
    columnList.add("checkedby");
    columnList.add("employername");
    columnList.add("modifiedby");
    columnList.add("id");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "currappstatus:" + currappstatus +"institutionid:" + institutionid +"makerlastcmt:" + makerlastcmt +"modifiedat:" + modifiedat +"madeby:" + madeby +"adminlastcmt:" + adminlastcmt +"madeat:" + madeat +"checkerlastcmt:" + checkerlastcmt +"rstatus:" + rstatus +"createdat:" + createdat +"employerid:" + employerid +"otherinfo:" + otherinfo +"checkedat:" + checkedat +"createdby:" + createdby +"checkedby:" + checkedby +"employername:" + employername +"modifiedby:" + modifiedby +"id:" + id +"";
  }
}
