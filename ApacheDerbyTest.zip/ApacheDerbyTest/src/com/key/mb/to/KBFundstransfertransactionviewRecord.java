package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBFundstransfertransactionviewRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBFundstransfertransactionviewRecord.class.getName());

  public String ftresultcode;

  public String ftsessionid;

  public String ftstepfailed;

  public String resp4;

  public String resp2;

  public String createdby;

  public String resp3;

  public String resp1;

  public String fttrantime;

  public String ftfrom;

  public String id;

  public String ftcif;

  public String ftsubcharge;

  public String ftamount;

  public String ftcharge;

  public String ftcomment;

  public String ftrefno;

  public String modifiedat;

  public String errmsg;

  public String fttype;

  public String rstatus;

  public String createdat;

  public String ftsource;

  public String ftresult;

  public String ftphoneid;

  public String ftto;

  public String modifiedby;

  public String resultcode;

  public String ftcurrcode;

  public String getFtresultcode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(ftresultcode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(ftresultcode);
    }
    else {
      return ftresultcode;
    }
  }

  public String getFtsessionid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(ftsessionid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(ftsessionid);
    }
    else {
      return ftsessionid;
    }
  }

  public String getFtstepfailed() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(ftstepfailed);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(ftstepfailed);
    }
    else {
      return ftstepfailed;
    }
  }

  public String getResp4() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(resp4);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(resp4);
    }
    else {
      return resp4;
    }
  }

  public String getResp2() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(resp2);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(resp2);
    }
    else {
      return resp2;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getResp3() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(resp3);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(resp3);
    }
    else {
      return resp3;
    }
  }

  public String getResp1() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(resp1);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(resp1);
    }
    else {
      return resp1;
    }
  }

  public String getFttrantime() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(fttrantime);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(fttrantime);
    }
    else {
      return fttrantime;
    }
  }

  public String getFtfrom() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(ftfrom);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(ftfrom);
    }
    else {
      return ftfrom;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public String getFtcif() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(ftcif);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(ftcif);
    }
    else {
      return ftcif;
    }
  }

  public String getFtsubcharge() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(ftsubcharge);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(ftsubcharge);
    }
    else {
      return ftsubcharge;
    }
  }

  public String getFtamount() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(ftamount);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(ftamount);
    }
    else {
      return ftamount;
    }
  }

  public String getFtcharge() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(ftcharge);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(ftcharge);
    }
    else {
      return ftcharge;
    }
  }

  public String getFtcomment() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(ftcomment);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(ftcomment);
    }
    else {
      return ftcomment;
    }
  }

  public String getFtrefno() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(ftrefno);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(ftrefno);
    }
    else {
      return ftrefno;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getErrmsg() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(errmsg);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(errmsg);
    }
    else {
      return errmsg;
    }
  }

  public String getFttype() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(fttype);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(fttype);
    }
    else {
      return fttype;
    }
  }

  public String getRstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rstatus);
    }
    else {
      return rstatus;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getFtsource() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(ftsource);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(ftsource);
    }
    else {
      return ftsource;
    }
  }

  public String getFtresult() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(ftresult);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(ftresult);
    }
    else {
      return ftresult;
    }
  }

  public String getFtphoneid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(ftphoneid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(ftphoneid);
    }
    else {
      return ftphoneid;
    }
  }

  public String getFtto() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(ftto);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(ftto);
    }
    else {
      return ftto;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getResultcode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(resultcode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(resultcode);
    }
    else {
      return resultcode;
    }
  }

  public String getFtcurrcode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(ftcurrcode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(ftcurrcode);
    }
    else {
      return ftcurrcode;
    }
  }

  public void setFtresultcode(String value) {
    ftresultcode = value;
  }

  public void setFtsessionid(String value) {
    ftsessionid = value;
  }

  public void setFtstepfailed(String value) {
    ftstepfailed = value;
  }

  public void setResp4(String value) {
    resp4 = value;
  }

  public void setResp2(String value) {
    resp2 = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setResp3(String value) {
    resp3 = value;
  }

  public void setResp1(String value) {
    resp1 = value;
  }

  public void setFttrantime(String value) {
    fttrantime = value;
  }

  public void setFtfrom(String value) {
    ftfrom = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void setFtcif(String value) {
    ftcif = value;
  }

  public void setFtsubcharge(String value) {
    ftsubcharge = value;
  }

  public void setFtamount(String value) {
    ftamount = value;
  }

  public void setFtcharge(String value) {
    ftcharge = value;
  }

  public void setFtcomment(String value) {
    ftcomment = value;
  }

  public void setFtrefno(String value) {
    ftrefno = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setErrmsg(String value) {
    errmsg = value;
  }

  public void setFttype(String value) {
    fttype = value;
  }

  public void setRstatus(String value) {
    rstatus = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setFtsource(String value) {
    ftsource = value;
  }

  public void setFtresult(String value) {
    ftresult = value;
  }

  public void setFtphoneid(String value) {
    ftphoneid = value;
  }

  public void setFtto(String value) {
    ftto = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setResultcode(String value) {
    resultcode = value;
  }

  public void setFtcurrcode(String value) {
    ftcurrcode = value;
  }

  public void loadContent(KBFundstransfertransactionviewRecord inputRecord) {
    setFtresultcode(inputRecord.getFtresultcode());
    setFtsessionid(inputRecord.getFtsessionid());
    setFtstepfailed(inputRecord.getFtstepfailed());
    setResp4(inputRecord.getResp4());
    setResp2(inputRecord.getResp2());
    setCreatedby(inputRecord.getCreatedby());
    setResp3(inputRecord.getResp3());
    setResp1(inputRecord.getResp1());
    setFttrantime(inputRecord.getFttrantime());
    setFtfrom(inputRecord.getFtfrom());
    setId(inputRecord.getId());
    setFtcif(inputRecord.getFtcif());
    setFtsubcharge(inputRecord.getFtsubcharge());
    setFtamount(inputRecord.getFtamount());
    setFtcharge(inputRecord.getFtcharge());
    setFtcomment(inputRecord.getFtcomment());
    setFtrefno(inputRecord.getFtrefno());
    setModifiedat(inputRecord.getModifiedat());
    setErrmsg(inputRecord.getErrmsg());
    setFttype(inputRecord.getFttype());
    setRstatus(inputRecord.getRstatus());
    setCreatedat(inputRecord.getCreatedat());
    setFtsource(inputRecord.getFtsource());
    setFtresult(inputRecord.getFtresult());
    setFtphoneid(inputRecord.getFtphoneid());
    setFtto(inputRecord.getFtto());
    setModifiedby(inputRecord.getModifiedby());
    setResultcode(inputRecord.getResultcode());
    setFtcurrcode(inputRecord.getFtcurrcode());
  }

  public void loadNonNullContent(KBFundstransfertransactionviewRecord inputRecord) {
    if (StringUtils.hasChanged(getFtresultcode(), inputRecord.getFtresultcode())) {
      setFtresultcode(StringUtils.noNull(inputRecord.getFtresultcode()));
    }
    if (StringUtils.hasChanged(getFtsessionid(), inputRecord.getFtsessionid())) {
      setFtsessionid(StringUtils.noNull(inputRecord.getFtsessionid()));
    }
    if (StringUtils.hasChanged(getFtstepfailed(), inputRecord.getFtstepfailed())) {
      setFtstepfailed(StringUtils.noNull(inputRecord.getFtstepfailed()));
    }
    if (StringUtils.hasChanged(getResp4(), inputRecord.getResp4())) {
      setResp4(StringUtils.noNull(inputRecord.getResp4()));
    }
    if (StringUtils.hasChanged(getResp2(), inputRecord.getResp2())) {
      setResp2(StringUtils.noNull(inputRecord.getResp2()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getResp3(), inputRecord.getResp3())) {
      setResp3(StringUtils.noNull(inputRecord.getResp3()));
    }
    if (StringUtils.hasChanged(getResp1(), inputRecord.getResp1())) {
      setResp1(StringUtils.noNull(inputRecord.getResp1()));
    }
    if (StringUtils.hasChanged(getFttrantime(), inputRecord.getFttrantime())) {
      setFttrantime(StringUtils.noNull(inputRecord.getFttrantime()));
    }
    if (StringUtils.hasChanged(getFtfrom(), inputRecord.getFtfrom())) {
      setFtfrom(StringUtils.noNull(inputRecord.getFtfrom()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
    if (StringUtils.hasChanged(getFtcif(), inputRecord.getFtcif())) {
      setFtcif(StringUtils.noNull(inputRecord.getFtcif()));
    }
    if (StringUtils.hasChanged(getFtsubcharge(), inputRecord.getFtsubcharge())) {
      setFtsubcharge(StringUtils.noNull(inputRecord.getFtsubcharge()));
    }
    if (StringUtils.hasChanged(getFtamount(), inputRecord.getFtamount())) {
      setFtamount(StringUtils.noNull(inputRecord.getFtamount()));
    }
    if (StringUtils.hasChanged(getFtcharge(), inputRecord.getFtcharge())) {
      setFtcharge(StringUtils.noNull(inputRecord.getFtcharge()));
    }
    if (StringUtils.hasChanged(getFtcomment(), inputRecord.getFtcomment())) {
      setFtcomment(StringUtils.noNull(inputRecord.getFtcomment()));
    }
    if (StringUtils.hasChanged(getFtrefno(), inputRecord.getFtrefno())) {
      setFtrefno(StringUtils.noNull(inputRecord.getFtrefno()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getErrmsg(), inputRecord.getErrmsg())) {
      setErrmsg(StringUtils.noNull(inputRecord.getErrmsg()));
    }
    if (StringUtils.hasChanged(getFttype(), inputRecord.getFttype())) {
      setFttype(StringUtils.noNull(inputRecord.getFttype()));
    }
    if (StringUtils.hasChanged(getRstatus(), inputRecord.getRstatus())) {
      setRstatus(StringUtils.noNull(inputRecord.getRstatus()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getFtsource(), inputRecord.getFtsource())) {
      setFtsource(StringUtils.noNull(inputRecord.getFtsource()));
    }
    if (StringUtils.hasChanged(getFtresult(), inputRecord.getFtresult())) {
      setFtresult(StringUtils.noNull(inputRecord.getFtresult()));
    }
    if (StringUtils.hasChanged(getFtphoneid(), inputRecord.getFtphoneid())) {
      setFtphoneid(StringUtils.noNull(inputRecord.getFtphoneid()));
    }
    if (StringUtils.hasChanged(getFtto(), inputRecord.getFtto())) {
      setFtto(StringUtils.noNull(inputRecord.getFtto()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getResultcode(), inputRecord.getResultcode())) {
      setResultcode(StringUtils.noNull(inputRecord.getResultcode()));
    }
    if (StringUtils.hasChanged(getFtcurrcode(), inputRecord.getFtcurrcode())) {
      setFtcurrcode(StringUtils.noNull(inputRecord.getFtcurrcode()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("ftresultcode",StringUtils.noNull(ftresultcode));
    obj.put("ftsessionid",StringUtils.noNull(ftsessionid));
    obj.put("ftstepfailed",StringUtils.noNull(ftstepfailed));
    obj.put("resp4",StringUtils.noNull(resp4));
    obj.put("resp2",StringUtils.noNull(resp2));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("resp3",StringUtils.noNull(resp3));
    obj.put("resp1",StringUtils.noNull(resp1));
    obj.put("fttrantime",StringUtils.noNull(fttrantime));
    obj.put("ftfrom",StringUtils.noNull(ftfrom));
    obj.put("id",StringUtils.noNull(id));
    obj.put("ftcif",StringUtils.noNull(ftcif));
    obj.put("ftsubcharge",StringUtils.noNull(ftsubcharge));
    obj.put("ftamount",StringUtils.noNull(ftamount));
    obj.put("ftcharge",StringUtils.noNull(ftcharge));
    obj.put("ftcomment",StringUtils.noNull(ftcomment));
    obj.put("ftrefno",StringUtils.noNull(ftrefno));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("errmsg",StringUtils.noNull(errmsg));
    obj.put("fttype",StringUtils.noNull(fttype));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("ftsource",StringUtils.noNull(ftsource));
    obj.put("ftresult",StringUtils.noNull(ftresult));
    obj.put("ftphoneid",StringUtils.noNull(ftphoneid));
    obj.put("ftto",StringUtils.noNull(ftto));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("resultcode",StringUtils.noNull(resultcode));
    obj.put("ftcurrcode",StringUtils.noNull(ftcurrcode));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    ftresultcode = StringUtils.getValueFromJSONObject(obj, "ftresultcode");
    ftsessionid = StringUtils.getValueFromJSONObject(obj, "ftsessionid");
    ftstepfailed = StringUtils.getValueFromJSONObject(obj, "ftstepfailed");
    resp4 = StringUtils.getValueFromJSONObject(obj, "resp4");
    resp2 = StringUtils.getValueFromJSONObject(obj, "resp2");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    resp3 = StringUtils.getValueFromJSONObject(obj, "resp3");
    resp1 = StringUtils.getValueFromJSONObject(obj, "resp1");
    fttrantime = StringUtils.getValueFromJSONObject(obj, "fttrantime");
    ftfrom = StringUtils.getValueFromJSONObject(obj, "ftfrom");
    id = StringUtils.getValueFromJSONObject(obj, "id");
    ftcif = StringUtils.getValueFromJSONObject(obj, "ftcif");
    ftsubcharge = StringUtils.getValueFromJSONObject(obj, "ftsubcharge");
    ftamount = StringUtils.getValueFromJSONObject(obj, "ftamount");
    ftcharge = StringUtils.getValueFromJSONObject(obj, "ftcharge");
    ftcomment = StringUtils.getValueFromJSONObject(obj, "ftcomment");
    ftrefno = StringUtils.getValueFromJSONObject(obj, "ftrefno");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    errmsg = StringUtils.getValueFromJSONObject(obj, "errmsg");
    fttype = StringUtils.getValueFromJSONObject(obj, "fttype");
    rstatus = StringUtils.getValueFromJSONObject(obj, "rstatus");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    ftsource = StringUtils.getValueFromJSONObject(obj, "ftsource");
    ftresult = StringUtils.getValueFromJSONObject(obj, "ftresult");
    ftphoneid = StringUtils.getValueFromJSONObject(obj, "ftphoneid");
    ftto = StringUtils.getValueFromJSONObject(obj, "ftto");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    resultcode = StringUtils.getValueFromJSONObject(obj, "resultcode");
    ftcurrcode = StringUtils.getValueFromJSONObject(obj, "ftcurrcode");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("ftresultcode",StringUtils.noNull(ftresultcode));
    obj.put("ftsessionid",StringUtils.noNull(ftsessionid));
    obj.put("ftstepfailed",StringUtils.noNull(ftstepfailed));
    obj.put("resp4",StringUtils.noNull(resp4));
    obj.put("resp2",StringUtils.noNull(resp2));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("resp3",StringUtils.noNull(resp3));
    obj.put("resp1",StringUtils.noNull(resp1));
    obj.put("fttrantime",StringUtils.noNull(fttrantime));
    obj.put("ftfrom",StringUtils.noNull(ftfrom));
    obj.put("id",StringUtils.noNull(id));
    obj.put("ftcif",StringUtils.noNull(ftcif));
    obj.put("ftsubcharge",StringUtils.noNull(ftsubcharge));
    obj.put("ftamount",StringUtils.noNull(ftamount));
    obj.put("ftcharge",StringUtils.noNull(ftcharge));
    obj.put("ftcomment",StringUtils.noNull(ftcomment));
    obj.put("ftrefno",StringUtils.noNull(ftrefno));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("errmsg",StringUtils.noNull(errmsg));
    obj.put("fttype",StringUtils.noNull(fttype));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("ftsource",StringUtils.noNull(ftsource));
    obj.put("ftresult",StringUtils.noNull(ftresult));
    obj.put("ftphoneid",StringUtils.noNull(ftphoneid));
    obj.put("ftto",StringUtils.noNull(ftto));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("resultcode",StringUtils.noNull(resultcode));
    obj.put("ftcurrcode",StringUtils.noNull(ftcurrcode));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("ftresultcode");
    columnList.add("ftsessionid");
    columnList.add("ftstepfailed");
    columnList.add("resp4");
    columnList.add("resp2");
    columnList.add("createdby");
    columnList.add("resp3");
    columnList.add("resp1");
    columnList.add("fttrantime");
    columnList.add("ftfrom");
    columnList.add("id");
    columnList.add("ftcif");
    columnList.add("ftsubcharge");
    columnList.add("ftamount");
    columnList.add("ftcharge");
    columnList.add("ftcomment");
    columnList.add("ftrefno");
    columnList.add("modifiedat");
    columnList.add("errmsg");
    columnList.add("fttype");
    columnList.add("rstatus");
    columnList.add("createdat");
    columnList.add("ftsource");
    columnList.add("ftresult");
    columnList.add("ftphoneid");
    columnList.add("ftto");
    columnList.add("modifiedby");
    columnList.add("resultcode");
    columnList.add("ftcurrcode");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "ftresultcode:" + ftresultcode +"ftsessionid:" + ftsessionid +"ftstepfailed:" + ftstepfailed +"resp4:" + resp4 +"resp2:" + resp2 +"createdby:" + createdby +"resp3:" + resp3 +"resp1:" + resp1 +"fttrantime:" + fttrantime +"ftfrom:" + ftfrom +"id:" + id +"ftcif:" + ftcif +"ftsubcharge:" + ftsubcharge +"ftamount:" + ftamount +"ftcharge:" + ftcharge +"ftcomment:" + ftcomment +"ftrefno:" + ftrefno +"modifiedat:" + modifiedat +"errmsg:" + errmsg +"fttype:" + fttype +"rstatus:" + rstatus +"createdat:" + createdat +"ftsource:" + ftsource +"ftresult:" + ftresult +"ftphoneid:" + ftphoneid +"ftto:" + ftto +"modifiedby:" + modifiedby +"resultcode:" + resultcode +"ftcurrcode:" + ftcurrcode +"";
  }
}
