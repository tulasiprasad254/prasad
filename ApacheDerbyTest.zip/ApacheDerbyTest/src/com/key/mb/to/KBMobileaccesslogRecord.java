package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBMobileaccesslogRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBMobileaccesslogRecord.class.getName());

  public String modifiedat;

  public String mmodel;

  public String trancharge;

  public String source;

  public String sessionid;

  public String tranref;

  public String result;

  public String createdat;

  public String createdby;

  public String service;

  public String customerid;

  public String tranremarks;

  public String modifiedby;

  public String id;

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getMmodel() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(mmodel);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(mmodel);
    }
    else {
      return mmodel;
    }
  }

  public String getTrancharge() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(trancharge);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(trancharge);
    }
    else {
      return trancharge;
    }
  }

  public String getSource() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(source);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(source);
    }
    else {
      return source;
    }
  }

  public String getSessionid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(sessionid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(sessionid);
    }
    else {
      return sessionid;
    }
  }

  public String getTranref() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(tranref);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(tranref);
    }
    else {
      return tranref;
    }
  }

  public String getResult() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(result);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(result);
    }
    else {
      return result;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getService() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(service);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(service);
    }
    else {
      return service;
    }
  }

  public String getCustomerid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(customerid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(customerid);
    }
    else {
      return customerid;
    }
  }

  public String getTranremarks() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(tranremarks);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(tranremarks);
    }
    else {
      return tranremarks;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setMmodel(String value) {
    mmodel = value;
  }

  public void setTrancharge(String value) {
    trancharge = value;
  }

  public void setSource(String value) {
    source = value;
  }

  public void setSessionid(String value) {
    sessionid = value;
  }

  public void setTranref(String value) {
    tranref = value;
  }

  public void setResult(String value) {
    result = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setService(String value) {
    service = value;
  }

  public void setCustomerid(String value) {
    customerid = value;
  }

  public void setTranremarks(String value) {
    tranremarks = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void loadContent(KBMobileaccesslogRecord inputRecord) {
    setModifiedat(inputRecord.getModifiedat());
    setMmodel(inputRecord.getMmodel());
    setTrancharge(inputRecord.getTrancharge());
    setSource(inputRecord.getSource());
    setSessionid(inputRecord.getSessionid());
    setTranref(inputRecord.getTranref());
    setResult(inputRecord.getResult());
    setCreatedat(inputRecord.getCreatedat());
    setCreatedby(inputRecord.getCreatedby());
    setService(inputRecord.getService());
    setCustomerid(inputRecord.getCustomerid());
    setTranremarks(inputRecord.getTranremarks());
    setModifiedby(inputRecord.getModifiedby());
    setId(inputRecord.getId());
  }

  public void loadNonNullContent(KBMobileaccesslogRecord inputRecord) {
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getMmodel(), inputRecord.getMmodel())) {
      setMmodel(StringUtils.noNull(inputRecord.getMmodel()));
    }
    if (StringUtils.hasChanged(getTrancharge(), inputRecord.getTrancharge())) {
      setTrancharge(StringUtils.noNull(inputRecord.getTrancharge()));
    }
    if (StringUtils.hasChanged(getSource(), inputRecord.getSource())) {
      setSource(StringUtils.noNull(inputRecord.getSource()));
    }
    if (StringUtils.hasChanged(getSessionid(), inputRecord.getSessionid())) {
      setSessionid(StringUtils.noNull(inputRecord.getSessionid()));
    }
    if (StringUtils.hasChanged(getTranref(), inputRecord.getTranref())) {
      setTranref(StringUtils.noNull(inputRecord.getTranref()));
    }
    if (StringUtils.hasChanged(getResult(), inputRecord.getResult())) {
      setResult(StringUtils.noNull(inputRecord.getResult()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getService(), inputRecord.getService())) {
      setService(StringUtils.noNull(inputRecord.getService()));
    }
    if (StringUtils.hasChanged(getCustomerid(), inputRecord.getCustomerid())) {
      setCustomerid(StringUtils.noNull(inputRecord.getCustomerid()));
    }
    if (StringUtils.hasChanged(getTranremarks(), inputRecord.getTranremarks())) {
      setTranremarks(StringUtils.noNull(inputRecord.getTranremarks()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("mmodel",StringUtils.noNull(mmodel));
    obj.put("trancharge",StringUtils.noNull(trancharge));
    obj.put("source",StringUtils.noNull(source));
    obj.put("sessionid",StringUtils.noNull(sessionid));
    obj.put("tranref",StringUtils.noNull(tranref));
    obj.put("result",StringUtils.noNull(result));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("service",StringUtils.noNull(service));
    obj.put("customerid",StringUtils.noNull(customerid));
    obj.put("tranremarks",StringUtils.noNull(tranremarks));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    mmodel = StringUtils.getValueFromJSONObject(obj, "mmodel");
    trancharge = StringUtils.getValueFromJSONObject(obj, "trancharge");
    source = StringUtils.getValueFromJSONObject(obj, "source");
    sessionid = StringUtils.getValueFromJSONObject(obj, "sessionid");
    tranref = StringUtils.getValueFromJSONObject(obj, "tranref");
    result = StringUtils.getValueFromJSONObject(obj, "result");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    service = StringUtils.getValueFromJSONObject(obj, "service");
    customerid = StringUtils.getValueFromJSONObject(obj, "customerid");
    tranremarks = StringUtils.getValueFromJSONObject(obj, "tranremarks");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    id = StringUtils.getValueFromJSONObject(obj, "id");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("mmodel",StringUtils.noNull(mmodel));
    obj.put("trancharge",StringUtils.noNull(trancharge));
    obj.put("source",StringUtils.noNull(source));
    obj.put("sessionid",StringUtils.noNull(sessionid));
    obj.put("tranref",StringUtils.noNull(tranref));
    obj.put("result",StringUtils.noNull(result));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("service",StringUtils.noNull(service));
    obj.put("customerid",StringUtils.noNull(customerid));
    obj.put("tranremarks",StringUtils.noNull(tranremarks));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("modifiedat");
    columnList.add("mmodel");
    columnList.add("trancharge");
    columnList.add("source");
    columnList.add("sessionid");
    columnList.add("tranref");
    columnList.add("result");
    columnList.add("createdat");
    columnList.add("createdby");
    columnList.add("service");
    columnList.add("customerid");
    columnList.add("tranremarks");
    columnList.add("modifiedby");
    columnList.add("id");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "modifiedat:" + modifiedat +"mmodel:" + mmodel +"trancharge:" + trancharge +"source:" + source +"sessionid:" + sessionid +"tranref:" + tranref +"result:" + result +"createdat:" + createdat +"createdby:" + createdby +"service:" + service +"customerid:" + customerid +"tranremarks:" + tranremarks +"modifiedby:" + modifiedby +"id:" + id +"";
  }
}
