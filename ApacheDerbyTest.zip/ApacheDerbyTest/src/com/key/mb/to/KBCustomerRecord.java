package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBCustomerRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBCustomerRecord.class.getName());

  public String currappstatus;

  public String cif;

  public String initialmpin;

  public String institutionid;

  public String idsubmitted;

  public String makerlastcmt;

  public String cname;

  public String allowedphoneid2;

  public String allowedphoneid1;

  public String reportfreq;

  public String allowedphoneid3;

  public String pinno;

  public String madeat;

  public String checkedat;

  public String nationalid;

  public String passport;

  public String authfailtpin;

  public String createdby;

  public String blockedflag;

  public String allowedphonetype1;

  public String idverified;

  public String custcat;

  public String allowedphonetype3;

  public String id;

  public String allowedphonetype2;

  public String email;

  public String preflang;

  public String valacc;

  public String modifiedat;

  public String mobile;

  public String madeby;

  public String adminlastcmt;

  public String checkerlastcmt;

  public String tpinno;

  public String rstatus;

  public String createdat;

  public String custextn4;

  public String nationality;

  public String custextn2;

  public String termssigned;

  public String custextn3;

  public String checkedby;

  public String custextn1;

  public String initialtpin;

  public String modifiedby;

  public String authfailpin;

  public String ugissued;

  public String getCurrappstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(currappstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(currappstatus);
    }
    else {
      return currappstatus;
    }
  }

  public String getCif() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(cif);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(cif);
    }
    else {
      return cif;
    }
  }

  public String getInitialmpin() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(initialmpin);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(initialmpin);
    }
    else {
      return initialmpin;
    }
  }

  public String getInstitutionid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(institutionid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(institutionid);
    }
    else {
      return institutionid;
    }
  }

  public String getIdsubmitted() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(idsubmitted);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(idsubmitted);
    }
    else {
      return idsubmitted;
    }
  }

  public String getMakerlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(makerlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(makerlastcmt);
    }
    else {
      return makerlastcmt;
    }
  }

  public String getCname() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(cname);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(cname);
    }
    else {
      return cname;
    }
  }

  public String getAllowedphoneid2() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(allowedphoneid2);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(allowedphoneid2);
    }
    else {
      return allowedphoneid2;
    }
  }

  public String getAllowedphoneid1() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(allowedphoneid1);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(allowedphoneid1);
    }
    else {
      return allowedphoneid1;
    }
  }

  public String getReportfreq() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(reportfreq);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(reportfreq);
    }
    else {
      return reportfreq;
    }
  }

  public String getAllowedphoneid3() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(allowedphoneid3);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(allowedphoneid3);
    }
    else {
      return allowedphoneid3;
    }
  }

  public String getPinno() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(pinno);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(pinno);
    }
    else {
      return pinno;
    }
  }

  public String getMadeat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(madeat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(madeat);
    }
    else {
      return madeat;
    }
  }

  public String getCheckedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkedat);
    }
    else {
      return checkedat;
    }
  }

  public String getNationalid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(nationalid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(nationalid);
    }
    else {
      return nationalid;
    }
  }

  public String getPassport() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(passport);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(passport);
    }
    else {
      return passport;
    }
  }

  public String getAuthfailtpin() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(authfailtpin);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(authfailtpin);
    }
    else {
      return authfailtpin;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getBlockedflag() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(blockedflag);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(blockedflag);
    }
    else {
      return blockedflag;
    }
  }

  public String getAllowedphonetype1() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(allowedphonetype1);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(allowedphonetype1);
    }
    else {
      return allowedphonetype1;
    }
  }

  public String getIdverified() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(idverified);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(idverified);
    }
    else {
      return idverified;
    }
  }

  public String getCustcat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(custcat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(custcat);
    }
    else {
      return custcat;
    }
  }

  public String getAllowedphonetype3() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(allowedphonetype3);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(allowedphonetype3);
    }
    else {
      return allowedphonetype3;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public String getAllowedphonetype2() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(allowedphonetype2);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(allowedphonetype2);
    }
    else {
      return allowedphonetype2;
    }
  }

  public String getEmail() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(email);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(email);
    }
    else {
      return email;
    }
  }

  public String getPreflang() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(preflang);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(preflang);
    }
    else {
      return preflang;
    }
  }

  public String getValacc() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(valacc);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(valacc);
    }
    else {
      return valacc;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getMobile() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(mobile);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(mobile);
    }
    else {
      return mobile;
    }
  }

  public String getMadeby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(madeby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(madeby);
    }
    else {
      return madeby;
    }
  }

  public String getAdminlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(adminlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(adminlastcmt);
    }
    else {
      return adminlastcmt;
    }
  }

  public String getCheckerlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkerlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkerlastcmt);
    }
    else {
      return checkerlastcmt;
    }
  }

  public String getTpinno() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(tpinno);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(tpinno);
    }
    else {
      return tpinno;
    }
  }

  public String getRstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rstatus);
    }
    else {
      return rstatus;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getCustextn4() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(custextn4);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(custextn4);
    }
    else {
      return custextn4;
    }
  }

  public String getNationality() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(nationality);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(nationality);
    }
    else {
      return nationality;
    }
  }

  public String getCustextn2() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(custextn2);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(custextn2);
    }
    else {
      return custextn2;
    }
  }

  public String getTermssigned() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(termssigned);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(termssigned);
    }
    else {
      return termssigned;
    }
  }

  public String getCustextn3() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(custextn3);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(custextn3);
    }
    else {
      return custextn3;
    }
  }

  public String getCheckedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkedby);
    }
    else {
      return checkedby;
    }
  }

  public String getCustextn1() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(custextn1);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(custextn1);
    }
    else {
      return custextn1;
    }
  }

  public String getInitialtpin() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(initialtpin);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(initialtpin);
    }
    else {
      return initialtpin;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getAuthfailpin() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(authfailpin);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(authfailpin);
    }
    else {
      return authfailpin;
    }
  }

  public String getUgissued() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(ugissued);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(ugissued);
    }
    else {
      return ugissued;
    }
  }

  public void setCurrappstatus(String value) {
    currappstatus = value;
  }

  public void setCif(String value) {
    cif = value;
  }

  public void setInitialmpin(String value) {
    initialmpin = value;
  }

  public void setInstitutionid(String value) {
    institutionid = value;
  }

  public void setIdsubmitted(String value) {
    idsubmitted = value;
  }

  public void setMakerlastcmt(String value) {
    makerlastcmt = value;
  }

  public void setCname(String value) {
    cname = value;
  }

  public void setAllowedphoneid2(String value) {
    allowedphoneid2 = value;
  }

  public void setAllowedphoneid1(String value) {
    allowedphoneid1 = value;
  }

  public void setReportfreq(String value) {
    reportfreq = value;
  }

  public void setAllowedphoneid3(String value) {
    allowedphoneid3 = value;
  }

  public void setPinno(String value) {
    pinno = value;
  }

  public void setMadeat(String value) {
    madeat = value;
  }

  public void setCheckedat(String value) {
    checkedat = value;
  }

  public void setNationalid(String value) {
    nationalid = value;
  }

  public void setPassport(String value) {
    passport = value;
  }

  public void setAuthfailtpin(String value) {
    authfailtpin = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setBlockedflag(String value) {
    blockedflag = value;
  }

  public void setAllowedphonetype1(String value) {
    allowedphonetype1 = value;
  }

  public void setIdverified(String value) {
    idverified = value;
  }

  public void setCustcat(String value) {
    custcat = value;
  }

  public void setAllowedphonetype3(String value) {
    allowedphonetype3 = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void setAllowedphonetype2(String value) {
    allowedphonetype2 = value;
  }

  public void setEmail(String value) {
    email = value;
  }

  public void setPreflang(String value) {
    preflang = value;
  }

  public void setValacc(String value) {
    valacc = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setMobile(String value) {
    mobile = value;
  }

  public void setMadeby(String value) {
    madeby = value;
  }

  public void setAdminlastcmt(String value) {
    adminlastcmt = value;
  }

  public void setCheckerlastcmt(String value) {
    checkerlastcmt = value;
  }

  public void setTpinno(String value) {
    tpinno = value;
  }

  public void setRstatus(String value) {
    rstatus = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setCustextn4(String value) {
    custextn4 = value;
  }

  public void setNationality(String value) {
    nationality = value;
  }

  public void setCustextn2(String value) {
    custextn2 = value;
  }

  public void setTermssigned(String value) {
    termssigned = value;
  }

  public void setCustextn3(String value) {
    custextn3 = value;
  }

  public void setCheckedby(String value) {
    checkedby = value;
  }

  public void setCustextn1(String value) {
    custextn1 = value;
  }

  public void setInitialtpin(String value) {
    initialtpin = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setAuthfailpin(String value) {
    authfailpin = value;
  }

  public void setUgissued(String value) {
    ugissued = value;
  }

  public void loadContent(KBCustomerRecord inputRecord) {
    setCurrappstatus(inputRecord.getCurrappstatus());
    setCif(inputRecord.getCif());
    setInitialmpin(inputRecord.getInitialmpin());
    setInstitutionid(inputRecord.getInstitutionid());
    setIdsubmitted(inputRecord.getIdsubmitted());
    setMakerlastcmt(inputRecord.getMakerlastcmt());
    setCname(inputRecord.getCname());
    setAllowedphoneid2(inputRecord.getAllowedphoneid2());
    setAllowedphoneid1(inputRecord.getAllowedphoneid1());
    setReportfreq(inputRecord.getReportfreq());
    setAllowedphoneid3(inputRecord.getAllowedphoneid3());
    setPinno(inputRecord.getPinno());
    setMadeat(inputRecord.getMadeat());
    setCheckedat(inputRecord.getCheckedat());
    setNationalid(inputRecord.getNationalid());
    setPassport(inputRecord.getPassport());
    setAuthfailtpin(inputRecord.getAuthfailtpin());
    setCreatedby(inputRecord.getCreatedby());
    setBlockedflag(inputRecord.getBlockedflag());
    setAllowedphonetype1(inputRecord.getAllowedphonetype1());
    setIdverified(inputRecord.getIdverified());
    setCustcat(inputRecord.getCustcat());
    setAllowedphonetype3(inputRecord.getAllowedphonetype3());
    setId(inputRecord.getId());
    setAllowedphonetype2(inputRecord.getAllowedphonetype2());
    setEmail(inputRecord.getEmail());
    setPreflang(inputRecord.getPreflang());
    setValacc(inputRecord.getValacc());
    setModifiedat(inputRecord.getModifiedat());
    setMobile(inputRecord.getMobile());
    setMadeby(inputRecord.getMadeby());
    setAdminlastcmt(inputRecord.getAdminlastcmt());
    setCheckerlastcmt(inputRecord.getCheckerlastcmt());
    setTpinno(inputRecord.getTpinno());
    setRstatus(inputRecord.getRstatus());
    setCreatedat(inputRecord.getCreatedat());
    setCustextn4(inputRecord.getCustextn4());
    setNationality(inputRecord.getNationality());
    setCustextn2(inputRecord.getCustextn2());
    setTermssigned(inputRecord.getTermssigned());
    setCustextn3(inputRecord.getCustextn3());
    setCheckedby(inputRecord.getCheckedby());
    setCustextn1(inputRecord.getCustextn1());
    setInitialtpin(inputRecord.getInitialtpin());
    setModifiedby(inputRecord.getModifiedby());
    setAuthfailpin(inputRecord.getAuthfailpin());
    setUgissued(inputRecord.getUgissued());
  }

  public void loadNonNullContent(KBCustomerRecord inputRecord) {
    if (StringUtils.hasChanged(getCurrappstatus(), inputRecord.getCurrappstatus())) {
      setCurrappstatus(StringUtils.noNull(inputRecord.getCurrappstatus()));
    }
    if (StringUtils.hasChanged(getCif(), inputRecord.getCif())) {
      setCif(StringUtils.noNull(inputRecord.getCif()));
    }
    if (StringUtils.hasChanged(getInitialmpin(), inputRecord.getInitialmpin())) {
      setInitialmpin(StringUtils.noNull(inputRecord.getInitialmpin()));
    }
    if (StringUtils.hasChanged(getInstitutionid(), inputRecord.getInstitutionid())) {
      setInstitutionid(StringUtils.noNull(inputRecord.getInstitutionid()));
    }
    if (StringUtils.hasChanged(getIdsubmitted(), inputRecord.getIdsubmitted())) {
      setIdsubmitted(StringUtils.noNull(inputRecord.getIdsubmitted()));
    }
    if (StringUtils.hasChanged(getMakerlastcmt(), inputRecord.getMakerlastcmt())) {
      setMakerlastcmt(StringUtils.noNull(inputRecord.getMakerlastcmt()));
    }
    if (StringUtils.hasChanged(getCname(), inputRecord.getCname())) {
      setCname(StringUtils.noNull(inputRecord.getCname()));
    }
    if (StringUtils.hasChanged(getAllowedphoneid2(), inputRecord.getAllowedphoneid2())) {
      setAllowedphoneid2(StringUtils.noNull(inputRecord.getAllowedphoneid2()));
    }
    if (StringUtils.hasChanged(getAllowedphoneid1(), inputRecord.getAllowedphoneid1())) {
      setAllowedphoneid1(StringUtils.noNull(inputRecord.getAllowedphoneid1()));
    }
    if (StringUtils.hasChanged(getReportfreq(), inputRecord.getReportfreq())) {
      setReportfreq(StringUtils.noNull(inputRecord.getReportfreq()));
    }
    if (StringUtils.hasChanged(getAllowedphoneid3(), inputRecord.getAllowedphoneid3())) {
      setAllowedphoneid3(StringUtils.noNull(inputRecord.getAllowedphoneid3()));
    }
    if (StringUtils.hasChanged(getPinno(), inputRecord.getPinno())) {
      setPinno(StringUtils.noNull(inputRecord.getPinno()));
    }
    if (StringUtils.hasChanged(getMadeat(), inputRecord.getMadeat())) {
      setMadeat(StringUtils.noNull(inputRecord.getMadeat()));
    }
    if (StringUtils.hasChanged(getCheckedat(), inputRecord.getCheckedat())) {
      setCheckedat(StringUtils.noNull(inputRecord.getCheckedat()));
    }
    if (StringUtils.hasChanged(getNationalid(), inputRecord.getNationalid())) {
      setNationalid(StringUtils.noNull(inputRecord.getNationalid()));
    }
    if (StringUtils.hasChanged(getPassport(), inputRecord.getPassport())) {
      setPassport(StringUtils.noNull(inputRecord.getPassport()));
    }
    if (StringUtils.hasChanged(getAuthfailtpin(), inputRecord.getAuthfailtpin())) {
      setAuthfailtpin(StringUtils.noNull(inputRecord.getAuthfailtpin()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getBlockedflag(), inputRecord.getBlockedflag())) {
      setBlockedflag(StringUtils.noNull(inputRecord.getBlockedflag()));
    }
    if (StringUtils.hasChanged(getAllowedphonetype1(), inputRecord.getAllowedphonetype1())) {
      setAllowedphonetype1(StringUtils.noNull(inputRecord.getAllowedphonetype1()));
    }
    if (StringUtils.hasChanged(getIdverified(), inputRecord.getIdverified())) {
      setIdverified(StringUtils.noNull(inputRecord.getIdverified()));
    }
    if (StringUtils.hasChanged(getCustcat(), inputRecord.getCustcat())) {
      setCustcat(StringUtils.noNull(inputRecord.getCustcat()));
    }
    if (StringUtils.hasChanged(getAllowedphonetype3(), inputRecord.getAllowedphonetype3())) {
      setAllowedphonetype3(StringUtils.noNull(inputRecord.getAllowedphonetype3()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
    if (StringUtils.hasChanged(getAllowedphonetype2(), inputRecord.getAllowedphonetype2())) {
      setAllowedphonetype2(StringUtils.noNull(inputRecord.getAllowedphonetype2()));
    }
    if (StringUtils.hasChanged(getEmail(), inputRecord.getEmail())) {
      setEmail(StringUtils.noNull(inputRecord.getEmail()));
    }
    if (StringUtils.hasChanged(getPreflang(), inputRecord.getPreflang())) {
      setPreflang(StringUtils.noNull(inputRecord.getPreflang()));
    }
    if (StringUtils.hasChanged(getValacc(), inputRecord.getValacc())) {
      setValacc(StringUtils.noNull(inputRecord.getValacc()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getMobile(), inputRecord.getMobile())) {
      setMobile(StringUtils.noNull(inputRecord.getMobile()));
    }
    if (StringUtils.hasChanged(getMadeby(), inputRecord.getMadeby())) {
      setMadeby(StringUtils.noNull(inputRecord.getMadeby()));
    }
    if (StringUtils.hasChanged(getAdminlastcmt(), inputRecord.getAdminlastcmt())) {
      setAdminlastcmt(StringUtils.noNull(inputRecord.getAdminlastcmt()));
    }
    if (StringUtils.hasChanged(getCheckerlastcmt(), inputRecord.getCheckerlastcmt())) {
      setCheckerlastcmt(StringUtils.noNull(inputRecord.getCheckerlastcmt()));
    }
    if (StringUtils.hasChanged(getTpinno(), inputRecord.getTpinno())) {
      setTpinno(StringUtils.noNull(inputRecord.getTpinno()));
    }
    if (StringUtils.hasChanged(getRstatus(), inputRecord.getRstatus())) {
      setRstatus(StringUtils.noNull(inputRecord.getRstatus()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getCustextn4(), inputRecord.getCustextn4())) {
      setCustextn4(StringUtils.noNull(inputRecord.getCustextn4()));
    }
    if (StringUtils.hasChanged(getNationality(), inputRecord.getNationality())) {
      setNationality(StringUtils.noNull(inputRecord.getNationality()));
    }
    if (StringUtils.hasChanged(getCustextn2(), inputRecord.getCustextn2())) {
      setCustextn2(StringUtils.noNull(inputRecord.getCustextn2()));
    }
    if (StringUtils.hasChanged(getTermssigned(), inputRecord.getTermssigned())) {
      setTermssigned(StringUtils.noNull(inputRecord.getTermssigned()));
    }
    if (StringUtils.hasChanged(getCustextn3(), inputRecord.getCustextn3())) {
      setCustextn3(StringUtils.noNull(inputRecord.getCustextn3()));
    }
    if (StringUtils.hasChanged(getCheckedby(), inputRecord.getCheckedby())) {
      setCheckedby(StringUtils.noNull(inputRecord.getCheckedby()));
    }
    if (StringUtils.hasChanged(getCustextn1(), inputRecord.getCustextn1())) {
      setCustextn1(StringUtils.noNull(inputRecord.getCustextn1()));
    }
    if (StringUtils.hasChanged(getInitialtpin(), inputRecord.getInitialtpin())) {
      setInitialtpin(StringUtils.noNull(inputRecord.getInitialtpin()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getAuthfailpin(), inputRecord.getAuthfailpin())) {
      setAuthfailpin(StringUtils.noNull(inputRecord.getAuthfailpin()));
    }
    if (StringUtils.hasChanged(getUgissued(), inputRecord.getUgissued())) {
      setUgissued(StringUtils.noNull(inputRecord.getUgissued()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("currappstatus",StringUtils.noNull(currappstatus));
    obj.put("cif",StringUtils.noNull(cif));
    obj.put("initialmpin",StringUtils.noNull(initialmpin));
    obj.put("institutionid",StringUtils.noNull(institutionid));
    obj.put("idsubmitted",StringUtils.noNull(idsubmitted));
    obj.put("makerlastcmt",StringUtils.noNull(makerlastcmt));
    obj.put("cname",StringUtils.noNull(cname));
    obj.put("allowedphoneid2",StringUtils.noNull(allowedphoneid2));
    obj.put("allowedphoneid1",StringUtils.noNull(allowedphoneid1));
    obj.put("reportfreq",StringUtils.noNull(reportfreq));
    obj.put("allowedphoneid3",StringUtils.noNull(allowedphoneid3));
    obj.put("pinno",StringUtils.noNull(pinno));
    obj.put("madeat",StringUtils.noNull(madeat));
    obj.put("checkedat",StringUtils.noNull(checkedat));
    obj.put("nationalid",StringUtils.noNull(nationalid));
    obj.put("passport",StringUtils.noNull(passport));
    obj.put("authfailtpin",StringUtils.noNull(authfailtpin));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("blockedflag",StringUtils.noNull(blockedflag));
    obj.put("allowedphonetype1",StringUtils.noNull(allowedphonetype1));
    obj.put("idverified",StringUtils.noNull(idverified));
    obj.put("custcat",StringUtils.noNull(custcat));
    obj.put("allowedphonetype3",StringUtils.noNull(allowedphonetype3));
    obj.put("id",StringUtils.noNull(id));
    obj.put("allowedphonetype2",StringUtils.noNull(allowedphonetype2));
    obj.put("email",StringUtils.noNull(email));
    obj.put("preflang",StringUtils.noNull(preflang));
    obj.put("valacc",StringUtils.noNull(valacc));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("mobile",StringUtils.noNull(mobile));
    obj.put("madeby",StringUtils.noNull(madeby));
    obj.put("adminlastcmt",StringUtils.noNull(adminlastcmt));
    obj.put("checkerlastcmt",StringUtils.noNull(checkerlastcmt));
    obj.put("tpinno",StringUtils.noNull(tpinno));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("custextn4",StringUtils.noNull(custextn4));
    obj.put("nationality",StringUtils.noNull(nationality));
    obj.put("custextn2",StringUtils.noNull(custextn2));
    obj.put("termssigned",StringUtils.noNull(termssigned));
    obj.put("custextn3",StringUtils.noNull(custextn3));
    obj.put("checkedby",StringUtils.noNull(checkedby));
    obj.put("custextn1",StringUtils.noNull(custextn1));
    obj.put("initialtpin",StringUtils.noNull(initialtpin));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("authfailpin",StringUtils.noNull(authfailpin));
    obj.put("ugissued",StringUtils.noNull(ugissued));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    currappstatus = StringUtils.getValueFromJSONObject(obj, "currappstatus");
    cif = StringUtils.getValueFromJSONObject(obj, "cif");
    initialmpin = StringUtils.getValueFromJSONObject(obj, "initialmpin");
    institutionid = StringUtils.getValueFromJSONObject(obj, "institutionid");
    idsubmitted = StringUtils.getValueFromJSONObject(obj, "idsubmitted");
    makerlastcmt = StringUtils.getValueFromJSONObject(obj, "makerlastcmt");
    cname = StringUtils.getValueFromJSONObject(obj, "cname");
    allowedphoneid2 = StringUtils.getValueFromJSONObject(obj, "allowedphoneid2");
    allowedphoneid1 = StringUtils.getValueFromJSONObject(obj, "allowedphoneid1");
    reportfreq = StringUtils.getValueFromJSONObject(obj, "reportfreq");
    allowedphoneid3 = StringUtils.getValueFromJSONObject(obj, "allowedphoneid3");
    pinno = StringUtils.getValueFromJSONObject(obj, "pinno");
    madeat = StringUtils.getValueFromJSONObject(obj, "madeat");
    checkedat = StringUtils.getValueFromJSONObject(obj, "checkedat");
    nationalid = StringUtils.getValueFromJSONObject(obj, "nationalid");
    passport = StringUtils.getValueFromJSONObject(obj, "passport");
    authfailtpin = StringUtils.getValueFromJSONObject(obj, "authfailtpin");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    blockedflag = StringUtils.getValueFromJSONObject(obj, "blockedflag");
    allowedphonetype1 = StringUtils.getValueFromJSONObject(obj, "allowedphonetype1");
    idverified = StringUtils.getValueFromJSONObject(obj, "idverified");
    custcat = StringUtils.getValueFromJSONObject(obj, "custcat");
    allowedphonetype3 = StringUtils.getValueFromJSONObject(obj, "allowedphonetype3");
    id = StringUtils.getValueFromJSONObject(obj, "id");
    allowedphonetype2 = StringUtils.getValueFromJSONObject(obj, "allowedphonetype2");
    email = StringUtils.getValueFromJSONObject(obj, "email");
    preflang = StringUtils.getValueFromJSONObject(obj, "preflang");
    valacc = StringUtils.getValueFromJSONObject(obj, "valacc");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    mobile = StringUtils.getValueFromJSONObject(obj, "mobile");
    madeby = StringUtils.getValueFromJSONObject(obj, "madeby");
    adminlastcmt = StringUtils.getValueFromJSONObject(obj, "adminlastcmt");
    checkerlastcmt = StringUtils.getValueFromJSONObject(obj, "checkerlastcmt");
    tpinno = StringUtils.getValueFromJSONObject(obj, "tpinno");
    rstatus = StringUtils.getValueFromJSONObject(obj, "rstatus");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    custextn4 = StringUtils.getValueFromJSONObject(obj, "custextn4");
    nationality = StringUtils.getValueFromJSONObject(obj, "nationality");
    custextn2 = StringUtils.getValueFromJSONObject(obj, "custextn2");
    termssigned = StringUtils.getValueFromJSONObject(obj, "termssigned");
    custextn3 = StringUtils.getValueFromJSONObject(obj, "custextn3");
    checkedby = StringUtils.getValueFromJSONObject(obj, "checkedby");
    custextn1 = StringUtils.getValueFromJSONObject(obj, "custextn1");
    initialtpin = StringUtils.getValueFromJSONObject(obj, "initialtpin");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    authfailpin = StringUtils.getValueFromJSONObject(obj, "authfailpin");
    ugissued = StringUtils.getValueFromJSONObject(obj, "ugissued");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("currappstatus",StringUtils.noNull(currappstatus));
    obj.put("cif",StringUtils.noNull(cif));
    obj.put("initialmpin",StringUtils.noNull(initialmpin));
    obj.put("institutionid",StringUtils.noNull(institutionid));
    obj.put("idsubmitted",StringUtils.noNull(idsubmitted));
    obj.put("makerlastcmt",StringUtils.noNull(makerlastcmt));
    obj.put("cname",StringUtils.noNull(cname));
    obj.put("allowedphoneid2",StringUtils.noNull(allowedphoneid2));
    obj.put("allowedphoneid1",StringUtils.noNull(allowedphoneid1));
    obj.put("reportfreq",StringUtils.noNull(reportfreq));
    obj.put("allowedphoneid3",StringUtils.noNull(allowedphoneid3));
    obj.put("pinno",StringUtils.noNull(pinno));
    obj.put("madeat",StringUtils.noNull(madeat));
    obj.put("checkedat",StringUtils.noNull(checkedat));
    obj.put("nationalid",StringUtils.noNull(nationalid));
    obj.put("passport",StringUtils.noNull(passport));
    obj.put("authfailtpin",StringUtils.noNull(authfailtpin));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("blockedflag",StringUtils.noNull(blockedflag));
    obj.put("allowedphonetype1",StringUtils.noNull(allowedphonetype1));
    obj.put("idverified",StringUtils.noNull(idverified));
    obj.put("custcat",StringUtils.noNull(custcat));
    obj.put("allowedphonetype3",StringUtils.noNull(allowedphonetype3));
    obj.put("id",StringUtils.noNull(id));
    obj.put("allowedphonetype2",StringUtils.noNull(allowedphonetype2));
    obj.put("email",StringUtils.noNull(email));
    obj.put("preflang",StringUtils.noNull(preflang));
    obj.put("valacc",StringUtils.noNull(valacc));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("mobile",StringUtils.noNull(mobile));
    obj.put("madeby",StringUtils.noNull(madeby));
    obj.put("adminlastcmt",StringUtils.noNull(adminlastcmt));
    obj.put("checkerlastcmt",StringUtils.noNull(checkerlastcmt));
    obj.put("tpinno",StringUtils.noNull(tpinno));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("custextn4",StringUtils.noNull(custextn4));
    obj.put("nationality",StringUtils.noNull(nationality));
    obj.put("custextn2",StringUtils.noNull(custextn2));
    obj.put("termssigned",StringUtils.noNull(termssigned));
    obj.put("custextn3",StringUtils.noNull(custextn3));
    obj.put("checkedby",StringUtils.noNull(checkedby));
    obj.put("custextn1",StringUtils.noNull(custextn1));
    obj.put("initialtpin",StringUtils.noNull(initialtpin));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("authfailpin",StringUtils.noNull(authfailpin));
    obj.put("ugissued",StringUtils.noNull(ugissued));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("currappstatus");
    columnList.add("cif");
    columnList.add("initialmpin");
    columnList.add("institutionid");
    columnList.add("idsubmitted");
    columnList.add("makerlastcmt");
    columnList.add("cname");
    columnList.add("allowedphoneid2");
    columnList.add("allowedphoneid1");
    columnList.add("reportfreq");
    columnList.add("allowedphoneid3");
    columnList.add("pinno");
    columnList.add("madeat");
    columnList.add("checkedat");
    columnList.add("nationalid");
    columnList.add("passport");
    columnList.add("authfailtpin");
    columnList.add("createdby");
    columnList.add("blockedflag");
    columnList.add("allowedphonetype1");
    columnList.add("idverified");
    columnList.add("custcat");
    columnList.add("allowedphonetype3");
    columnList.add("id");
    columnList.add("allowedphonetype2");
    columnList.add("email");
    columnList.add("preflang");
    columnList.add("valacc");
    columnList.add("modifiedat");
    columnList.add("mobile");
    columnList.add("madeby");
    columnList.add("adminlastcmt");
    columnList.add("checkerlastcmt");
    columnList.add("tpinno");
    columnList.add("rstatus");
    columnList.add("createdat");
    columnList.add("custextn4");
    columnList.add("nationality");
    columnList.add("custextn2");
    columnList.add("termssigned");
    columnList.add("custextn3");
    columnList.add("checkedby");
    columnList.add("custextn1");
    columnList.add("initialtpin");
    columnList.add("modifiedby");
    columnList.add("authfailpin");
    columnList.add("ugissued");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "currappstatus:" + currappstatus +"cif:" + cif +"initialmpin:" + initialmpin +"institutionid:" + institutionid +"idsubmitted:" + idsubmitted +"makerlastcmt:" + makerlastcmt +"cname:" + cname +"allowedphoneid2:" + allowedphoneid2 +"allowedphoneid1:" + allowedphoneid1 +"reportfreq:" + reportfreq +"allowedphoneid3:" + allowedphoneid3 +"pinno:" + pinno +"madeat:" + madeat +"checkedat:" + checkedat +"nationalid:" + nationalid +"passport:" + passport +"authfailtpin:" + authfailtpin +"createdby:" + createdby +"blockedflag:" + blockedflag +"allowedphonetype1:" + allowedphonetype1 +"idverified:" + idverified +"custcat:" + custcat +"allowedphonetype3:" + allowedphonetype3 +"id:" + id +"allowedphonetype2:" + allowedphonetype2 +"email:" + email +"preflang:" + preflang +"valacc:" + valacc +"modifiedat:" + modifiedat +"mobile:" + mobile +"madeby:" + madeby +"adminlastcmt:" + adminlastcmt +"checkerlastcmt:" + checkerlastcmt +"tpinno:" + tpinno +"rstatus:" + rstatus +"createdat:" + createdat +"custextn4:" + custextn4 +"nationality:" + nationality +"custextn2:" + custextn2 +"termssigned:" + termssigned +"custextn3:" + custextn3 +"checkedby:" + checkedby +"custextn1:" + custextn1 +"initialtpin:" + initialtpin +"modifiedby:" + modifiedby +"authfailpin:" + authfailpin +"ugissued:" + ugissued +"";
  }
}
