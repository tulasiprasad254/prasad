package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBCustomercategoryviewRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBCustomercategoryviewRecord.class.getName());

  public String currappstatus;

  public String mintranlimit;

  public String institutionid;

  public String makerlastcmt;

  public String modifiedat;

  public String statusname;

  public String madeby;

  public String adminlastcmt;

  public String perdaylimit;

  public String madeat;

  public String checkerlastcmt;

  public String iname;

  public String rstatus;

  public String createdat;

  public String checkedat;

  public String createdby;

  public String pertranlimit;

  public String checkedby;

  public String currappstatusname;

  public String modifiedby;

  public String id;

  public String chargetype;

  public String category;

  public String chargevalue;

  public String getCurrappstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(currappstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(currappstatus);
    }
    else {
      return currappstatus;
    }
  }

  public String getMintranlimit() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(mintranlimit);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(mintranlimit);
    }
    else {
      return mintranlimit;
    }
  }

  public String getInstitutionid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(institutionid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(institutionid);
    }
    else {
      return institutionid;
    }
  }

  public String getMakerlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(makerlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(makerlastcmt);
    }
    else {
      return makerlastcmt;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getStatusname() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(statusname);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(statusname);
    }
    else {
      return statusname;
    }
  }

  public String getMadeby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(madeby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(madeby);
    }
    else {
      return madeby;
    }
  }

  public String getAdminlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(adminlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(adminlastcmt);
    }
    else {
      return adminlastcmt;
    }
  }

  public String getPerdaylimit() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(perdaylimit);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(perdaylimit);
    }
    else {
      return perdaylimit;
    }
  }

  public String getMadeat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(madeat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(madeat);
    }
    else {
      return madeat;
    }
  }

  public String getCheckerlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkerlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkerlastcmt);
    }
    else {
      return checkerlastcmt;
    }
  }

  public String getIname() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(iname);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(iname);
    }
    else {
      return iname;
    }
  }

  public String getRstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rstatus);
    }
    else {
      return rstatus;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getCheckedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkedat);
    }
    else {
      return checkedat;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getPertranlimit() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(pertranlimit);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(pertranlimit);
    }
    else {
      return pertranlimit;
    }
  }

  public String getCheckedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkedby);
    }
    else {
      return checkedby;
    }
  }

  public String getCurrappstatusname() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(currappstatusname);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(currappstatusname);
    }
    else {
      return currappstatusname;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public String getChargetype() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(chargetype);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(chargetype);
    }
    else {
      return chargetype;
    }
  }

  public String getCategory() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(category);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(category);
    }
    else {
      return category;
    }
  }

  public String getChargevalue() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(chargevalue);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(chargevalue);
    }
    else {
      return chargevalue;
    }
  }

  public void setCurrappstatus(String value) {
    currappstatus = value;
  }

  public void setMintranlimit(String value) {
    mintranlimit = value;
  }

  public void setInstitutionid(String value) {
    institutionid = value;
  }

  public void setMakerlastcmt(String value) {
    makerlastcmt = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setStatusname(String value) {
    statusname = value;
  }

  public void setMadeby(String value) {
    madeby = value;
  }

  public void setAdminlastcmt(String value) {
    adminlastcmt = value;
  }

  public void setPerdaylimit(String value) {
    perdaylimit = value;
  }

  public void setMadeat(String value) {
    madeat = value;
  }

  public void setCheckerlastcmt(String value) {
    checkerlastcmt = value;
  }

  public void setIname(String value) {
    iname = value;
  }

  public void setRstatus(String value) {
    rstatus = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setCheckedat(String value) {
    checkedat = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setPertranlimit(String value) {
    pertranlimit = value;
  }

  public void setCheckedby(String value) {
    checkedby = value;
  }

  public void setCurrappstatusname(String value) {
    currappstatusname = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void setChargetype(String value) {
    chargetype = value;
  }

  public void setCategory(String value) {
    category = value;
  }

  public void setChargevalue(String value) {
    chargevalue = value;
  }

  public void loadContent(KBCustomercategoryviewRecord inputRecord) {
    setCurrappstatus(inputRecord.getCurrappstatus());
    setMintranlimit(inputRecord.getMintranlimit());
    setInstitutionid(inputRecord.getInstitutionid());
    setMakerlastcmt(inputRecord.getMakerlastcmt());
    setModifiedat(inputRecord.getModifiedat());
    setStatusname(inputRecord.getStatusname());
    setMadeby(inputRecord.getMadeby());
    setAdminlastcmt(inputRecord.getAdminlastcmt());
    setPerdaylimit(inputRecord.getPerdaylimit());
    setMadeat(inputRecord.getMadeat());
    setCheckerlastcmt(inputRecord.getCheckerlastcmt());
    setIname(inputRecord.getIname());
    setRstatus(inputRecord.getRstatus());
    setCreatedat(inputRecord.getCreatedat());
    setCheckedat(inputRecord.getCheckedat());
    setCreatedby(inputRecord.getCreatedby());
    setPertranlimit(inputRecord.getPertranlimit());
    setCheckedby(inputRecord.getCheckedby());
    setCurrappstatusname(inputRecord.getCurrappstatusname());
    setModifiedby(inputRecord.getModifiedby());
    setId(inputRecord.getId());
    setChargetype(inputRecord.getChargetype());
    setCategory(inputRecord.getCategory());
    setChargevalue(inputRecord.getChargevalue());
  }

  public void loadNonNullContent(KBCustomercategoryviewRecord inputRecord) {
    if (StringUtils.hasChanged(getCurrappstatus(), inputRecord.getCurrappstatus())) {
      setCurrappstatus(StringUtils.noNull(inputRecord.getCurrappstatus()));
    }
    if (StringUtils.hasChanged(getMintranlimit(), inputRecord.getMintranlimit())) {
      setMintranlimit(StringUtils.noNull(inputRecord.getMintranlimit()));
    }
    if (StringUtils.hasChanged(getInstitutionid(), inputRecord.getInstitutionid())) {
      setInstitutionid(StringUtils.noNull(inputRecord.getInstitutionid()));
    }
    if (StringUtils.hasChanged(getMakerlastcmt(), inputRecord.getMakerlastcmt())) {
      setMakerlastcmt(StringUtils.noNull(inputRecord.getMakerlastcmt()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getStatusname(), inputRecord.getStatusname())) {
      setStatusname(StringUtils.noNull(inputRecord.getStatusname()));
    }
    if (StringUtils.hasChanged(getMadeby(), inputRecord.getMadeby())) {
      setMadeby(StringUtils.noNull(inputRecord.getMadeby()));
    }
    if (StringUtils.hasChanged(getAdminlastcmt(), inputRecord.getAdminlastcmt())) {
      setAdminlastcmt(StringUtils.noNull(inputRecord.getAdminlastcmt()));
    }
    if (StringUtils.hasChanged(getPerdaylimit(), inputRecord.getPerdaylimit())) {
      setPerdaylimit(StringUtils.noNull(inputRecord.getPerdaylimit()));
    }
    if (StringUtils.hasChanged(getMadeat(), inputRecord.getMadeat())) {
      setMadeat(StringUtils.noNull(inputRecord.getMadeat()));
    }
    if (StringUtils.hasChanged(getCheckerlastcmt(), inputRecord.getCheckerlastcmt())) {
      setCheckerlastcmt(StringUtils.noNull(inputRecord.getCheckerlastcmt()));
    }
    if (StringUtils.hasChanged(getIname(), inputRecord.getIname())) {
      setIname(StringUtils.noNull(inputRecord.getIname()));
    }
    if (StringUtils.hasChanged(getRstatus(), inputRecord.getRstatus())) {
      setRstatus(StringUtils.noNull(inputRecord.getRstatus()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getCheckedat(), inputRecord.getCheckedat())) {
      setCheckedat(StringUtils.noNull(inputRecord.getCheckedat()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getPertranlimit(), inputRecord.getPertranlimit())) {
      setPertranlimit(StringUtils.noNull(inputRecord.getPertranlimit()));
    }
    if (StringUtils.hasChanged(getCheckedby(), inputRecord.getCheckedby())) {
      setCheckedby(StringUtils.noNull(inputRecord.getCheckedby()));
    }
    if (StringUtils.hasChanged(getCurrappstatusname(), inputRecord.getCurrappstatusname())) {
      setCurrappstatusname(StringUtils.noNull(inputRecord.getCurrappstatusname()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
    if (StringUtils.hasChanged(getChargetype(), inputRecord.getChargetype())) {
      setChargetype(StringUtils.noNull(inputRecord.getChargetype()));
    }
    if (StringUtils.hasChanged(getCategory(), inputRecord.getCategory())) {
      setCategory(StringUtils.noNull(inputRecord.getCategory()));
    }
    if (StringUtils.hasChanged(getChargevalue(), inputRecord.getChargevalue())) {
      setChargevalue(StringUtils.noNull(inputRecord.getChargevalue()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("currappstatus",StringUtils.noNull(currappstatus));
    obj.put("mintranlimit",StringUtils.noNull(mintranlimit));
    obj.put("institutionid",StringUtils.noNull(institutionid));
    obj.put("makerlastcmt",StringUtils.noNull(makerlastcmt));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("statusname",StringUtils.noNull(statusname));
    obj.put("madeby",StringUtils.noNull(madeby));
    obj.put("adminlastcmt",StringUtils.noNull(adminlastcmt));
    obj.put("perdaylimit",StringUtils.noNull(perdaylimit));
    obj.put("madeat",StringUtils.noNull(madeat));
    obj.put("checkerlastcmt",StringUtils.noNull(checkerlastcmt));
    obj.put("iname",StringUtils.noNull(iname));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("checkedat",StringUtils.noNull(checkedat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("pertranlimit",StringUtils.noNull(pertranlimit));
    obj.put("checkedby",StringUtils.noNull(checkedby));
    obj.put("currappstatusname",StringUtils.noNull(currappstatusname));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("chargetype",StringUtils.noNull(chargetype));
    obj.put("category",StringUtils.noNull(category));
    obj.put("chargevalue",StringUtils.noNull(chargevalue));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    currappstatus = StringUtils.getValueFromJSONObject(obj, "currappstatus");
    mintranlimit = StringUtils.getValueFromJSONObject(obj, "mintranlimit");
    institutionid = StringUtils.getValueFromJSONObject(obj, "institutionid");
    makerlastcmt = StringUtils.getValueFromJSONObject(obj, "makerlastcmt");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    statusname = StringUtils.getValueFromJSONObject(obj, "statusname");
    madeby = StringUtils.getValueFromJSONObject(obj, "madeby");
    adminlastcmt = StringUtils.getValueFromJSONObject(obj, "adminlastcmt");
    perdaylimit = StringUtils.getValueFromJSONObject(obj, "perdaylimit");
    madeat = StringUtils.getValueFromJSONObject(obj, "madeat");
    checkerlastcmt = StringUtils.getValueFromJSONObject(obj, "checkerlastcmt");
    iname = StringUtils.getValueFromJSONObject(obj, "iname");
    rstatus = StringUtils.getValueFromJSONObject(obj, "rstatus");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    checkedat = StringUtils.getValueFromJSONObject(obj, "checkedat");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    pertranlimit = StringUtils.getValueFromJSONObject(obj, "pertranlimit");
    checkedby = StringUtils.getValueFromJSONObject(obj, "checkedby");
    currappstatusname = StringUtils.getValueFromJSONObject(obj, "currappstatusname");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    id = StringUtils.getValueFromJSONObject(obj, "id");
    chargetype = StringUtils.getValueFromJSONObject(obj, "chargetype");
    category = StringUtils.getValueFromJSONObject(obj, "category");
    chargevalue = StringUtils.getValueFromJSONObject(obj, "chargevalue");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("currappstatus",StringUtils.noNull(currappstatus));
    obj.put("mintranlimit",StringUtils.noNull(mintranlimit));
    obj.put("institutionid",StringUtils.noNull(institutionid));
    obj.put("makerlastcmt",StringUtils.noNull(makerlastcmt));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("statusname",StringUtils.noNull(statusname));
    obj.put("madeby",StringUtils.noNull(madeby));
    obj.put("adminlastcmt",StringUtils.noNull(adminlastcmt));
    obj.put("perdaylimit",StringUtils.noNull(perdaylimit));
    obj.put("madeat",StringUtils.noNull(madeat));
    obj.put("checkerlastcmt",StringUtils.noNull(checkerlastcmt));
    obj.put("iname",StringUtils.noNull(iname));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("checkedat",StringUtils.noNull(checkedat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("pertranlimit",StringUtils.noNull(pertranlimit));
    obj.put("checkedby",StringUtils.noNull(checkedby));
    obj.put("currappstatusname",StringUtils.noNull(currappstatusname));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("chargetype",StringUtils.noNull(chargetype));
    obj.put("category",StringUtils.noNull(category));
    obj.put("chargevalue",StringUtils.noNull(chargevalue));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("currappstatus");
    columnList.add("mintranlimit");
    columnList.add("institutionid");
    columnList.add("makerlastcmt");
    columnList.add("modifiedat");
    columnList.add("statusname");
    columnList.add("madeby");
    columnList.add("adminlastcmt");
    columnList.add("perdaylimit");
    columnList.add("madeat");
    columnList.add("checkerlastcmt");
    columnList.add("iname");
    columnList.add("rstatus");
    columnList.add("createdat");
    columnList.add("checkedat");
    columnList.add("createdby");
    columnList.add("pertranlimit");
    columnList.add("checkedby");
    columnList.add("currappstatusname");
    columnList.add("modifiedby");
    columnList.add("id");
    columnList.add("chargetype");
    columnList.add("category");
    columnList.add("chargevalue");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "currappstatus:" + currappstatus +"mintranlimit:" + mintranlimit +"institutionid:" + institutionid +"makerlastcmt:" + makerlastcmt +"modifiedat:" + modifiedat +"statusname:" + statusname +"madeby:" + madeby +"adminlastcmt:" + adminlastcmt +"perdaylimit:" + perdaylimit +"madeat:" + madeat +"checkerlastcmt:" + checkerlastcmt +"iname:" + iname +"rstatus:" + rstatus +"createdat:" + createdat +"checkedat:" + checkedat +"createdby:" + createdby +"pertranlimit:" + pertranlimit +"checkedby:" + checkedby +"currappstatusname:" + currappstatusname +"modifiedby:" + modifiedby +"id:" + id +"chargetype:" + chargetype +"category:" + category +"chargevalue:" + chargevalue +"";
  }
}
