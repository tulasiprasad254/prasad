package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBAgentotpRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBAgentotpRecord.class.getName());

  public String rstatus;

  public String cif;

  public String createdat;

  public String amount;

  public String createdby;

  public String modifiedat;

  public String otpts;

  public String mobile;

  public String otp;

  public String modifiedby;

  public String id;

  public String account;

  public String getRstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rstatus);
    }
    else {
      return rstatus;
    }
  }

  public String getCif() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(cif);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(cif);
    }
    else {
      return cif;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getAmount() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(amount);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(amount);
    }
    else {
      return amount;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getOtpts() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(otpts);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(otpts);
    }
    else {
      return otpts;
    }
  }

  public String getMobile() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(mobile);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(mobile);
    }
    else {
      return mobile;
    }
  }

  public String getOtp() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(otp);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(otp);
    }
    else {
      return otp;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public String getAccount() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(account);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(account);
    }
    else {
      return account;
    }
  }

  public void setRstatus(String value) {
    rstatus = value;
  }

  public void setCif(String value) {
    cif = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setAmount(String value) {
    amount = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setOtpts(String value) {
    otpts = value;
  }

  public void setMobile(String value) {
    mobile = value;
  }

  public void setOtp(String value) {
    otp = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void setAccount(String value) {
    account = value;
  }

  public void loadContent(KBAgentotpRecord inputRecord) {
    setRstatus(inputRecord.getRstatus());
    setCif(inputRecord.getCif());
    setCreatedat(inputRecord.getCreatedat());
    setAmount(inputRecord.getAmount());
    setCreatedby(inputRecord.getCreatedby());
    setModifiedat(inputRecord.getModifiedat());
    setOtpts(inputRecord.getOtpts());
    setMobile(inputRecord.getMobile());
    setOtp(inputRecord.getOtp());
    setModifiedby(inputRecord.getModifiedby());
    setId(inputRecord.getId());
    setAccount(inputRecord.getAccount());
  }

  public void loadNonNullContent(KBAgentotpRecord inputRecord) {
    if (StringUtils.hasChanged(getRstatus(), inputRecord.getRstatus())) {
      setRstatus(StringUtils.noNull(inputRecord.getRstatus()));
    }
    if (StringUtils.hasChanged(getCif(), inputRecord.getCif())) {
      setCif(StringUtils.noNull(inputRecord.getCif()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getAmount(), inputRecord.getAmount())) {
      setAmount(StringUtils.noNull(inputRecord.getAmount()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getOtpts(), inputRecord.getOtpts())) {
      setOtpts(StringUtils.noNull(inputRecord.getOtpts()));
    }
    if (StringUtils.hasChanged(getMobile(), inputRecord.getMobile())) {
      setMobile(StringUtils.noNull(inputRecord.getMobile()));
    }
    if (StringUtils.hasChanged(getOtp(), inputRecord.getOtp())) {
      setOtp(StringUtils.noNull(inputRecord.getOtp()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
    if (StringUtils.hasChanged(getAccount(), inputRecord.getAccount())) {
      setAccount(StringUtils.noNull(inputRecord.getAccount()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("cif",StringUtils.noNull(cif));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("amount",StringUtils.noNull(amount));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("otpts",StringUtils.noNull(otpts));
    obj.put("mobile",StringUtils.noNull(mobile));
    obj.put("otp",StringUtils.noNull(otp));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("account",StringUtils.noNull(account));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    rstatus = StringUtils.getValueFromJSONObject(obj, "rstatus");
    cif = StringUtils.getValueFromJSONObject(obj, "cif");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    amount = StringUtils.getValueFromJSONObject(obj, "amount");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    otpts = StringUtils.getValueFromJSONObject(obj, "otpts");
    mobile = StringUtils.getValueFromJSONObject(obj, "mobile");
    otp = StringUtils.getValueFromJSONObject(obj, "otp");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    id = StringUtils.getValueFromJSONObject(obj, "id");
    account = StringUtils.getValueFromJSONObject(obj, "account");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("cif",StringUtils.noNull(cif));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("amount",StringUtils.noNull(amount));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("otpts",StringUtils.noNull(otpts));
    obj.put("mobile",StringUtils.noNull(mobile));
    obj.put("otp",StringUtils.noNull(otp));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("account",StringUtils.noNull(account));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("rstatus");
    columnList.add("cif");
    columnList.add("createdat");
    columnList.add("amount");
    columnList.add("createdby");
    columnList.add("modifiedat");
    columnList.add("otpts");
    columnList.add("mobile");
    columnList.add("otp");
    columnList.add("modifiedby");
    columnList.add("id");
    columnList.add("account");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "rstatus:" + rstatus +"cif:" + cif +"createdat:" + createdat +"amount:" + amount +"createdby:" + createdby +"modifiedat:" + modifiedat +"otpts:" + otpts +"mobile:" + mobile +"otp:" + otp +"modifiedby:" + modifiedby +"id:" + id +"account:" + account +"";
  }
}
