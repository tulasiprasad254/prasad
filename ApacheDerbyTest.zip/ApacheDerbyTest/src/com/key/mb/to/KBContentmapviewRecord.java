package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBContentmapviewRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBContentmapviewRecord.class.getName());

  public String institutionid;

  public String modifiedat;

  public String statusname;

  public String iname;

  public String rstatus;

  public String ccode;

  public String createdat;

  public String cvalue;

  public String cseq;

  public String ctype;

  public String ccatg;

  public String createdby;

  public String modifiedby;

  public String id;

  public String getInstitutionid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(institutionid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(institutionid);
    }
    else {
      return institutionid;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getStatusname() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(statusname);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(statusname);
    }
    else {
      return statusname;
    }
  }

  public String getIname() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(iname);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(iname);
    }
    else {
      return iname;
    }
  }

  public String getRstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rstatus);
    }
    else {
      return rstatus;
    }
  }

  public String getCcode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(ccode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(ccode);
    }
    else {
      return ccode;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getCvalue() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(cvalue);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(cvalue);
    }
    else {
      return cvalue;
    }
  }

  public String getCseq() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(cseq);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(cseq);
    }
    else {
      return cseq;
    }
  }

  public String getCtype() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(ctype);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(ctype);
    }
    else {
      return ctype;
    }
  }

  public String getCcatg() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(ccatg);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(ccatg);
    }
    else {
      return ccatg;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public void setInstitutionid(String value) {
    institutionid = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setStatusname(String value) {
    statusname = value;
  }

  public void setIname(String value) {
    iname = value;
  }

  public void setRstatus(String value) {
    rstatus = value;
  }

  public void setCcode(String value) {
    ccode = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setCvalue(String value) {
    cvalue = value;
  }

  public void setCseq(String value) {
    cseq = value;
  }

  public void setCtype(String value) {
    ctype = value;
  }

  public void setCcatg(String value) {
    ccatg = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void loadContent(KBContentmapviewRecord inputRecord) {
    setInstitutionid(inputRecord.getInstitutionid());
    setModifiedat(inputRecord.getModifiedat());
    setStatusname(inputRecord.getStatusname());
    setIname(inputRecord.getIname());
    setRstatus(inputRecord.getRstatus());
    setCcode(inputRecord.getCcode());
    setCreatedat(inputRecord.getCreatedat());
    setCvalue(inputRecord.getCvalue());
    setCseq(inputRecord.getCseq());
    setCtype(inputRecord.getCtype());
    setCcatg(inputRecord.getCcatg());
    setCreatedby(inputRecord.getCreatedby());
    setModifiedby(inputRecord.getModifiedby());
    setId(inputRecord.getId());
  }

  public void loadNonNullContent(KBContentmapviewRecord inputRecord) {
    if (StringUtils.hasChanged(getInstitutionid(), inputRecord.getInstitutionid())) {
      setInstitutionid(StringUtils.noNull(inputRecord.getInstitutionid()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getStatusname(), inputRecord.getStatusname())) {
      setStatusname(StringUtils.noNull(inputRecord.getStatusname()));
    }
    if (StringUtils.hasChanged(getIname(), inputRecord.getIname())) {
      setIname(StringUtils.noNull(inputRecord.getIname()));
    }
    if (StringUtils.hasChanged(getRstatus(), inputRecord.getRstatus())) {
      setRstatus(StringUtils.noNull(inputRecord.getRstatus()));
    }
    if (StringUtils.hasChanged(getCcode(), inputRecord.getCcode())) {
      setCcode(StringUtils.noNull(inputRecord.getCcode()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getCvalue(), inputRecord.getCvalue())) {
      setCvalue(StringUtils.noNull(inputRecord.getCvalue()));
    }
    if (StringUtils.hasChanged(getCseq(), inputRecord.getCseq())) {
      setCseq(StringUtils.noNull(inputRecord.getCseq()));
    }
    if (StringUtils.hasChanged(getCtype(), inputRecord.getCtype())) {
      setCtype(StringUtils.noNull(inputRecord.getCtype()));
    }
    if (StringUtils.hasChanged(getCcatg(), inputRecord.getCcatg())) {
      setCcatg(StringUtils.noNull(inputRecord.getCcatg()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("institutionid",StringUtils.noNull(institutionid));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("statusname",StringUtils.noNull(statusname));
    obj.put("iname",StringUtils.noNull(iname));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("ccode",StringUtils.noNull(ccode));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("cvalue",StringUtils.noNull(cvalue));
    obj.put("cseq",StringUtils.noNull(cseq));
    obj.put("ctype",StringUtils.noNull(ctype));
    obj.put("ccatg",StringUtils.noNull(ccatg));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    institutionid = StringUtils.getValueFromJSONObject(obj, "institutionid");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    statusname = StringUtils.getValueFromJSONObject(obj, "statusname");
    iname = StringUtils.getValueFromJSONObject(obj, "iname");
    rstatus = StringUtils.getValueFromJSONObject(obj, "rstatus");
    ccode = StringUtils.getValueFromJSONObject(obj, "ccode");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    cvalue = StringUtils.getValueFromJSONObject(obj, "cvalue");
    cseq = StringUtils.getValueFromJSONObject(obj, "cseq");
    ctype = StringUtils.getValueFromJSONObject(obj, "ctype");
    ccatg = StringUtils.getValueFromJSONObject(obj, "ccatg");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    id = StringUtils.getValueFromJSONObject(obj, "id");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("institutionid",StringUtils.noNull(institutionid));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("statusname",StringUtils.noNull(statusname));
    obj.put("iname",StringUtils.noNull(iname));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("ccode",StringUtils.noNull(ccode));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("cvalue",StringUtils.noNull(cvalue));
    obj.put("cseq",StringUtils.noNull(cseq));
    obj.put("ctype",StringUtils.noNull(ctype));
    obj.put("ccatg",StringUtils.noNull(ccatg));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("institutionid");
    columnList.add("modifiedat");
    columnList.add("statusname");
    columnList.add("iname");
    columnList.add("rstatus");
    columnList.add("ccode");
    columnList.add("createdat");
    columnList.add("cvalue");
    columnList.add("cseq");
    columnList.add("ctype");
    columnList.add("ccatg");
    columnList.add("createdby");
    columnList.add("modifiedby");
    columnList.add("id");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "institutionid:" + institutionid +"modifiedat:" + modifiedat +"statusname:" + statusname +"iname:" + iname +"rstatus:" + rstatus +"ccode:" + ccode +"createdat:" + createdat +"cvalue:" + cvalue +"cseq:" + cseq +"ctype:" + ctype +"ccatg:" + ccatg +"createdby:" + createdby +"modifiedby:" + modifiedby +"id:" + id +"";
  }
}
