package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBAgencyRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBAgencyRecord.class.getName());

  public String busstat;

  public String currappstatus;

  public String institutionid;

  public String pstaddr;

  public String makerlastcmt;

  public String mastagcode;

  public String profprov;

  public String agtype;

  public String brnchcode;

  public String madeat;

  public String domibrnch;

  public String servpk;

  public String checkedat;

  public String mnthlimit;

  public String createdby;

  public String pstzip;

  public String busname;

  public String id;

  public String dlylimit;

  public String extn4;

  public String busloc;

  public String extn3;

  public String extn2;

  public String busnationality;

  public String extn1;

  public String modifiedat;

  public String lrnum;

  public String busdesig;

  public String madeby;

  public String adminlastcmt;

  public String nationalty;

  public String checkerlastcmt;

  public String extn5;

  public String rstatus;

  public String createdat;

  public String pstcity;

  public String profagcode;

  public String checkedby;

  public String profcont2;

  public String profcont1;

  public String phyaddr;

  public String modifiedby;

  public String accnum3;

  public String trdname;

  public String accnum2;

  public String accnum1;

  public String getBusstat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(busstat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(busstat);
    }
    else {
      return busstat;
    }
  }

  public String getCurrappstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(currappstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(currappstatus);
    }
    else {
      return currappstatus;
    }
  }

  public String getInstitutionid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(institutionid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(institutionid);
    }
    else {
      return institutionid;
    }
  }

  public String getPstaddr() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(pstaddr);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(pstaddr);
    }
    else {
      return pstaddr;
    }
  }

  public String getMakerlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(makerlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(makerlastcmt);
    }
    else {
      return makerlastcmt;
    }
  }

  public String getMastagcode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(mastagcode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(mastagcode);
    }
    else {
      return mastagcode;
    }
  }

  public String getProfprov() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(profprov);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(profprov);
    }
    else {
      return profprov;
    }
  }

  public String getAgtype() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(agtype);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(agtype);
    }
    else {
      return agtype;
    }
  }

  public String getBrnchcode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(brnchcode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(brnchcode);
    }
    else {
      return brnchcode;
    }
  }

  public String getMadeat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(madeat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(madeat);
    }
    else {
      return madeat;
    }
  }

  public String getDomibrnch() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(domibrnch);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(domibrnch);
    }
    else {
      return domibrnch;
    }
  }

  public String getServpk() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(servpk);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(servpk);
    }
    else {
      return servpk;
    }
  }

  public String getCheckedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkedat);
    }
    else {
      return checkedat;
    }
  }

  public String getMnthlimit() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(mnthlimit);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(mnthlimit);
    }
    else {
      return mnthlimit;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getPstzip() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(pstzip);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(pstzip);
    }
    else {
      return pstzip;
    }
  }

  public String getBusname() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(busname);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(busname);
    }
    else {
      return busname;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public String getDlylimit() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(dlylimit);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(dlylimit);
    }
    else {
      return dlylimit;
    }
  }

  public String getExtn4() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(extn4);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(extn4);
    }
    else {
      return extn4;
    }
  }

  public String getBusloc() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(busloc);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(busloc);
    }
    else {
      return busloc;
    }
  }

  public String getExtn3() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(extn3);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(extn3);
    }
    else {
      return extn3;
    }
  }

  public String getExtn2() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(extn2);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(extn2);
    }
    else {
      return extn2;
    }
  }

  public String getBusnationality() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(busnationality);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(busnationality);
    }
    else {
      return busnationality;
    }
  }

  public String getExtn1() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(extn1);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(extn1);
    }
    else {
      return extn1;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getLrnum() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(lrnum);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(lrnum);
    }
    else {
      return lrnum;
    }
  }

  public String getBusdesig() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(busdesig);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(busdesig);
    }
    else {
      return busdesig;
    }
  }

  public String getMadeby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(madeby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(madeby);
    }
    else {
      return madeby;
    }
  }

  public String getAdminlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(adminlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(adminlastcmt);
    }
    else {
      return adminlastcmt;
    }
  }

  public String getNationalty() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(nationalty);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(nationalty);
    }
    else {
      return nationalty;
    }
  }

  public String getCheckerlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkerlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkerlastcmt);
    }
    else {
      return checkerlastcmt;
    }
  }

  public String getExtn5() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(extn5);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(extn5);
    }
    else {
      return extn5;
    }
  }

  public String getRstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rstatus);
    }
    else {
      return rstatus;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getPstcity() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(pstcity);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(pstcity);
    }
    else {
      return pstcity;
    }
  }

  public String getProfagcode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(profagcode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(profagcode);
    }
    else {
      return profagcode;
    }
  }

  public String getCheckedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkedby);
    }
    else {
      return checkedby;
    }
  }

  public String getProfcont2() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(profcont2);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(profcont2);
    }
    else {
      return profcont2;
    }
  }

  public String getProfcont1() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(profcont1);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(profcont1);
    }
    else {
      return profcont1;
    }
  }

  public String getPhyaddr() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(phyaddr);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(phyaddr);
    }
    else {
      return phyaddr;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getAccnum3() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(accnum3);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(accnum3);
    }
    else {
      return accnum3;
    }
  }

  public String getTrdname() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(trdname);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(trdname);
    }
    else {
      return trdname;
    }
  }

  public String getAccnum2() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(accnum2);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(accnum2);
    }
    else {
      return accnum2;
    }
  }

  public String getAccnum1() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(accnum1);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(accnum1);
    }
    else {
      return accnum1;
    }
  }

  public void setBusstat(String value) {
    busstat = value;
  }

  public void setCurrappstatus(String value) {
    currappstatus = value;
  }

  public void setInstitutionid(String value) {
    institutionid = value;
  }

  public void setPstaddr(String value) {
    pstaddr = value;
  }

  public void setMakerlastcmt(String value) {
    makerlastcmt = value;
  }

  public void setMastagcode(String value) {
    mastagcode = value;
  }

  public void setProfprov(String value) {
    profprov = value;
  }

  public void setAgtype(String value) {
    agtype = value;
  }

  public void setBrnchcode(String value) {
    brnchcode = value;
  }

  public void setMadeat(String value) {
    madeat = value;
  }

  public void setDomibrnch(String value) {
    domibrnch = value;
  }

  public void setServpk(String value) {
    servpk = value;
  }

  public void setCheckedat(String value) {
    checkedat = value;
  }

  public void setMnthlimit(String value) {
    mnthlimit = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setPstzip(String value) {
    pstzip = value;
  }

  public void setBusname(String value) {
    busname = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void setDlylimit(String value) {
    dlylimit = value;
  }

  public void setExtn4(String value) {
    extn4 = value;
  }

  public void setBusloc(String value) {
    busloc = value;
  }

  public void setExtn3(String value) {
    extn3 = value;
  }

  public void setExtn2(String value) {
    extn2 = value;
  }

  public void setBusnationality(String value) {
    busnationality = value;
  }

  public void setExtn1(String value) {
    extn1 = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setLrnum(String value) {
    lrnum = value;
  }

  public void setBusdesig(String value) {
    busdesig = value;
  }

  public void setMadeby(String value) {
    madeby = value;
  }

  public void setAdminlastcmt(String value) {
    adminlastcmt = value;
  }

  public void setNationalty(String value) {
    nationalty = value;
  }

  public void setCheckerlastcmt(String value) {
    checkerlastcmt = value;
  }

  public void setExtn5(String value) {
    extn5 = value;
  }

  public void setRstatus(String value) {
    rstatus = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setPstcity(String value) {
    pstcity = value;
  }

  public void setProfagcode(String value) {
    profagcode = value;
  }

  public void setCheckedby(String value) {
    checkedby = value;
  }

  public void setProfcont2(String value) {
    profcont2 = value;
  }

  public void setProfcont1(String value) {
    profcont1 = value;
  }

  public void setPhyaddr(String value) {
    phyaddr = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setAccnum3(String value) {
    accnum3 = value;
  }

  public void setTrdname(String value) {
    trdname = value;
  }

  public void setAccnum2(String value) {
    accnum2 = value;
  }

  public void setAccnum1(String value) {
    accnum1 = value;
  }

  public void loadContent(KBAgencyRecord inputRecord) {
    setBusstat(inputRecord.getBusstat());
    setCurrappstatus(inputRecord.getCurrappstatus());
    setInstitutionid(inputRecord.getInstitutionid());
    setPstaddr(inputRecord.getPstaddr());
    setMakerlastcmt(inputRecord.getMakerlastcmt());
    setMastagcode(inputRecord.getMastagcode());
    setProfprov(inputRecord.getProfprov());
    setAgtype(inputRecord.getAgtype());
    setBrnchcode(inputRecord.getBrnchcode());
    setMadeat(inputRecord.getMadeat());
    setDomibrnch(inputRecord.getDomibrnch());
    setServpk(inputRecord.getServpk());
    setCheckedat(inputRecord.getCheckedat());
    setMnthlimit(inputRecord.getMnthlimit());
    setCreatedby(inputRecord.getCreatedby());
    setPstzip(inputRecord.getPstzip());
    setBusname(inputRecord.getBusname());
    setId(inputRecord.getId());
    setDlylimit(inputRecord.getDlylimit());
    setExtn4(inputRecord.getExtn4());
    setBusloc(inputRecord.getBusloc());
    setExtn3(inputRecord.getExtn3());
    setExtn2(inputRecord.getExtn2());
    setBusnationality(inputRecord.getBusnationality());
    setExtn1(inputRecord.getExtn1());
    setModifiedat(inputRecord.getModifiedat());
    setLrnum(inputRecord.getLrnum());
    setBusdesig(inputRecord.getBusdesig());
    setMadeby(inputRecord.getMadeby());
    setAdminlastcmt(inputRecord.getAdminlastcmt());
    setNationalty(inputRecord.getNationalty());
    setCheckerlastcmt(inputRecord.getCheckerlastcmt());
    setExtn5(inputRecord.getExtn5());
    setRstatus(inputRecord.getRstatus());
    setCreatedat(inputRecord.getCreatedat());
    setPstcity(inputRecord.getPstcity());
    setProfagcode(inputRecord.getProfagcode());
    setCheckedby(inputRecord.getCheckedby());
    setProfcont2(inputRecord.getProfcont2());
    setProfcont1(inputRecord.getProfcont1());
    setPhyaddr(inputRecord.getPhyaddr());
    setModifiedby(inputRecord.getModifiedby());
    setAccnum3(inputRecord.getAccnum3());
    setTrdname(inputRecord.getTrdname());
    setAccnum2(inputRecord.getAccnum2());
    setAccnum1(inputRecord.getAccnum1());
  }

  public void loadNonNullContent(KBAgencyRecord inputRecord) {
    if (StringUtils.hasChanged(getBusstat(), inputRecord.getBusstat())) {
      setBusstat(StringUtils.noNull(inputRecord.getBusstat()));
    }
    if (StringUtils.hasChanged(getCurrappstatus(), inputRecord.getCurrappstatus())) {
      setCurrappstatus(StringUtils.noNull(inputRecord.getCurrappstatus()));
    }
    if (StringUtils.hasChanged(getInstitutionid(), inputRecord.getInstitutionid())) {
      setInstitutionid(StringUtils.noNull(inputRecord.getInstitutionid()));
    }
    if (StringUtils.hasChanged(getPstaddr(), inputRecord.getPstaddr())) {
      setPstaddr(StringUtils.noNull(inputRecord.getPstaddr()));
    }
    if (StringUtils.hasChanged(getMakerlastcmt(), inputRecord.getMakerlastcmt())) {
      setMakerlastcmt(StringUtils.noNull(inputRecord.getMakerlastcmt()));
    }
    if (StringUtils.hasChanged(getMastagcode(), inputRecord.getMastagcode())) {
      setMastagcode(StringUtils.noNull(inputRecord.getMastagcode()));
    }
    if (StringUtils.hasChanged(getProfprov(), inputRecord.getProfprov())) {
      setProfprov(StringUtils.noNull(inputRecord.getProfprov()));
    }
    if (StringUtils.hasChanged(getAgtype(), inputRecord.getAgtype())) {
      setAgtype(StringUtils.noNull(inputRecord.getAgtype()));
    }
    if (StringUtils.hasChanged(getBrnchcode(), inputRecord.getBrnchcode())) {
      setBrnchcode(StringUtils.noNull(inputRecord.getBrnchcode()));
    }
    if (StringUtils.hasChanged(getMadeat(), inputRecord.getMadeat())) {
      setMadeat(StringUtils.noNull(inputRecord.getMadeat()));
    }
    if (StringUtils.hasChanged(getDomibrnch(), inputRecord.getDomibrnch())) {
      setDomibrnch(StringUtils.noNull(inputRecord.getDomibrnch()));
    }
    if (StringUtils.hasChanged(getServpk(), inputRecord.getServpk())) {
      setServpk(StringUtils.noNull(inputRecord.getServpk()));
    }
    if (StringUtils.hasChanged(getCheckedat(), inputRecord.getCheckedat())) {
      setCheckedat(StringUtils.noNull(inputRecord.getCheckedat()));
    }
    if (StringUtils.hasChanged(getMnthlimit(), inputRecord.getMnthlimit())) {
      setMnthlimit(StringUtils.noNull(inputRecord.getMnthlimit()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getPstzip(), inputRecord.getPstzip())) {
      setPstzip(StringUtils.noNull(inputRecord.getPstzip()));
    }
    if (StringUtils.hasChanged(getBusname(), inputRecord.getBusname())) {
      setBusname(StringUtils.noNull(inputRecord.getBusname()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
    if (StringUtils.hasChanged(getDlylimit(), inputRecord.getDlylimit())) {
      setDlylimit(StringUtils.noNull(inputRecord.getDlylimit()));
    }
    if (StringUtils.hasChanged(getExtn4(), inputRecord.getExtn4())) {
      setExtn4(StringUtils.noNull(inputRecord.getExtn4()));
    }
    if (StringUtils.hasChanged(getBusloc(), inputRecord.getBusloc())) {
      setBusloc(StringUtils.noNull(inputRecord.getBusloc()));
    }
    if (StringUtils.hasChanged(getExtn3(), inputRecord.getExtn3())) {
      setExtn3(StringUtils.noNull(inputRecord.getExtn3()));
    }
    if (StringUtils.hasChanged(getExtn2(), inputRecord.getExtn2())) {
      setExtn2(StringUtils.noNull(inputRecord.getExtn2()));
    }
    if (StringUtils.hasChanged(getBusnationality(), inputRecord.getBusnationality())) {
      setBusnationality(StringUtils.noNull(inputRecord.getBusnationality()));
    }
    if (StringUtils.hasChanged(getExtn1(), inputRecord.getExtn1())) {
      setExtn1(StringUtils.noNull(inputRecord.getExtn1()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getLrnum(), inputRecord.getLrnum())) {
      setLrnum(StringUtils.noNull(inputRecord.getLrnum()));
    }
    if (StringUtils.hasChanged(getBusdesig(), inputRecord.getBusdesig())) {
      setBusdesig(StringUtils.noNull(inputRecord.getBusdesig()));
    }
    if (StringUtils.hasChanged(getMadeby(), inputRecord.getMadeby())) {
      setMadeby(StringUtils.noNull(inputRecord.getMadeby()));
    }
    if (StringUtils.hasChanged(getAdminlastcmt(), inputRecord.getAdminlastcmt())) {
      setAdminlastcmt(StringUtils.noNull(inputRecord.getAdminlastcmt()));
    }
    if (StringUtils.hasChanged(getNationalty(), inputRecord.getNationalty())) {
      setNationalty(StringUtils.noNull(inputRecord.getNationalty()));
    }
    if (StringUtils.hasChanged(getCheckerlastcmt(), inputRecord.getCheckerlastcmt())) {
      setCheckerlastcmt(StringUtils.noNull(inputRecord.getCheckerlastcmt()));
    }
    if (StringUtils.hasChanged(getExtn5(), inputRecord.getExtn5())) {
      setExtn5(StringUtils.noNull(inputRecord.getExtn5()));
    }
    if (StringUtils.hasChanged(getRstatus(), inputRecord.getRstatus())) {
      setRstatus(StringUtils.noNull(inputRecord.getRstatus()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getPstcity(), inputRecord.getPstcity())) {
      setPstcity(StringUtils.noNull(inputRecord.getPstcity()));
    }
    if (StringUtils.hasChanged(getProfagcode(), inputRecord.getProfagcode())) {
      setProfagcode(StringUtils.noNull(inputRecord.getProfagcode()));
    }
    if (StringUtils.hasChanged(getCheckedby(), inputRecord.getCheckedby())) {
      setCheckedby(StringUtils.noNull(inputRecord.getCheckedby()));
    }
    if (StringUtils.hasChanged(getProfcont2(), inputRecord.getProfcont2())) {
      setProfcont2(StringUtils.noNull(inputRecord.getProfcont2()));
    }
    if (StringUtils.hasChanged(getProfcont1(), inputRecord.getProfcont1())) {
      setProfcont1(StringUtils.noNull(inputRecord.getProfcont1()));
    }
    if (StringUtils.hasChanged(getPhyaddr(), inputRecord.getPhyaddr())) {
      setPhyaddr(StringUtils.noNull(inputRecord.getPhyaddr()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getAccnum3(), inputRecord.getAccnum3())) {
      setAccnum3(StringUtils.noNull(inputRecord.getAccnum3()));
    }
    if (StringUtils.hasChanged(getTrdname(), inputRecord.getTrdname())) {
      setTrdname(StringUtils.noNull(inputRecord.getTrdname()));
    }
    if (StringUtils.hasChanged(getAccnum2(), inputRecord.getAccnum2())) {
      setAccnum2(StringUtils.noNull(inputRecord.getAccnum2()));
    }
    if (StringUtils.hasChanged(getAccnum1(), inputRecord.getAccnum1())) {
      setAccnum1(StringUtils.noNull(inputRecord.getAccnum1()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("busstat",StringUtils.noNull(busstat));
    obj.put("currappstatus",StringUtils.noNull(currappstatus));
    obj.put("institutionid",StringUtils.noNull(institutionid));
    obj.put("pstaddr",StringUtils.noNull(pstaddr));
    obj.put("makerlastcmt",StringUtils.noNull(makerlastcmt));
    obj.put("mastagcode",StringUtils.noNull(mastagcode));
    obj.put("profprov",StringUtils.noNull(profprov));
    obj.put("agtype",StringUtils.noNull(agtype));
    obj.put("brnchcode",StringUtils.noNull(brnchcode));
    obj.put("madeat",StringUtils.noNull(madeat));
    obj.put("domibrnch",StringUtils.noNull(domibrnch));
    obj.put("servpk",StringUtils.noNull(servpk));
    obj.put("checkedat",StringUtils.noNull(checkedat));
    obj.put("mnthlimit",StringUtils.noNull(mnthlimit));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("pstzip",StringUtils.noNull(pstzip));
    obj.put("busname",StringUtils.noNull(busname));
    obj.put("id",StringUtils.noNull(id));
    obj.put("dlylimit",StringUtils.noNull(dlylimit));
    obj.put("extn4",StringUtils.noNull(extn4));
    obj.put("busloc",StringUtils.noNull(busloc));
    obj.put("extn3",StringUtils.noNull(extn3));
    obj.put("extn2",StringUtils.noNull(extn2));
    obj.put("busnationality",StringUtils.noNull(busnationality));
    obj.put("extn1",StringUtils.noNull(extn1));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("lrnum",StringUtils.noNull(lrnum));
    obj.put("busdesig",StringUtils.noNull(busdesig));
    obj.put("madeby",StringUtils.noNull(madeby));
    obj.put("adminlastcmt",StringUtils.noNull(adminlastcmt));
    obj.put("nationalty",StringUtils.noNull(nationalty));
    obj.put("checkerlastcmt",StringUtils.noNull(checkerlastcmt));
    obj.put("extn5",StringUtils.noNull(extn5));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("pstcity",StringUtils.noNull(pstcity));
    obj.put("profagcode",StringUtils.noNull(profagcode));
    obj.put("checkedby",StringUtils.noNull(checkedby));
    obj.put("profcont2",StringUtils.noNull(profcont2));
    obj.put("profcont1",StringUtils.noNull(profcont1));
    obj.put("phyaddr",StringUtils.noNull(phyaddr));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("accnum3",StringUtils.noNull(accnum3));
    obj.put("trdname",StringUtils.noNull(trdname));
    obj.put("accnum2",StringUtils.noNull(accnum2));
    obj.put("accnum1",StringUtils.noNull(accnum1));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    busstat = StringUtils.getValueFromJSONObject(obj, "busstat");
    currappstatus = StringUtils.getValueFromJSONObject(obj, "currappstatus");
    institutionid = StringUtils.getValueFromJSONObject(obj, "institutionid");
    pstaddr = StringUtils.getValueFromJSONObject(obj, "pstaddr");
    makerlastcmt = StringUtils.getValueFromJSONObject(obj, "makerlastcmt");
    mastagcode = StringUtils.getValueFromJSONObject(obj, "mastagcode");
    profprov = StringUtils.getValueFromJSONObject(obj, "profprov");
    agtype = StringUtils.getValueFromJSONObject(obj, "agtype");
    brnchcode = StringUtils.getValueFromJSONObject(obj, "brnchcode");
    madeat = StringUtils.getValueFromJSONObject(obj, "madeat");
    domibrnch = StringUtils.getValueFromJSONObject(obj, "domibrnch");
    servpk = StringUtils.getValueFromJSONObject(obj, "servpk");
    checkedat = StringUtils.getValueFromJSONObject(obj, "checkedat");
    mnthlimit = StringUtils.getValueFromJSONObject(obj, "mnthlimit");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    pstzip = StringUtils.getValueFromJSONObject(obj, "pstzip");
    busname = StringUtils.getValueFromJSONObject(obj, "busname");
    id = StringUtils.getValueFromJSONObject(obj, "id");
    dlylimit = StringUtils.getValueFromJSONObject(obj, "dlylimit");
    extn4 = StringUtils.getValueFromJSONObject(obj, "extn4");
    busloc = StringUtils.getValueFromJSONObject(obj, "busloc");
    extn3 = StringUtils.getValueFromJSONObject(obj, "extn3");
    extn2 = StringUtils.getValueFromJSONObject(obj, "extn2");
    busnationality = StringUtils.getValueFromJSONObject(obj, "busnationality");
    extn1 = StringUtils.getValueFromJSONObject(obj, "extn1");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    lrnum = StringUtils.getValueFromJSONObject(obj, "lrnum");
    busdesig = StringUtils.getValueFromJSONObject(obj, "busdesig");
    madeby = StringUtils.getValueFromJSONObject(obj, "madeby");
    adminlastcmt = StringUtils.getValueFromJSONObject(obj, "adminlastcmt");
    nationalty = StringUtils.getValueFromJSONObject(obj, "nationalty");
    checkerlastcmt = StringUtils.getValueFromJSONObject(obj, "checkerlastcmt");
    extn5 = StringUtils.getValueFromJSONObject(obj, "extn5");
    rstatus = StringUtils.getValueFromJSONObject(obj, "rstatus");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    pstcity = StringUtils.getValueFromJSONObject(obj, "pstcity");
    profagcode = StringUtils.getValueFromJSONObject(obj, "profagcode");
    checkedby = StringUtils.getValueFromJSONObject(obj, "checkedby");
    profcont2 = StringUtils.getValueFromJSONObject(obj, "profcont2");
    profcont1 = StringUtils.getValueFromJSONObject(obj, "profcont1");
    phyaddr = StringUtils.getValueFromJSONObject(obj, "phyaddr");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    accnum3 = StringUtils.getValueFromJSONObject(obj, "accnum3");
    trdname = StringUtils.getValueFromJSONObject(obj, "trdname");
    accnum2 = StringUtils.getValueFromJSONObject(obj, "accnum2");
    accnum1 = StringUtils.getValueFromJSONObject(obj, "accnum1");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("busstat",StringUtils.noNull(busstat));
    obj.put("currappstatus",StringUtils.noNull(currappstatus));
    obj.put("institutionid",StringUtils.noNull(institutionid));
    obj.put("pstaddr",StringUtils.noNull(pstaddr));
    obj.put("makerlastcmt",StringUtils.noNull(makerlastcmt));
    obj.put("mastagcode",StringUtils.noNull(mastagcode));
    obj.put("profprov",StringUtils.noNull(profprov));
    obj.put("agtype",StringUtils.noNull(agtype));
    obj.put("brnchcode",StringUtils.noNull(brnchcode));
    obj.put("madeat",StringUtils.noNull(madeat));
    obj.put("domibrnch",StringUtils.noNull(domibrnch));
    obj.put("servpk",StringUtils.noNull(servpk));
    obj.put("checkedat",StringUtils.noNull(checkedat));
    obj.put("mnthlimit",StringUtils.noNull(mnthlimit));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("pstzip",StringUtils.noNull(pstzip));
    obj.put("busname",StringUtils.noNull(busname));
    obj.put("id",StringUtils.noNull(id));
    obj.put("dlylimit",StringUtils.noNull(dlylimit));
    obj.put("extn4",StringUtils.noNull(extn4));
    obj.put("busloc",StringUtils.noNull(busloc));
    obj.put("extn3",StringUtils.noNull(extn3));
    obj.put("extn2",StringUtils.noNull(extn2));
    obj.put("busnationality",StringUtils.noNull(busnationality));
    obj.put("extn1",StringUtils.noNull(extn1));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("lrnum",StringUtils.noNull(lrnum));
    obj.put("busdesig",StringUtils.noNull(busdesig));
    obj.put("madeby",StringUtils.noNull(madeby));
    obj.put("adminlastcmt",StringUtils.noNull(adminlastcmt));
    obj.put("nationalty",StringUtils.noNull(nationalty));
    obj.put("checkerlastcmt",StringUtils.noNull(checkerlastcmt));
    obj.put("extn5",StringUtils.noNull(extn5));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("pstcity",StringUtils.noNull(pstcity));
    obj.put("profagcode",StringUtils.noNull(profagcode));
    obj.put("checkedby",StringUtils.noNull(checkedby));
    obj.put("profcont2",StringUtils.noNull(profcont2));
    obj.put("profcont1",StringUtils.noNull(profcont1));
    obj.put("phyaddr",StringUtils.noNull(phyaddr));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("accnum3",StringUtils.noNull(accnum3));
    obj.put("trdname",StringUtils.noNull(trdname));
    obj.put("accnum2",StringUtils.noNull(accnum2));
    obj.put("accnum1",StringUtils.noNull(accnum1));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("busstat");
    columnList.add("currappstatus");
    columnList.add("institutionid");
    columnList.add("pstaddr");
    columnList.add("makerlastcmt");
    columnList.add("mastagcode");
    columnList.add("profprov");
    columnList.add("agtype");
    columnList.add("brnchcode");
    columnList.add("madeat");
    columnList.add("domibrnch");
    columnList.add("servpk");
    columnList.add("checkedat");
    columnList.add("mnthlimit");
    columnList.add("createdby");
    columnList.add("pstzip");
    columnList.add("busname");
    columnList.add("id");
    columnList.add("dlylimit");
    columnList.add("extn4");
    columnList.add("busloc");
    columnList.add("extn3");
    columnList.add("extn2");
    columnList.add("busnationality");
    columnList.add("extn1");
    columnList.add("modifiedat");
    columnList.add("lrnum");
    columnList.add("busdesig");
    columnList.add("madeby");
    columnList.add("adminlastcmt");
    columnList.add("nationalty");
    columnList.add("checkerlastcmt");
    columnList.add("extn5");
    columnList.add("rstatus");
    columnList.add("createdat");
    columnList.add("pstcity");
    columnList.add("profagcode");
    columnList.add("checkedby");
    columnList.add("profcont2");
    columnList.add("profcont1");
    columnList.add("phyaddr");
    columnList.add("modifiedby");
    columnList.add("accnum3");
    columnList.add("trdname");
    columnList.add("accnum2");
    columnList.add("accnum1");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "busstat:" + busstat +"currappstatus:" + currappstatus +"institutionid:" + institutionid +"pstaddr:" + pstaddr +"makerlastcmt:" + makerlastcmt +"mastagcode:" + mastagcode +"profprov:" + profprov +"agtype:" + agtype +"brnchcode:" + brnchcode +"madeat:" + madeat +"domibrnch:" + domibrnch +"servpk:" + servpk +"checkedat:" + checkedat +"mnthlimit:" + mnthlimit +"createdby:" + createdby +"pstzip:" + pstzip +"busname:" + busname +"id:" + id +"dlylimit:" + dlylimit +"extn4:" + extn4 +"busloc:" + busloc +"extn3:" + extn3 +"extn2:" + extn2 +"busnationality:" + busnationality +"extn1:" + extn1 +"modifiedat:" + modifiedat +"lrnum:" + lrnum +"busdesig:" + busdesig +"madeby:" + madeby +"adminlastcmt:" + adminlastcmt +"nationalty:" + nationalty +"checkerlastcmt:" + checkerlastcmt +"extn5:" + extn5 +"rstatus:" + rstatus +"createdat:" + createdat +"pstcity:" + pstcity +"profagcode:" + profagcode +"checkedby:" + checkedby +"profcont2:" + profcont2 +"profcont1:" + profcont1 +"phyaddr:" + phyaddr +"modifiedby:" + modifiedby +"accnum3:" + accnum3 +"trdname:" + trdname +"accnum2:" + accnum2 +"accnum1:" + accnum1 +"";
  }
}
