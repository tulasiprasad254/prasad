package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBAirteltranRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBAirteltranRecord.class.getName());

  public String airtelchrgts;

  public String currappstatus;

  public String taxresult;

  public String custtrnsts;

  public String safaricomcharges;

  public String bankchrgresultcode;

  public String dest;

  public String atsender;

  public String madeat;

  public String attdate;

  public String aterrmsg;

  public String custtrnsamt;

  public String createdby;

  public String attamt;

  public String atcustid;

  public String id;

  public String requestsourceip;

  public String atresp;

  public String suspenseresult;

  public String atid;

  public String suspensechrgamt;

  public String taxresultcode;

  public String atttime;

  public String airtelchrgresult;

  public String madeby;

  public String adminlastcmt;

  public String bankchrgamt;

  public String checkerlastcmt;

  public String rstatus;

  public String createdat;

  public String tstamp;

  public String atcode;

  public String modifiedby;

  public String taxamt;

  public String makerlastcmt;

  public String suspensechrgts;

  public String statusdesc;

  public String atrtmethodid;

  public String bankchrgresult;

  public String checkedat;

  public String rcvbtrnsresultcode;

  public String atpass;

  public String rcvbtrnsts;

  public String atuser;

  public String custtrnsresult;

  public String atacc;

  public String airtelchrgresultcode;

  public String modifiedat;

  public String rcvbtrnsresult;

  public String airtelchrgamt;

  public String bankcharges;

  public String suspenseresultcode;

  public String rcvbtrnsamt;

  public String bankchrgts;

  public String orig;

  public String checkedby;

  public String atrtmethodname;

  public String custtrnsresultcode;

  public String taxts;

  public String atisdn;

  public String attext;

  public String getAirtelchrgts() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(airtelchrgts);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(airtelchrgts);
    }
    else {
      return airtelchrgts;
    }
  }

  public String getCurrappstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(currappstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(currappstatus);
    }
    else {
      return currappstatus;
    }
  }

  public String getTaxresult() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(taxresult);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(taxresult);
    }
    else {
      return taxresult;
    }
  }

  public String getCusttrnsts() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(custtrnsts);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(custtrnsts);
    }
    else {
      return custtrnsts;
    }
  }

  public String getSafaricomcharges() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(safaricomcharges);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(safaricomcharges);
    }
    else {
      return safaricomcharges;
    }
  }

  public String getBankchrgresultcode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(bankchrgresultcode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(bankchrgresultcode);
    }
    else {
      return bankchrgresultcode;
    }
  }

  public String getDest() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(dest);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(dest);
    }
    else {
      return dest;
    }
  }

  public String getAtsender() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(atsender);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(atsender);
    }
    else {
      return atsender;
    }
  }

  public String getMadeat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(madeat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(madeat);
    }
    else {
      return madeat;
    }
  }

  public String getAttdate() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(attdate);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(attdate);
    }
    else {
      return attdate;
    }
  }

  public String getAterrmsg() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(aterrmsg);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(aterrmsg);
    }
    else {
      return aterrmsg;
    }
  }

  public String getCusttrnsamt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(custtrnsamt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(custtrnsamt);
    }
    else {
      return custtrnsamt;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getAttamt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(attamt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(attamt);
    }
    else {
      return attamt;
    }
  }

  public String getAtcustid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(atcustid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(atcustid);
    }
    else {
      return atcustid;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public String getRequestsourceip() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(requestsourceip);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(requestsourceip);
    }
    else {
      return requestsourceip;
    }
  }

  public String getAtresp() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(atresp);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(atresp);
    }
    else {
      return atresp;
    }
  }

  public String getSuspenseresult() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(suspenseresult);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(suspenseresult);
    }
    else {
      return suspenseresult;
    }
  }

  public String getAtid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(atid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(atid);
    }
    else {
      return atid;
    }
  }

  public String getSuspensechrgamt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(suspensechrgamt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(suspensechrgamt);
    }
    else {
      return suspensechrgamt;
    }
  }

  public String getTaxresultcode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(taxresultcode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(taxresultcode);
    }
    else {
      return taxresultcode;
    }
  }

  public String getAtttime() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(atttime);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(atttime);
    }
    else {
      return atttime;
    }
  }

  public String getAirtelchrgresult() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(airtelchrgresult);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(airtelchrgresult);
    }
    else {
      return airtelchrgresult;
    }
  }

  public String getMadeby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(madeby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(madeby);
    }
    else {
      return madeby;
    }
  }

  public String getAdminlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(adminlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(adminlastcmt);
    }
    else {
      return adminlastcmt;
    }
  }

  public String getBankchrgamt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(bankchrgamt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(bankchrgamt);
    }
    else {
      return bankchrgamt;
    }
  }

  public String getCheckerlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkerlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkerlastcmt);
    }
    else {
      return checkerlastcmt;
    }
  }

  public String getRstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rstatus);
    }
    else {
      return rstatus;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getTstamp() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(tstamp);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(tstamp);
    }
    else {
      return tstamp;
    }
  }

  public String getAtcode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(atcode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(atcode);
    }
    else {
      return atcode;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getTaxamt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(taxamt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(taxamt);
    }
    else {
      return taxamt;
    }
  }

  public String getMakerlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(makerlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(makerlastcmt);
    }
    else {
      return makerlastcmt;
    }
  }

  public String getSuspensechrgts() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(suspensechrgts);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(suspensechrgts);
    }
    else {
      return suspensechrgts;
    }
  }

  public String getStatusdesc() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(statusdesc);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(statusdesc);
    }
    else {
      return statusdesc;
    }
  }

  public String getAtrtmethodid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(atrtmethodid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(atrtmethodid);
    }
    else {
      return atrtmethodid;
    }
  }

  public String getBankchrgresult() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(bankchrgresult);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(bankchrgresult);
    }
    else {
      return bankchrgresult;
    }
  }

  public String getCheckedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkedat);
    }
    else {
      return checkedat;
    }
  }

  public String getRcvbtrnsresultcode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rcvbtrnsresultcode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rcvbtrnsresultcode);
    }
    else {
      return rcvbtrnsresultcode;
    }
  }

  public String getAtpass() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(atpass);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(atpass);
    }
    else {
      return atpass;
    }
  }

  public String getRcvbtrnsts() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rcvbtrnsts);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rcvbtrnsts);
    }
    else {
      return rcvbtrnsts;
    }
  }

  public String getAtuser() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(atuser);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(atuser);
    }
    else {
      return atuser;
    }
  }

  public String getCusttrnsresult() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(custtrnsresult);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(custtrnsresult);
    }
    else {
      return custtrnsresult;
    }
  }

  public String getAtacc() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(atacc);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(atacc);
    }
    else {
      return atacc;
    }
  }

  public String getAirtelchrgresultcode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(airtelchrgresultcode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(airtelchrgresultcode);
    }
    else {
      return airtelchrgresultcode;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getRcvbtrnsresult() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rcvbtrnsresult);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rcvbtrnsresult);
    }
    else {
      return rcvbtrnsresult;
    }
  }

  public String getAirtelchrgamt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(airtelchrgamt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(airtelchrgamt);
    }
    else {
      return airtelchrgamt;
    }
  }

  public String getBankcharges() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(bankcharges);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(bankcharges);
    }
    else {
      return bankcharges;
    }
  }

  public String getSuspenseresultcode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(suspenseresultcode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(suspenseresultcode);
    }
    else {
      return suspenseresultcode;
    }
  }

  public String getRcvbtrnsamt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rcvbtrnsamt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rcvbtrnsamt);
    }
    else {
      return rcvbtrnsamt;
    }
  }

  public String getBankchrgts() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(bankchrgts);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(bankchrgts);
    }
    else {
      return bankchrgts;
    }
  }

  public String getOrig() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(orig);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(orig);
    }
    else {
      return orig;
    }
  }

  public String getCheckedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkedby);
    }
    else {
      return checkedby;
    }
  }

  public String getAtrtmethodname() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(atrtmethodname);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(atrtmethodname);
    }
    else {
      return atrtmethodname;
    }
  }

  public String getCusttrnsresultcode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(custtrnsresultcode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(custtrnsresultcode);
    }
    else {
      return custtrnsresultcode;
    }
  }

  public String getTaxts() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(taxts);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(taxts);
    }
    else {
      return taxts;
    }
  }

  public String getAtisdn() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(atisdn);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(atisdn);
    }
    else {
      return atisdn;
    }
  }

  public String getAttext() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(attext);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(attext);
    }
    else {
      return attext;
    }
  }

  public void setAirtelchrgts(String value) {
    airtelchrgts = value;
  }

  public void setCurrappstatus(String value) {
    currappstatus = value;
  }

  public void setTaxresult(String value) {
    taxresult = value;
  }

  public void setCusttrnsts(String value) {
    custtrnsts = value;
  }

  public void setSafaricomcharges(String value) {
    safaricomcharges = value;
  }

  public void setBankchrgresultcode(String value) {
    bankchrgresultcode = value;
  }

  public void setDest(String value) {
    dest = value;
  }

  public void setAtsender(String value) {
    atsender = value;
  }

  public void setMadeat(String value) {
    madeat = value;
  }

  public void setAttdate(String value) {
    attdate = value;
  }

  public void setAterrmsg(String value) {
    aterrmsg = value;
  }

  public void setCusttrnsamt(String value) {
    custtrnsamt = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setAttamt(String value) {
    attamt = value;
  }

  public void setAtcustid(String value) {
    atcustid = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void setRequestsourceip(String value) {
    requestsourceip = value;
  }

  public void setAtresp(String value) {
    atresp = value;
  }

  public void setSuspenseresult(String value) {
    suspenseresult = value;
  }

  public void setAtid(String value) {
    atid = value;
  }

  public void setSuspensechrgamt(String value) {
    suspensechrgamt = value;
  }

  public void setTaxresultcode(String value) {
    taxresultcode = value;
  }

  public void setAtttime(String value) {
    atttime = value;
  }

  public void setAirtelchrgresult(String value) {
    airtelchrgresult = value;
  }

  public void setMadeby(String value) {
    madeby = value;
  }

  public void setAdminlastcmt(String value) {
    adminlastcmt = value;
  }

  public void setBankchrgamt(String value) {
    bankchrgamt = value;
  }

  public void setCheckerlastcmt(String value) {
    checkerlastcmt = value;
  }

  public void setRstatus(String value) {
    rstatus = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setTstamp(String value) {
    tstamp = value;
  }

  public void setAtcode(String value) {
    atcode = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setTaxamt(String value) {
    taxamt = value;
  }

  public void setMakerlastcmt(String value) {
    makerlastcmt = value;
  }

  public void setSuspensechrgts(String value) {
    suspensechrgts = value;
  }

  public void setStatusdesc(String value) {
    statusdesc = value;
  }

  public void setAtrtmethodid(String value) {
    atrtmethodid = value;
  }

  public void setBankchrgresult(String value) {
    bankchrgresult = value;
  }

  public void setCheckedat(String value) {
    checkedat = value;
  }

  public void setRcvbtrnsresultcode(String value) {
    rcvbtrnsresultcode = value;
  }

  public void setAtpass(String value) {
    atpass = value;
  }

  public void setRcvbtrnsts(String value) {
    rcvbtrnsts = value;
  }

  public void setAtuser(String value) {
    atuser = value;
  }

  public void setCusttrnsresult(String value) {
    custtrnsresult = value;
  }

  public void setAtacc(String value) {
    atacc = value;
  }

  public void setAirtelchrgresultcode(String value) {
    airtelchrgresultcode = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setRcvbtrnsresult(String value) {
    rcvbtrnsresult = value;
  }

  public void setAirtelchrgamt(String value) {
    airtelchrgamt = value;
  }

  public void setBankcharges(String value) {
    bankcharges = value;
  }

  public void setSuspenseresultcode(String value) {
    suspenseresultcode = value;
  }

  public void setRcvbtrnsamt(String value) {
    rcvbtrnsamt = value;
  }

  public void setBankchrgts(String value) {
    bankchrgts = value;
  }

  public void setOrig(String value) {
    orig = value;
  }

  public void setCheckedby(String value) {
    checkedby = value;
  }

  public void setAtrtmethodname(String value) {
    atrtmethodname = value;
  }

  public void setCusttrnsresultcode(String value) {
    custtrnsresultcode = value;
  }

  public void setTaxts(String value) {
    taxts = value;
  }

  public void setAtisdn(String value) {
    atisdn = value;
  }

  public void setAttext(String value) {
    attext = value;
  }

  public void loadContent(KBAirteltranRecord inputRecord) {
    setAirtelchrgts(inputRecord.getAirtelchrgts());
    setCurrappstatus(inputRecord.getCurrappstatus());
    setTaxresult(inputRecord.getTaxresult());
    setCusttrnsts(inputRecord.getCusttrnsts());
    setSafaricomcharges(inputRecord.getSafaricomcharges());
    setBankchrgresultcode(inputRecord.getBankchrgresultcode());
    setDest(inputRecord.getDest());
    setAtsender(inputRecord.getAtsender());
    setMadeat(inputRecord.getMadeat());
    setAttdate(inputRecord.getAttdate());
    setAterrmsg(inputRecord.getAterrmsg());
    setCusttrnsamt(inputRecord.getCusttrnsamt());
    setCreatedby(inputRecord.getCreatedby());
    setAttamt(inputRecord.getAttamt());
    setAtcustid(inputRecord.getAtcustid());
    setId(inputRecord.getId());
    setRequestsourceip(inputRecord.getRequestsourceip());
    setAtresp(inputRecord.getAtresp());
    setSuspenseresult(inputRecord.getSuspenseresult());
    setAtid(inputRecord.getAtid());
    setSuspensechrgamt(inputRecord.getSuspensechrgamt());
    setTaxresultcode(inputRecord.getTaxresultcode());
    setAtttime(inputRecord.getAtttime());
    setAirtelchrgresult(inputRecord.getAirtelchrgresult());
    setMadeby(inputRecord.getMadeby());
    setAdminlastcmt(inputRecord.getAdminlastcmt());
    setBankchrgamt(inputRecord.getBankchrgamt());
    setCheckerlastcmt(inputRecord.getCheckerlastcmt());
    setRstatus(inputRecord.getRstatus());
    setCreatedat(inputRecord.getCreatedat());
    setTstamp(inputRecord.getTstamp());
    setAtcode(inputRecord.getAtcode());
    setModifiedby(inputRecord.getModifiedby());
    setTaxamt(inputRecord.getTaxamt());
    setMakerlastcmt(inputRecord.getMakerlastcmt());
    setSuspensechrgts(inputRecord.getSuspensechrgts());
    setStatusdesc(inputRecord.getStatusdesc());
    setAtrtmethodid(inputRecord.getAtrtmethodid());
    setBankchrgresult(inputRecord.getBankchrgresult());
    setCheckedat(inputRecord.getCheckedat());
    setRcvbtrnsresultcode(inputRecord.getRcvbtrnsresultcode());
    setAtpass(inputRecord.getAtpass());
    setRcvbtrnsts(inputRecord.getRcvbtrnsts());
    setAtuser(inputRecord.getAtuser());
    setCusttrnsresult(inputRecord.getCusttrnsresult());
    setAtacc(inputRecord.getAtacc());
    setAirtelchrgresultcode(inputRecord.getAirtelchrgresultcode());
    setModifiedat(inputRecord.getModifiedat());
    setRcvbtrnsresult(inputRecord.getRcvbtrnsresult());
    setAirtelchrgamt(inputRecord.getAirtelchrgamt());
    setBankcharges(inputRecord.getBankcharges());
    setSuspenseresultcode(inputRecord.getSuspenseresultcode());
    setRcvbtrnsamt(inputRecord.getRcvbtrnsamt());
    setBankchrgts(inputRecord.getBankchrgts());
    setOrig(inputRecord.getOrig());
    setCheckedby(inputRecord.getCheckedby());
    setAtrtmethodname(inputRecord.getAtrtmethodname());
    setCusttrnsresultcode(inputRecord.getCusttrnsresultcode());
    setTaxts(inputRecord.getTaxts());
    setAtisdn(inputRecord.getAtisdn());
    setAttext(inputRecord.getAttext());
  }

  public void loadNonNullContent(KBAirteltranRecord inputRecord) {
    if (StringUtils.hasChanged(getAirtelchrgts(), inputRecord.getAirtelchrgts())) {
      setAirtelchrgts(StringUtils.noNull(inputRecord.getAirtelchrgts()));
    }
    if (StringUtils.hasChanged(getCurrappstatus(), inputRecord.getCurrappstatus())) {
      setCurrappstatus(StringUtils.noNull(inputRecord.getCurrappstatus()));
    }
    if (StringUtils.hasChanged(getTaxresult(), inputRecord.getTaxresult())) {
      setTaxresult(StringUtils.noNull(inputRecord.getTaxresult()));
    }
    if (StringUtils.hasChanged(getCusttrnsts(), inputRecord.getCusttrnsts())) {
      setCusttrnsts(StringUtils.noNull(inputRecord.getCusttrnsts()));
    }
    if (StringUtils.hasChanged(getSafaricomcharges(), inputRecord.getSafaricomcharges())) {
      setSafaricomcharges(StringUtils.noNull(inputRecord.getSafaricomcharges()));
    }
    if (StringUtils.hasChanged(getBankchrgresultcode(), inputRecord.getBankchrgresultcode())) {
      setBankchrgresultcode(StringUtils.noNull(inputRecord.getBankchrgresultcode()));
    }
    if (StringUtils.hasChanged(getDest(), inputRecord.getDest())) {
      setDest(StringUtils.noNull(inputRecord.getDest()));
    }
    if (StringUtils.hasChanged(getAtsender(), inputRecord.getAtsender())) {
      setAtsender(StringUtils.noNull(inputRecord.getAtsender()));
    }
    if (StringUtils.hasChanged(getMadeat(), inputRecord.getMadeat())) {
      setMadeat(StringUtils.noNull(inputRecord.getMadeat()));
    }
    if (StringUtils.hasChanged(getAttdate(), inputRecord.getAttdate())) {
      setAttdate(StringUtils.noNull(inputRecord.getAttdate()));
    }
    if (StringUtils.hasChanged(getAterrmsg(), inputRecord.getAterrmsg())) {
      setAterrmsg(StringUtils.noNull(inputRecord.getAterrmsg()));
    }
    if (StringUtils.hasChanged(getCusttrnsamt(), inputRecord.getCusttrnsamt())) {
      setCusttrnsamt(StringUtils.noNull(inputRecord.getCusttrnsamt()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getAttamt(), inputRecord.getAttamt())) {
      setAttamt(StringUtils.noNull(inputRecord.getAttamt()));
    }
    if (StringUtils.hasChanged(getAtcustid(), inputRecord.getAtcustid())) {
      setAtcustid(StringUtils.noNull(inputRecord.getAtcustid()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
    if (StringUtils.hasChanged(getRequestsourceip(), inputRecord.getRequestsourceip())) {
      setRequestsourceip(StringUtils.noNull(inputRecord.getRequestsourceip()));
    }
    if (StringUtils.hasChanged(getAtresp(), inputRecord.getAtresp())) {
      setAtresp(StringUtils.noNull(inputRecord.getAtresp()));
    }
    if (StringUtils.hasChanged(getSuspenseresult(), inputRecord.getSuspenseresult())) {
      setSuspenseresult(StringUtils.noNull(inputRecord.getSuspenseresult()));
    }
    if (StringUtils.hasChanged(getAtid(), inputRecord.getAtid())) {
      setAtid(StringUtils.noNull(inputRecord.getAtid()));
    }
    if (StringUtils.hasChanged(getSuspensechrgamt(), inputRecord.getSuspensechrgamt())) {
      setSuspensechrgamt(StringUtils.noNull(inputRecord.getSuspensechrgamt()));
    }
    if (StringUtils.hasChanged(getTaxresultcode(), inputRecord.getTaxresultcode())) {
      setTaxresultcode(StringUtils.noNull(inputRecord.getTaxresultcode()));
    }
    if (StringUtils.hasChanged(getAtttime(), inputRecord.getAtttime())) {
      setAtttime(StringUtils.noNull(inputRecord.getAtttime()));
    }
    if (StringUtils.hasChanged(getAirtelchrgresult(), inputRecord.getAirtelchrgresult())) {
      setAirtelchrgresult(StringUtils.noNull(inputRecord.getAirtelchrgresult()));
    }
    if (StringUtils.hasChanged(getMadeby(), inputRecord.getMadeby())) {
      setMadeby(StringUtils.noNull(inputRecord.getMadeby()));
    }
    if (StringUtils.hasChanged(getAdminlastcmt(), inputRecord.getAdminlastcmt())) {
      setAdminlastcmt(StringUtils.noNull(inputRecord.getAdminlastcmt()));
    }
    if (StringUtils.hasChanged(getBankchrgamt(), inputRecord.getBankchrgamt())) {
      setBankchrgamt(StringUtils.noNull(inputRecord.getBankchrgamt()));
    }
    if (StringUtils.hasChanged(getCheckerlastcmt(), inputRecord.getCheckerlastcmt())) {
      setCheckerlastcmt(StringUtils.noNull(inputRecord.getCheckerlastcmt()));
    }
    if (StringUtils.hasChanged(getRstatus(), inputRecord.getRstatus())) {
      setRstatus(StringUtils.noNull(inputRecord.getRstatus()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getTstamp(), inputRecord.getTstamp())) {
      setTstamp(StringUtils.noNull(inputRecord.getTstamp()));
    }
    if (StringUtils.hasChanged(getAtcode(), inputRecord.getAtcode())) {
      setAtcode(StringUtils.noNull(inputRecord.getAtcode()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getTaxamt(), inputRecord.getTaxamt())) {
      setTaxamt(StringUtils.noNull(inputRecord.getTaxamt()));
    }
    if (StringUtils.hasChanged(getMakerlastcmt(), inputRecord.getMakerlastcmt())) {
      setMakerlastcmt(StringUtils.noNull(inputRecord.getMakerlastcmt()));
    }
    if (StringUtils.hasChanged(getSuspensechrgts(), inputRecord.getSuspensechrgts())) {
      setSuspensechrgts(StringUtils.noNull(inputRecord.getSuspensechrgts()));
    }
    if (StringUtils.hasChanged(getStatusdesc(), inputRecord.getStatusdesc())) {
      setStatusdesc(StringUtils.noNull(inputRecord.getStatusdesc()));
    }
    if (StringUtils.hasChanged(getAtrtmethodid(), inputRecord.getAtrtmethodid())) {
      setAtrtmethodid(StringUtils.noNull(inputRecord.getAtrtmethodid()));
    }
    if (StringUtils.hasChanged(getBankchrgresult(), inputRecord.getBankchrgresult())) {
      setBankchrgresult(StringUtils.noNull(inputRecord.getBankchrgresult()));
    }
    if (StringUtils.hasChanged(getCheckedat(), inputRecord.getCheckedat())) {
      setCheckedat(StringUtils.noNull(inputRecord.getCheckedat()));
    }
    if (StringUtils.hasChanged(getRcvbtrnsresultcode(), inputRecord.getRcvbtrnsresultcode())) {
      setRcvbtrnsresultcode(StringUtils.noNull(inputRecord.getRcvbtrnsresultcode()));
    }
    if (StringUtils.hasChanged(getAtpass(), inputRecord.getAtpass())) {
      setAtpass(StringUtils.noNull(inputRecord.getAtpass()));
    }
    if (StringUtils.hasChanged(getRcvbtrnsts(), inputRecord.getRcvbtrnsts())) {
      setRcvbtrnsts(StringUtils.noNull(inputRecord.getRcvbtrnsts()));
    }
    if (StringUtils.hasChanged(getAtuser(), inputRecord.getAtuser())) {
      setAtuser(StringUtils.noNull(inputRecord.getAtuser()));
    }
    if (StringUtils.hasChanged(getCusttrnsresult(), inputRecord.getCusttrnsresult())) {
      setCusttrnsresult(StringUtils.noNull(inputRecord.getCusttrnsresult()));
    }
    if (StringUtils.hasChanged(getAtacc(), inputRecord.getAtacc())) {
      setAtacc(StringUtils.noNull(inputRecord.getAtacc()));
    }
    if (StringUtils.hasChanged(getAirtelchrgresultcode(), inputRecord.getAirtelchrgresultcode())) {
      setAirtelchrgresultcode(StringUtils.noNull(inputRecord.getAirtelchrgresultcode()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getRcvbtrnsresult(), inputRecord.getRcvbtrnsresult())) {
      setRcvbtrnsresult(StringUtils.noNull(inputRecord.getRcvbtrnsresult()));
    }
    if (StringUtils.hasChanged(getAirtelchrgamt(), inputRecord.getAirtelchrgamt())) {
      setAirtelchrgamt(StringUtils.noNull(inputRecord.getAirtelchrgamt()));
    }
    if (StringUtils.hasChanged(getBankcharges(), inputRecord.getBankcharges())) {
      setBankcharges(StringUtils.noNull(inputRecord.getBankcharges()));
    }
    if (StringUtils.hasChanged(getSuspenseresultcode(), inputRecord.getSuspenseresultcode())) {
      setSuspenseresultcode(StringUtils.noNull(inputRecord.getSuspenseresultcode()));
    }
    if (StringUtils.hasChanged(getRcvbtrnsamt(), inputRecord.getRcvbtrnsamt())) {
      setRcvbtrnsamt(StringUtils.noNull(inputRecord.getRcvbtrnsamt()));
    }
    if (StringUtils.hasChanged(getBankchrgts(), inputRecord.getBankchrgts())) {
      setBankchrgts(StringUtils.noNull(inputRecord.getBankchrgts()));
    }
    if (StringUtils.hasChanged(getOrig(), inputRecord.getOrig())) {
      setOrig(StringUtils.noNull(inputRecord.getOrig()));
    }
    if (StringUtils.hasChanged(getCheckedby(), inputRecord.getCheckedby())) {
      setCheckedby(StringUtils.noNull(inputRecord.getCheckedby()));
    }
    if (StringUtils.hasChanged(getAtrtmethodname(), inputRecord.getAtrtmethodname())) {
      setAtrtmethodname(StringUtils.noNull(inputRecord.getAtrtmethodname()));
    }
    if (StringUtils.hasChanged(getCusttrnsresultcode(), inputRecord.getCusttrnsresultcode())) {
      setCusttrnsresultcode(StringUtils.noNull(inputRecord.getCusttrnsresultcode()));
    }
    if (StringUtils.hasChanged(getTaxts(), inputRecord.getTaxts())) {
      setTaxts(StringUtils.noNull(inputRecord.getTaxts()));
    }
    if (StringUtils.hasChanged(getAtisdn(), inputRecord.getAtisdn())) {
      setAtisdn(StringUtils.noNull(inputRecord.getAtisdn()));
    }
    if (StringUtils.hasChanged(getAttext(), inputRecord.getAttext())) {
      setAttext(StringUtils.noNull(inputRecord.getAttext()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("airtelchrgts",StringUtils.noNull(airtelchrgts));
    obj.put("currappstatus",StringUtils.noNull(currappstatus));
    obj.put("taxresult",StringUtils.noNull(taxresult));
    obj.put("custtrnsts",StringUtils.noNull(custtrnsts));
    obj.put("safaricomcharges",StringUtils.noNull(safaricomcharges));
    obj.put("bankchrgresultcode",StringUtils.noNull(bankchrgresultcode));
    obj.put("dest",StringUtils.noNull(dest));
    obj.put("atsender",StringUtils.noNull(atsender));
    obj.put("madeat",StringUtils.noNull(madeat));
    obj.put("attdate",StringUtils.noNull(attdate));
    obj.put("aterrmsg",StringUtils.noNull(aterrmsg));
    obj.put("custtrnsamt",StringUtils.noNull(custtrnsamt));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("attamt",StringUtils.noNull(attamt));
    obj.put("atcustid",StringUtils.noNull(atcustid));
    obj.put("id",StringUtils.noNull(id));
    obj.put("requestsourceip",StringUtils.noNull(requestsourceip));
    obj.put("atresp",StringUtils.noNull(atresp));
    obj.put("suspenseresult",StringUtils.noNull(suspenseresult));
    obj.put("atid",StringUtils.noNull(atid));
    obj.put("suspensechrgamt",StringUtils.noNull(suspensechrgamt));
    obj.put("taxresultcode",StringUtils.noNull(taxresultcode));
    obj.put("atttime",StringUtils.noNull(atttime));
    obj.put("airtelchrgresult",StringUtils.noNull(airtelchrgresult));
    obj.put("madeby",StringUtils.noNull(madeby));
    obj.put("adminlastcmt",StringUtils.noNull(adminlastcmt));
    obj.put("bankchrgamt",StringUtils.noNull(bankchrgamt));
    obj.put("checkerlastcmt",StringUtils.noNull(checkerlastcmt));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("tstamp",StringUtils.noNull(tstamp));
    obj.put("atcode",StringUtils.noNull(atcode));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("taxamt",StringUtils.noNull(taxamt));
    obj.put("makerlastcmt",StringUtils.noNull(makerlastcmt));
    obj.put("suspensechrgts",StringUtils.noNull(suspensechrgts));
    obj.put("statusdesc",StringUtils.noNull(statusdesc));
    obj.put("atrtmethodid",StringUtils.noNull(atrtmethodid));
    obj.put("bankchrgresult",StringUtils.noNull(bankchrgresult));
    obj.put("checkedat",StringUtils.noNull(checkedat));
    obj.put("rcvbtrnsresultcode",StringUtils.noNull(rcvbtrnsresultcode));
    obj.put("atpass",StringUtils.noNull(atpass));
    obj.put("rcvbtrnsts",StringUtils.noNull(rcvbtrnsts));
    obj.put("atuser",StringUtils.noNull(atuser));
    obj.put("custtrnsresult",StringUtils.noNull(custtrnsresult));
    obj.put("atacc",StringUtils.noNull(atacc));
    obj.put("airtelchrgresultcode",StringUtils.noNull(airtelchrgresultcode));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("rcvbtrnsresult",StringUtils.noNull(rcvbtrnsresult));
    obj.put("airtelchrgamt",StringUtils.noNull(airtelchrgamt));
    obj.put("bankcharges",StringUtils.noNull(bankcharges));
    obj.put("suspenseresultcode",StringUtils.noNull(suspenseresultcode));
    obj.put("rcvbtrnsamt",StringUtils.noNull(rcvbtrnsamt));
    obj.put("bankchrgts",StringUtils.noNull(bankchrgts));
    obj.put("orig",StringUtils.noNull(orig));
    obj.put("checkedby",StringUtils.noNull(checkedby));
    obj.put("atrtmethodname",StringUtils.noNull(atrtmethodname));
    obj.put("custtrnsresultcode",StringUtils.noNull(custtrnsresultcode));
    obj.put("taxts",StringUtils.noNull(taxts));
    obj.put("atisdn",StringUtils.noNull(atisdn));
    obj.put("attext",StringUtils.noNull(attext));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    airtelchrgts = StringUtils.getValueFromJSONObject(obj, "airtelchrgts");
    currappstatus = StringUtils.getValueFromJSONObject(obj, "currappstatus");
    taxresult = StringUtils.getValueFromJSONObject(obj, "taxresult");
    custtrnsts = StringUtils.getValueFromJSONObject(obj, "custtrnsts");
    safaricomcharges = StringUtils.getValueFromJSONObject(obj, "safaricomcharges");
    bankchrgresultcode = StringUtils.getValueFromJSONObject(obj, "bankchrgresultcode");
    dest = StringUtils.getValueFromJSONObject(obj, "dest");
    atsender = StringUtils.getValueFromJSONObject(obj, "atsender");
    madeat = StringUtils.getValueFromJSONObject(obj, "madeat");
    attdate = StringUtils.getValueFromJSONObject(obj, "attdate");
    aterrmsg = StringUtils.getValueFromJSONObject(obj, "aterrmsg");
    custtrnsamt = StringUtils.getValueFromJSONObject(obj, "custtrnsamt");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    attamt = StringUtils.getValueFromJSONObject(obj, "attamt");
    atcustid = StringUtils.getValueFromJSONObject(obj, "atcustid");
    id = StringUtils.getValueFromJSONObject(obj, "id");
    requestsourceip = StringUtils.getValueFromJSONObject(obj, "requestsourceip");
    atresp = StringUtils.getValueFromJSONObject(obj, "atresp");
    suspenseresult = StringUtils.getValueFromJSONObject(obj, "suspenseresult");
    atid = StringUtils.getValueFromJSONObject(obj, "atid");
    suspensechrgamt = StringUtils.getValueFromJSONObject(obj, "suspensechrgamt");
    taxresultcode = StringUtils.getValueFromJSONObject(obj, "taxresultcode");
    atttime = StringUtils.getValueFromJSONObject(obj, "atttime");
    airtelchrgresult = StringUtils.getValueFromJSONObject(obj, "airtelchrgresult");
    madeby = StringUtils.getValueFromJSONObject(obj, "madeby");
    adminlastcmt = StringUtils.getValueFromJSONObject(obj, "adminlastcmt");
    bankchrgamt = StringUtils.getValueFromJSONObject(obj, "bankchrgamt");
    checkerlastcmt = StringUtils.getValueFromJSONObject(obj, "checkerlastcmt");
    rstatus = StringUtils.getValueFromJSONObject(obj, "rstatus");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    tstamp = StringUtils.getValueFromJSONObject(obj, "tstamp");
    atcode = StringUtils.getValueFromJSONObject(obj, "atcode");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    taxamt = StringUtils.getValueFromJSONObject(obj, "taxamt");
    makerlastcmt = StringUtils.getValueFromJSONObject(obj, "makerlastcmt");
    suspensechrgts = StringUtils.getValueFromJSONObject(obj, "suspensechrgts");
    statusdesc = StringUtils.getValueFromJSONObject(obj, "statusdesc");
    atrtmethodid = StringUtils.getValueFromJSONObject(obj, "atrtmethodid");
    bankchrgresult = StringUtils.getValueFromJSONObject(obj, "bankchrgresult");
    checkedat = StringUtils.getValueFromJSONObject(obj, "checkedat");
    rcvbtrnsresultcode = StringUtils.getValueFromJSONObject(obj, "rcvbtrnsresultcode");
    atpass = StringUtils.getValueFromJSONObject(obj, "atpass");
    rcvbtrnsts = StringUtils.getValueFromJSONObject(obj, "rcvbtrnsts");
    atuser = StringUtils.getValueFromJSONObject(obj, "atuser");
    custtrnsresult = StringUtils.getValueFromJSONObject(obj, "custtrnsresult");
    atacc = StringUtils.getValueFromJSONObject(obj, "atacc");
    airtelchrgresultcode = StringUtils.getValueFromJSONObject(obj, "airtelchrgresultcode");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    rcvbtrnsresult = StringUtils.getValueFromJSONObject(obj, "rcvbtrnsresult");
    airtelchrgamt = StringUtils.getValueFromJSONObject(obj, "airtelchrgamt");
    bankcharges = StringUtils.getValueFromJSONObject(obj, "bankcharges");
    suspenseresultcode = StringUtils.getValueFromJSONObject(obj, "suspenseresultcode");
    rcvbtrnsamt = StringUtils.getValueFromJSONObject(obj, "rcvbtrnsamt");
    bankchrgts = StringUtils.getValueFromJSONObject(obj, "bankchrgts");
    orig = StringUtils.getValueFromJSONObject(obj, "orig");
    checkedby = StringUtils.getValueFromJSONObject(obj, "checkedby");
    atrtmethodname = StringUtils.getValueFromJSONObject(obj, "atrtmethodname");
    custtrnsresultcode = StringUtils.getValueFromJSONObject(obj, "custtrnsresultcode");
    taxts = StringUtils.getValueFromJSONObject(obj, "taxts");
    atisdn = StringUtils.getValueFromJSONObject(obj, "atisdn");
    attext = StringUtils.getValueFromJSONObject(obj, "attext");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("airtelchrgts",StringUtils.noNull(airtelchrgts));
    obj.put("currappstatus",StringUtils.noNull(currappstatus));
    obj.put("taxresult",StringUtils.noNull(taxresult));
    obj.put("custtrnsts",StringUtils.noNull(custtrnsts));
    obj.put("safaricomcharges",StringUtils.noNull(safaricomcharges));
    obj.put("bankchrgresultcode",StringUtils.noNull(bankchrgresultcode));
    obj.put("dest",StringUtils.noNull(dest));
    obj.put("atsender",StringUtils.noNull(atsender));
    obj.put("madeat",StringUtils.noNull(madeat));
    obj.put("attdate",StringUtils.noNull(attdate));
    obj.put("aterrmsg",StringUtils.noNull(aterrmsg));
    obj.put("custtrnsamt",StringUtils.noNull(custtrnsamt));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("attamt",StringUtils.noNull(attamt));
    obj.put("atcustid",StringUtils.noNull(atcustid));
    obj.put("id",StringUtils.noNull(id));
    obj.put("requestsourceip",StringUtils.noNull(requestsourceip));
    obj.put("atresp",StringUtils.noNull(atresp));
    obj.put("suspenseresult",StringUtils.noNull(suspenseresult));
    obj.put("atid",StringUtils.noNull(atid));
    obj.put("suspensechrgamt",StringUtils.noNull(suspensechrgamt));
    obj.put("taxresultcode",StringUtils.noNull(taxresultcode));
    obj.put("atttime",StringUtils.noNull(atttime));
    obj.put("airtelchrgresult",StringUtils.noNull(airtelchrgresult));
    obj.put("madeby",StringUtils.noNull(madeby));
    obj.put("adminlastcmt",StringUtils.noNull(adminlastcmt));
    obj.put("bankchrgamt",StringUtils.noNull(bankchrgamt));
    obj.put("checkerlastcmt",StringUtils.noNull(checkerlastcmt));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("tstamp",StringUtils.noNull(tstamp));
    obj.put("atcode",StringUtils.noNull(atcode));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("taxamt",StringUtils.noNull(taxamt));
    obj.put("makerlastcmt",StringUtils.noNull(makerlastcmt));
    obj.put("suspensechrgts",StringUtils.noNull(suspensechrgts));
    obj.put("statusdesc",StringUtils.noNull(statusdesc));
    obj.put("atrtmethodid",StringUtils.noNull(atrtmethodid));
    obj.put("bankchrgresult",StringUtils.noNull(bankchrgresult));
    obj.put("checkedat",StringUtils.noNull(checkedat));
    obj.put("rcvbtrnsresultcode",StringUtils.noNull(rcvbtrnsresultcode));
    obj.put("atpass",StringUtils.noNull(atpass));
    obj.put("rcvbtrnsts",StringUtils.noNull(rcvbtrnsts));
    obj.put("atuser",StringUtils.noNull(atuser));
    obj.put("custtrnsresult",StringUtils.noNull(custtrnsresult));
    obj.put("atacc",StringUtils.noNull(atacc));
    obj.put("airtelchrgresultcode",StringUtils.noNull(airtelchrgresultcode));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("rcvbtrnsresult",StringUtils.noNull(rcvbtrnsresult));
    obj.put("airtelchrgamt",StringUtils.noNull(airtelchrgamt));
    obj.put("bankcharges",StringUtils.noNull(bankcharges));
    obj.put("suspenseresultcode",StringUtils.noNull(suspenseresultcode));
    obj.put("rcvbtrnsamt",StringUtils.noNull(rcvbtrnsamt));
    obj.put("bankchrgts",StringUtils.noNull(bankchrgts));
    obj.put("orig",StringUtils.noNull(orig));
    obj.put("checkedby",StringUtils.noNull(checkedby));
    obj.put("atrtmethodname",StringUtils.noNull(atrtmethodname));
    obj.put("custtrnsresultcode",StringUtils.noNull(custtrnsresultcode));
    obj.put("taxts",StringUtils.noNull(taxts));
    obj.put("atisdn",StringUtils.noNull(atisdn));
    obj.put("attext",StringUtils.noNull(attext));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("airtelchrgts");
    columnList.add("currappstatus");
    columnList.add("taxresult");
    columnList.add("custtrnsts");
    columnList.add("safaricomcharges");
    columnList.add("bankchrgresultcode");
    columnList.add("dest");
    columnList.add("atsender");
    columnList.add("madeat");
    columnList.add("attdate");
    columnList.add("aterrmsg");
    columnList.add("custtrnsamt");
    columnList.add("createdby");
    columnList.add("attamt");
    columnList.add("atcustid");
    columnList.add("id");
    columnList.add("requestsourceip");
    columnList.add("atresp");
    columnList.add("suspenseresult");
    columnList.add("atid");
    columnList.add("suspensechrgamt");
    columnList.add("taxresultcode");
    columnList.add("atttime");
    columnList.add("airtelchrgresult");
    columnList.add("madeby");
    columnList.add("adminlastcmt");
    columnList.add("bankchrgamt");
    columnList.add("checkerlastcmt");
    columnList.add("rstatus");
    columnList.add("createdat");
    columnList.add("tstamp");
    columnList.add("atcode");
    columnList.add("modifiedby");
    columnList.add("taxamt");
    columnList.add("makerlastcmt");
    columnList.add("suspensechrgts");
    columnList.add("statusdesc");
    columnList.add("atrtmethodid");
    columnList.add("bankchrgresult");
    columnList.add("checkedat");
    columnList.add("rcvbtrnsresultcode");
    columnList.add("atpass");
    columnList.add("rcvbtrnsts");
    columnList.add("atuser");
    columnList.add("custtrnsresult");
    columnList.add("atacc");
    columnList.add("airtelchrgresultcode");
    columnList.add("modifiedat");
    columnList.add("rcvbtrnsresult");
    columnList.add("airtelchrgamt");
    columnList.add("bankcharges");
    columnList.add("suspenseresultcode");
    columnList.add("rcvbtrnsamt");
    columnList.add("bankchrgts");
    columnList.add("orig");
    columnList.add("checkedby");
    columnList.add("atrtmethodname");
    columnList.add("custtrnsresultcode");
    columnList.add("taxts");
    columnList.add("atisdn");
    columnList.add("attext");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "airtelchrgts:" + airtelchrgts +"currappstatus:" + currappstatus +"taxresult:" + taxresult +"custtrnsts:" + custtrnsts +"safaricomcharges:" + safaricomcharges +"bankchrgresultcode:" + bankchrgresultcode +"dest:" + dest +"atsender:" + atsender +"madeat:" + madeat +"attdate:" + attdate +"aterrmsg:" + aterrmsg +"custtrnsamt:" + custtrnsamt +"createdby:" + createdby +"attamt:" + attamt +"atcustid:" + atcustid +"id:" + id +"requestsourceip:" + requestsourceip +"atresp:" + atresp +"suspenseresult:" + suspenseresult +"atid:" + atid +"suspensechrgamt:" + suspensechrgamt +"taxresultcode:" + taxresultcode +"atttime:" + atttime +"airtelchrgresult:" + airtelchrgresult +"madeby:" + madeby +"adminlastcmt:" + adminlastcmt +"bankchrgamt:" + bankchrgamt +"checkerlastcmt:" + checkerlastcmt +"rstatus:" + rstatus +"createdat:" + createdat +"tstamp:" + tstamp +"atcode:" + atcode +"modifiedby:" + modifiedby +"taxamt:" + taxamt +"makerlastcmt:" + makerlastcmt +"suspensechrgts:" + suspensechrgts +"statusdesc:" + statusdesc +"atrtmethodid:" + atrtmethodid +"bankchrgresult:" + bankchrgresult +"checkedat:" + checkedat +"rcvbtrnsresultcode:" + rcvbtrnsresultcode +"atpass:" + atpass +"rcvbtrnsts:" + rcvbtrnsts +"atuser:" + atuser +"custtrnsresult:" + custtrnsresult +"atacc:" + atacc +"airtelchrgresultcode:" + airtelchrgresultcode +"modifiedat:" + modifiedat +"rcvbtrnsresult:" + rcvbtrnsresult +"airtelchrgamt:" + airtelchrgamt +"bankcharges:" + bankcharges +"suspenseresultcode:" + suspenseresultcode +"rcvbtrnsamt:" + rcvbtrnsamt +"bankchrgts:" + bankchrgts +"orig:" + orig +"checkedby:" + checkedby +"atrtmethodname:" + atrtmethodname +"custtrnsresultcode:" + custtrnsresultcode +"taxts:" + taxts +"atisdn:" + atisdn +"attext:" + attext +"";
  }
}
