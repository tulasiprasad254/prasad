package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBServicemapRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBServicemapRecord.class.getName());

  public String rstatus;

  public String createdat;

  public String servicemethod;

  public String servicecode;

  public String createdby;

  public String modifiedat;

  public String serviceclass;

  public String modifiedby;

  public String servicetitle;

  public String id;

  public String intenv;

  public String getRstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rstatus);
    }
    else {
      return rstatus;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getServicemethod() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(servicemethod);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(servicemethod);
    }
    else {
      return servicemethod;
    }
  }

  public String getServicecode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(servicecode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(servicecode);
    }
    else {
      return servicecode;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getServiceclass() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(serviceclass);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(serviceclass);
    }
    else {
      return serviceclass;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getServicetitle() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(servicetitle);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(servicetitle);
    }
    else {
      return servicetitle;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public String getIntenv() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(intenv);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(intenv);
    }
    else {
      return intenv;
    }
  }

  public void setRstatus(String value) {
    rstatus = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setServicemethod(String value) {
    servicemethod = value;
  }

  public void setServicecode(String value) {
    servicecode = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setServiceclass(String value) {
    serviceclass = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setServicetitle(String value) {
    servicetitle = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void setIntenv(String value) {
    intenv = value;
  }

  public void loadContent(KBServicemapRecord inputRecord) {
    setRstatus(inputRecord.getRstatus());
    setCreatedat(inputRecord.getCreatedat());
    setServicemethod(inputRecord.getServicemethod());
    setServicecode(inputRecord.getServicecode());
    setCreatedby(inputRecord.getCreatedby());
    setModifiedat(inputRecord.getModifiedat());
    setServiceclass(inputRecord.getServiceclass());
    setModifiedby(inputRecord.getModifiedby());
    setServicetitle(inputRecord.getServicetitle());
    setId(inputRecord.getId());
    setIntenv(inputRecord.getIntenv());
  }

  public void loadNonNullContent(KBServicemapRecord inputRecord) {
    if (StringUtils.hasChanged(getRstatus(), inputRecord.getRstatus())) {
      setRstatus(StringUtils.noNull(inputRecord.getRstatus()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getServicemethod(), inputRecord.getServicemethod())) {
      setServicemethod(StringUtils.noNull(inputRecord.getServicemethod()));
    }
    if (StringUtils.hasChanged(getServicecode(), inputRecord.getServicecode())) {
      setServicecode(StringUtils.noNull(inputRecord.getServicecode()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getServiceclass(), inputRecord.getServiceclass())) {
      setServiceclass(StringUtils.noNull(inputRecord.getServiceclass()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getServicetitle(), inputRecord.getServicetitle())) {
      setServicetitle(StringUtils.noNull(inputRecord.getServicetitle()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
    if (StringUtils.hasChanged(getIntenv(), inputRecord.getIntenv())) {
      setIntenv(StringUtils.noNull(inputRecord.getIntenv()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("servicemethod",StringUtils.noNull(servicemethod));
    obj.put("servicecode",StringUtils.noNull(servicecode));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("serviceclass",StringUtils.noNull(serviceclass));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("servicetitle",StringUtils.noNull(servicetitle));
    obj.put("id",StringUtils.noNull(id));
    obj.put("intenv",StringUtils.noNull(intenv));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    rstatus = StringUtils.getValueFromJSONObject(obj, "rstatus");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    servicemethod = StringUtils.getValueFromJSONObject(obj, "servicemethod");
    servicecode = StringUtils.getValueFromJSONObject(obj, "servicecode");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    serviceclass = StringUtils.getValueFromJSONObject(obj, "serviceclass");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    servicetitle = StringUtils.getValueFromJSONObject(obj, "servicetitle");
    id = StringUtils.getValueFromJSONObject(obj, "id");
    intenv = StringUtils.getValueFromJSONObject(obj, "intenv");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("servicemethod",StringUtils.noNull(servicemethod));
    obj.put("servicecode",StringUtils.noNull(servicecode));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("serviceclass",StringUtils.noNull(serviceclass));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("servicetitle",StringUtils.noNull(servicetitle));
    obj.put("id",StringUtils.noNull(id));
    obj.put("intenv",StringUtils.noNull(intenv));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("rstatus");
    columnList.add("createdat");
    columnList.add("servicemethod");
    columnList.add("servicecode");
    columnList.add("createdby");
    columnList.add("modifiedat");
    columnList.add("serviceclass");
    columnList.add("modifiedby");
    columnList.add("servicetitle");
    columnList.add("id");
    columnList.add("intenv");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "rstatus:" + rstatus +"createdat:" + createdat +"servicemethod:" + servicemethod +"servicecode:" + servicecode +"createdby:" + createdby +"modifiedat:" + modifiedat +"serviceclass:" + serviceclass +"modifiedby:" + modifiedby +"servicetitle:" + servicetitle +"id:" + id +"intenv:" + intenv +"";
  }
}
