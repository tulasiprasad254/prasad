package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBMakercheckerauditRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBMakercheckerauditRecord.class.getName());

  public String rstatus;

  public String tabname;

  public String createdat;

  public String comments;

  public String tablelabel;

  public String createdby;

  public String modifiedat;

  public String modifiedby;

  public String id;

  public String actionname;

  public String recid;

  public String getRstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rstatus);
    }
    else {
      return rstatus;
    }
  }

  public String getTabname() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(tabname);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(tabname);
    }
    else {
      return tabname;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getComments() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(comments);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(comments);
    }
    else {
      return comments;
    }
  }

  public String getTablelabel() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(tablelabel);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(tablelabel);
    }
    else {
      return tablelabel;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public String getActionname() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(actionname);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(actionname);
    }
    else {
      return actionname;
    }
  }

  public String getRecid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(recid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(recid);
    }
    else {
      return recid;
    }
  }

  public void setRstatus(String value) {
    rstatus = value;
  }

  public void setTabname(String value) {
    tabname = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setComments(String value) {
    comments = value;
  }

  public void setTablelabel(String value) {
    tablelabel = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void setActionname(String value) {
    actionname = value;
  }

  public void setRecid(String value) {
    recid = value;
  }

  public void loadContent(KBMakercheckerauditRecord inputRecord) {
    setRstatus(inputRecord.getRstatus());
    setTabname(inputRecord.getTabname());
    setCreatedat(inputRecord.getCreatedat());
    setComments(inputRecord.getComments());
    setTablelabel(inputRecord.getTablelabel());
    setCreatedby(inputRecord.getCreatedby());
    setModifiedat(inputRecord.getModifiedat());
    setModifiedby(inputRecord.getModifiedby());
    setId(inputRecord.getId());
    setActionname(inputRecord.getActionname());
    setRecid(inputRecord.getRecid());
  }

  public void loadNonNullContent(KBMakercheckerauditRecord inputRecord) {
    if (StringUtils.hasChanged(getRstatus(), inputRecord.getRstatus())) {
      setRstatus(StringUtils.noNull(inputRecord.getRstatus()));
    }
    if (StringUtils.hasChanged(getTabname(), inputRecord.getTabname())) {
      setTabname(StringUtils.noNull(inputRecord.getTabname()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getComments(), inputRecord.getComments())) {
      setComments(StringUtils.noNull(inputRecord.getComments()));
    }
    if (StringUtils.hasChanged(getTablelabel(), inputRecord.getTablelabel())) {
      setTablelabel(StringUtils.noNull(inputRecord.getTablelabel()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
    if (StringUtils.hasChanged(getActionname(), inputRecord.getActionname())) {
      setActionname(StringUtils.noNull(inputRecord.getActionname()));
    }
    if (StringUtils.hasChanged(getRecid(), inputRecord.getRecid())) {
      setRecid(StringUtils.noNull(inputRecord.getRecid()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("tabname",StringUtils.noNull(tabname));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("comments",StringUtils.noNull(comments));
    obj.put("tablelabel",StringUtils.noNull(tablelabel));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("actionname",StringUtils.noNull(actionname));
    obj.put("recid",StringUtils.noNull(recid));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    rstatus = StringUtils.getValueFromJSONObject(obj, "rstatus");
    tabname = StringUtils.getValueFromJSONObject(obj, "tabname");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    comments = StringUtils.getValueFromJSONObject(obj, "comments");
    tablelabel = StringUtils.getValueFromJSONObject(obj, "tablelabel");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    id = StringUtils.getValueFromJSONObject(obj, "id");
    actionname = StringUtils.getValueFromJSONObject(obj, "actionname");
    recid = StringUtils.getValueFromJSONObject(obj, "recid");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("tabname",StringUtils.noNull(tabname));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("comments",StringUtils.noNull(comments));
    obj.put("tablelabel",StringUtils.noNull(tablelabel));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("actionname",StringUtils.noNull(actionname));
    obj.put("recid",StringUtils.noNull(recid));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("rstatus");
    columnList.add("tabname");
    columnList.add("createdat");
    columnList.add("comments");
    columnList.add("tablelabel");
    columnList.add("createdby");
    columnList.add("modifiedat");
    columnList.add("modifiedby");
    columnList.add("id");
    columnList.add("actionname");
    columnList.add("recid");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "rstatus:" + rstatus +"tabname:" + tabname +"createdat:" + createdat +"comments:" + comments +"tablelabel:" + tablelabel +"createdby:" + createdby +"modifiedat:" + modifiedat +"modifiedby:" + modifiedby +"id:" + id +"actionname:" + actionname +"recid:" + recid +"";
  }
}
