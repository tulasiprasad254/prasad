package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBMailmesgRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBMailmesgRecord.class.getName());

  public String mretrycnt;

  public String nextattempt;

  public String lastattempt;

  public String modifiedat;

  public String mccaddr;

  public String mesgqin;

  public String rstatus;

  public String mfromaddr;

  public String mmessage;

  public String createdat;

  public String mesgqerr;

  public String msubject;

  public String createdby;

  public String mtoaddr;

  public String mesgqout;

  public String modifiedby;

  public String id;

  public String getMretrycnt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(mretrycnt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(mretrycnt);
    }
    else {
      return mretrycnt;
    }
  }

  public String getNextattempt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(nextattempt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(nextattempt);
    }
    else {
      return nextattempt;
    }
  }

  public String getLastattempt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(lastattempt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(lastattempt);
    }
    else {
      return lastattempt;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getMccaddr() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(mccaddr);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(mccaddr);
    }
    else {
      return mccaddr;
    }
  }

  public String getMesgqin() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(mesgqin);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(mesgqin);
    }
    else {
      return mesgqin;
    }
  }

  public String getRstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rstatus);
    }
    else {
      return rstatus;
    }
  }

  public String getMfromaddr() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(mfromaddr);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(mfromaddr);
    }
    else {
      return mfromaddr;
    }
  }

  public String getMmessage() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(mmessage);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(mmessage);
    }
    else {
      return mmessage;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getMesgqerr() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(mesgqerr);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(mesgqerr);
    }
    else {
      return mesgqerr;
    }
  }

  public String getMsubject() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(msubject);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(msubject);
    }
    else {
      return msubject;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getMtoaddr() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(mtoaddr);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(mtoaddr);
    }
    else {
      return mtoaddr;
    }
  }

  public String getMesgqout() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(mesgqout);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(mesgqout);
    }
    else {
      return mesgqout;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public void setMretrycnt(String value) {
    mretrycnt = value;
  }

  public void setNextattempt(String value) {
    nextattempt = value;
  }

  public void setLastattempt(String value) {
    lastattempt = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setMccaddr(String value) {
    mccaddr = value;
  }

  public void setMesgqin(String value) {
    mesgqin = value;
  }

  public void setRstatus(String value) {
    rstatus = value;
  }

  public void setMfromaddr(String value) {
    mfromaddr = value;
  }

  public void setMmessage(String value) {
    mmessage = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setMesgqerr(String value) {
    mesgqerr = value;
  }

  public void setMsubject(String value) {
    msubject = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setMtoaddr(String value) {
    mtoaddr = value;
  }

  public void setMesgqout(String value) {
    mesgqout = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void loadContent(KBMailmesgRecord inputRecord) {
    setMretrycnt(inputRecord.getMretrycnt());
    setNextattempt(inputRecord.getNextattempt());
    setLastattempt(inputRecord.getLastattempt());
    setModifiedat(inputRecord.getModifiedat());
    setMccaddr(inputRecord.getMccaddr());
    setMesgqin(inputRecord.getMesgqin());
    setRstatus(inputRecord.getRstatus());
    setMfromaddr(inputRecord.getMfromaddr());
    setMmessage(inputRecord.getMmessage());
    setCreatedat(inputRecord.getCreatedat());
    setMesgqerr(inputRecord.getMesgqerr());
    setMsubject(inputRecord.getMsubject());
    setCreatedby(inputRecord.getCreatedby());
    setMtoaddr(inputRecord.getMtoaddr());
    setMesgqout(inputRecord.getMesgqout());
    setModifiedby(inputRecord.getModifiedby());
    setId(inputRecord.getId());
  }

  public void loadNonNullContent(KBMailmesgRecord inputRecord) {
    if (StringUtils.hasChanged(getMretrycnt(), inputRecord.getMretrycnt())) {
      setMretrycnt(StringUtils.noNull(inputRecord.getMretrycnt()));
    }
    if (StringUtils.hasChanged(getNextattempt(), inputRecord.getNextattempt())) {
      setNextattempt(StringUtils.noNull(inputRecord.getNextattempt()));
    }
    if (StringUtils.hasChanged(getLastattempt(), inputRecord.getLastattempt())) {
      setLastattempt(StringUtils.noNull(inputRecord.getLastattempt()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getMccaddr(), inputRecord.getMccaddr())) {
      setMccaddr(StringUtils.noNull(inputRecord.getMccaddr()));
    }
    if (StringUtils.hasChanged(getMesgqin(), inputRecord.getMesgqin())) {
      setMesgqin(StringUtils.noNull(inputRecord.getMesgqin()));
    }
    if (StringUtils.hasChanged(getRstatus(), inputRecord.getRstatus())) {
      setRstatus(StringUtils.noNull(inputRecord.getRstatus()));
    }
    if (StringUtils.hasChanged(getMfromaddr(), inputRecord.getMfromaddr())) {
      setMfromaddr(StringUtils.noNull(inputRecord.getMfromaddr()));
    }
    if (StringUtils.hasChanged(getMmessage(), inputRecord.getMmessage())) {
      setMmessage(StringUtils.noNull(inputRecord.getMmessage()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getMesgqerr(), inputRecord.getMesgqerr())) {
      setMesgqerr(StringUtils.noNull(inputRecord.getMesgqerr()));
    }
    if (StringUtils.hasChanged(getMsubject(), inputRecord.getMsubject())) {
      setMsubject(StringUtils.noNull(inputRecord.getMsubject()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getMtoaddr(), inputRecord.getMtoaddr())) {
      setMtoaddr(StringUtils.noNull(inputRecord.getMtoaddr()));
    }
    if (StringUtils.hasChanged(getMesgqout(), inputRecord.getMesgqout())) {
      setMesgqout(StringUtils.noNull(inputRecord.getMesgqout()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("mretrycnt",StringUtils.noNull(mretrycnt));
    obj.put("nextattempt",StringUtils.noNull(nextattempt));
    obj.put("lastattempt",StringUtils.noNull(lastattempt));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("mccaddr",StringUtils.noNull(mccaddr));
    obj.put("mesgqin",StringUtils.noNull(mesgqin));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("mfromaddr",StringUtils.noNull(mfromaddr));
    obj.put("mmessage",StringUtils.noNull(mmessage));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("mesgqerr",StringUtils.noNull(mesgqerr));
    obj.put("msubject",StringUtils.noNull(msubject));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("mtoaddr",StringUtils.noNull(mtoaddr));
    obj.put("mesgqout",StringUtils.noNull(mesgqout));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    mretrycnt = StringUtils.getValueFromJSONObject(obj, "mretrycnt");
    nextattempt = StringUtils.getValueFromJSONObject(obj, "nextattempt");
    lastattempt = StringUtils.getValueFromJSONObject(obj, "lastattempt");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    mccaddr = StringUtils.getValueFromJSONObject(obj, "mccaddr");
    mesgqin = StringUtils.getValueFromJSONObject(obj, "mesgqin");
    rstatus = StringUtils.getValueFromJSONObject(obj, "rstatus");
    mfromaddr = StringUtils.getValueFromJSONObject(obj, "mfromaddr");
    mmessage = StringUtils.getValueFromJSONObject(obj, "mmessage");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    mesgqerr = StringUtils.getValueFromJSONObject(obj, "mesgqerr");
    msubject = StringUtils.getValueFromJSONObject(obj, "msubject");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    mtoaddr = StringUtils.getValueFromJSONObject(obj, "mtoaddr");
    mesgqout = StringUtils.getValueFromJSONObject(obj, "mesgqout");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    id = StringUtils.getValueFromJSONObject(obj, "id");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("mretrycnt",StringUtils.noNull(mretrycnt));
    obj.put("nextattempt",StringUtils.noNull(nextattempt));
    obj.put("lastattempt",StringUtils.noNull(lastattempt));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("mccaddr",StringUtils.noNull(mccaddr));
    obj.put("mesgqin",StringUtils.noNull(mesgqin));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("mfromaddr",StringUtils.noNull(mfromaddr));
    obj.put("mmessage",StringUtils.noNull(mmessage));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("mesgqerr",StringUtils.noNull(mesgqerr));
    obj.put("msubject",StringUtils.noNull(msubject));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("mtoaddr",StringUtils.noNull(mtoaddr));
    obj.put("mesgqout",StringUtils.noNull(mesgqout));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("mretrycnt");
    columnList.add("nextattempt");
    columnList.add("lastattempt");
    columnList.add("modifiedat");
    columnList.add("mccaddr");
    columnList.add("mesgqin");
    columnList.add("rstatus");
    columnList.add("mfromaddr");
    columnList.add("mmessage");
    columnList.add("createdat");
    columnList.add("mesgqerr");
    columnList.add("msubject");
    columnList.add("createdby");
    columnList.add("mtoaddr");
    columnList.add("mesgqout");
    columnList.add("modifiedby");
    columnList.add("id");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "mretrycnt:" + mretrycnt +"nextattempt:" + nextattempt +"lastattempt:" + lastattempt +"modifiedat:" + modifiedat +"mccaddr:" + mccaddr +"mesgqin:" + mesgqin +"rstatus:" + rstatus +"mfromaddr:" + mfromaddr +"mmessage:" + mmessage +"createdat:" + createdat +"mesgqerr:" + mesgqerr +"msubject:" + msubject +"createdby:" + createdby +"mtoaddr:" + mtoaddr +"mesgqout:" + mesgqout +"modifiedby:" + modifiedby +"id:" + id +"";
  }
}
