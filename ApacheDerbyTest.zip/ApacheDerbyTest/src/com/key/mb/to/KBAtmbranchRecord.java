package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBAtmbranchRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBAtmbranchRecord.class.getName());

  public String ablong;

  public String currappstatus;

  public String institutionid;

  public String makerlastcmt;

  public String dist;

  public String abaddress;

  public String ablatt;

  public String madeat;

  public String abmgr;

  public String checkedat;

  public String abcity;

  public String createdby;

  public String abfax;

  public String id;

  public String modifiedat;

  public String abregion;

  public String madeby;

  public String adminlastcmt;

  public String abhours;

  public String checkerlastcmt;

  public String rstatus;

  public String createdat;

  public String abname;

  public String checkedby;

  public String abtype;

  public String modifiedby;

  public String abphone;

  public String getAblong() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(ablong);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(ablong);
    }
    else {
      return ablong;
    }
  }

  public String getCurrappstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(currappstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(currappstatus);
    }
    else {
      return currappstatus;
    }
  }

  public String getInstitutionid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(institutionid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(institutionid);
    }
    else {
      return institutionid;
    }
  }

  public String getMakerlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(makerlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(makerlastcmt);
    }
    else {
      return makerlastcmt;
    }
  }

  public String getDist() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(dist);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(dist);
    }
    else {
      return dist;
    }
  }

  public String getAbaddress() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(abaddress);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(abaddress);
    }
    else {
      return abaddress;
    }
  }

  public String getAblatt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(ablatt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(ablatt);
    }
    else {
      return ablatt;
    }
  }

  public String getMadeat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(madeat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(madeat);
    }
    else {
      return madeat;
    }
  }

  public String getAbmgr() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(abmgr);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(abmgr);
    }
    else {
      return abmgr;
    }
  }

  public String getCheckedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkedat);
    }
    else {
      return checkedat;
    }
  }

  public String getAbcity() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(abcity);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(abcity);
    }
    else {
      return abcity;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getAbfax() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(abfax);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(abfax);
    }
    else {
      return abfax;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getAbregion() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(abregion);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(abregion);
    }
    else {
      return abregion;
    }
  }

  public String getMadeby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(madeby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(madeby);
    }
    else {
      return madeby;
    }
  }

  public String getAdminlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(adminlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(adminlastcmt);
    }
    else {
      return adminlastcmt;
    }
  }

  public String getAbhours() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(abhours);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(abhours);
    }
    else {
      return abhours;
    }
  }

  public String getCheckerlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkerlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkerlastcmt);
    }
    else {
      return checkerlastcmt;
    }
  }

  public String getRstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rstatus);
    }
    else {
      return rstatus;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getAbname() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(abname);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(abname);
    }
    else {
      return abname;
    }
  }

  public String getCheckedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkedby);
    }
    else {
      return checkedby;
    }
  }

  public String getAbtype() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(abtype);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(abtype);
    }
    else {
      return abtype;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getAbphone() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(abphone);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(abphone);
    }
    else {
      return abphone;
    }
  }

  public void setAblong(String value) {
    ablong = value;
  }

  public void setCurrappstatus(String value) {
    currappstatus = value;
  }

  public void setInstitutionid(String value) {
    institutionid = value;
  }

  public void setMakerlastcmt(String value) {
    makerlastcmt = value;
  }

  public void setDist(String value) {
    dist = value;
  }

  public void setAbaddress(String value) {
    abaddress = value;
  }

  public void setAblatt(String value) {
    ablatt = value;
  }

  public void setMadeat(String value) {
    madeat = value;
  }

  public void setAbmgr(String value) {
    abmgr = value;
  }

  public void setCheckedat(String value) {
    checkedat = value;
  }

  public void setAbcity(String value) {
    abcity = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setAbfax(String value) {
    abfax = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setAbregion(String value) {
    abregion = value;
  }

  public void setMadeby(String value) {
    madeby = value;
  }

  public void setAdminlastcmt(String value) {
    adminlastcmt = value;
  }

  public void setAbhours(String value) {
    abhours = value;
  }

  public void setCheckerlastcmt(String value) {
    checkerlastcmt = value;
  }

  public void setRstatus(String value) {
    rstatus = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setAbname(String value) {
    abname = value;
  }

  public void setCheckedby(String value) {
    checkedby = value;
  }

  public void setAbtype(String value) {
    abtype = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setAbphone(String value) {
    abphone = value;
  }

  public void loadContent(KBAtmbranchRecord inputRecord) {
    setAblong(inputRecord.getAblong());
    setCurrappstatus(inputRecord.getCurrappstatus());
    setInstitutionid(inputRecord.getInstitutionid());
    setMakerlastcmt(inputRecord.getMakerlastcmt());
    setDist(inputRecord.getDist());
    setAbaddress(inputRecord.getAbaddress());
    setAblatt(inputRecord.getAblatt());
    setMadeat(inputRecord.getMadeat());
    setAbmgr(inputRecord.getAbmgr());
    setCheckedat(inputRecord.getCheckedat());
    setAbcity(inputRecord.getAbcity());
    setCreatedby(inputRecord.getCreatedby());
    setAbfax(inputRecord.getAbfax());
    setId(inputRecord.getId());
    setModifiedat(inputRecord.getModifiedat());
    setAbregion(inputRecord.getAbregion());
    setMadeby(inputRecord.getMadeby());
    setAdminlastcmt(inputRecord.getAdminlastcmt());
    setAbhours(inputRecord.getAbhours());
    setCheckerlastcmt(inputRecord.getCheckerlastcmt());
    setRstatus(inputRecord.getRstatus());
    setCreatedat(inputRecord.getCreatedat());
    setAbname(inputRecord.getAbname());
    setCheckedby(inputRecord.getCheckedby());
    setAbtype(inputRecord.getAbtype());
    setModifiedby(inputRecord.getModifiedby());
    setAbphone(inputRecord.getAbphone());
  }

  public void loadNonNullContent(KBAtmbranchRecord inputRecord) {
    if (StringUtils.hasChanged(getAblong(), inputRecord.getAblong())) {
      setAblong(StringUtils.noNull(inputRecord.getAblong()));
    }
    if (StringUtils.hasChanged(getCurrappstatus(), inputRecord.getCurrappstatus())) {
      setCurrappstatus(StringUtils.noNull(inputRecord.getCurrappstatus()));
    }
    if (StringUtils.hasChanged(getInstitutionid(), inputRecord.getInstitutionid())) {
      setInstitutionid(StringUtils.noNull(inputRecord.getInstitutionid()));
    }
    if (StringUtils.hasChanged(getMakerlastcmt(), inputRecord.getMakerlastcmt())) {
      setMakerlastcmt(StringUtils.noNull(inputRecord.getMakerlastcmt()));
    }
    if (StringUtils.hasChanged(getDist(), inputRecord.getDist())) {
      setDist(StringUtils.noNull(inputRecord.getDist()));
    }
    if (StringUtils.hasChanged(getAbaddress(), inputRecord.getAbaddress())) {
      setAbaddress(StringUtils.noNull(inputRecord.getAbaddress()));
    }
    if (StringUtils.hasChanged(getAblatt(), inputRecord.getAblatt())) {
      setAblatt(StringUtils.noNull(inputRecord.getAblatt()));
    }
    if (StringUtils.hasChanged(getMadeat(), inputRecord.getMadeat())) {
      setMadeat(StringUtils.noNull(inputRecord.getMadeat()));
    }
    if (StringUtils.hasChanged(getAbmgr(), inputRecord.getAbmgr())) {
      setAbmgr(StringUtils.noNull(inputRecord.getAbmgr()));
    }
    if (StringUtils.hasChanged(getCheckedat(), inputRecord.getCheckedat())) {
      setCheckedat(StringUtils.noNull(inputRecord.getCheckedat()));
    }
    if (StringUtils.hasChanged(getAbcity(), inputRecord.getAbcity())) {
      setAbcity(StringUtils.noNull(inputRecord.getAbcity()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getAbfax(), inputRecord.getAbfax())) {
      setAbfax(StringUtils.noNull(inputRecord.getAbfax()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getAbregion(), inputRecord.getAbregion())) {
      setAbregion(StringUtils.noNull(inputRecord.getAbregion()));
    }
    if (StringUtils.hasChanged(getMadeby(), inputRecord.getMadeby())) {
      setMadeby(StringUtils.noNull(inputRecord.getMadeby()));
    }
    if (StringUtils.hasChanged(getAdminlastcmt(), inputRecord.getAdminlastcmt())) {
      setAdminlastcmt(StringUtils.noNull(inputRecord.getAdminlastcmt()));
    }
    if (StringUtils.hasChanged(getAbhours(), inputRecord.getAbhours())) {
      setAbhours(StringUtils.noNull(inputRecord.getAbhours()));
    }
    if (StringUtils.hasChanged(getCheckerlastcmt(), inputRecord.getCheckerlastcmt())) {
      setCheckerlastcmt(StringUtils.noNull(inputRecord.getCheckerlastcmt()));
    }
    if (StringUtils.hasChanged(getRstatus(), inputRecord.getRstatus())) {
      setRstatus(StringUtils.noNull(inputRecord.getRstatus()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getAbname(), inputRecord.getAbname())) {
      setAbname(StringUtils.noNull(inputRecord.getAbname()));
    }
    if (StringUtils.hasChanged(getCheckedby(), inputRecord.getCheckedby())) {
      setCheckedby(StringUtils.noNull(inputRecord.getCheckedby()));
    }
    if (StringUtils.hasChanged(getAbtype(), inputRecord.getAbtype())) {
      setAbtype(StringUtils.noNull(inputRecord.getAbtype()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getAbphone(), inputRecord.getAbphone())) {
      setAbphone(StringUtils.noNull(inputRecord.getAbphone()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("ablong",StringUtils.noNull(ablong));
    obj.put("currappstatus",StringUtils.noNull(currappstatus));
    obj.put("institutionid",StringUtils.noNull(institutionid));
    obj.put("makerlastcmt",StringUtils.noNull(makerlastcmt));
    obj.put("dist",StringUtils.noNull(dist));
    obj.put("abaddress",StringUtils.noNull(abaddress));
    obj.put("ablatt",StringUtils.noNull(ablatt));
    obj.put("madeat",StringUtils.noNull(madeat));
    obj.put("abmgr",StringUtils.noNull(abmgr));
    obj.put("checkedat",StringUtils.noNull(checkedat));
    obj.put("abcity",StringUtils.noNull(abcity));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("abfax",StringUtils.noNull(abfax));
    obj.put("id",StringUtils.noNull(id));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("abregion",StringUtils.noNull(abregion));
    obj.put("madeby",StringUtils.noNull(madeby));
    obj.put("adminlastcmt",StringUtils.noNull(adminlastcmt));
    obj.put("abhours",StringUtils.noNull(abhours));
    obj.put("checkerlastcmt",StringUtils.noNull(checkerlastcmt));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("abname",StringUtils.noNull(abname));
    obj.put("checkedby",StringUtils.noNull(checkedby));
    obj.put("abtype",StringUtils.noNull(abtype));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("abphone",StringUtils.noNull(abphone));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    ablong = StringUtils.getValueFromJSONObject(obj, "ablong");
    currappstatus = StringUtils.getValueFromJSONObject(obj, "currappstatus");
    institutionid = StringUtils.getValueFromJSONObject(obj, "institutionid");
    makerlastcmt = StringUtils.getValueFromJSONObject(obj, "makerlastcmt");
    dist = StringUtils.getValueFromJSONObject(obj, "dist");
    abaddress = StringUtils.getValueFromJSONObject(obj, "abaddress");
    ablatt = StringUtils.getValueFromJSONObject(obj, "ablatt");
    madeat = StringUtils.getValueFromJSONObject(obj, "madeat");
    abmgr = StringUtils.getValueFromJSONObject(obj, "abmgr");
    checkedat = StringUtils.getValueFromJSONObject(obj, "checkedat");
    abcity = StringUtils.getValueFromJSONObject(obj, "abcity");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    abfax = StringUtils.getValueFromJSONObject(obj, "abfax");
    id = StringUtils.getValueFromJSONObject(obj, "id");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    abregion = StringUtils.getValueFromJSONObject(obj, "abregion");
    madeby = StringUtils.getValueFromJSONObject(obj, "madeby");
    adminlastcmt = StringUtils.getValueFromJSONObject(obj, "adminlastcmt");
    abhours = StringUtils.getValueFromJSONObject(obj, "abhours");
    checkerlastcmt = StringUtils.getValueFromJSONObject(obj, "checkerlastcmt");
    rstatus = StringUtils.getValueFromJSONObject(obj, "rstatus");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    abname = StringUtils.getValueFromJSONObject(obj, "abname");
    checkedby = StringUtils.getValueFromJSONObject(obj, "checkedby");
    abtype = StringUtils.getValueFromJSONObject(obj, "abtype");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    abphone = StringUtils.getValueFromJSONObject(obj, "abphone");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("ablong",StringUtils.noNull(ablong));
    obj.put("currappstatus",StringUtils.noNull(currappstatus));
    obj.put("institutionid",StringUtils.noNull(institutionid));
    obj.put("makerlastcmt",StringUtils.noNull(makerlastcmt));
    obj.put("dist",StringUtils.noNull(dist));
    obj.put("abaddress",StringUtils.noNull(abaddress));
    obj.put("ablatt",StringUtils.noNull(ablatt));
    obj.put("madeat",StringUtils.noNull(madeat));
    obj.put("abmgr",StringUtils.noNull(abmgr));
    obj.put("checkedat",StringUtils.noNull(checkedat));
    obj.put("abcity",StringUtils.noNull(abcity));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("abfax",StringUtils.noNull(abfax));
    obj.put("id",StringUtils.noNull(id));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("abregion",StringUtils.noNull(abregion));
    obj.put("madeby",StringUtils.noNull(madeby));
    obj.put("adminlastcmt",StringUtils.noNull(adminlastcmt));
    obj.put("abhours",StringUtils.noNull(abhours));
    obj.put("checkerlastcmt",StringUtils.noNull(checkerlastcmt));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("abname",StringUtils.noNull(abname));
    obj.put("checkedby",StringUtils.noNull(checkedby));
    obj.put("abtype",StringUtils.noNull(abtype));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("abphone",StringUtils.noNull(abphone));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("ablong");
    columnList.add("currappstatus");
    columnList.add("institutionid");
    columnList.add("makerlastcmt");
    columnList.add("dist");
    columnList.add("abaddress");
    columnList.add("ablatt");
    columnList.add("madeat");
    columnList.add("abmgr");
    columnList.add("checkedat");
    columnList.add("abcity");
    columnList.add("createdby");
    columnList.add("abfax");
    columnList.add("id");
    columnList.add("modifiedat");
    columnList.add("abregion");
    columnList.add("madeby");
    columnList.add("adminlastcmt");
    columnList.add("abhours");
    columnList.add("checkerlastcmt");
    columnList.add("rstatus");
    columnList.add("createdat");
    columnList.add("abname");
    columnList.add("checkedby");
    columnList.add("abtype");
    columnList.add("modifiedby");
    columnList.add("abphone");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "ablong:" + ablong +"currappstatus:" + currappstatus +"institutionid:" + institutionid +"makerlastcmt:" + makerlastcmt +"dist:" + dist +"abaddress:" + abaddress +"ablatt:" + ablatt +"madeat:" + madeat +"abmgr:" + abmgr +"checkedat:" + checkedat +"abcity:" + abcity +"createdby:" + createdby +"abfax:" + abfax +"id:" + id +"modifiedat:" + modifiedat +"abregion:" + abregion +"madeby:" + madeby +"adminlastcmt:" + adminlastcmt +"abhours:" + abhours +"checkerlastcmt:" + checkerlastcmt +"rstatus:" + rstatus +"createdat:" + createdat +"abname:" + abname +"checkedby:" + checkedby +"abtype:" + abtype +"modifiedby:" + modifiedby +"abphone:" + abphone +"";
  }
}
