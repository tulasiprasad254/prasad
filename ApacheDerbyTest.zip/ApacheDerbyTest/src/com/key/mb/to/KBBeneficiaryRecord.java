package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBBeneficiaryRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBBeneficiaryRecord.class.getName());

  public String currappstatus;

  public String benemobile;

  public String beneficiaryname;

  public String institutionid;

  public String makerlastcmt;

  public String beneficiaryacno;

  public String modifiedat;

  public String beneficiarytype;

  public String madeby;

  public String adminlastcmt;

  public String branch;

  public String madeat;

  public String checkerlastcmt;

  public String rstatus;

  public String createdat;

  public String checkedat;

  public String createdby;

  public String checkedby;

  public String benecurr;

  public String customerid;

  public String modifiedby;

  public String id;

  public String bankcode;

  public String getCurrappstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(currappstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(currappstatus);
    }
    else {
      return currappstatus;
    }
  }

  public String getBenemobile() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(benemobile);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(benemobile);
    }
    else {
      return benemobile;
    }
  }

  public String getBeneficiaryname() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(beneficiaryname);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(beneficiaryname);
    }
    else {
      return beneficiaryname;
    }
  }

  public String getInstitutionid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(institutionid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(institutionid);
    }
    else {
      return institutionid;
    }
  }

  public String getMakerlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(makerlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(makerlastcmt);
    }
    else {
      return makerlastcmt;
    }
  }

  public String getBeneficiaryacno() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(beneficiaryacno);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(beneficiaryacno);
    }
    else {
      return beneficiaryacno;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getBeneficiarytype() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(beneficiarytype);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(beneficiarytype);
    }
    else {
      return beneficiarytype;
    }
  }

  public String getMadeby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(madeby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(madeby);
    }
    else {
      return madeby;
    }
  }

  public String getAdminlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(adminlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(adminlastcmt);
    }
    else {
      return adminlastcmt;
    }
  }

  public String getBranch() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(branch);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(branch);
    }
    else {
      return branch;
    }
  }

  public String getMadeat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(madeat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(madeat);
    }
    else {
      return madeat;
    }
  }

  public String getCheckerlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkerlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkerlastcmt);
    }
    else {
      return checkerlastcmt;
    }
  }

  public String getRstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rstatus);
    }
    else {
      return rstatus;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getCheckedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkedat);
    }
    else {
      return checkedat;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getCheckedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkedby);
    }
    else {
      return checkedby;
    }
  }

  public String getBenecurr() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(benecurr);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(benecurr);
    }
    else {
      return benecurr;
    }
  }

  public String getCustomerid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(customerid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(customerid);
    }
    else {
      return customerid;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public String getBankcode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(bankcode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(bankcode);
    }
    else {
      return bankcode;
    }
  }

  public void setCurrappstatus(String value) {
    currappstatus = value;
  }

  public void setBenemobile(String value) {
    benemobile = value;
  }

  public void setBeneficiaryname(String value) {
    beneficiaryname = value;
  }

  public void setInstitutionid(String value) {
    institutionid = value;
  }

  public void setMakerlastcmt(String value) {
    makerlastcmt = value;
  }

  public void setBeneficiaryacno(String value) {
    beneficiaryacno = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setBeneficiarytype(String value) {
    beneficiarytype = value;
  }

  public void setMadeby(String value) {
    madeby = value;
  }

  public void setAdminlastcmt(String value) {
    adminlastcmt = value;
  }

  public void setBranch(String value) {
    branch = value;
  }

  public void setMadeat(String value) {
    madeat = value;
  }

  public void setCheckerlastcmt(String value) {
    checkerlastcmt = value;
  }

  public void setRstatus(String value) {
    rstatus = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setCheckedat(String value) {
    checkedat = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setCheckedby(String value) {
    checkedby = value;
  }

  public void setBenecurr(String value) {
    benecurr = value;
  }

  public void setCustomerid(String value) {
    customerid = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void setBankcode(String value) {
    bankcode = value;
  }

  public void loadContent(KBBeneficiaryRecord inputRecord) {
    setCurrappstatus(inputRecord.getCurrappstatus());
    setBenemobile(inputRecord.getBenemobile());
    setBeneficiaryname(inputRecord.getBeneficiaryname());
    setInstitutionid(inputRecord.getInstitutionid());
    setMakerlastcmt(inputRecord.getMakerlastcmt());
    setBeneficiaryacno(inputRecord.getBeneficiaryacno());
    setModifiedat(inputRecord.getModifiedat());
    setBeneficiarytype(inputRecord.getBeneficiarytype());
    setMadeby(inputRecord.getMadeby());
    setAdminlastcmt(inputRecord.getAdminlastcmt());
    setBranch(inputRecord.getBranch());
    setMadeat(inputRecord.getMadeat());
    setCheckerlastcmt(inputRecord.getCheckerlastcmt());
    setRstatus(inputRecord.getRstatus());
    setCreatedat(inputRecord.getCreatedat());
    setCheckedat(inputRecord.getCheckedat());
    setCreatedby(inputRecord.getCreatedby());
    setCheckedby(inputRecord.getCheckedby());
    setBenecurr(inputRecord.getBenecurr());
    setCustomerid(inputRecord.getCustomerid());
    setModifiedby(inputRecord.getModifiedby());
    setId(inputRecord.getId());
    setBankcode(inputRecord.getBankcode());
  }

  public void loadNonNullContent(KBBeneficiaryRecord inputRecord) {
    if (StringUtils.hasChanged(getCurrappstatus(), inputRecord.getCurrappstatus())) {
      setCurrappstatus(StringUtils.noNull(inputRecord.getCurrappstatus()));
    }
    if (StringUtils.hasChanged(getBenemobile(), inputRecord.getBenemobile())) {
      setBenemobile(StringUtils.noNull(inputRecord.getBenemobile()));
    }
    if (StringUtils.hasChanged(getBeneficiaryname(), inputRecord.getBeneficiaryname())) {
      setBeneficiaryname(StringUtils.noNull(inputRecord.getBeneficiaryname()));
    }
    if (StringUtils.hasChanged(getInstitutionid(), inputRecord.getInstitutionid())) {
      setInstitutionid(StringUtils.noNull(inputRecord.getInstitutionid()));
    }
    if (StringUtils.hasChanged(getMakerlastcmt(), inputRecord.getMakerlastcmt())) {
      setMakerlastcmt(StringUtils.noNull(inputRecord.getMakerlastcmt()));
    }
    if (StringUtils.hasChanged(getBeneficiaryacno(), inputRecord.getBeneficiaryacno())) {
      setBeneficiaryacno(StringUtils.noNull(inputRecord.getBeneficiaryacno()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getBeneficiarytype(), inputRecord.getBeneficiarytype())) {
      setBeneficiarytype(StringUtils.noNull(inputRecord.getBeneficiarytype()));
    }
    if (StringUtils.hasChanged(getMadeby(), inputRecord.getMadeby())) {
      setMadeby(StringUtils.noNull(inputRecord.getMadeby()));
    }
    if (StringUtils.hasChanged(getAdminlastcmt(), inputRecord.getAdminlastcmt())) {
      setAdminlastcmt(StringUtils.noNull(inputRecord.getAdminlastcmt()));
    }
    if (StringUtils.hasChanged(getBranch(), inputRecord.getBranch())) {
      setBranch(StringUtils.noNull(inputRecord.getBranch()));
    }
    if (StringUtils.hasChanged(getMadeat(), inputRecord.getMadeat())) {
      setMadeat(StringUtils.noNull(inputRecord.getMadeat()));
    }
    if (StringUtils.hasChanged(getCheckerlastcmt(), inputRecord.getCheckerlastcmt())) {
      setCheckerlastcmt(StringUtils.noNull(inputRecord.getCheckerlastcmt()));
    }
    if (StringUtils.hasChanged(getRstatus(), inputRecord.getRstatus())) {
      setRstatus(StringUtils.noNull(inputRecord.getRstatus()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getCheckedat(), inputRecord.getCheckedat())) {
      setCheckedat(StringUtils.noNull(inputRecord.getCheckedat()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getCheckedby(), inputRecord.getCheckedby())) {
      setCheckedby(StringUtils.noNull(inputRecord.getCheckedby()));
    }
    if (StringUtils.hasChanged(getBenecurr(), inputRecord.getBenecurr())) {
      setBenecurr(StringUtils.noNull(inputRecord.getBenecurr()));
    }
    if (StringUtils.hasChanged(getCustomerid(), inputRecord.getCustomerid())) {
      setCustomerid(StringUtils.noNull(inputRecord.getCustomerid()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
    if (StringUtils.hasChanged(getBankcode(), inputRecord.getBankcode())) {
      setBankcode(StringUtils.noNull(inputRecord.getBankcode()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("currappstatus",StringUtils.noNull(currappstatus));
    obj.put("benemobile",StringUtils.noNull(benemobile));
    obj.put("beneficiaryname",StringUtils.noNull(beneficiaryname));
    obj.put("institutionid",StringUtils.noNull(institutionid));
    obj.put("makerlastcmt",StringUtils.noNull(makerlastcmt));
    obj.put("beneficiaryacno",StringUtils.noNull(beneficiaryacno));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("beneficiarytype",StringUtils.noNull(beneficiarytype));
    obj.put("madeby",StringUtils.noNull(madeby));
    obj.put("adminlastcmt",StringUtils.noNull(adminlastcmt));
    obj.put("branch",StringUtils.noNull(branch));
    obj.put("madeat",StringUtils.noNull(madeat));
    obj.put("checkerlastcmt",StringUtils.noNull(checkerlastcmt));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("checkedat",StringUtils.noNull(checkedat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("checkedby",StringUtils.noNull(checkedby));
    obj.put("benecurr",StringUtils.noNull(benecurr));
    obj.put("customerid",StringUtils.noNull(customerid));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("bankcode",StringUtils.noNull(bankcode));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    currappstatus = StringUtils.getValueFromJSONObject(obj, "currappstatus");
    benemobile = StringUtils.getValueFromJSONObject(obj, "benemobile");
    beneficiaryname = StringUtils.getValueFromJSONObject(obj, "beneficiaryname");
    institutionid = StringUtils.getValueFromJSONObject(obj, "institutionid");
    makerlastcmt = StringUtils.getValueFromJSONObject(obj, "makerlastcmt");
    beneficiaryacno = StringUtils.getValueFromJSONObject(obj, "beneficiaryacno");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    beneficiarytype = StringUtils.getValueFromJSONObject(obj, "beneficiarytype");
    madeby = StringUtils.getValueFromJSONObject(obj, "madeby");
    adminlastcmt = StringUtils.getValueFromJSONObject(obj, "adminlastcmt");
    branch = StringUtils.getValueFromJSONObject(obj, "branch");
    madeat = StringUtils.getValueFromJSONObject(obj, "madeat");
    checkerlastcmt = StringUtils.getValueFromJSONObject(obj, "checkerlastcmt");
    rstatus = StringUtils.getValueFromJSONObject(obj, "rstatus");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    checkedat = StringUtils.getValueFromJSONObject(obj, "checkedat");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    checkedby = StringUtils.getValueFromJSONObject(obj, "checkedby");
    benecurr = StringUtils.getValueFromJSONObject(obj, "benecurr");
    customerid = StringUtils.getValueFromJSONObject(obj, "customerid");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    id = StringUtils.getValueFromJSONObject(obj, "id");
    bankcode = StringUtils.getValueFromJSONObject(obj, "bankcode");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("currappstatus",StringUtils.noNull(currappstatus));
    obj.put("benemobile",StringUtils.noNull(benemobile));
    obj.put("beneficiaryname",StringUtils.noNull(beneficiaryname));
    obj.put("institutionid",StringUtils.noNull(institutionid));
    obj.put("makerlastcmt",StringUtils.noNull(makerlastcmt));
    obj.put("beneficiaryacno",StringUtils.noNull(beneficiaryacno));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("beneficiarytype",StringUtils.noNull(beneficiarytype));
    obj.put("madeby",StringUtils.noNull(madeby));
    obj.put("adminlastcmt",StringUtils.noNull(adminlastcmt));
    obj.put("branch",StringUtils.noNull(branch));
    obj.put("madeat",StringUtils.noNull(madeat));
    obj.put("checkerlastcmt",StringUtils.noNull(checkerlastcmt));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("checkedat",StringUtils.noNull(checkedat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("checkedby",StringUtils.noNull(checkedby));
    obj.put("benecurr",StringUtils.noNull(benecurr));
    obj.put("customerid",StringUtils.noNull(customerid));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("bankcode",StringUtils.noNull(bankcode));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("currappstatus");
    columnList.add("benemobile");
    columnList.add("beneficiaryname");
    columnList.add("institutionid");
    columnList.add("makerlastcmt");
    columnList.add("beneficiaryacno");
    columnList.add("modifiedat");
    columnList.add("beneficiarytype");
    columnList.add("madeby");
    columnList.add("adminlastcmt");
    columnList.add("branch");
    columnList.add("madeat");
    columnList.add("checkerlastcmt");
    columnList.add("rstatus");
    columnList.add("createdat");
    columnList.add("checkedat");
    columnList.add("createdby");
    columnList.add("checkedby");
    columnList.add("benecurr");
    columnList.add("customerid");
    columnList.add("modifiedby");
    columnList.add("id");
    columnList.add("bankcode");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "currappstatus:" + currappstatus +"benemobile:" + benemobile +"beneficiaryname:" + beneficiaryname +"institutionid:" + institutionid +"makerlastcmt:" + makerlastcmt +"beneficiaryacno:" + beneficiaryacno +"modifiedat:" + modifiedat +"beneficiarytype:" + beneficiarytype +"madeby:" + madeby +"adminlastcmt:" + adminlastcmt +"branch:" + branch +"madeat:" + madeat +"checkerlastcmt:" + checkerlastcmt +"rstatus:" + rstatus +"createdat:" + createdat +"checkedat:" + checkedat +"createdby:" + createdby +"checkedby:" + checkedby +"benecurr:" + benecurr +"customerid:" + customerid +"modifiedby:" + modifiedby +"id:" + id +"bankcode:" + bankcode +"";
  }
}
