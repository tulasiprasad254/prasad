package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBMobilesession2Record extends KBRecord {
  public static LogUtils logger = new LogUtils(KBMobilesession2Record.class.getName());

  public String lastphonetype;

  public String lastphoneid;

  public String extnval1;

  public String cifno;

  public String modifiedat;

  public String extnval3;

  public String lastftamt;

  public String extnval2;

  public String lastftfrom;

  public String sessionid;

  public String agentacc;

  public String createdat;

  public String langcode;

  public String lastftto;

  public String navcont;

  public String createdby;

  public String agentflag;

  public String extnval4;

  public String lastacc;

  public String modifiedby;

  public String id;

  public String lastftremarks;

  public String agentchargesacc;

  public String status;

  public String getLastphonetype() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(lastphonetype);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(lastphonetype);
    }
    else {
      return lastphonetype;
    }
  }

  public String getLastphoneid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(lastphoneid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(lastphoneid);
    }
    else {
      return lastphoneid;
    }
  }

  public String getExtnval1() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(extnval1);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(extnval1);
    }
    else {
      return extnval1;
    }
  }

  public String getCifno() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(cifno);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(cifno);
    }
    else {
      return cifno;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getExtnval3() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(extnval3);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(extnval3);
    }
    else {
      return extnval3;
    }
  }

  public String getLastftamt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(lastftamt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(lastftamt);
    }
    else {
      return lastftamt;
    }
  }

  public String getExtnval2() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(extnval2);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(extnval2);
    }
    else {
      return extnval2;
    }
  }

  public String getLastftfrom() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(lastftfrom);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(lastftfrom);
    }
    else {
      return lastftfrom;
    }
  }

  public String getSessionid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(sessionid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(sessionid);
    }
    else {
      return sessionid;
    }
  }

  public String getAgentacc() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(agentacc);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(agentacc);
    }
    else {
      return agentacc;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getLangcode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(langcode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(langcode);
    }
    else {
      return langcode;
    }
  }

  public String getLastftto() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(lastftto);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(lastftto);
    }
    else {
      return lastftto;
    }
  }

  public String getNavcont() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(navcont);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(navcont);
    }
    else {
      return navcont;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getAgentflag() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(agentflag);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(agentflag);
    }
    else {
      return agentflag;
    }
  }

  public String getExtnval4() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(extnval4);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(extnval4);
    }
    else {
      return extnval4;
    }
  }

  public String getLastacc() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(lastacc);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(lastacc);
    }
    else {
      return lastacc;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public String getLastftremarks() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(lastftremarks);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(lastftremarks);
    }
    else {
      return lastftremarks;
    }
  }

  public String getAgentchargesacc() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(agentchargesacc);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(agentchargesacc);
    }
    else {
      return agentchargesacc;
    }
  }

  public String getStatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(status);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(status);
    }
    else {
      return status;
    }
  }

  public void setLastphonetype(String value) {
    lastphonetype = value;
  }

  public void setLastphoneid(String value) {
    lastphoneid = value;
  }

  public void setExtnval1(String value) {
    extnval1 = value;
  }

  public void setCifno(String value) {
    cifno = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setExtnval3(String value) {
    extnval3 = value;
  }

  public void setLastftamt(String value) {
    lastftamt = value;
  }

  public void setExtnval2(String value) {
    extnval2 = value;
  }

  public void setLastftfrom(String value) {
    lastftfrom = value;
  }

  public void setSessionid(String value) {
    sessionid = value;
  }

  public void setAgentacc(String value) {
    agentacc = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setLangcode(String value) {
    langcode = value;
  }

  public void setLastftto(String value) {
    lastftto = value;
  }

  public void setNavcont(String value) {
    navcont = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setAgentflag(String value) {
    agentflag = value;
  }

  public void setExtnval4(String value) {
    extnval4 = value;
  }

  public void setLastacc(String value) {
    lastacc = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void setLastftremarks(String value) {
    lastftremarks = value;
  }

  public void setAgentchargesacc(String value) {
    agentchargesacc = value;
  }

  public void setStatus(String value) {
    status = value;
  }

  public void loadContent(KBMobilesession2Record inputRecord) {
    setLastphonetype(inputRecord.getLastphonetype());
    setLastphoneid(inputRecord.getLastphoneid());
    setExtnval1(inputRecord.getExtnval1());
    setCifno(inputRecord.getCifno());
    setModifiedat(inputRecord.getModifiedat());
    setExtnval3(inputRecord.getExtnval3());
    setLastftamt(inputRecord.getLastftamt());
    setExtnval2(inputRecord.getExtnval2());
    setLastftfrom(inputRecord.getLastftfrom());
    setSessionid(inputRecord.getSessionid());
    setAgentacc(inputRecord.getAgentacc());
    setCreatedat(inputRecord.getCreatedat());
    setLangcode(inputRecord.getLangcode());
    setLastftto(inputRecord.getLastftto());
    setNavcont(inputRecord.getNavcont());
    setCreatedby(inputRecord.getCreatedby());
    setAgentflag(inputRecord.getAgentflag());
    setExtnval4(inputRecord.getExtnval4());
    setLastacc(inputRecord.getLastacc());
    setModifiedby(inputRecord.getModifiedby());
    setId(inputRecord.getId());
    setLastftremarks(inputRecord.getLastftremarks());
    setAgentchargesacc(inputRecord.getAgentchargesacc());
    setStatus(inputRecord.getStatus());
  }

  public void loadNonNullContent(KBMobilesession2Record inputRecord) {
    if (StringUtils.hasChanged(getLastphonetype(), inputRecord.getLastphonetype())) {
      setLastphonetype(StringUtils.noNull(inputRecord.getLastphonetype()));
    }
    if (StringUtils.hasChanged(getLastphoneid(), inputRecord.getLastphoneid())) {
      setLastphoneid(StringUtils.noNull(inputRecord.getLastphoneid()));
    }
    if (StringUtils.hasChanged(getExtnval1(), inputRecord.getExtnval1())) {
      setExtnval1(StringUtils.noNull(inputRecord.getExtnval1()));
    }
    if (StringUtils.hasChanged(getCifno(), inputRecord.getCifno())) {
      setCifno(StringUtils.noNull(inputRecord.getCifno()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getExtnval3(), inputRecord.getExtnval3())) {
      setExtnval3(StringUtils.noNull(inputRecord.getExtnval3()));
    }
    if (StringUtils.hasChanged(getLastftamt(), inputRecord.getLastftamt())) {
      setLastftamt(StringUtils.noNull(inputRecord.getLastftamt()));
    }
    if (StringUtils.hasChanged(getExtnval2(), inputRecord.getExtnval2())) {
      setExtnval2(StringUtils.noNull(inputRecord.getExtnval2()));
    }
    if (StringUtils.hasChanged(getLastftfrom(), inputRecord.getLastftfrom())) {
      setLastftfrom(StringUtils.noNull(inputRecord.getLastftfrom()));
    }
    if (StringUtils.hasChanged(getSessionid(), inputRecord.getSessionid())) {
      setSessionid(StringUtils.noNull(inputRecord.getSessionid()));
    }
    if (StringUtils.hasChanged(getAgentacc(), inputRecord.getAgentacc())) {
      setAgentacc(StringUtils.noNull(inputRecord.getAgentacc()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getLangcode(), inputRecord.getLangcode())) {
      setLangcode(StringUtils.noNull(inputRecord.getLangcode()));
    }
    if (StringUtils.hasChanged(getLastftto(), inputRecord.getLastftto())) {
      setLastftto(StringUtils.noNull(inputRecord.getLastftto()));
    }
    if (StringUtils.hasChanged(getNavcont(), inputRecord.getNavcont())) {
      setNavcont(StringUtils.noNull(inputRecord.getNavcont()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getAgentflag(), inputRecord.getAgentflag())) {
      setAgentflag(StringUtils.noNull(inputRecord.getAgentflag()));
    }
    if (StringUtils.hasChanged(getExtnval4(), inputRecord.getExtnval4())) {
      setExtnval4(StringUtils.noNull(inputRecord.getExtnval4()));
    }
    if (StringUtils.hasChanged(getLastacc(), inputRecord.getLastacc())) {
      setLastacc(StringUtils.noNull(inputRecord.getLastacc()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
    if (StringUtils.hasChanged(getLastftremarks(), inputRecord.getLastftremarks())) {
      setLastftremarks(StringUtils.noNull(inputRecord.getLastftremarks()));
    }
    if (StringUtils.hasChanged(getAgentchargesacc(), inputRecord.getAgentchargesacc())) {
      setAgentchargesacc(StringUtils.noNull(inputRecord.getAgentchargesacc()));
    }
    if (StringUtils.hasChanged(getStatus(), inputRecord.getStatus())) {
      setStatus(StringUtils.noNull(inputRecord.getStatus()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("lastphonetype",StringUtils.noNull(lastphonetype));
    obj.put("lastphoneid",StringUtils.noNull(lastphoneid));
    obj.put("extnval1",StringUtils.noNull(extnval1));
    obj.put("cifno",StringUtils.noNull(cifno));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("extnval3",StringUtils.noNull(extnval3));
    obj.put("lastftamt",StringUtils.noNull(lastftamt));
    obj.put("extnval2",StringUtils.noNull(extnval2));
    obj.put("lastftfrom",StringUtils.noNull(lastftfrom));
    obj.put("sessionid",StringUtils.noNull(sessionid));
    obj.put("agentacc",StringUtils.noNull(agentacc));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("langcode",StringUtils.noNull(langcode));
    obj.put("lastftto",StringUtils.noNull(lastftto));
    obj.put("navcont",StringUtils.noNull(navcont));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("agentflag",StringUtils.noNull(agentflag));
    obj.put("extnval4",StringUtils.noNull(extnval4));
    obj.put("lastacc",StringUtils.noNull(lastacc));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("lastftremarks",StringUtils.noNull(lastftremarks));
    obj.put("agentchargesacc",StringUtils.noNull(agentchargesacc));
    obj.put("status",StringUtils.noNull(status));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    lastphonetype = StringUtils.getValueFromJSONObject(obj, "lastphonetype");
    lastphoneid = StringUtils.getValueFromJSONObject(obj, "lastphoneid");
    extnval1 = StringUtils.getValueFromJSONObject(obj, "extnval1");
    cifno = StringUtils.getValueFromJSONObject(obj, "cifno");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    extnval3 = StringUtils.getValueFromJSONObject(obj, "extnval3");
    lastftamt = StringUtils.getValueFromJSONObject(obj, "lastftamt");
    extnval2 = StringUtils.getValueFromJSONObject(obj, "extnval2");
    lastftfrom = StringUtils.getValueFromJSONObject(obj, "lastftfrom");
    sessionid = StringUtils.getValueFromJSONObject(obj, "sessionid");
    agentacc = StringUtils.getValueFromJSONObject(obj, "agentacc");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    langcode = StringUtils.getValueFromJSONObject(obj, "langcode");
    lastftto = StringUtils.getValueFromJSONObject(obj, "lastftto");
    navcont = StringUtils.getValueFromJSONObject(obj, "navcont");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    agentflag = StringUtils.getValueFromJSONObject(obj, "agentflag");
    extnval4 = StringUtils.getValueFromJSONObject(obj, "extnval4");
    lastacc = StringUtils.getValueFromJSONObject(obj, "lastacc");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    id = StringUtils.getValueFromJSONObject(obj, "id");
    lastftremarks = StringUtils.getValueFromJSONObject(obj, "lastftremarks");
    agentchargesacc = StringUtils.getValueFromJSONObject(obj, "agentchargesacc");
    status = StringUtils.getValueFromJSONObject(obj, "status");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("lastphonetype",StringUtils.noNull(lastphonetype));
    obj.put("lastphoneid",StringUtils.noNull(lastphoneid));
    obj.put("extnval1",StringUtils.noNull(extnval1));
    obj.put("cifno",StringUtils.noNull(cifno));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("extnval3",StringUtils.noNull(extnval3));
    obj.put("lastftamt",StringUtils.noNull(lastftamt));
    obj.put("extnval2",StringUtils.noNull(extnval2));
    obj.put("lastftfrom",StringUtils.noNull(lastftfrom));
    obj.put("sessionid",StringUtils.noNull(sessionid));
    obj.put("agentacc",StringUtils.noNull(agentacc));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("langcode",StringUtils.noNull(langcode));
    obj.put("lastftto",StringUtils.noNull(lastftto));
    obj.put("navcont",StringUtils.noNull(navcont));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("agentflag",StringUtils.noNull(agentflag));
    obj.put("extnval4",StringUtils.noNull(extnval4));
    obj.put("lastacc",StringUtils.noNull(lastacc));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("lastftremarks",StringUtils.noNull(lastftremarks));
    obj.put("agentchargesacc",StringUtils.noNull(agentchargesacc));
    obj.put("status",StringUtils.noNull(status));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("lastphonetype");
    columnList.add("lastphoneid");
    columnList.add("extnval1");
    columnList.add("cifno");
    columnList.add("modifiedat");
    columnList.add("extnval3");
    columnList.add("lastftamt");
    columnList.add("extnval2");
    columnList.add("lastftfrom");
    columnList.add("sessionid");
    columnList.add("agentacc");
    columnList.add("createdat");
    columnList.add("langcode");
    columnList.add("lastftto");
    columnList.add("navcont");
    columnList.add("createdby");
    columnList.add("agentflag");
    columnList.add("extnval4");
    columnList.add("lastacc");
    columnList.add("modifiedby");
    columnList.add("id");
    columnList.add("lastftremarks");
    columnList.add("agentchargesacc");
    columnList.add("status");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "lastphonetype:" + lastphonetype +"lastphoneid:" + lastphoneid +"extnval1:" + extnval1 +"cifno:" + cifno +"modifiedat:" + modifiedat +"extnval3:" + extnval3 +"lastftamt:" + lastftamt +"extnval2:" + extnval2 +"lastftfrom:" + lastftfrom +"sessionid:" + sessionid +"agentacc:" + agentacc +"createdat:" + createdat +"langcode:" + langcode +"lastftto:" + lastftto +"navcont:" + navcont +"createdby:" + createdby +"agentflag:" + agentflag +"extnval4:" + extnval4 +"lastacc:" + lastacc +"modifiedby:" + modifiedby +"id:" + id +"lastftremarks:" + lastftremarks +"agentchargesacc:" + agentchargesacc +"status:" + status +"";
  }
}
