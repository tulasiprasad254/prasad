package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBAuditlogRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBAuditlogRecord.class.getName());

  public String actiontype;

  public String createdat;

  public String institutionid;

  public String createdby;

  public String modifiedat;

  public String entityname;

  public String modifiedby;

  public String id;

  public String message;

  public String userid;

  public String getActiontype() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(actiontype);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(actiontype);
    }
    else {
      return actiontype;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getInstitutionid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(institutionid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(institutionid);
    }
    else {
      return institutionid;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getEntityname() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(entityname);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(entityname);
    }
    else {
      return entityname;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public String getMessage() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(message);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(message);
    }
    else {
      return message;
    }
  }

  public String getUserid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(userid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(userid);
    }
    else {
      return userid;
    }
  }

  public void setActiontype(String value) {
    actiontype = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setInstitutionid(String value) {
    institutionid = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setEntityname(String value) {
    entityname = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void setMessage(String value) {
    message = value;
  }

  public void setUserid(String value) {
    userid = value;
  }

  public void loadContent(KBAuditlogRecord inputRecord) {
    setActiontype(inputRecord.getActiontype());
    setCreatedat(inputRecord.getCreatedat());
    setInstitutionid(inputRecord.getInstitutionid());
    setCreatedby(inputRecord.getCreatedby());
    setModifiedat(inputRecord.getModifiedat());
    setEntityname(inputRecord.getEntityname());
    setModifiedby(inputRecord.getModifiedby());
    setId(inputRecord.getId());
    setMessage(inputRecord.getMessage());
    setUserid(inputRecord.getUserid());
  }

  public void loadNonNullContent(KBAuditlogRecord inputRecord) {
    if (StringUtils.hasChanged(getActiontype(), inputRecord.getActiontype())) {
      setActiontype(StringUtils.noNull(inputRecord.getActiontype()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getInstitutionid(), inputRecord.getInstitutionid())) {
      setInstitutionid(StringUtils.noNull(inputRecord.getInstitutionid()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getEntityname(), inputRecord.getEntityname())) {
      setEntityname(StringUtils.noNull(inputRecord.getEntityname()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
    if (StringUtils.hasChanged(getMessage(), inputRecord.getMessage())) {
      setMessage(StringUtils.noNull(inputRecord.getMessage()));
    }
    if (StringUtils.hasChanged(getUserid(), inputRecord.getUserid())) {
      setUserid(StringUtils.noNull(inputRecord.getUserid()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("actiontype",StringUtils.noNull(actiontype));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("institutionid",StringUtils.noNull(institutionid));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("entityname",StringUtils.noNull(entityname));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("message",StringUtils.noNull(message));
    obj.put("userid",StringUtils.noNull(userid));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    actiontype = StringUtils.getValueFromJSONObject(obj, "actiontype");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    institutionid = StringUtils.getValueFromJSONObject(obj, "institutionid");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    entityname = StringUtils.getValueFromJSONObject(obj, "entityname");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    id = StringUtils.getValueFromJSONObject(obj, "id");
    message = StringUtils.getValueFromJSONObject(obj, "message");
    userid = StringUtils.getValueFromJSONObject(obj, "userid");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("actiontype",StringUtils.noNull(actiontype));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("institutionid",StringUtils.noNull(institutionid));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("entityname",StringUtils.noNull(entityname));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("message",StringUtils.noNull(message));
    obj.put("userid",StringUtils.noNull(userid));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("actiontype");
    columnList.add("createdat");
    columnList.add("institutionid");
    columnList.add("createdby");
    columnList.add("modifiedat");
    columnList.add("entityname");
    columnList.add("modifiedby");
    columnList.add("id");
    columnList.add("message");
    columnList.add("userid");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "actiontype:" + actiontype +"createdat:" + createdat +"institutionid:" + institutionid +"createdby:" + createdby +"modifiedat:" + modifiedat +"entityname:" + entityname +"modifiedby:" + modifiedby +"id:" + id +"message:" + message +"userid:" + userid +"";
  }
}
