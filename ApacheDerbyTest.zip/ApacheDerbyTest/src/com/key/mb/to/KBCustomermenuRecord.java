package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBCustomermenuRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBCustomermenuRecord.class.getName());

  public String extn3;

  public String extn2;

  public String extn1;

  public String institutionid;

  public String menuname;

  public String modifiedat;

  public String menutype;

  public String sequencenumber;

  public String parentid;

  public String createdat;

  public String createdby;

  public String menulevel;

  public String modifiedby;

  public String id;

  public String serviceid;

  public String status;

  public String getExtn3() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(extn3);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(extn3);
    }
    else {
      return extn3;
    }
  }

  public String getExtn2() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(extn2);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(extn2);
    }
    else {
      return extn2;
    }
  }

  public String getExtn1() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(extn1);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(extn1);
    }
    else {
      return extn1;
    }
  }

  public String getInstitutionid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(institutionid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(institutionid);
    }
    else {
      return institutionid;
    }
  }

  public String getMenuname() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(menuname);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(menuname);
    }
    else {
      return menuname;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getMenutype() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(menutype);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(menutype);
    }
    else {
      return menutype;
    }
  }

  public String getSequencenumber() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(sequencenumber);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(sequencenumber);
    }
    else {
      return sequencenumber;
    }
  }

  public String getParentid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(parentid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(parentid);
    }
    else {
      return parentid;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getMenulevel() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(menulevel);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(menulevel);
    }
    else {
      return menulevel;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public String getServiceid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(serviceid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(serviceid);
    }
    else {
      return serviceid;
    }
  }

  public String getStatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(status);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(status);
    }
    else {
      return status;
    }
  }

  public void setExtn3(String value) {
    extn3 = value;
  }

  public void setExtn2(String value) {
    extn2 = value;
  }

  public void setExtn1(String value) {
    extn1 = value;
  }

  public void setInstitutionid(String value) {
    institutionid = value;
  }

  public void setMenuname(String value) {
    menuname = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setMenutype(String value) {
    menutype = value;
  }

  public void setSequencenumber(String value) {
    sequencenumber = value;
  }

  public void setParentid(String value) {
    parentid = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setMenulevel(String value) {
    menulevel = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void setServiceid(String value) {
    serviceid = value;
  }

  public void setStatus(String value) {
    status = value;
  }

  public void loadContent(KBCustomermenuRecord inputRecord) {
    setExtn3(inputRecord.getExtn3());
    setExtn2(inputRecord.getExtn2());
    setExtn1(inputRecord.getExtn1());
    setInstitutionid(inputRecord.getInstitutionid());
    setMenuname(inputRecord.getMenuname());
    setModifiedat(inputRecord.getModifiedat());
    setMenutype(inputRecord.getMenutype());
    setSequencenumber(inputRecord.getSequencenumber());
    setParentid(inputRecord.getParentid());
    setCreatedat(inputRecord.getCreatedat());
    setCreatedby(inputRecord.getCreatedby());
    setMenulevel(inputRecord.getMenulevel());
    setModifiedby(inputRecord.getModifiedby());
    setId(inputRecord.getId());
    setServiceid(inputRecord.getServiceid());
    setStatus(inputRecord.getStatus());
  }

  public void loadNonNullContent(KBCustomermenuRecord inputRecord) {
    if (StringUtils.hasChanged(getExtn3(), inputRecord.getExtn3())) {
      setExtn3(StringUtils.noNull(inputRecord.getExtn3()));
    }
    if (StringUtils.hasChanged(getExtn2(), inputRecord.getExtn2())) {
      setExtn2(StringUtils.noNull(inputRecord.getExtn2()));
    }
    if (StringUtils.hasChanged(getExtn1(), inputRecord.getExtn1())) {
      setExtn1(StringUtils.noNull(inputRecord.getExtn1()));
    }
    if (StringUtils.hasChanged(getInstitutionid(), inputRecord.getInstitutionid())) {
      setInstitutionid(StringUtils.noNull(inputRecord.getInstitutionid()));
    }
    if (StringUtils.hasChanged(getMenuname(), inputRecord.getMenuname())) {
      setMenuname(StringUtils.noNull(inputRecord.getMenuname()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getMenutype(), inputRecord.getMenutype())) {
      setMenutype(StringUtils.noNull(inputRecord.getMenutype()));
    }
    if (StringUtils.hasChanged(getSequencenumber(), inputRecord.getSequencenumber())) {
      setSequencenumber(StringUtils.noNull(inputRecord.getSequencenumber()));
    }
    if (StringUtils.hasChanged(getParentid(), inputRecord.getParentid())) {
      setParentid(StringUtils.noNull(inputRecord.getParentid()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getMenulevel(), inputRecord.getMenulevel())) {
      setMenulevel(StringUtils.noNull(inputRecord.getMenulevel()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
    if (StringUtils.hasChanged(getServiceid(), inputRecord.getServiceid())) {
      setServiceid(StringUtils.noNull(inputRecord.getServiceid()));
    }
    if (StringUtils.hasChanged(getStatus(), inputRecord.getStatus())) {
      setStatus(StringUtils.noNull(inputRecord.getStatus()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("extn3",StringUtils.noNull(extn3));
    obj.put("extn2",StringUtils.noNull(extn2));
    obj.put("extn1",StringUtils.noNull(extn1));
    obj.put("institutionid",StringUtils.noNull(institutionid));
    obj.put("menuname",StringUtils.noNull(menuname));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("menutype",StringUtils.noNull(menutype));
    obj.put("sequencenumber",StringUtils.noNull(sequencenumber));
    obj.put("parentid",StringUtils.noNull(parentid));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("menulevel",StringUtils.noNull(menulevel));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("serviceid",StringUtils.noNull(serviceid));
    obj.put("status",StringUtils.noNull(status));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    extn3 = StringUtils.getValueFromJSONObject(obj, "extn3");
    extn2 = StringUtils.getValueFromJSONObject(obj, "extn2");
    extn1 = StringUtils.getValueFromJSONObject(obj, "extn1");
    institutionid = StringUtils.getValueFromJSONObject(obj, "institutionid");
    menuname = StringUtils.getValueFromJSONObject(obj, "menuname");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    menutype = StringUtils.getValueFromJSONObject(obj, "menutype");
    sequencenumber = StringUtils.getValueFromJSONObject(obj, "sequencenumber");
    parentid = StringUtils.getValueFromJSONObject(obj, "parentid");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    menulevel = StringUtils.getValueFromJSONObject(obj, "menulevel");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    id = StringUtils.getValueFromJSONObject(obj, "id");
    serviceid = StringUtils.getValueFromJSONObject(obj, "serviceid");
    status = StringUtils.getValueFromJSONObject(obj, "status");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("extn3",StringUtils.noNull(extn3));
    obj.put("extn2",StringUtils.noNull(extn2));
    obj.put("extn1",StringUtils.noNull(extn1));
    obj.put("institutionid",StringUtils.noNull(institutionid));
    obj.put("menuname",StringUtils.noNull(menuname));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("menutype",StringUtils.noNull(menutype));
    obj.put("sequencenumber",StringUtils.noNull(sequencenumber));
    obj.put("parentid",StringUtils.noNull(parentid));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("menulevel",StringUtils.noNull(menulevel));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("serviceid",StringUtils.noNull(serviceid));
    obj.put("status",StringUtils.noNull(status));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("extn3");
    columnList.add("extn2");
    columnList.add("extn1");
    columnList.add("institutionid");
    columnList.add("menuname");
    columnList.add("modifiedat");
    columnList.add("menutype");
    columnList.add("sequencenumber");
    columnList.add("parentid");
    columnList.add("createdat");
    columnList.add("createdby");
    columnList.add("menulevel");
    columnList.add("modifiedby");
    columnList.add("id");
    columnList.add("serviceid");
    columnList.add("status");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "extn3:" + extn3 +"extn2:" + extn2 +"extn1:" + extn1 +"institutionid:" + institutionid +"menuname:" + menuname +"modifiedat:" + modifiedat +"menutype:" + menutype +"sequencenumber:" + sequencenumber +"parentid:" + parentid +"createdat:" + createdat +"createdby:" + createdby +"menulevel:" + menulevel +"modifiedby:" + modifiedby +"id:" + id +"serviceid:" + serviceid +"status:" + status +"";
  }
}
