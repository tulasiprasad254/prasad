package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBLanguageRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBLanguageRecord.class.getName());

  public String extn3;

  public String extn2;

  public String extn1;

  public String modifiedat;

  public String rtl;

  public String locale;

  public String enabled;

  public String createdat;

  public String createdby;

  public String name;

  public String unicode;

  public String modifiedby;

  public String id;

  public String base;

  public String status;

  public String getExtn3() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(extn3);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(extn3);
    }
    else {
      return extn3;
    }
  }

  public String getExtn2() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(extn2);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(extn2);
    }
    else {
      return extn2;
    }
  }

  public String getExtn1() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(extn1);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(extn1);
    }
    else {
      return extn1;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getRtl() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rtl);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rtl);
    }
    else {
      return rtl;
    }
  }

  public String getLocale() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(locale);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(locale);
    }
    else {
      return locale;
    }
  }

  public String getEnabled() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(enabled);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(enabled);
    }
    else {
      return enabled;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getName() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(name);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(name);
    }
    else {
      return name;
    }
  }

  public String getUnicode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(unicode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(unicode);
    }
    else {
      return unicode;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public String getBase() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(base);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(base);
    }
    else {
      return base;
    }
  }

  public String getStatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(status);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(status);
    }
    else {
      return status;
    }
  }

  public void setExtn3(String value) {
    extn3 = value;
  }

  public void setExtn2(String value) {
    extn2 = value;
  }

  public void setExtn1(String value) {
    extn1 = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setRtl(String value) {
    rtl = value;
  }

  public void setLocale(String value) {
    locale = value;
  }

  public void setEnabled(String value) {
    enabled = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setName(String value) {
    name = value;
  }

  public void setUnicode(String value) {
    unicode = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void setBase(String value) {
    base = value;
  }

  public void setStatus(String value) {
    status = value;
  }

  public void loadContent(KBLanguageRecord inputRecord) {
    setExtn3(inputRecord.getExtn3());
    setExtn2(inputRecord.getExtn2());
    setExtn1(inputRecord.getExtn1());
    setModifiedat(inputRecord.getModifiedat());
    setRtl(inputRecord.getRtl());
    setLocale(inputRecord.getLocale());
    setEnabled(inputRecord.getEnabled());
    setCreatedat(inputRecord.getCreatedat());
    setCreatedby(inputRecord.getCreatedby());
    setName(inputRecord.getName());
    setUnicode(inputRecord.getUnicode());
    setModifiedby(inputRecord.getModifiedby());
    setId(inputRecord.getId());
    setBase(inputRecord.getBase());
    setStatus(inputRecord.getStatus());
  }

  public void loadNonNullContent(KBLanguageRecord inputRecord) {
    if (StringUtils.hasChanged(getExtn3(), inputRecord.getExtn3())) {
      setExtn3(StringUtils.noNull(inputRecord.getExtn3()));
    }
    if (StringUtils.hasChanged(getExtn2(), inputRecord.getExtn2())) {
      setExtn2(StringUtils.noNull(inputRecord.getExtn2()));
    }
    if (StringUtils.hasChanged(getExtn1(), inputRecord.getExtn1())) {
      setExtn1(StringUtils.noNull(inputRecord.getExtn1()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getRtl(), inputRecord.getRtl())) {
      setRtl(StringUtils.noNull(inputRecord.getRtl()));
    }
    if (StringUtils.hasChanged(getLocale(), inputRecord.getLocale())) {
      setLocale(StringUtils.noNull(inputRecord.getLocale()));
    }
    if (StringUtils.hasChanged(getEnabled(), inputRecord.getEnabled())) {
      setEnabled(StringUtils.noNull(inputRecord.getEnabled()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getName(), inputRecord.getName())) {
      setName(StringUtils.noNull(inputRecord.getName()));
    }
    if (StringUtils.hasChanged(getUnicode(), inputRecord.getUnicode())) {
      setUnicode(StringUtils.noNull(inputRecord.getUnicode()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
    if (StringUtils.hasChanged(getBase(), inputRecord.getBase())) {
      setBase(StringUtils.noNull(inputRecord.getBase()));
    }
    if (StringUtils.hasChanged(getStatus(), inputRecord.getStatus())) {
      setStatus(StringUtils.noNull(inputRecord.getStatus()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("extn3",StringUtils.noNull(extn3));
    obj.put("extn2",StringUtils.noNull(extn2));
    obj.put("extn1",StringUtils.noNull(extn1));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("rtl",StringUtils.noNull(rtl));
    obj.put("locale",StringUtils.noNull(locale));
    obj.put("enabled",StringUtils.noNull(enabled));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("name",StringUtils.noNull(name));
    obj.put("unicode",StringUtils.noNull(unicode));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("base",StringUtils.noNull(base));
    obj.put("status",StringUtils.noNull(status));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    extn3 = StringUtils.getValueFromJSONObject(obj, "extn3");
    extn2 = StringUtils.getValueFromJSONObject(obj, "extn2");
    extn1 = StringUtils.getValueFromJSONObject(obj, "extn1");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    rtl = StringUtils.getValueFromJSONObject(obj, "rtl");
    locale = StringUtils.getValueFromJSONObject(obj, "locale");
    enabled = StringUtils.getValueFromJSONObject(obj, "enabled");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    name = StringUtils.getValueFromJSONObject(obj, "name");
    unicode = StringUtils.getValueFromJSONObject(obj, "unicode");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    id = StringUtils.getValueFromJSONObject(obj, "id");
    base = StringUtils.getValueFromJSONObject(obj, "base");
    status = StringUtils.getValueFromJSONObject(obj, "status");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("extn3",StringUtils.noNull(extn3));
    obj.put("extn2",StringUtils.noNull(extn2));
    obj.put("extn1",StringUtils.noNull(extn1));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("rtl",StringUtils.noNull(rtl));
    obj.put("locale",StringUtils.noNull(locale));
    obj.put("enabled",StringUtils.noNull(enabled));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("name",StringUtils.noNull(name));
    obj.put("unicode",StringUtils.noNull(unicode));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("base",StringUtils.noNull(base));
    obj.put("status",StringUtils.noNull(status));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("extn3");
    columnList.add("extn2");
    columnList.add("extn1");
    columnList.add("modifiedat");
    columnList.add("rtl");
    columnList.add("locale");
    columnList.add("enabled");
    columnList.add("createdat");
    columnList.add("createdby");
    columnList.add("name");
    columnList.add("unicode");
    columnList.add("modifiedby");
    columnList.add("id");
    columnList.add("base");
    columnList.add("status");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "extn3:" + extn3 +"extn2:" + extn2 +"extn1:" + extn1 +"modifiedat:" + modifiedat +"rtl:" + rtl +"locale:" + locale +"enabled:" + enabled +"createdat:" + createdat +"createdby:" + createdby +"name:" + name +"unicode:" + unicode +"modifiedby:" + modifiedby +"id:" + id +"base:" + base +"status:" + status +"";
  }
}
