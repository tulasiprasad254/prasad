package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBControllermapRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBControllermapRecord.class.getName());

  public String authflag;

  public String code;

  public String classname;

  public String id;

  public String getAuthflag() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(authflag);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(authflag);
    }
    else {
      return authflag;
    }
  }

  public String getCode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(code);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(code);
    }
    else {
      return code;
    }
  }

  public String getClassname() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(classname);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(classname);
    }
    else {
      return classname;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public void setAuthflag(String value) {
    authflag = value;
  }

  public void setCode(String value) {
    code = value;
  }

  public void setClassname(String value) {
    classname = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void loadContent(KBControllermapRecord inputRecord) {
    setAuthflag(inputRecord.getAuthflag());
    setCode(inputRecord.getCode());
    setClassname(inputRecord.getClassname());
    setId(inputRecord.getId());
  }

  public void loadNonNullContent(KBControllermapRecord inputRecord) {
    if (StringUtils.hasChanged(getAuthflag(), inputRecord.getAuthflag())) {
      setAuthflag(StringUtils.noNull(inputRecord.getAuthflag()));
    }
    if (StringUtils.hasChanged(getCode(), inputRecord.getCode())) {
      setCode(StringUtils.noNull(inputRecord.getCode()));
    }
    if (StringUtils.hasChanged(getClassname(), inputRecord.getClassname())) {
      setClassname(StringUtils.noNull(inputRecord.getClassname()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("authflag",StringUtils.noNull(authflag));
    obj.put("code",StringUtils.noNull(code));
    obj.put("classname",StringUtils.noNull(classname));
    obj.put("id",StringUtils.noNull(id));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    authflag = StringUtils.getValueFromJSONObject(obj, "authflag");
    code = StringUtils.getValueFromJSONObject(obj, "code");
    classname = StringUtils.getValueFromJSONObject(obj, "classname");
    id = StringUtils.getValueFromJSONObject(obj, "id");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("authflag",StringUtils.noNull(authflag));
    obj.put("code",StringUtils.noNull(code));
    obj.put("classname",StringUtils.noNull(classname));
    obj.put("id",StringUtils.noNull(id));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("authflag");
    columnList.add("code");
    columnList.add("classname");
    columnList.add("id");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "authflag:" + authflag +"code:" + code +"classname:" + classname +"id:" + id +"";
  }
}
