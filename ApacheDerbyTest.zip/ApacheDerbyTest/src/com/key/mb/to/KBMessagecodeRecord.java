package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBMessagecodeRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBMessagecodeRecord.class.getName());

  public String rstatus;

  public String createdat;

  public String messagetype;

  public String messagel3;

  public String createdby;

  public String messagel2;

  public String modifiedat;

  public String messagel1;

  public String messagecode;

  public String modifiedby;

  public String id;

  public String messageen;

  public String getRstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rstatus);
    }
    else {
      return rstatus;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getMessagetype() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(messagetype);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(messagetype);
    }
    else {
      return messagetype;
    }
  }

  public String getMessagel3() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(messagel3);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(messagel3);
    }
    else {
      return messagel3;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getMessagel2() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(messagel2);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(messagel2);
    }
    else {
      return messagel2;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getMessagel1() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(messagel1);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(messagel1);
    }
    else {
      return messagel1;
    }
  }

  public String getMessagecode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(messagecode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(messagecode);
    }
    else {
      return messagecode;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public String getMessageen() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(messageen);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(messageen);
    }
    else {
      return messageen;
    }
  }

  public void setRstatus(String value) {
    rstatus = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setMessagetype(String value) {
    messagetype = value;
  }

  public void setMessagel3(String value) {
    messagel3 = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setMessagel2(String value) {
    messagel2 = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setMessagel1(String value) {
    messagel1 = value;
  }

  public void setMessagecode(String value) {
    messagecode = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void setMessageen(String value) {
    messageen = value;
  }

  public void loadContent(KBMessagecodeRecord inputRecord) {
    setRstatus(inputRecord.getRstatus());
    setCreatedat(inputRecord.getCreatedat());
    setMessagetype(inputRecord.getMessagetype());
    setMessagel3(inputRecord.getMessagel3());
    setCreatedby(inputRecord.getCreatedby());
    setMessagel2(inputRecord.getMessagel2());
    setModifiedat(inputRecord.getModifiedat());
    setMessagel1(inputRecord.getMessagel1());
    setMessagecode(inputRecord.getMessagecode());
    setModifiedby(inputRecord.getModifiedby());
    setId(inputRecord.getId());
    setMessageen(inputRecord.getMessageen());
  }

  public void loadNonNullContent(KBMessagecodeRecord inputRecord) {
    if (StringUtils.hasChanged(getRstatus(), inputRecord.getRstatus())) {
      setRstatus(StringUtils.noNull(inputRecord.getRstatus()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getMessagetype(), inputRecord.getMessagetype())) {
      setMessagetype(StringUtils.noNull(inputRecord.getMessagetype()));
    }
    if (StringUtils.hasChanged(getMessagel3(), inputRecord.getMessagel3())) {
      setMessagel3(StringUtils.noNull(inputRecord.getMessagel3()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getMessagel2(), inputRecord.getMessagel2())) {
      setMessagel2(StringUtils.noNull(inputRecord.getMessagel2()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getMessagel1(), inputRecord.getMessagel1())) {
      setMessagel1(StringUtils.noNull(inputRecord.getMessagel1()));
    }
    if (StringUtils.hasChanged(getMessagecode(), inputRecord.getMessagecode())) {
      setMessagecode(StringUtils.noNull(inputRecord.getMessagecode()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
    if (StringUtils.hasChanged(getMessageen(), inputRecord.getMessageen())) {
      setMessageen(StringUtils.noNull(inputRecord.getMessageen()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("messagetype",StringUtils.noNull(messagetype));
    obj.put("messagel3",StringUtils.noNull(messagel3));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("messagel2",StringUtils.noNull(messagel2));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("messagel1",StringUtils.noNull(messagel1));
    obj.put("messagecode",StringUtils.noNull(messagecode));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("messageen",StringUtils.noNull(messageen));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    rstatus = StringUtils.getValueFromJSONObject(obj, "rstatus");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    messagetype = StringUtils.getValueFromJSONObject(obj, "messagetype");
    messagel3 = StringUtils.getValueFromJSONObject(obj, "messagel3");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    messagel2 = StringUtils.getValueFromJSONObject(obj, "messagel2");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    messagel1 = StringUtils.getValueFromJSONObject(obj, "messagel1");
    messagecode = StringUtils.getValueFromJSONObject(obj, "messagecode");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    id = StringUtils.getValueFromJSONObject(obj, "id");
    messageen = StringUtils.getValueFromJSONObject(obj, "messageen");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("messagetype",StringUtils.noNull(messagetype));
    obj.put("messagel3",StringUtils.noNull(messagel3));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("messagel2",StringUtils.noNull(messagel2));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("messagel1",StringUtils.noNull(messagel1));
    obj.put("messagecode",StringUtils.noNull(messagecode));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("messageen",StringUtils.noNull(messageen));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("rstatus");
    columnList.add("createdat");
    columnList.add("messagetype");
    columnList.add("messagel3");
    columnList.add("createdby");
    columnList.add("messagel2");
    columnList.add("modifiedat");
    columnList.add("messagel1");
    columnList.add("messagecode");
    columnList.add("modifiedby");
    columnList.add("id");
    columnList.add("messageen");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "rstatus:" + rstatus +"createdat:" + createdat +"messagetype:" + messagetype +"messagel3:" + messagel3 +"createdby:" + createdby +"messagel2:" + messagel2 +"modifiedat:" + modifiedat +"messagel1:" + messagel1 +"messagecode:" + messagecode +"modifiedby:" + modifiedby +"id:" + id +"messageen:" + messageen +"";
  }
}
