package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBIntfcalllogRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBIntfcalllogRecord.class.getName());

  public String currappstatus;

  public String responsets;

  public String institutionid;

  public String makerlastcmt;

  public String sessionid;

  public String madeat;

  public String servicemapid;

  public String result;

  public String requestts;

  public String checkedat;

  public String requestorid;

  public String createdby;

  public String requestsource;

  public String id;

  public String requestmap;

  public String errormesg;

  public String responsemap;

  public String modifiedat;

  public String madeby;

  public String adminlastcmt;

  public String message;

  public String checkerlastcmt;

  public String rstatus;

  public String createdat;

  public String charges;

  public String servicecode;

  public String checkedby;

  public String modifiedby;

  public String getCurrappstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(currappstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(currappstatus);
    }
    else {
      return currappstatus;
    }
  }

  public String getResponsets() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(responsets);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(responsets);
    }
    else {
      return responsets;
    }
  }

  public String getInstitutionid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(institutionid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(institutionid);
    }
    else {
      return institutionid;
    }
  }

  public String getMakerlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(makerlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(makerlastcmt);
    }
    else {
      return makerlastcmt;
    }
  }

  public String getSessionid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(sessionid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(sessionid);
    }
    else {
      return sessionid;
    }
  }

  public String getMadeat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(madeat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(madeat);
    }
    else {
      return madeat;
    }
  }

  public String getServicemapid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(servicemapid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(servicemapid);
    }
    else {
      return servicemapid;
    }
  }

  public String getResult() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(result);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(result);
    }
    else {
      return result;
    }
  }

  public String getRequestts() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(requestts);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(requestts);
    }
    else {
      return requestts;
    }
  }

  public String getCheckedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkedat);
    }
    else {
      return checkedat;
    }
  }

  public String getRequestorid() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(requestorid);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(requestorid);
    }
    else {
      return requestorid;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getRequestsource() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(requestsource);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(requestsource);
    }
    else {
      return requestsource;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public String getRequestmap() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(requestmap);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(requestmap);
    }
    else {
      return requestmap;
    }
  }

  public String getErrormesg() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(errormesg);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(errormesg);
    }
    else {
      return errormesg;
    }
  }

  public String getResponsemap() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(responsemap);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(responsemap);
    }
    else {
      return responsemap;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getMadeby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(madeby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(madeby);
    }
    else {
      return madeby;
    }
  }

  public String getAdminlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(adminlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(adminlastcmt);
    }
    else {
      return adminlastcmt;
    }
  }

  public String getMessage() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(message);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(message);
    }
    else {
      return message;
    }
  }

  public String getCheckerlastcmt() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkerlastcmt);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkerlastcmt);
    }
    else {
      return checkerlastcmt;
    }
  }

  public String getRstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rstatus);
    }
    else {
      return rstatus;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getCharges() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(charges);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(charges);
    }
    else {
      return charges;
    }
  }

  public String getServicecode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(servicecode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(servicecode);
    }
    else {
      return servicecode;
    }
  }

  public String getCheckedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(checkedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(checkedby);
    }
    else {
      return checkedby;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public void setCurrappstatus(String value) {
    currappstatus = value;
  }

  public void setResponsets(String value) {
    responsets = value;
  }

  public void setInstitutionid(String value) {
    institutionid = value;
  }

  public void setMakerlastcmt(String value) {
    makerlastcmt = value;
  }

  public void setSessionid(String value) {
    sessionid = value;
  }

  public void setMadeat(String value) {
    madeat = value;
  }

  public void setServicemapid(String value) {
    servicemapid = value;
  }

  public void setResult(String value) {
    result = value;
  }

  public void setRequestts(String value) {
    requestts = value;
  }

  public void setCheckedat(String value) {
    checkedat = value;
  }

  public void setRequestorid(String value) {
    requestorid = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setRequestsource(String value) {
    requestsource = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void setRequestmap(String value) {
    requestmap = value;
  }

  public void setErrormesg(String value) {
    errormesg = value;
  }

  public void setResponsemap(String value) {
    responsemap = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setMadeby(String value) {
    madeby = value;
  }

  public void setAdminlastcmt(String value) {
    adminlastcmt = value;
  }

  public void setMessage(String value) {
    message = value;
  }

  public void setCheckerlastcmt(String value) {
    checkerlastcmt = value;
  }

  public void setRstatus(String value) {
    rstatus = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setCharges(String value) {
    charges = value;
  }

  public void setServicecode(String value) {
    servicecode = value;
  }

  public void setCheckedby(String value) {
    checkedby = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void loadContent(KBIntfcalllogRecord inputRecord) {
    setCurrappstatus(inputRecord.getCurrappstatus());
    setResponsets(inputRecord.getResponsets());
    setInstitutionid(inputRecord.getInstitutionid());
    setMakerlastcmt(inputRecord.getMakerlastcmt());
    setSessionid(inputRecord.getSessionid());
    setMadeat(inputRecord.getMadeat());
    setServicemapid(inputRecord.getServicemapid());
    setResult(inputRecord.getResult());
    setRequestts(inputRecord.getRequestts());
    setCheckedat(inputRecord.getCheckedat());
    setRequestorid(inputRecord.getRequestorid());
    setCreatedby(inputRecord.getCreatedby());
    setRequestsource(inputRecord.getRequestsource());
    setId(inputRecord.getId());
    setRequestmap(inputRecord.getRequestmap());
    setErrormesg(inputRecord.getErrormesg());
    setResponsemap(inputRecord.getResponsemap());
    setModifiedat(inputRecord.getModifiedat());
    setMadeby(inputRecord.getMadeby());
    setAdminlastcmt(inputRecord.getAdminlastcmt());
    setMessage(inputRecord.getMessage());
    setCheckerlastcmt(inputRecord.getCheckerlastcmt());
    setRstatus(inputRecord.getRstatus());
    setCreatedat(inputRecord.getCreatedat());
    setCharges(inputRecord.getCharges());
    setServicecode(inputRecord.getServicecode());
    setCheckedby(inputRecord.getCheckedby());
    setModifiedby(inputRecord.getModifiedby());
  }

  public void loadNonNullContent(KBIntfcalllogRecord inputRecord) {
    if (StringUtils.hasChanged(getCurrappstatus(), inputRecord.getCurrappstatus())) {
      setCurrappstatus(StringUtils.noNull(inputRecord.getCurrappstatus()));
    }
    if (StringUtils.hasChanged(getResponsets(), inputRecord.getResponsets())) {
      setResponsets(StringUtils.noNull(inputRecord.getResponsets()));
    }
    if (StringUtils.hasChanged(getInstitutionid(), inputRecord.getInstitutionid())) {
      setInstitutionid(StringUtils.noNull(inputRecord.getInstitutionid()));
    }
    if (StringUtils.hasChanged(getMakerlastcmt(), inputRecord.getMakerlastcmt())) {
      setMakerlastcmt(StringUtils.noNull(inputRecord.getMakerlastcmt()));
    }
    if (StringUtils.hasChanged(getSessionid(), inputRecord.getSessionid())) {
      setSessionid(StringUtils.noNull(inputRecord.getSessionid()));
    }
    if (StringUtils.hasChanged(getMadeat(), inputRecord.getMadeat())) {
      setMadeat(StringUtils.noNull(inputRecord.getMadeat()));
    }
    if (StringUtils.hasChanged(getServicemapid(), inputRecord.getServicemapid())) {
      setServicemapid(StringUtils.noNull(inputRecord.getServicemapid()));
    }
    if (StringUtils.hasChanged(getResult(), inputRecord.getResult())) {
      setResult(StringUtils.noNull(inputRecord.getResult()));
    }
    if (StringUtils.hasChanged(getRequestts(), inputRecord.getRequestts())) {
      setRequestts(StringUtils.noNull(inputRecord.getRequestts()));
    }
    if (StringUtils.hasChanged(getCheckedat(), inputRecord.getCheckedat())) {
      setCheckedat(StringUtils.noNull(inputRecord.getCheckedat()));
    }
    if (StringUtils.hasChanged(getRequestorid(), inputRecord.getRequestorid())) {
      setRequestorid(StringUtils.noNull(inputRecord.getRequestorid()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getRequestsource(), inputRecord.getRequestsource())) {
      setRequestsource(StringUtils.noNull(inputRecord.getRequestsource()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
    if (StringUtils.hasChanged(getRequestmap(), inputRecord.getRequestmap())) {
      setRequestmap(StringUtils.noNull(inputRecord.getRequestmap()));
    }
    if (StringUtils.hasChanged(getErrormesg(), inputRecord.getErrormesg())) {
      setErrormesg(StringUtils.noNull(inputRecord.getErrormesg()));
    }
    if (StringUtils.hasChanged(getResponsemap(), inputRecord.getResponsemap())) {
      setResponsemap(StringUtils.noNull(inputRecord.getResponsemap()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getMadeby(), inputRecord.getMadeby())) {
      setMadeby(StringUtils.noNull(inputRecord.getMadeby()));
    }
    if (StringUtils.hasChanged(getAdminlastcmt(), inputRecord.getAdminlastcmt())) {
      setAdminlastcmt(StringUtils.noNull(inputRecord.getAdminlastcmt()));
    }
    if (StringUtils.hasChanged(getMessage(), inputRecord.getMessage())) {
      setMessage(StringUtils.noNull(inputRecord.getMessage()));
    }
    if (StringUtils.hasChanged(getCheckerlastcmt(), inputRecord.getCheckerlastcmt())) {
      setCheckerlastcmt(StringUtils.noNull(inputRecord.getCheckerlastcmt()));
    }
    if (StringUtils.hasChanged(getRstatus(), inputRecord.getRstatus())) {
      setRstatus(StringUtils.noNull(inputRecord.getRstatus()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getCharges(), inputRecord.getCharges())) {
      setCharges(StringUtils.noNull(inputRecord.getCharges()));
    }
    if (StringUtils.hasChanged(getServicecode(), inputRecord.getServicecode())) {
      setServicecode(StringUtils.noNull(inputRecord.getServicecode()));
    }
    if (StringUtils.hasChanged(getCheckedby(), inputRecord.getCheckedby())) {
      setCheckedby(StringUtils.noNull(inputRecord.getCheckedby()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("currappstatus",StringUtils.noNull(currappstatus));
    obj.put("responsets",StringUtils.noNull(responsets));
    obj.put("institutionid",StringUtils.noNull(institutionid));
    obj.put("makerlastcmt",StringUtils.noNull(makerlastcmt));
    obj.put("sessionid",StringUtils.noNull(sessionid));
    obj.put("madeat",StringUtils.noNull(madeat));
    obj.put("servicemapid",StringUtils.noNull(servicemapid));
    obj.put("result",StringUtils.noNull(result));
    obj.put("requestts",StringUtils.noNull(requestts));
    obj.put("checkedat",StringUtils.noNull(checkedat));
    obj.put("requestorid",StringUtils.noNull(requestorid));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("requestsource",StringUtils.noNull(requestsource));
    obj.put("id",StringUtils.noNull(id));
    obj.put("requestmap",StringUtils.noNull(requestmap));
    obj.put("errormesg",StringUtils.noNull(errormesg));
    obj.put("responsemap",StringUtils.noNull(responsemap));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("madeby",StringUtils.noNull(madeby));
    obj.put("adminlastcmt",StringUtils.noNull(adminlastcmt));
    obj.put("message",StringUtils.noNull(message));
    obj.put("checkerlastcmt",StringUtils.noNull(checkerlastcmt));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("charges",StringUtils.noNull(charges));
    obj.put("servicecode",StringUtils.noNull(servicecode));
    obj.put("checkedby",StringUtils.noNull(checkedby));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    currappstatus = StringUtils.getValueFromJSONObject(obj, "currappstatus");
    responsets = StringUtils.getValueFromJSONObject(obj, "responsets");
    institutionid = StringUtils.getValueFromJSONObject(obj, "institutionid");
    makerlastcmt = StringUtils.getValueFromJSONObject(obj, "makerlastcmt");
    sessionid = StringUtils.getValueFromJSONObject(obj, "sessionid");
    madeat = StringUtils.getValueFromJSONObject(obj, "madeat");
    servicemapid = StringUtils.getValueFromJSONObject(obj, "servicemapid");
    result = StringUtils.getValueFromJSONObject(obj, "result");
    requestts = StringUtils.getValueFromJSONObject(obj, "requestts");
    checkedat = StringUtils.getValueFromJSONObject(obj, "checkedat");
    requestorid = StringUtils.getValueFromJSONObject(obj, "requestorid");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    requestsource = StringUtils.getValueFromJSONObject(obj, "requestsource");
    id = StringUtils.getValueFromJSONObject(obj, "id");
    requestmap = StringUtils.getValueFromJSONObject(obj, "requestmap");
    errormesg = StringUtils.getValueFromJSONObject(obj, "errormesg");
    responsemap = StringUtils.getValueFromJSONObject(obj, "responsemap");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    madeby = StringUtils.getValueFromJSONObject(obj, "madeby");
    adminlastcmt = StringUtils.getValueFromJSONObject(obj, "adminlastcmt");
    message = StringUtils.getValueFromJSONObject(obj, "message");
    checkerlastcmt = StringUtils.getValueFromJSONObject(obj, "checkerlastcmt");
    rstatus = StringUtils.getValueFromJSONObject(obj, "rstatus");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    charges = StringUtils.getValueFromJSONObject(obj, "charges");
    servicecode = StringUtils.getValueFromJSONObject(obj, "servicecode");
    checkedby = StringUtils.getValueFromJSONObject(obj, "checkedby");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("currappstatus",StringUtils.noNull(currappstatus));
    obj.put("responsets",StringUtils.noNull(responsets));
    obj.put("institutionid",StringUtils.noNull(institutionid));
    obj.put("makerlastcmt",StringUtils.noNull(makerlastcmt));
    obj.put("sessionid",StringUtils.noNull(sessionid));
    obj.put("madeat",StringUtils.noNull(madeat));
    obj.put("servicemapid",StringUtils.noNull(servicemapid));
    obj.put("result",StringUtils.noNull(result));
    obj.put("requestts",StringUtils.noNull(requestts));
    obj.put("checkedat",StringUtils.noNull(checkedat));
    obj.put("requestorid",StringUtils.noNull(requestorid));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("requestsource",StringUtils.noNull(requestsource));
    obj.put("id",StringUtils.noNull(id));
    obj.put("requestmap",StringUtils.noNull(requestmap));
    obj.put("errormesg",StringUtils.noNull(errormesg));
    obj.put("responsemap",StringUtils.noNull(responsemap));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("madeby",StringUtils.noNull(madeby));
    obj.put("adminlastcmt",StringUtils.noNull(adminlastcmt));
    obj.put("message",StringUtils.noNull(message));
    obj.put("checkerlastcmt",StringUtils.noNull(checkerlastcmt));
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("charges",StringUtils.noNull(charges));
    obj.put("servicecode",StringUtils.noNull(servicecode));
    obj.put("checkedby",StringUtils.noNull(checkedby));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("currappstatus");
    columnList.add("responsets");
    columnList.add("institutionid");
    columnList.add("makerlastcmt");
    columnList.add("sessionid");
    columnList.add("madeat");
    columnList.add("servicemapid");
    columnList.add("result");
    columnList.add("requestts");
    columnList.add("checkedat");
    columnList.add("requestorid");
    columnList.add("createdby");
    columnList.add("requestsource");
    columnList.add("id");
    columnList.add("requestmap");
    columnList.add("errormesg");
    columnList.add("responsemap");
    columnList.add("modifiedat");
    columnList.add("madeby");
    columnList.add("adminlastcmt");
    columnList.add("message");
    columnList.add("checkerlastcmt");
    columnList.add("rstatus");
    columnList.add("createdat");
    columnList.add("charges");
    columnList.add("servicecode");
    columnList.add("checkedby");
    columnList.add("modifiedby");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "currappstatus:" + currappstatus +"responsets:" + responsets +"institutionid:" + institutionid +"makerlastcmt:" + makerlastcmt +"sessionid:" + sessionid +"madeat:" + madeat +"servicemapid:" + servicemapid +"result:" + result +"requestts:" + requestts +"checkedat:" + checkedat +"requestorid:" + requestorid +"createdby:" + createdby +"requestsource:" + requestsource +"id:" + id +"requestmap:" + requestmap +"errormesg:" + errormesg +"responsemap:" + responsemap +"modifiedat:" + modifiedat +"madeby:" + madeby +"adminlastcmt:" + adminlastcmt +"message:" + message +"checkerlastcmt:" + checkerlastcmt +"rstatus:" + rstatus +"createdat:" + createdat +"charges:" + charges +"servicecode:" + servicecode +"checkedby:" + checkedby +"modifiedby:" + modifiedby +"";
  }
}
