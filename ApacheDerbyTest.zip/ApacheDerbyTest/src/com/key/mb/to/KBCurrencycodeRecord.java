package com.key.mb.to;

import com.key.mb.common.KBRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONObject;

public class KBCurrencycodeRecord extends KBRecord {
  public static LogUtils logger = new LogUtils(KBCurrencycodeRecord.class.getName());

  public String rstatus;

  public String createdat;

  public String createdby;

  public String modifiedat;

  public String currencyname;

  public String modifiedby;

  public String id;

  public String currencycode;

  public String getRstatus() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(rstatus);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(rstatus);
    }
    else {
      return rstatus;
    }
  }

  public String getCreatedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdat);
    }
    else {
      return createdat;
    }
  }

  public String getCreatedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(createdby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(createdby);
    }
    else {
      return createdby;
    }
  }

  public String getModifiedat() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedat);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedat);
    }
    else {
      return modifiedat;
    }
  }

  public String getCurrencyname() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(currencyname);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(currencyname);
    }
    else {
      return currencyname;
    }
  }

  public String getModifiedby() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(modifiedby);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(modifiedby);
    }
    else {
      return modifiedby;
    }
  }

  public String getId() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(id);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(id);
    }
    else {
      return id;
    }
  }

  public String getCurrencycode() {
    if(isNoNullForHTMLEnabled()) {
      return StringUtils.noNullForHTML(currencycode);
    }
    else if(isNoNullEnabled()) {
      return StringUtils.noNull(currencycode);
    }
    else {
      return currencycode;
    }
  }

  public void setRstatus(String value) {
    rstatus = value;
  }

  public void setCreatedat(String value) {
    createdat = value;
  }

  public void setCreatedby(String value) {
    createdby = value;
  }

  public void setModifiedat(String value) {
    modifiedat = value;
  }

  public void setCurrencyname(String value) {
    currencyname = value;
  }

  public void setModifiedby(String value) {
    modifiedby = value;
  }

  public void setId(String value) {
    id = value;
  }

  public void setCurrencycode(String value) {
    currencycode = value;
  }

  public void loadContent(KBCurrencycodeRecord inputRecord) {
    setRstatus(inputRecord.getRstatus());
    setCreatedat(inputRecord.getCreatedat());
    setCreatedby(inputRecord.getCreatedby());
    setModifiedat(inputRecord.getModifiedat());
    setCurrencyname(inputRecord.getCurrencyname());
    setModifiedby(inputRecord.getModifiedby());
    setId(inputRecord.getId());
    setCurrencycode(inputRecord.getCurrencycode());
  }

  public void loadNonNullContent(KBCurrencycodeRecord inputRecord) {
    if (StringUtils.hasChanged(getRstatus(), inputRecord.getRstatus())) {
      setRstatus(StringUtils.noNull(inputRecord.getRstatus()));
    }
    if (StringUtils.hasChanged(getCreatedat(), inputRecord.getCreatedat())) {
      setCreatedat(StringUtils.noNull(inputRecord.getCreatedat()));
    }
    if (StringUtils.hasChanged(getCreatedby(), inputRecord.getCreatedby())) {
      setCreatedby(StringUtils.noNull(inputRecord.getCreatedby()));
    }
    if (StringUtils.hasChanged(getModifiedat(), inputRecord.getModifiedat())) {
      setModifiedat(StringUtils.noNull(inputRecord.getModifiedat()));
    }
    if (StringUtils.hasChanged(getCurrencyname(), inputRecord.getCurrencyname())) {
      setCurrencyname(StringUtils.noNull(inputRecord.getCurrencyname()));
    }
    if (StringUtils.hasChanged(getModifiedby(), inputRecord.getModifiedby())) {
      setModifiedby(StringUtils.noNull(inputRecord.getModifiedby()));
    }
    if (StringUtils.hasChanged(getId(), inputRecord.getId())) {
      setId(StringUtils.noNull(inputRecord.getId()));
    }
    if (StringUtils.hasChanged(getCurrencycode(), inputRecord.getCurrencycode())) {
      setCurrencycode(StringUtils.noNull(inputRecord.getCurrencycode()));
    }
  }

  public JSONObject getJSONObject() {
    JSONObject obj = new JSONObject();
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("currencyname",StringUtils.noNull(currencyname));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("currencycode",StringUtils.noNull(currencycode));
    return obj;
  }

  public void loadJSONObject(JSONObject obj) throws Exception {
    if (obj == null) {
      return;
    }
    rstatus = StringUtils.getValueFromJSONObject(obj, "rstatus");
    createdat = StringUtils.getValueFromJSONObject(obj, "createdat");
    createdby = StringUtils.getValueFromJSONObject(obj, "createdby");
    modifiedat = StringUtils.getValueFromJSONObject(obj, "modifiedat");
    currencyname = StringUtils.getValueFromJSONObject(obj, "currencyname");
    modifiedby = StringUtils.getValueFromJSONObject(obj, "modifiedby");
    id = StringUtils.getValueFromJSONObject(obj, "id");
    currencycode = StringUtils.getValueFromJSONObject(obj, "currencycode");
  }

  public JSONObject getJSONObjectUI() {
    JSONObject obj = new JSONObject();
    obj.put("rstatus",StringUtils.noNull(rstatus));
    obj.put("createdat",StringUtils.noNull(createdat));
    obj.put("createdby",StringUtils.noNull(createdby));
    obj.put("modifiedat",StringUtils.noNull(modifiedat));
    obj.put("currencyname",StringUtils.noNull(currencyname));
    obj.put("modifiedby",StringUtils.noNull(modifiedby));
    obj.put("id",StringUtils.noNull(id));
    obj.put("currencycode",StringUtils.noNull(currencycode));
    return obj;
  }

  public HashMap getTableMap() {
    HashMap resultMap = new HashMap();
    ArrayList columnList = new ArrayList();
    resultMap.put("table", "call_back");
    columnList.add("rstatus");
    columnList.add("createdat");
    columnList.add("createdby");
    columnList.add("modifiedat");
    columnList.add("currencyname");
    columnList.add("modifiedby");
    columnList.add("id");
    columnList.add("currencycode");
    resultMap.put("ColumnList", columnList);
    return resultMap;
  }

  public String toString() {
    return "rstatus:" + rstatus +"createdat:" + createdat +"createdby:" + createdby +"modifiedat:" + modifiedat +"currencyname:" + currencyname +"modifiedby:" + modifiedby +"id:" + id +"currencycode:" + currencycode +"";
  }
}
