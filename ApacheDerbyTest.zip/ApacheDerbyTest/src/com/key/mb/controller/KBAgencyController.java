package com.key.mb.controller;

import com.key.mb.common.KBController;
import com.key.mb.service.KBAgencyService;
import com.key.mb.to.KBAgencyRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class KBAgencyController extends KBController {
  public static LogUtils logger = new LogUtils(KBAgencyController.class.getName());

  public KBAgencyRecord loadFormKBAgencyRecord(HttpServletRequest req, HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadFormKBAgencyRecord", null);
    KBAgencyRecord record = new KBAgencyRecord();
    record.setBusstat(getFormFieldValue(req, res, "tfBusstat"));
    record.setAgtype(getFormFieldValue(req, res, "tfAgtype"));
    record.setPstaddr(getFormFieldValue(req, res, "tfPstaddr"));
    record.setProfprov(getFormFieldValue(req, res, "tfProfprov"));
    record.setCheckedby(getFormFieldValue(req, res, "tfCheckedby"));
    record.setCreatedat(getFormFieldValue(req, res, "tfCreatedat"));
    record.setMakerlastcmt(getFormFieldValue(req, res, "tfMakerlastcmt"));
    record.setBrnchcode(getFormFieldValue(req, res, "tfBrnchcode"));
    record.setInstitutionid(getFormFieldValue(req, res, "tfInstitutionid"));
    record.setDomibrnch(getFormFieldValue(req, res, "tfDomibrnch"));
    record.setServpk(getFormFieldValue(req, res, "tfServpk"));
    record.setMastagcode(getFormFieldValue(req, res, "tfMastagcode"));
    record.setPstzip(getFormFieldValue(req, res, "tfPstzip"));
    record.setBusname(getFormFieldValue(req, res, "tfBusname"));
    record.setId(getFormFieldValue(req, res, "tfId"));
    record.setModifiedat(getFormFieldValue(req, res, "tfModifiedat"));
    record.setMadeat(getFormFieldValue(req, res, "tfMadeat"));
    record.setExtn4(getFormFieldValue(req, res, "tfExtn4"));
    record.setBusloc(getFormFieldValue(req, res, "tfBusloc"));
    record.setExtn3(getFormFieldValue(req, res, "tfExtn3"));
    record.setExtn2(getFormFieldValue(req, res, "tfExtn2"));
    record.setBusnationality(getFormFieldValue(req, res, "tfBusnationality"));
    record.setCheckedat(getFormFieldValue(req, res, "tfCheckedat"));
    record.setExtn1(getFormFieldValue(req, res, "tfExtn1"));
    record.setDlylimit(getFormFieldValue(req, res, "tfDlylimit"));
    record.setLrnum(getFormFieldValue(req, res, "tfLrnum"));
    record.setBusdesig(getFormFieldValue(req, res, "tfBusdesig"));
    record.setCreatedby(getFormFieldValue(req, res, "tfCreatedby"));
    record.setMnthlimit(getFormFieldValue(req, res, "tfMnthlimit"));
    record.setNationalty(getFormFieldValue(req, res, "tfNationalty"));
    record.setExtn5(getFormFieldValue(req, res, "tfExtn5"));
    record.setRstatus(getFormFieldValue(req, res, "tfRstatus"));
    record.setCurrappstatus(getFormFieldValue(req, res, "tfCurrappstatus"));
    record.setPstcity(getFormFieldValue(req, res, "tfPstcity"));
    record.setProfagcode(getFormFieldValue(req, res, "tfProfagcode"));
    record.setAdminlastcmt(getFormFieldValue(req, res, "tfAdminlastcmt"));
    record.setProfcont2(getFormFieldValue(req, res, "tfProfcont2"));
    record.setModifiedby(getFormFieldValue(req, res, "tfModifiedby"));
    record.setProfcont1(getFormFieldValue(req, res, "tfProfcont1"));
    record.setPhyaddr(getFormFieldValue(req, res, "tfPhyaddr"));
    record.setMadeby(getFormFieldValue(req, res, "tfMadeby"));
    record.setAccnum3(getFormFieldValue(req, res, "tfAccnum3"));
    record.setTrdname(getFormFieldValue(req, res, "tfTrdname"));
    record.setAccnum2(getFormFieldValue(req, res, "tfAccnum2"));
    record.setCheckerlastcmt(getFormFieldValue(req, res, "tfCheckerlastcmt"));
    record.setAccnum1(getFormFieldValue(req, res, "tfAccnum1"));
    logger.trace("loadFormKBAgencyRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBAgencyRecord loadJSONFormKBAgencyRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBAgencyRecord", null);
    KBAgencyRecord record = new KBAgencyRecord();
    record.setBusstat(getFormFieldValue(req, res, "busstat"));
    record.setAgtype(getFormFieldValue(req, res, "ag_type"));
    record.setPstaddr(getFormFieldValue(req, res, "pstaddr"));
    record.setProfprov(getFormFieldValue(req, res, "profprov"));
    record.setCheckedby(getFormFieldValue(req, res, "checked_by"));
    record.setCreatedat(getFormFieldValue(req, res, "created_at"));
    record.setMakerlastcmt(getFormFieldValue(req, res, "maker_last_cmt"));
    record.setBrnchcode(getFormFieldValue(req, res, "brnchcode"));
    record.setInstitutionid(getFormFieldValue(req, res, "institution_id"));
    record.setDomibrnch(getFormFieldValue(req, res, "domibrnch"));
    record.setServpk(getFormFieldValue(req, res, "servpk"));
    record.setMastagcode(getFormFieldValue(req, res, "mast_agcode"));
    record.setPstzip(getFormFieldValue(req, res, "pstzip"));
    record.setBusname(getFormFieldValue(req, res, "busname"));
    record.setId(getFormFieldValue(req, res, "id"));
    record.setModifiedat(getFormFieldValue(req, res, "modified_at"));
    record.setMadeat(getFormFieldValue(req, res, "made_at"));
    record.setExtn4(getFormFieldValue(req, res, "extn4"));
    record.setBusloc(getFormFieldValue(req, res, "busloc"));
    record.setExtn3(getFormFieldValue(req, res, "extn3"));
    record.setExtn2(getFormFieldValue(req, res, "extn2"));
    record.setBusnationality(getFormFieldValue(req, res, "busnationality"));
    record.setCheckedat(getFormFieldValue(req, res, "checked_at"));
    record.setExtn1(getFormFieldValue(req, res, "extn1"));
    record.setDlylimit(getFormFieldValue(req, res, "dly_limit"));
    record.setLrnum(getFormFieldValue(req, res, "lrnum"));
    record.setBusdesig(getFormFieldValue(req, res, "busdesig"));
    record.setCreatedby(getFormFieldValue(req, res, "created_by"));
    record.setMnthlimit(getFormFieldValue(req, res, "mnth_limit"));
    record.setNationalty(getFormFieldValue(req, res, "nationalty"));
    record.setExtn5(getFormFieldValue(req, res, "extn5"));
    record.setRstatus(getFormFieldValue(req, res, "rstatus"));
    record.setCurrappstatus(getFormFieldValue(req, res, "curr_app_status"));
    record.setPstcity(getFormFieldValue(req, res, "pstcity"));
    record.setProfagcode(getFormFieldValue(req, res, "profagcode"));
    record.setAdminlastcmt(getFormFieldValue(req, res, "admin_last_cmt"));
    record.setProfcont2(getFormFieldValue(req, res, "profcont2"));
    record.setModifiedby(getFormFieldValue(req, res, "modified_by"));
    record.setProfcont1(getFormFieldValue(req, res, "profcont1"));
    record.setPhyaddr(getFormFieldValue(req, res, "phyaddr"));
    record.setMadeby(getFormFieldValue(req, res, "made_by"));
    record.setAccnum3(getFormFieldValue(req, res, "accnum3"));
    record.setTrdname(getFormFieldValue(req, res, "trdname"));
    record.setAccnum2(getFormFieldValue(req, res, "accnum2"));
    record.setCheckerlastcmt(getFormFieldValue(req, res, "checker_last_cmt"));
    record.setAccnum1(getFormFieldValue(req, res, "accnum1"));
    logger.trace("loadJSONFormKBAgencyRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBAgencyRecord loadJSONFormKBAgencyRecordEncode(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBAgencyRecordEncode", null);
    KBAgencyRecord record = new KBAgencyRecord();
    record.setBusstat(getFormFieldValueEncode(req, res, "busstat"));
    record.setAgtype(getFormFieldValueEncode(req, res, "ag_type"));
    record.setPstaddr(getFormFieldValueEncode(req, res, "pstaddr"));
    record.setProfprov(getFormFieldValueEncode(req, res, "profprov"));
    record.setCheckedby(getFormFieldValueEncode(req, res, "checked_by"));
    record.setCreatedat(getFormFieldValueEncode(req, res, "created_at"));
    record.setMakerlastcmt(getFormFieldValueEncode(req, res, "maker_last_cmt"));
    record.setBrnchcode(getFormFieldValueEncode(req, res, "brnchcode"));
    record.setInstitutionid(getFormFieldValueEncode(req, res, "institution_id"));
    record.setDomibrnch(getFormFieldValueEncode(req, res, "domibrnch"));
    record.setServpk(getFormFieldValueEncode(req, res, "servpk"));
    record.setMastagcode(getFormFieldValueEncode(req, res, "mast_agcode"));
    record.setPstzip(getFormFieldValueEncode(req, res, "pstzip"));
    record.setBusname(getFormFieldValueEncode(req, res, "busname"));
    record.setId(getFormFieldValueEncode(req, res, "id"));
    record.setModifiedat(getFormFieldValueEncode(req, res, "modified_at"));
    record.setMadeat(getFormFieldValueEncode(req, res, "made_at"));
    record.setExtn4(getFormFieldValueEncode(req, res, "extn4"));
    record.setBusloc(getFormFieldValueEncode(req, res, "busloc"));
    record.setExtn3(getFormFieldValueEncode(req, res, "extn3"));
    record.setExtn2(getFormFieldValueEncode(req, res, "extn2"));
    record.setBusnationality(getFormFieldValueEncode(req, res, "busnationality"));
    record.setCheckedat(getFormFieldValueEncode(req, res, "checked_at"));
    record.setExtn1(getFormFieldValueEncode(req, res, "extn1"));
    record.setDlylimit(getFormFieldValueEncode(req, res, "dly_limit"));
    record.setLrnum(getFormFieldValueEncode(req, res, "lrnum"));
    record.setBusdesig(getFormFieldValueEncode(req, res, "busdesig"));
    record.setCreatedby(getFormFieldValueEncode(req, res, "created_by"));
    record.setMnthlimit(getFormFieldValueEncode(req, res, "mnth_limit"));
    record.setNationalty(getFormFieldValueEncode(req, res, "nationalty"));
    record.setExtn5(getFormFieldValueEncode(req, res, "extn5"));
    record.setRstatus(getFormFieldValueEncode(req, res, "rstatus"));
    record.setCurrappstatus(getFormFieldValueEncode(req, res, "curr_app_status"));
    record.setPstcity(getFormFieldValueEncode(req, res, "pstcity"));
    record.setProfagcode(getFormFieldValueEncode(req, res, "profagcode"));
    record.setAdminlastcmt(getFormFieldValueEncode(req, res, "admin_last_cmt"));
    record.setProfcont2(getFormFieldValueEncode(req, res, "profcont2"));
    record.setModifiedby(getFormFieldValueEncode(req, res, "modified_by"));
    record.setProfcont1(getFormFieldValueEncode(req, res, "profcont1"));
    record.setPhyaddr(getFormFieldValueEncode(req, res, "phyaddr"));
    record.setMadeby(getFormFieldValueEncode(req, res, "made_by"));
    record.setAccnum3(getFormFieldValueEncode(req, res, "accnum3"));
    record.setTrdname(getFormFieldValueEncode(req, res, "trdname"));
    record.setAccnum2(getFormFieldValueEncode(req, res, "accnum2"));
    record.setCheckerlastcmt(getFormFieldValueEncode(req, res, "checker_last_cmt"));
    record.setAccnum1(getFormFieldValueEncode(req, res, "accnum1"));
    logger.trace("loadJSONFormKBAgencyRecordEncode	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBAgencyRecord loadMapKBAgencyRecord(HashMap inputMap) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadMapKBAgencyRecord", null);
    KBAgencyRecord record = new KBAgencyRecord();
    record.setBusstat(getMapValue(inputMap,"busstat"));
    record.setAgtype(getMapValue(inputMap,"ag_type"));
    record.setPstaddr(getMapValue(inputMap,"pstaddr"));
    record.setProfprov(getMapValue(inputMap,"profprov"));
    record.setCheckedby(getMapValue(inputMap,"checked_by"));
    record.setCreatedat(getMapValue(inputMap,"created_at"));
    record.setMakerlastcmt(getMapValue(inputMap,"maker_last_cmt"));
    record.setBrnchcode(getMapValue(inputMap,"brnchcode"));
    record.setInstitutionid(getMapValue(inputMap,"institution_id"));
    record.setDomibrnch(getMapValue(inputMap,"domibrnch"));
    record.setServpk(getMapValue(inputMap,"servpk"));
    record.setMastagcode(getMapValue(inputMap,"mast_agcode"));
    record.setPstzip(getMapValue(inputMap,"pstzip"));
    record.setBusname(getMapValue(inputMap,"busname"));
    record.setId(getMapValue(inputMap,"id"));
    record.setModifiedat(getMapValue(inputMap,"modified_at"));
    record.setMadeat(getMapValue(inputMap,"made_at"));
    record.setExtn4(getMapValue(inputMap,"extn4"));
    record.setBusloc(getMapValue(inputMap,"busloc"));
    record.setExtn3(getMapValue(inputMap,"extn3"));
    record.setExtn2(getMapValue(inputMap,"extn2"));
    record.setBusnationality(getMapValue(inputMap,"busnationality"));
    record.setCheckedat(getMapValue(inputMap,"checked_at"));
    record.setExtn1(getMapValue(inputMap,"extn1"));
    record.setDlylimit(getMapValue(inputMap,"dly_limit"));
    record.setLrnum(getMapValue(inputMap,"lrnum"));
    record.setBusdesig(getMapValue(inputMap,"busdesig"));
    record.setCreatedby(getMapValue(inputMap,"created_by"));
    record.setMnthlimit(getMapValue(inputMap,"mnth_limit"));
    record.setNationalty(getMapValue(inputMap,"nationalty"));
    record.setExtn5(getMapValue(inputMap,"extn5"));
    record.setRstatus(getMapValue(inputMap,"rstatus"));
    record.setCurrappstatus(getMapValue(inputMap,"curr_app_status"));
    record.setPstcity(getMapValue(inputMap,"pstcity"));
    record.setProfagcode(getMapValue(inputMap,"profagcode"));
    record.setAdminlastcmt(getMapValue(inputMap,"admin_last_cmt"));
    record.setProfcont2(getMapValue(inputMap,"profcont2"));
    record.setModifiedby(getMapValue(inputMap,"modified_by"));
    record.setProfcont1(getMapValue(inputMap,"profcont1"));
    record.setPhyaddr(getMapValue(inputMap,"phyaddr"));
    record.setMadeby(getMapValue(inputMap,"made_by"));
    record.setAccnum3(getMapValue(inputMap,"accnum3"));
    record.setTrdname(getMapValue(inputMap,"trdname"));
    record.setAccnum2(getMapValue(inputMap,"accnum2"));
    record.setCheckerlastcmt(getMapValue(inputMap,"checker_last_cmt"));
    record.setAccnum1(getMapValue(inputMap,"accnum1"));
    logger.trace("loadMapKBAgencyRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public void processInsertKBAgencyRecord(HttpServletRequest req, HttpServletResponse res) throws
      Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processInsertKBAgencyRecord", null);
    KBAgencyService service = new KBAgencyService();
    try {
      KBAgencyRecord record = loadFormKBAgencyRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      int resultId = service.insertKBAgencyRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~" + resultId);
      logger.generateFunctionEndTimerMessage(beginMesssage);
       res.sendRedirect("KBAgencyController.jsp");
    }
    catch(Exception e) {
      setActionMessageLn(req, res, "AdminActionMessage", "FailedtoCreate~~KBAgencyRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBAgencyController.jsp");
    }
  }

  public void processUpdateKBAgencyRecord(HttpServletRequest req, HttpServletResponse res) throws
      Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processUpdateKBAgencyRecord", null);
    KBAgencyService service = new KBAgencyService();
    try {
      KBAgencyRecord record = loadFormKBAgencyRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.updateKBAgencyRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBAgencyController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBAgencyRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBAgencyController.jsp");
    }
  }

  public void processDeleteKBAgencyRecord(HttpServletRequest req, HttpServletResponse res) throws
      Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processDeleteKBAgencyRecord", null);
    KBAgencyService service = new KBAgencyService();
    try {
      KBAgencyRecord record = loadFormKBAgencyRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.deleteKBAgencyRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBAgencyController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBAgencyRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBAgencyController.jsp");
    }
  }

  public void processWebRequest(HttpServletRequest req, HttpServletResponse res, String actionType)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processWebRequest", null);
     logger.trace("Action Type:" + actionType + "");
    if (actionType.equals("InsertAgencyRecord")) {
      processInsertKBAgencyRecord(req, res);
    }
    if (actionType.equals("UpdateAgencyRecord")) {
      processUpdateKBAgencyRecord(req, res);
    }
    if (actionType.equals("DeleteAgencyRecord")) {
      processDeleteKBAgencyRecord(req, res);
    }
    logger.generateFunctionEndTimerMessage(beginMesssage);
  }
}
