package com.key.mb.controller;

import com.key.mb.common.KBController;
import com.key.mb.service.KBCustomercategoryService;
import com.key.mb.to.KBCustomercategoryRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class KBCustomercategoryController extends KBController {
  public static LogUtils logger = new LogUtils(KBCustomercategoryController.class.getName());

  public KBCustomercategoryRecord loadFormKBCustomercategoryRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadFormKBCustomercategoryRecord", null);
    KBCustomercategoryRecord record = new KBCustomercategoryRecord();
    record.setMadeat(getFormFieldValue(req, res, "tfMadeat"));
    record.setChargetype(getFormFieldValue(req, res, "tfChargetype"));
    record.setCheckedat(getFormFieldValue(req, res, "tfCheckedat"));
    record.setChargevalue(getFormFieldValue(req, res, "tfChargevalue"));
    record.setCheckedby(getFormFieldValue(req, res, "tfCheckedby"));
    record.setCreatedat(getFormFieldValue(req, res, "tfCreatedat"));
    record.setMintranlimit(getFormFieldValue(req, res, "tfMintranlimit"));
    record.setMakerlastcmt(getFormFieldValue(req, res, "tfMakerlastcmt"));
    record.setCreatedby(getFormFieldValue(req, res, "tfCreatedby"));
    record.setInstitutionid(getFormFieldValue(req, res, "tfInstitutionid"));
    record.setRstatus(getFormFieldValue(req, res, "tfRstatus"));
    record.setCurrappstatus(getFormFieldValue(req, res, "tfCurrappstatus"));
    record.setAdminlastcmt(getFormFieldValue(req, res, "tfAdminlastcmt"));
    record.setPerdaylimit(getFormFieldValue(req, res, "tfPerdaylimit"));
    record.setServiceid(getFormFieldValue(req, res, "tfServiceid"));
    record.setModifiedby(getFormFieldValue(req, res, "tfModifiedby"));
    record.setPertranlimit(getFormFieldValue(req, res, "tfPertranlimit"));
    record.setId(getFormFieldValue(req, res, "tfId"));
    record.setCategory(getFormFieldValue(req, res, "tfCategory"));
    record.setMadeby(getFormFieldValue(req, res, "tfMadeby"));
    record.setModifiedat(getFormFieldValue(req, res, "tfModifiedat"));
    record.setCheckerlastcmt(getFormFieldValue(req, res, "tfCheckerlastcmt"));
    logger.trace("loadFormKBCustomercategoryRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBCustomercategoryRecord loadJSONFormKBCustomercategoryRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBCustomercategoryRecord", null);
    KBCustomercategoryRecord record = new KBCustomercategoryRecord();
    record.setMadeat(getFormFieldValue(req, res, "made_at"));
    record.setChargetype(getFormFieldValue(req, res, "charge_type"));
    record.setCheckedat(getFormFieldValue(req, res, "checked_at"));
    record.setChargevalue(getFormFieldValue(req, res, "charge_value"));
    record.setCheckedby(getFormFieldValue(req, res, "checked_by"));
    record.setCreatedat(getFormFieldValue(req, res, "created_at"));
    record.setMintranlimit(getFormFieldValue(req, res, "min_tran_limit"));
    record.setMakerlastcmt(getFormFieldValue(req, res, "maker_last_cmt"));
    record.setCreatedby(getFormFieldValue(req, res, "created_by"));
    record.setInstitutionid(getFormFieldValue(req, res, "institution_id"));
    record.setRstatus(getFormFieldValue(req, res, "rstatus"));
    record.setCurrappstatus(getFormFieldValue(req, res, "curr_app_status"));
    record.setAdminlastcmt(getFormFieldValue(req, res, "admin_last_cmt"));
    record.setPerdaylimit(getFormFieldValue(req, res, "per_day_limit"));
    record.setServiceid(getFormFieldValue(req, res, "service_id"));
    record.setModifiedby(getFormFieldValue(req, res, "modified_by"));
    record.setPertranlimit(getFormFieldValue(req, res, "per_tran_limit"));
    record.setId(getFormFieldValue(req, res, "id"));
    record.setCategory(getFormFieldValue(req, res, "category"));
    record.setMadeby(getFormFieldValue(req, res, "made_by"));
    record.setModifiedat(getFormFieldValue(req, res, "modified_at"));
    record.setCheckerlastcmt(getFormFieldValue(req, res, "checker_last_cmt"));
    logger.trace("loadJSONFormKBCustomercategoryRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBCustomercategoryRecord loadJSONFormKBCustomercategoryRecordEncode(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBCustomercategoryRecordEncode", null);
    KBCustomercategoryRecord record = new KBCustomercategoryRecord();
    record.setMadeat(getFormFieldValueEncode(req, res, "made_at"));
    record.setChargetype(getFormFieldValueEncode(req, res, "charge_type"));
    record.setCheckedat(getFormFieldValueEncode(req, res, "checked_at"));
    record.setChargevalue(getFormFieldValueEncode(req, res, "charge_value"));
    record.setCheckedby(getFormFieldValueEncode(req, res, "checked_by"));
    record.setCreatedat(getFormFieldValueEncode(req, res, "created_at"));
    record.setMintranlimit(getFormFieldValueEncode(req, res, "min_tran_limit"));
    record.setMakerlastcmt(getFormFieldValueEncode(req, res, "maker_last_cmt"));
    record.setCreatedby(getFormFieldValueEncode(req, res, "created_by"));
    record.setInstitutionid(getFormFieldValueEncode(req, res, "institution_id"));
    record.setRstatus(getFormFieldValueEncode(req, res, "rstatus"));
    record.setCurrappstatus(getFormFieldValueEncode(req, res, "curr_app_status"));
    record.setAdminlastcmt(getFormFieldValueEncode(req, res, "admin_last_cmt"));
    record.setPerdaylimit(getFormFieldValueEncode(req, res, "per_day_limit"));
    record.setServiceid(getFormFieldValueEncode(req, res, "service_id"));
    record.setModifiedby(getFormFieldValueEncode(req, res, "modified_by"));
    record.setPertranlimit(getFormFieldValueEncode(req, res, "per_tran_limit"));
    record.setId(getFormFieldValueEncode(req, res, "id"));
    record.setCategory(getFormFieldValueEncode(req, res, "category"));
    record.setMadeby(getFormFieldValueEncode(req, res, "made_by"));
    record.setModifiedat(getFormFieldValueEncode(req, res, "modified_at"));
    record.setCheckerlastcmt(getFormFieldValueEncode(req, res, "checker_last_cmt"));
    logger.trace("loadJSONFormKBCustomercategoryRecordEncode	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBCustomercategoryRecord loadMapKBCustomercategoryRecord(HashMap inputMap) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadMapKBCustomercategoryRecord", null);
    KBCustomercategoryRecord record = new KBCustomercategoryRecord();
    record.setMadeat(getMapValue(inputMap,"made_at"));
    record.setChargetype(getMapValue(inputMap,"charge_type"));
    record.setCheckedat(getMapValue(inputMap,"checked_at"));
    record.setChargevalue(getMapValue(inputMap,"charge_value"));
    record.setCheckedby(getMapValue(inputMap,"checked_by"));
    record.setCreatedat(getMapValue(inputMap,"created_at"));
    record.setMintranlimit(getMapValue(inputMap,"min_tran_limit"));
    record.setMakerlastcmt(getMapValue(inputMap,"maker_last_cmt"));
    record.setCreatedby(getMapValue(inputMap,"created_by"));
    record.setInstitutionid(getMapValue(inputMap,"institution_id"));
    record.setRstatus(getMapValue(inputMap,"rstatus"));
    record.setCurrappstatus(getMapValue(inputMap,"curr_app_status"));
    record.setAdminlastcmt(getMapValue(inputMap,"admin_last_cmt"));
    record.setPerdaylimit(getMapValue(inputMap,"per_day_limit"));
    record.setServiceid(getMapValue(inputMap,"service_id"));
    record.setModifiedby(getMapValue(inputMap,"modified_by"));
    record.setPertranlimit(getMapValue(inputMap,"per_tran_limit"));
    record.setId(getMapValue(inputMap,"id"));
    record.setCategory(getMapValue(inputMap,"category"));
    record.setMadeby(getMapValue(inputMap,"made_by"));
    record.setModifiedat(getMapValue(inputMap,"modified_at"));
    record.setCheckerlastcmt(getMapValue(inputMap,"checker_last_cmt"));
    logger.trace("loadMapKBCustomercategoryRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public void processInsertKBCustomercategoryRecord(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processInsertKBCustomercategoryRecord", null);
    KBCustomercategoryService service = new KBCustomercategoryService();
    try {
      KBCustomercategoryRecord record = loadFormKBCustomercategoryRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      int resultId = service.insertKBCustomercategoryRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~" + resultId);
      logger.generateFunctionEndTimerMessage(beginMesssage);
       res.sendRedirect("KBCustomercategoryController.jsp");
    }
    catch(Exception e) {
      setActionMessageLn(req, res, "AdminActionMessage", "FailedtoCreate~~KBCustomercategoryRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBCustomercategoryController.jsp");
    }
  }

  public void processUpdateKBCustomercategoryRecord(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processUpdateKBCustomercategoryRecord", null);
    KBCustomercategoryService service = new KBCustomercategoryService();
    try {
      KBCustomercategoryRecord record = loadFormKBCustomercategoryRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.updateKBCustomercategoryRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBCustomercategoryController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBCustomercategoryRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBCustomercategoryController.jsp");
    }
  }

  public void processDeleteKBCustomercategoryRecord(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processDeleteKBCustomercategoryRecord", null);
    KBCustomercategoryService service = new KBCustomercategoryService();
    try {
      KBCustomercategoryRecord record = loadFormKBCustomercategoryRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.deleteKBCustomercategoryRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBCustomercategoryController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBCustomercategoryRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBCustomercategoryController.jsp");
    }
  }

  public void processWebRequest(HttpServletRequest req, HttpServletResponse res, String actionType)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processWebRequest", null);
     logger.trace("Action Type:" + actionType + "");
    if (actionType.equals("InsertCustomercategoryRecord")) {
      processInsertKBCustomercategoryRecord(req, res);
    }
    if (actionType.equals("UpdateCustomercategoryRecord")) {
      processUpdateKBCustomercategoryRecord(req, res);
    }
    if (actionType.equals("DeleteCustomercategoryRecord")) {
      processDeleteKBCustomercategoryRecord(req, res);
    }
    logger.generateFunctionEndTimerMessage(beginMesssage);
  }
}
