package com.key.mb.controller;

import com.key.mb.common.KBController;
import com.key.mb.service.KBCustomerviewService;
import com.key.mb.to.KBCustomerviewRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class KBCustomerviewController extends KBController {
  public static LogUtils logger = new LogUtils(KBCustomerviewController.class.getName());

  public KBCustomerviewRecord loadFormKBCustomerviewRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadFormKBCustomerviewRecord", null);
    KBCustomerviewRecord record = new KBCustomerviewRecord();
    record.setCheckedby(getFormFieldValue(req, res, "tfCheckedby"));
    record.setTermssigned(getFormFieldValue(req, res, "tfTermssigned"));
    record.setMakerlastcmt(getFormFieldValue(req, res, "tfMakerlastcmt"));
    record.setPreflang(getFormFieldValue(req, res, "tfPreflang"));
    record.setInstitutionid(getFormFieldValue(req, res, "tfInstitutionid"));
    record.setIname(getFormFieldValue(req, res, "tfIname"));
    record.setBlockedflag(getFormFieldValue(req, res, "tfBlockedflag"));
    record.setPassport(getFormFieldValue(req, res, "tfPassport"));
    record.setId(getFormFieldValue(req, res, "tfId"));
    record.setModifiedat(getFormFieldValue(req, res, "tfModifiedat"));
    record.setAuthfailtpin(getFormFieldValue(req, res, "tfAuthfailtpin"));
    record.setValacc(getFormFieldValue(req, res, "tfValacc"));
    record.setMadeat(getFormFieldValue(req, res, "tfMadeat"));
    record.setCheckedat(getFormFieldValue(req, res, "tfCheckedat"));
    record.setAllowedphoneid1(getFormFieldValue(req, res, "tfAllowedphoneid1"));
    record.setAllowedphoneid2(getFormFieldValue(req, res, "tfAllowedphoneid2"));
    record.setCreatedby(getFormFieldValue(req, res, "tfCreatedby"));
    record.setRstatus(getFormFieldValue(req, res, "tfRstatus"));
    record.setPinno(getFormFieldValue(req, res, "tfPinno"));
    record.setNationality(getFormFieldValue(req, res, "tfNationality"));
    record.setAdminlastcmt(getFormFieldValue(req, res, "tfAdminlastcmt"));
    record.setAllowedphoneid3(getFormFieldValue(req, res, "tfAllowedphoneid3"));
    record.setCheckerlastcmt(getFormFieldValue(req, res, "tfCheckerlastcmt"));
    record.setNationalid(getFormFieldValue(req, res, "tfNationalid"));
    record.setCif(getFormFieldValue(req, res, "tfCif"));
    record.setCname(getFormFieldValue(req, res, "tfCname"));
    record.setCreatedat(getFormFieldValue(req, res, "tfCreatedat"));
    record.setAuthfailpin(getFormFieldValue(req, res, "tfAuthfailpin"));
    record.setEmail(getFormFieldValue(req, res, "tfEmail"));
    record.setReportfreq(getFormFieldValue(req, res, "tfReportfreq"));
    record.setStatusname(getFormFieldValue(req, res, "tfStatusname"));
    record.setMobile(getFormFieldValue(req, res, "tfMobile"));
    record.setAllowedphonetype3(getFormFieldValue(req, res, "tfAllowedphonetype3"));
    record.setIdsubmitted(getFormFieldValue(req, res, "tfIdsubmitted"));
    record.setAllowedphonetype2(getFormFieldValue(req, res, "tfAllowedphonetype2"));
    record.setIdverified(getFormFieldValue(req, res, "tfIdverified"));
    record.setCustcat(getFormFieldValue(req, res, "tfCustcat"));
    record.setCustextn4(getFormFieldValue(req, res, "tfCustextn4"));
    record.setCustextn3(getFormFieldValue(req, res, "tfCustextn3"));
    record.setCurrappstatus(getFormFieldValue(req, res, "tfCurrappstatus"));
    record.setCustextn2(getFormFieldValue(req, res, "tfCustextn2"));
    record.setCustextn1(getFormFieldValue(req, res, "tfCustextn1"));
    record.setTpinno(getFormFieldValue(req, res, "tfTpinno"));
    record.setAllowedphonetype1(getFormFieldValue(req, res, "tfAllowedphonetype1"));
    record.setCurrappstatusname(getFormFieldValue(req, res, "tfCurrappstatusname"));
    record.setModifiedby(getFormFieldValue(req, res, "tfModifiedby"));
    record.setMadeby(getFormFieldValue(req, res, "tfMadeby"));
    record.setCategory(getFormFieldValue(req, res, "tfCategory"));
    record.setUgissued(getFormFieldValue(req, res, "tfUgissued"));
    logger.trace("loadFormKBCustomerviewRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBCustomerviewRecord loadJSONFormKBCustomerviewRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBCustomerviewRecord", null);
    KBCustomerviewRecord record = new KBCustomerviewRecord();
    record.setCheckedby(getFormFieldValue(req, res, "checked_by"));
    record.setTermssigned(getFormFieldValue(req, res, "terms_signed"));
    record.setMakerlastcmt(getFormFieldValue(req, res, "maker_last_cmt"));
    record.setPreflang(getFormFieldValue(req, res, "pref_lang"));
    record.setInstitutionid(getFormFieldValue(req, res, "institution_id"));
    record.setIname(getFormFieldValue(req, res, "iname"));
    record.setBlockedflag(getFormFieldValue(req, res, "blocked_flag"));
    record.setPassport(getFormFieldValue(req, res, "passport"));
    record.setId(getFormFieldValue(req, res, "id"));
    record.setModifiedat(getFormFieldValue(req, res, "modified_at"));
    record.setAuthfailtpin(getFormFieldValue(req, res, "auth_fail_tpin"));
    record.setValacc(getFormFieldValue(req, res, "val_acc"));
    record.setMadeat(getFormFieldValue(req, res, "made_at"));
    record.setCheckedat(getFormFieldValue(req, res, "checked_at"));
    record.setAllowedphoneid1(getFormFieldValue(req, res, "allowed_phone_id1"));
    record.setAllowedphoneid2(getFormFieldValue(req, res, "allowed_phone_id2"));
    record.setCreatedby(getFormFieldValue(req, res, "created_by"));
    record.setRstatus(getFormFieldValue(req, res, "rstatus"));
    record.setPinno(getFormFieldValue(req, res, "pin_no"));
    record.setNationality(getFormFieldValue(req, res, "nationality"));
    record.setAdminlastcmt(getFormFieldValue(req, res, "admin_last_cmt"));
    record.setAllowedphoneid3(getFormFieldValue(req, res, "allowed_phone_id3"));
    record.setCheckerlastcmt(getFormFieldValue(req, res, "checker_last_cmt"));
    record.setNationalid(getFormFieldValue(req, res, "national_id"));
    record.setCif(getFormFieldValue(req, res, "cif"));
    record.setCname(getFormFieldValue(req, res, "cname"));
    record.setCreatedat(getFormFieldValue(req, res, "created_at"));
    record.setAuthfailpin(getFormFieldValue(req, res, "auth_fail_pin"));
    record.setEmail(getFormFieldValue(req, res, "email"));
    record.setReportfreq(getFormFieldValue(req, res, "report_freq"));
    record.setStatusname(getFormFieldValue(req, res, "status_name"));
    record.setMobile(getFormFieldValue(req, res, "mobile"));
    record.setAllowedphonetype3(getFormFieldValue(req, res, "allowed_phone_type3"));
    record.setIdsubmitted(getFormFieldValue(req, res, "id_submitted"));
    record.setAllowedphonetype2(getFormFieldValue(req, res, "allowed_phone_type2"));
    record.setIdverified(getFormFieldValue(req, res, "id_verified"));
    record.setCustcat(getFormFieldValue(req, res, "cust_cat"));
    record.setCustextn4(getFormFieldValue(req, res, "cust_extn4"));
    record.setCustextn3(getFormFieldValue(req, res, "cust_extn3"));
    record.setCurrappstatus(getFormFieldValue(req, res, "curr_app_status"));
    record.setCustextn2(getFormFieldValue(req, res, "cust_extn2"));
    record.setCustextn1(getFormFieldValue(req, res, "cust_extn1"));
    record.setTpinno(getFormFieldValue(req, res, "tpin_no"));
    record.setAllowedphonetype1(getFormFieldValue(req, res, "allowed_phone_type1"));
    record.setCurrappstatusname(getFormFieldValue(req, res, "curr_app_status_name"));
    record.setModifiedby(getFormFieldValue(req, res, "modified_by"));
    record.setMadeby(getFormFieldValue(req, res, "made_by"));
    record.setCategory(getFormFieldValue(req, res, "category"));
    record.setUgissued(getFormFieldValue(req, res, "ug_issued"));
    logger.trace("loadJSONFormKBCustomerviewRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBCustomerviewRecord loadJSONFormKBCustomerviewRecordEncode(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBCustomerviewRecordEncode", null);
    KBCustomerviewRecord record = new KBCustomerviewRecord();
    record.setCheckedby(getFormFieldValueEncode(req, res, "checked_by"));
    record.setTermssigned(getFormFieldValueEncode(req, res, "terms_signed"));
    record.setMakerlastcmt(getFormFieldValueEncode(req, res, "maker_last_cmt"));
    record.setPreflang(getFormFieldValueEncode(req, res, "pref_lang"));
    record.setInstitutionid(getFormFieldValueEncode(req, res, "institution_id"));
    record.setIname(getFormFieldValueEncode(req, res, "iname"));
    record.setBlockedflag(getFormFieldValueEncode(req, res, "blocked_flag"));
    record.setPassport(getFormFieldValueEncode(req, res, "passport"));
    record.setId(getFormFieldValueEncode(req, res, "id"));
    record.setModifiedat(getFormFieldValueEncode(req, res, "modified_at"));
    record.setAuthfailtpin(getFormFieldValueEncode(req, res, "auth_fail_tpin"));
    record.setValacc(getFormFieldValueEncode(req, res, "val_acc"));
    record.setMadeat(getFormFieldValueEncode(req, res, "made_at"));
    record.setCheckedat(getFormFieldValueEncode(req, res, "checked_at"));
    record.setAllowedphoneid1(getFormFieldValueEncode(req, res, "allowed_phone_id1"));
    record.setAllowedphoneid2(getFormFieldValueEncode(req, res, "allowed_phone_id2"));
    record.setCreatedby(getFormFieldValueEncode(req, res, "created_by"));
    record.setRstatus(getFormFieldValueEncode(req, res, "rstatus"));
    record.setPinno(getFormFieldValueEncode(req, res, "pin_no"));
    record.setNationality(getFormFieldValueEncode(req, res, "nationality"));
    record.setAdminlastcmt(getFormFieldValueEncode(req, res, "admin_last_cmt"));
    record.setAllowedphoneid3(getFormFieldValueEncode(req, res, "allowed_phone_id3"));
    record.setCheckerlastcmt(getFormFieldValueEncode(req, res, "checker_last_cmt"));
    record.setNationalid(getFormFieldValueEncode(req, res, "national_id"));
    record.setCif(getFormFieldValueEncode(req, res, "cif"));
    record.setCname(getFormFieldValueEncode(req, res, "cname"));
    record.setCreatedat(getFormFieldValueEncode(req, res, "created_at"));
    record.setAuthfailpin(getFormFieldValueEncode(req, res, "auth_fail_pin"));
    record.setEmail(getFormFieldValueEncode(req, res, "email"));
    record.setReportfreq(getFormFieldValueEncode(req, res, "report_freq"));
    record.setStatusname(getFormFieldValueEncode(req, res, "status_name"));
    record.setMobile(getFormFieldValueEncode(req, res, "mobile"));
    record.setAllowedphonetype3(getFormFieldValueEncode(req, res, "allowed_phone_type3"));
    record.setIdsubmitted(getFormFieldValueEncode(req, res, "id_submitted"));
    record.setAllowedphonetype2(getFormFieldValueEncode(req, res, "allowed_phone_type2"));
    record.setIdverified(getFormFieldValueEncode(req, res, "id_verified"));
    record.setCustcat(getFormFieldValueEncode(req, res, "cust_cat"));
    record.setCustextn4(getFormFieldValueEncode(req, res, "cust_extn4"));
    record.setCustextn3(getFormFieldValueEncode(req, res, "cust_extn3"));
    record.setCurrappstatus(getFormFieldValueEncode(req, res, "curr_app_status"));
    record.setCustextn2(getFormFieldValueEncode(req, res, "cust_extn2"));
    record.setCustextn1(getFormFieldValueEncode(req, res, "cust_extn1"));
    record.setTpinno(getFormFieldValueEncode(req, res, "tpin_no"));
    record.setAllowedphonetype1(getFormFieldValueEncode(req, res, "allowed_phone_type1"));
    record.setCurrappstatusname(getFormFieldValueEncode(req, res, "curr_app_status_name"));
    record.setModifiedby(getFormFieldValueEncode(req, res, "modified_by"));
    record.setMadeby(getFormFieldValueEncode(req, res, "made_by"));
    record.setCategory(getFormFieldValueEncode(req, res, "category"));
    record.setUgissued(getFormFieldValueEncode(req, res, "ug_issued"));
    logger.trace("loadJSONFormKBCustomerviewRecordEncode	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBCustomerviewRecord loadMapKBCustomerviewRecord(HashMap inputMap) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadMapKBCustomerviewRecord", null);
    KBCustomerviewRecord record = new KBCustomerviewRecord();
    record.setCheckedby(getMapValue(inputMap,"checked_by"));
    record.setTermssigned(getMapValue(inputMap,"terms_signed"));
    record.setMakerlastcmt(getMapValue(inputMap,"maker_last_cmt"));
    record.setPreflang(getMapValue(inputMap,"pref_lang"));
    record.setInstitutionid(getMapValue(inputMap,"institution_id"));
    record.setIname(getMapValue(inputMap,"iname"));
    record.setBlockedflag(getMapValue(inputMap,"blocked_flag"));
    record.setPassport(getMapValue(inputMap,"passport"));
    record.setId(getMapValue(inputMap,"id"));
    record.setModifiedat(getMapValue(inputMap,"modified_at"));
    record.setAuthfailtpin(getMapValue(inputMap,"auth_fail_tpin"));
    record.setValacc(getMapValue(inputMap,"val_acc"));
    record.setMadeat(getMapValue(inputMap,"made_at"));
    record.setCheckedat(getMapValue(inputMap,"checked_at"));
    record.setAllowedphoneid1(getMapValue(inputMap,"allowed_phone_id1"));
    record.setAllowedphoneid2(getMapValue(inputMap,"allowed_phone_id2"));
    record.setCreatedby(getMapValue(inputMap,"created_by"));
    record.setRstatus(getMapValue(inputMap,"rstatus"));
    record.setPinno(getMapValue(inputMap,"pin_no"));
    record.setNationality(getMapValue(inputMap,"nationality"));
    record.setAdminlastcmt(getMapValue(inputMap,"admin_last_cmt"));
    record.setAllowedphoneid3(getMapValue(inputMap,"allowed_phone_id3"));
    record.setCheckerlastcmt(getMapValue(inputMap,"checker_last_cmt"));
    record.setNationalid(getMapValue(inputMap,"national_id"));
    record.setCif(getMapValue(inputMap,"cif"));
    record.setCname(getMapValue(inputMap,"cname"));
    record.setCreatedat(getMapValue(inputMap,"created_at"));
    record.setAuthfailpin(getMapValue(inputMap,"auth_fail_pin"));
    record.setEmail(getMapValue(inputMap,"email"));
    record.setReportfreq(getMapValue(inputMap,"report_freq"));
    record.setStatusname(getMapValue(inputMap,"status_name"));
    record.setMobile(getMapValue(inputMap,"mobile"));
    record.setAllowedphonetype3(getMapValue(inputMap,"allowed_phone_type3"));
    record.setIdsubmitted(getMapValue(inputMap,"id_submitted"));
    record.setAllowedphonetype2(getMapValue(inputMap,"allowed_phone_type2"));
    record.setIdverified(getMapValue(inputMap,"id_verified"));
    record.setCustcat(getMapValue(inputMap,"cust_cat"));
    record.setCustextn4(getMapValue(inputMap,"cust_extn4"));
    record.setCustextn3(getMapValue(inputMap,"cust_extn3"));
    record.setCurrappstatus(getMapValue(inputMap,"curr_app_status"));
    record.setCustextn2(getMapValue(inputMap,"cust_extn2"));
    record.setCustextn1(getMapValue(inputMap,"cust_extn1"));
    record.setTpinno(getMapValue(inputMap,"tpin_no"));
    record.setAllowedphonetype1(getMapValue(inputMap,"allowed_phone_type1"));
    record.setCurrappstatusname(getMapValue(inputMap,"curr_app_status_name"));
    record.setModifiedby(getMapValue(inputMap,"modified_by"));
    record.setMadeby(getMapValue(inputMap,"made_by"));
    record.setCategory(getMapValue(inputMap,"category"));
    record.setUgissued(getMapValue(inputMap,"ug_issued"));
    logger.trace("loadMapKBCustomerviewRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public void processInsertKBCustomerviewRecord(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processInsertKBCustomerviewRecord", null);
    KBCustomerviewService service = new KBCustomerviewService();
    try {
      KBCustomerviewRecord record = loadFormKBCustomerviewRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      int resultId = service.insertKBCustomerviewRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~" + resultId);
      logger.generateFunctionEndTimerMessage(beginMesssage);
       res.sendRedirect("KBCustomerviewController.jsp");
    }
    catch(Exception e) {
      setActionMessageLn(req, res, "AdminActionMessage", "FailedtoCreate~~KBCustomerviewRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBCustomerviewController.jsp");
    }
  }

  public void processUpdateKBCustomerviewRecord(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processUpdateKBCustomerviewRecord", null);
    KBCustomerviewService service = new KBCustomerviewService();
    try {
      KBCustomerviewRecord record = loadFormKBCustomerviewRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.updateKBCustomerviewRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBCustomerviewController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBCustomerviewRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBCustomerviewController.jsp");
    }
  }

  public void processDeleteKBCustomerviewRecord(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processDeleteKBCustomerviewRecord", null);
    KBCustomerviewService service = new KBCustomerviewService();
    try {
      KBCustomerviewRecord record = loadFormKBCustomerviewRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.deleteKBCustomerviewRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBCustomerviewController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBCustomerviewRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBCustomerviewController.jsp");
    }
  }

  public void processWebRequest(HttpServletRequest req, HttpServletResponse res, String actionType)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processWebRequest", null);
     logger.trace("Action Type:" + actionType + "");
    if (actionType.equals("InsertCustomerviewRecord")) {
      processInsertKBCustomerviewRecord(req, res);
    }
    if (actionType.equals("UpdateCustomerviewRecord")) {
      processUpdateKBCustomerviewRecord(req, res);
    }
    if (actionType.equals("DeleteCustomerviewRecord")) {
      processDeleteKBCustomerviewRecord(req, res);
    }
    logger.generateFunctionEndTimerMessage(beginMesssage);
  }
}
