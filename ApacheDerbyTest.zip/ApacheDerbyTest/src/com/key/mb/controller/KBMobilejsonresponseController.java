package com.key.mb.controller;

import com.key.mb.common.KBController;
import com.key.mb.service.KBMobilejsonresponseService;
import com.key.mb.to.KBMobilejsonresponseRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class KBMobilejsonresponseController extends KBController {
  public static LogUtils logger = new LogUtils(KBMobilejsonresponseController.class.getName());

  public KBMobilejsonresponseRecord loadFormKBMobilejsonresponseRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadFormKBMobilejsonresponseRecord", null);
    KBMobilejsonresponseRecord record = new KBMobilejsonresponseRecord();
    record.setRstatus(getFormFieldValue(req, res, "tfRstatus"));
    record.setControllist(getFormFieldValue(req, res, "tfControllist"));
    record.setModifiedby(getFormFieldValue(req, res, "tfModifiedby"));
    record.setCreatedat(getFormFieldValue(req, res, "tfCreatedat"));
    record.setId(getFormFieldValue(req, res, "tfId"));
    record.setSessionid(getFormFieldValue(req, res, "tfSessionid"));
    record.setModifiedat(getFormFieldValue(req, res, "tfModifiedat"));
    record.setCreatedby(getFormFieldValue(req, res, "tfCreatedby"));
    record.setRequestid(getFormFieldValue(req, res, "tfRequestid"));
    record.setDirection(getFormFieldValue(req, res, "tfDirection"));
    logger.trace("loadFormKBMobilejsonresponseRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBMobilejsonresponseRecord loadJSONFormKBMobilejsonresponseRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBMobilejsonresponseRecord", null);
    KBMobilejsonresponseRecord record = new KBMobilejsonresponseRecord();
    record.setRstatus(getFormFieldValue(req, res, "rstatus"));
    record.setControllist(getFormFieldValue(req, res, "controllist"));
    record.setModifiedby(getFormFieldValue(req, res, "modified_by"));
    record.setCreatedat(getFormFieldValue(req, res, "created_at"));
    record.setId(getFormFieldValue(req, res, "id"));
    record.setSessionid(getFormFieldValue(req, res, "sessionid"));
    record.setModifiedat(getFormFieldValue(req, res, "modified_at"));
    record.setCreatedby(getFormFieldValue(req, res, "created_by"));
    record.setRequestid(getFormFieldValue(req, res, "request_id"));
    record.setDirection(getFormFieldValue(req, res, "direction"));
    logger.trace("loadJSONFormKBMobilejsonresponseRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBMobilejsonresponseRecord loadJSONFormKBMobilejsonresponseRecordEncode(
      HttpServletRequest req, HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBMobilejsonresponseRecordEncode", null);
    KBMobilejsonresponseRecord record = new KBMobilejsonresponseRecord();
    record.setRstatus(getFormFieldValueEncode(req, res, "rstatus"));
    record.setControllist(getFormFieldValueEncode(req, res, "controllist"));
    record.setModifiedby(getFormFieldValueEncode(req, res, "modified_by"));
    record.setCreatedat(getFormFieldValueEncode(req, res, "created_at"));
    record.setId(getFormFieldValueEncode(req, res, "id"));
    record.setSessionid(getFormFieldValueEncode(req, res, "sessionid"));
    record.setModifiedat(getFormFieldValueEncode(req, res, "modified_at"));
    record.setCreatedby(getFormFieldValueEncode(req, res, "created_by"));
    record.setRequestid(getFormFieldValueEncode(req, res, "request_id"));
    record.setDirection(getFormFieldValueEncode(req, res, "direction"));
    logger.trace("loadJSONFormKBMobilejsonresponseRecordEncode	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBMobilejsonresponseRecord loadMapKBMobilejsonresponseRecord(HashMap inputMap) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadMapKBMobilejsonresponseRecord", null);
    KBMobilejsonresponseRecord record = new KBMobilejsonresponseRecord();
    record.setRstatus(getMapValue(inputMap,"rstatus"));
    record.setControllist(getMapValue(inputMap,"controllist"));
    record.setModifiedby(getMapValue(inputMap,"modified_by"));
    record.setCreatedat(getMapValue(inputMap,"created_at"));
    record.setId(getMapValue(inputMap,"id"));
    record.setSessionid(getMapValue(inputMap,"sessionid"));
    record.setModifiedat(getMapValue(inputMap,"modified_at"));
    record.setCreatedby(getMapValue(inputMap,"created_by"));
    record.setRequestid(getMapValue(inputMap,"request_id"));
    record.setDirection(getMapValue(inputMap,"direction"));
    logger.trace("loadMapKBMobilejsonresponseRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public void processInsertKBMobilejsonresponseRecord(HttpServletRequest req,
      HttpServletResponse res) throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processInsertKBMobilejsonresponseRecord", null);
    KBMobilejsonresponseService service = new KBMobilejsonresponseService();
    try {
      KBMobilejsonresponseRecord record = loadFormKBMobilejsonresponseRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      int resultId = service.insertKBMobilejsonresponseRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~" + resultId);
      logger.generateFunctionEndTimerMessage(beginMesssage);
       res.sendRedirect("KBMobilejsonresponseController.jsp");
    }
    catch(Exception e) {
      setActionMessageLn(req, res, "AdminActionMessage", "FailedtoCreate~~KBMobilejsonresponseRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilejsonresponseController.jsp");
    }
  }

  public void processUpdateKBMobilejsonresponseRecord(HttpServletRequest req,
      HttpServletResponse res) throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processUpdateKBMobilejsonresponseRecord", null);
    KBMobilejsonresponseService service = new KBMobilejsonresponseService();
    try {
      KBMobilejsonresponseRecord record = loadFormKBMobilejsonresponseRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.updateKBMobilejsonresponseRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilejsonresponseController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBMobilejsonresponseRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilejsonresponseController.jsp");
    }
  }

  public void processDeleteKBMobilejsonresponseRecord(HttpServletRequest req,
      HttpServletResponse res) throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processDeleteKBMobilejsonresponseRecord", null);
    KBMobilejsonresponseService service = new KBMobilejsonresponseService();
    try {
      KBMobilejsonresponseRecord record = loadFormKBMobilejsonresponseRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.deleteKBMobilejsonresponseRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilejsonresponseController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBMobilejsonresponseRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilejsonresponseController.jsp");
    }
  }

  public void processWebRequest(HttpServletRequest req, HttpServletResponse res, String actionType)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processWebRequest", null);
     logger.trace("Action Type:" + actionType + "");
    if (actionType.equals("InsertMobilejsonresponseRecord")) {
      processInsertKBMobilejsonresponseRecord(req, res);
    }
    if (actionType.equals("UpdateMobilejsonresponseRecord")) {
      processUpdateKBMobilejsonresponseRecord(req, res);
    }
    if (actionType.equals("DeleteMobilejsonresponseRecord")) {
      processDeleteKBMobilejsonresponseRecord(req, res);
    }
    logger.generateFunctionEndTimerMessage(beginMesssage);
  }
}
