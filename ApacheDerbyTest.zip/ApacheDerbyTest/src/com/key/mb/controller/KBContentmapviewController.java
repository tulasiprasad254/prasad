package com.key.mb.controller;

import com.key.mb.common.KBController;
import com.key.mb.service.KBContentmapviewService;
import com.key.mb.to.KBContentmapviewRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class KBContentmapviewController extends KBController {
  public static LogUtils logger = new LogUtils(KBContentmapviewController.class.getName());

  public KBContentmapviewRecord loadFormKBContentmapviewRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadFormKBContentmapviewRecord", null);
    KBContentmapviewRecord record = new KBContentmapviewRecord();
    record.setStatusname(getFormFieldValue(req, res, "tfStatusname"));
    record.setCreatedat(getFormFieldValue(req, res, "tfCreatedat"));
    record.setCreatedby(getFormFieldValue(req, res, "tfCreatedby"));
    record.setInstitutionid(getFormFieldValue(req, res, "tfInstitutionid"));
    record.setIname(getFormFieldValue(req, res, "tfIname"));
    record.setRstatus(getFormFieldValue(req, res, "tfRstatus"));
    record.setCcode(getFormFieldValue(req, res, "tfCcode"));
    record.setCvalue(getFormFieldValue(req, res, "tfCvalue"));
    record.setCseq(getFormFieldValue(req, res, "tfCseq"));
    record.setCtype(getFormFieldValue(req, res, "tfCtype"));
    record.setCcatg(getFormFieldValue(req, res, "tfCcatg"));
    record.setModifiedby(getFormFieldValue(req, res, "tfModifiedby"));
    record.setId(getFormFieldValue(req, res, "tfId"));
    record.setModifiedat(getFormFieldValue(req, res, "tfModifiedat"));
    logger.trace("loadFormKBContentmapviewRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBContentmapviewRecord loadJSONFormKBContentmapviewRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBContentmapviewRecord", null);
    KBContentmapviewRecord record = new KBContentmapviewRecord();
    record.setStatusname(getFormFieldValue(req, res, "status_name"));
    record.setCreatedat(getFormFieldValue(req, res, "created_at"));
    record.setCreatedby(getFormFieldValue(req, res, "created_by"));
    record.setInstitutionid(getFormFieldValue(req, res, "institution_id"));
    record.setIname(getFormFieldValue(req, res, "iname"));
    record.setRstatus(getFormFieldValue(req, res, "rstatus"));
    record.setCcode(getFormFieldValue(req, res, "ccode"));
    record.setCvalue(getFormFieldValue(req, res, "cvalue"));
    record.setCseq(getFormFieldValue(req, res, "cseq"));
    record.setCtype(getFormFieldValue(req, res, "ctype"));
    record.setCcatg(getFormFieldValue(req, res, "ccatg"));
    record.setModifiedby(getFormFieldValue(req, res, "modified_by"));
    record.setId(getFormFieldValue(req, res, "id"));
    record.setModifiedat(getFormFieldValue(req, res, "modified_at"));
    logger.trace("loadJSONFormKBContentmapviewRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBContentmapviewRecord loadJSONFormKBContentmapviewRecordEncode(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBContentmapviewRecordEncode", null);
    KBContentmapviewRecord record = new KBContentmapviewRecord();
    record.setStatusname(getFormFieldValueEncode(req, res, "status_name"));
    record.setCreatedat(getFormFieldValueEncode(req, res, "created_at"));
    record.setCreatedby(getFormFieldValueEncode(req, res, "created_by"));
    record.setInstitutionid(getFormFieldValueEncode(req, res, "institution_id"));
    record.setIname(getFormFieldValueEncode(req, res, "iname"));
    record.setRstatus(getFormFieldValueEncode(req, res, "rstatus"));
    record.setCcode(getFormFieldValueEncode(req, res, "ccode"));
    record.setCvalue(getFormFieldValueEncode(req, res, "cvalue"));
    record.setCseq(getFormFieldValueEncode(req, res, "cseq"));
    record.setCtype(getFormFieldValueEncode(req, res, "ctype"));
    record.setCcatg(getFormFieldValueEncode(req, res, "ccatg"));
    record.setModifiedby(getFormFieldValueEncode(req, res, "modified_by"));
    record.setId(getFormFieldValueEncode(req, res, "id"));
    record.setModifiedat(getFormFieldValueEncode(req, res, "modified_at"));
    logger.trace("loadJSONFormKBContentmapviewRecordEncode	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBContentmapviewRecord loadMapKBContentmapviewRecord(HashMap inputMap) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadMapKBContentmapviewRecord", null);
    KBContentmapviewRecord record = new KBContentmapviewRecord();
    record.setStatusname(getMapValue(inputMap,"status_name"));
    record.setCreatedat(getMapValue(inputMap,"created_at"));
    record.setCreatedby(getMapValue(inputMap,"created_by"));
    record.setInstitutionid(getMapValue(inputMap,"institution_id"));
    record.setIname(getMapValue(inputMap,"iname"));
    record.setRstatus(getMapValue(inputMap,"rstatus"));
    record.setCcode(getMapValue(inputMap,"ccode"));
    record.setCvalue(getMapValue(inputMap,"cvalue"));
    record.setCseq(getMapValue(inputMap,"cseq"));
    record.setCtype(getMapValue(inputMap,"ctype"));
    record.setCcatg(getMapValue(inputMap,"ccatg"));
    record.setModifiedby(getMapValue(inputMap,"modified_by"));
    record.setId(getMapValue(inputMap,"id"));
    record.setModifiedat(getMapValue(inputMap,"modified_at"));
    logger.trace("loadMapKBContentmapviewRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public void processInsertKBContentmapviewRecord(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processInsertKBContentmapviewRecord", null);
    KBContentmapviewService service = new KBContentmapviewService();
    try {
      KBContentmapviewRecord record = loadFormKBContentmapviewRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      int resultId = service.insertKBContentmapviewRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~" + resultId);
      logger.generateFunctionEndTimerMessage(beginMesssage);
       res.sendRedirect("KBContentmapviewController.jsp");
    }
    catch(Exception e) {
      setActionMessageLn(req, res, "AdminActionMessage", "FailedtoCreate~~KBContentmapviewRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBContentmapviewController.jsp");
    }
  }

  public void processUpdateKBContentmapviewRecord(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processUpdateKBContentmapviewRecord", null);
    KBContentmapviewService service = new KBContentmapviewService();
    try {
      KBContentmapviewRecord record = loadFormKBContentmapviewRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.updateKBContentmapviewRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBContentmapviewController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBContentmapviewRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBContentmapviewController.jsp");
    }
  }

  public void processDeleteKBContentmapviewRecord(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processDeleteKBContentmapviewRecord", null);
    KBContentmapviewService service = new KBContentmapviewService();
    try {
      KBContentmapviewRecord record = loadFormKBContentmapviewRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.deleteKBContentmapviewRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBContentmapviewController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBContentmapviewRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBContentmapviewController.jsp");
    }
  }

  public void processWebRequest(HttpServletRequest req, HttpServletResponse res, String actionType)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processWebRequest", null);
     logger.trace("Action Type:" + actionType + "");
    if (actionType.equals("InsertContentmapviewRecord")) {
      processInsertKBContentmapviewRecord(req, res);
    }
    if (actionType.equals("UpdateContentmapviewRecord")) {
      processUpdateKBContentmapviewRecord(req, res);
    }
    if (actionType.equals("DeleteContentmapviewRecord")) {
      processDeleteKBContentmapviewRecord(req, res);
    }
    logger.generateFunctionEndTimerMessage(beginMesssage);
  }
}
