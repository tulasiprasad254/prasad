package com.key.mb.controller;

import com.key.mb.common.KBController;
import com.key.mb.service.KBMobilejsonrequestService;
import com.key.mb.to.KBMobilejsonrequestRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class KBMobilejsonrequestController extends KBController {
  public static LogUtils logger = new LogUtils(KBMobilejsonrequestController.class.getName());

  public KBMobilejsonrequestRecord loadFormKBMobilejsonrequestRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadFormKBMobilejsonrequestRecord", null);
    KBMobilejsonrequestRecord record = new KBMobilejsonrequestRecord();
    record.setRstatus(getFormFieldValue(req, res, "tfRstatus"));
    record.setLangcode(getFormFieldValue(req, res, "tfLangcode"));
    record.setModifiedby(getFormFieldValue(req, res, "tfModifiedby"));
    record.setActionid(getFormFieldValue(req, res, "tfActionid"));
    record.setRdata(getFormFieldValue(req, res, "tfRdata"));
    record.setCreatedat(getFormFieldValue(req, res, "tfCreatedat"));
    record.setId(getFormFieldValue(req, res, "tfId"));
    record.setSessionid(getFormFieldValue(req, res, "tfSessionid"));
    record.setModifiedat(getFormFieldValue(req, res, "tfModifiedat"));
    record.setCreatedby(getFormFieldValue(req, res, "tfCreatedby"));
    logger.trace("loadFormKBMobilejsonrequestRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBMobilejsonrequestRecord loadJSONFormKBMobilejsonrequestRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBMobilejsonrequestRecord", null);
    KBMobilejsonrequestRecord record = new KBMobilejsonrequestRecord();
    record.setRstatus(getFormFieldValue(req, res, "rstatus"));
    record.setLangcode(getFormFieldValue(req, res, "langcode"));
    record.setModifiedby(getFormFieldValue(req, res, "modified_by"));
    record.setActionid(getFormFieldValue(req, res, "actionid"));
    record.setRdata(getFormFieldValue(req, res, "rdata"));
    record.setCreatedat(getFormFieldValue(req, res, "created_at"));
    record.setId(getFormFieldValue(req, res, "id"));
    record.setSessionid(getFormFieldValue(req, res, "sessionid"));
    record.setModifiedat(getFormFieldValue(req, res, "modified_at"));
    record.setCreatedby(getFormFieldValue(req, res, "created_by"));
    logger.trace("loadJSONFormKBMobilejsonrequestRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBMobilejsonrequestRecord loadJSONFormKBMobilejsonrequestRecordEncode(
      HttpServletRequest req, HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBMobilejsonrequestRecordEncode", null);
    KBMobilejsonrequestRecord record = new KBMobilejsonrequestRecord();
    record.setRstatus(getFormFieldValueEncode(req, res, "rstatus"));
    record.setLangcode(getFormFieldValueEncode(req, res, "langcode"));
    record.setModifiedby(getFormFieldValueEncode(req, res, "modified_by"));
    record.setActionid(getFormFieldValueEncode(req, res, "actionid"));
    record.setRdata(getFormFieldValueEncode(req, res, "rdata"));
    record.setCreatedat(getFormFieldValueEncode(req, res, "created_at"));
    record.setId(getFormFieldValueEncode(req, res, "id"));
    record.setSessionid(getFormFieldValueEncode(req, res, "sessionid"));
    record.setModifiedat(getFormFieldValueEncode(req, res, "modified_at"));
    record.setCreatedby(getFormFieldValueEncode(req, res, "created_by"));
    logger.trace("loadJSONFormKBMobilejsonrequestRecordEncode	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBMobilejsonrequestRecord loadMapKBMobilejsonrequestRecord(HashMap inputMap) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadMapKBMobilejsonrequestRecord", null);
    KBMobilejsonrequestRecord record = new KBMobilejsonrequestRecord();
    record.setRstatus(getMapValue(inputMap,"rstatus"));
    record.setLangcode(getMapValue(inputMap,"langcode"));
    record.setModifiedby(getMapValue(inputMap,"modified_by"));
    record.setActionid(getMapValue(inputMap,"actionid"));
    record.setRdata(getMapValue(inputMap,"rdata"));
    record.setCreatedat(getMapValue(inputMap,"created_at"));
    record.setId(getMapValue(inputMap,"id"));
    record.setSessionid(getMapValue(inputMap,"sessionid"));
    record.setModifiedat(getMapValue(inputMap,"modified_at"));
    record.setCreatedby(getMapValue(inputMap,"created_by"));
    logger.trace("loadMapKBMobilejsonrequestRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public void processInsertKBMobilejsonrequestRecord(HttpServletRequest req,
      HttpServletResponse res) throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processInsertKBMobilejsonrequestRecord", null);
    KBMobilejsonrequestService service = new KBMobilejsonrequestService();
    try {
      KBMobilejsonrequestRecord record = loadFormKBMobilejsonrequestRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      int resultId = service.insertKBMobilejsonrequestRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~" + resultId);
      logger.generateFunctionEndTimerMessage(beginMesssage);
       res.sendRedirect("KBMobilejsonrequestController.jsp");
    }
    catch(Exception e) {
      setActionMessageLn(req, res, "AdminActionMessage", "FailedtoCreate~~KBMobilejsonrequestRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilejsonrequestController.jsp");
    }
  }

  public void processUpdateKBMobilejsonrequestRecord(HttpServletRequest req,
      HttpServletResponse res) throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processUpdateKBMobilejsonrequestRecord", null);
    KBMobilejsonrequestService service = new KBMobilejsonrequestService();
    try {
      KBMobilejsonrequestRecord record = loadFormKBMobilejsonrequestRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.updateKBMobilejsonrequestRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilejsonrequestController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBMobilejsonrequestRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilejsonrequestController.jsp");
    }
  }

  public void processDeleteKBMobilejsonrequestRecord(HttpServletRequest req,
      HttpServletResponse res) throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processDeleteKBMobilejsonrequestRecord", null);
    KBMobilejsonrequestService service = new KBMobilejsonrequestService();
    try {
      KBMobilejsonrequestRecord record = loadFormKBMobilejsonrequestRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.deleteKBMobilejsonrequestRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilejsonrequestController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBMobilejsonrequestRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilejsonrequestController.jsp");
    }
  }

  public void processWebRequest(HttpServletRequest req, HttpServletResponse res, String actionType)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processWebRequest", null);
     logger.trace("Action Type:" + actionType + "");
    if (actionType.equals("InsertMobilejsonrequestRecord")) {
      processInsertKBMobilejsonrequestRecord(req, res);
    }
    if (actionType.equals("UpdateMobilejsonrequestRecord")) {
      processUpdateKBMobilejsonrequestRecord(req, res);
    }
    if (actionType.equals("DeleteMobilejsonrequestRecord")) {
      processDeleteKBMobilejsonrequestRecord(req, res);
    }
    logger.generateFunctionEndTimerMessage(beginMesssage);
  }
}
