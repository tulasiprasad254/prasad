package com.key.mb.controller;

import com.key.mb.common.KBController;
import com.key.mb.service.KBMobilemenumapviewService;
import com.key.mb.to.KBMobilemenumapviewRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class KBMobilemenumapviewController extends KBController {
  public static LogUtils logger = new LogUtils(KBMobilemenumapviewController.class.getName());

  public KBMobilemenumapviewRecord loadFormKBMobilemenumapviewRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadFormKBMobilemenumapviewRecord", null);
    KBMobilemenumapviewRecord record = new KBMobilemenumapviewRecord();
    record.setFtext(getFormFieldValue(req, res, "tfFtext"));
    record.setFfldtype(getFormFieldValue(req, res, "tfFfldtype"));
    record.setFseq(getFormFieldValue(req, res, "tfFseq"));
    record.setCreatedat(getFormFieldValue(req, res, "tfCreatedat"));
    record.setActiveflag(getFormFieldValue(req, res, "tfActiveflag"));
    record.setFsesscont(getFormFieldValue(req, res, "tfFsesscont"));
    record.setFfldcode(getFormFieldValue(req, res, "tfFfldcode"));
    record.setLangcode(getFormFieldValue(req, res, "tfLangcode"));
    record.setActionid(getFormFieldValue(req, res, "tfActionid"));
    record.setServiceid(getFormFieldValue(req, res, "tfServiceid"));
    record.setId(getFormFieldValue(req, res, "tfId"));
    record.setNewsess(getFormFieldValue(req, res, "tfNewsess"));
    record.setModifiedat(getFormFieldValue(req, res, "tfModifiedat"));
    record.setContentlength(getFormFieldValue(req, res, "tfContentlength"));
    record.setMenutype(getFormFieldValue(req, res, "tfMenutype"));
    record.setStatusname(getFormFieldValue(req, res, "tfStatusname"));
    record.setOverridecode(getFormFieldValue(req, res, "tfOverridecode"));
    record.setFconttype(getFormFieldValue(req, res, "tfFconttype"));
    record.setFwidth(getFormFieldValue(req, res, "tfFwidth"));
    record.setCreatedby(getFormFieldValue(req, res, "tfCreatedby"));
    record.setRstatus(getFormFieldValue(req, res, "tfRstatus"));
    record.setParentid(getFormFieldValue(req, res, "tfParentid"));
    record.setFfldlen(getFormFieldValue(req, res, "tfFfldlen"));
    record.setModifiedby(getFormFieldValue(req, res, "tfModifiedby"));
    record.setFheight(getFormFieldValue(req, res, "tfFheight"));
    record.setScreenid(getFormFieldValue(req, res, "tfScreenid"));
    logger.trace("loadFormKBMobilemenumapviewRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBMobilemenumapviewRecord loadJSONFormKBMobilemenumapviewRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBMobilemenumapviewRecord", null);
    KBMobilemenumapviewRecord record = new KBMobilemenumapviewRecord();
    record.setFtext(getFormFieldValue(req, res, "ftext"));
    record.setFfldtype(getFormFieldValue(req, res, "ffldtype"));
    record.setFseq(getFormFieldValue(req, res, "fseq"));
    record.setCreatedat(getFormFieldValue(req, res, "created_at"));
    record.setActiveflag(getFormFieldValue(req, res, "active_flag"));
    record.setFsesscont(getFormFieldValue(req, res, "fsesscont"));
    record.setFfldcode(getFormFieldValue(req, res, "ffldcode"));
    record.setLangcode(getFormFieldValue(req, res, "langcode"));
    record.setActionid(getFormFieldValue(req, res, "action_id"));
    record.setServiceid(getFormFieldValue(req, res, "service_id"));
    record.setId(getFormFieldValue(req, res, "id"));
    record.setNewsess(getFormFieldValue(req, res, "newsess"));
    record.setModifiedat(getFormFieldValue(req, res, "modified_at"));
    record.setContentlength(getFormFieldValue(req, res, "content_length"));
    record.setMenutype(getFormFieldValue(req, res, "menu_type"));
    record.setStatusname(getFormFieldValue(req, res, "status_name"));
    record.setOverridecode(getFormFieldValue(req, res, "override_code"));
    record.setFconttype(getFormFieldValue(req, res, "fconttype"));
    record.setFwidth(getFormFieldValue(req, res, "fwidth"));
    record.setCreatedby(getFormFieldValue(req, res, "created_by"));
    record.setRstatus(getFormFieldValue(req, res, "rstatus"));
    record.setParentid(getFormFieldValue(req, res, "parent_id"));
    record.setFfldlen(getFormFieldValue(req, res, "ffldlen"));
    record.setModifiedby(getFormFieldValue(req, res, "modified_by"));
    record.setFheight(getFormFieldValue(req, res, "fheight"));
    record.setScreenid(getFormFieldValue(req, res, "screen_id"));
    logger.trace("loadJSONFormKBMobilemenumapviewRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBMobilemenumapviewRecord loadJSONFormKBMobilemenumapviewRecordEncode(
      HttpServletRequest req, HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBMobilemenumapviewRecordEncode", null);
    KBMobilemenumapviewRecord record = new KBMobilemenumapviewRecord();
    record.setFtext(getFormFieldValueEncode(req, res, "ftext"));
    record.setFfldtype(getFormFieldValueEncode(req, res, "ffldtype"));
    record.setFseq(getFormFieldValueEncode(req, res, "fseq"));
    record.setCreatedat(getFormFieldValueEncode(req, res, "created_at"));
    record.setActiveflag(getFormFieldValueEncode(req, res, "active_flag"));
    record.setFsesscont(getFormFieldValueEncode(req, res, "fsesscont"));
    record.setFfldcode(getFormFieldValueEncode(req, res, "ffldcode"));
    record.setLangcode(getFormFieldValueEncode(req, res, "langcode"));
    record.setActionid(getFormFieldValueEncode(req, res, "action_id"));
    record.setServiceid(getFormFieldValueEncode(req, res, "service_id"));
    record.setId(getFormFieldValueEncode(req, res, "id"));
    record.setNewsess(getFormFieldValueEncode(req, res, "newsess"));
    record.setModifiedat(getFormFieldValueEncode(req, res, "modified_at"));
    record.setContentlength(getFormFieldValueEncode(req, res, "content_length"));
    record.setMenutype(getFormFieldValueEncode(req, res, "menu_type"));
    record.setStatusname(getFormFieldValueEncode(req, res, "status_name"));
    record.setOverridecode(getFormFieldValueEncode(req, res, "override_code"));
    record.setFconttype(getFormFieldValueEncode(req, res, "fconttype"));
    record.setFwidth(getFormFieldValueEncode(req, res, "fwidth"));
    record.setCreatedby(getFormFieldValueEncode(req, res, "created_by"));
    record.setRstatus(getFormFieldValueEncode(req, res, "rstatus"));
    record.setParentid(getFormFieldValueEncode(req, res, "parent_id"));
    record.setFfldlen(getFormFieldValueEncode(req, res, "ffldlen"));
    record.setModifiedby(getFormFieldValueEncode(req, res, "modified_by"));
    record.setFheight(getFormFieldValueEncode(req, res, "fheight"));
    record.setScreenid(getFormFieldValueEncode(req, res, "screen_id"));
    logger.trace("loadJSONFormKBMobilemenumapviewRecordEncode	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBMobilemenumapviewRecord loadMapKBMobilemenumapviewRecord(HashMap inputMap) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadMapKBMobilemenumapviewRecord", null);
    KBMobilemenumapviewRecord record = new KBMobilemenumapviewRecord();
    record.setFtext(getMapValue(inputMap,"ftext"));
    record.setFfldtype(getMapValue(inputMap,"ffldtype"));
    record.setFseq(getMapValue(inputMap,"fseq"));
    record.setCreatedat(getMapValue(inputMap,"created_at"));
    record.setActiveflag(getMapValue(inputMap,"active_flag"));
    record.setFsesscont(getMapValue(inputMap,"fsesscont"));
    record.setFfldcode(getMapValue(inputMap,"ffldcode"));
    record.setLangcode(getMapValue(inputMap,"langcode"));
    record.setActionid(getMapValue(inputMap,"action_id"));
    record.setServiceid(getMapValue(inputMap,"service_id"));
    record.setId(getMapValue(inputMap,"id"));
    record.setNewsess(getMapValue(inputMap,"newsess"));
    record.setModifiedat(getMapValue(inputMap,"modified_at"));
    record.setContentlength(getMapValue(inputMap,"content_length"));
    record.setMenutype(getMapValue(inputMap,"menu_type"));
    record.setStatusname(getMapValue(inputMap,"status_name"));
    record.setOverridecode(getMapValue(inputMap,"override_code"));
    record.setFconttype(getMapValue(inputMap,"fconttype"));
    record.setFwidth(getMapValue(inputMap,"fwidth"));
    record.setCreatedby(getMapValue(inputMap,"created_by"));
    record.setRstatus(getMapValue(inputMap,"rstatus"));
    record.setParentid(getMapValue(inputMap,"parent_id"));
    record.setFfldlen(getMapValue(inputMap,"ffldlen"));
    record.setModifiedby(getMapValue(inputMap,"modified_by"));
    record.setFheight(getMapValue(inputMap,"fheight"));
    record.setScreenid(getMapValue(inputMap,"screen_id"));
    logger.trace("loadMapKBMobilemenumapviewRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public void processInsertKBMobilemenumapviewRecord(HttpServletRequest req,
      HttpServletResponse res) throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processInsertKBMobilemenumapviewRecord", null);
    KBMobilemenumapviewService service = new KBMobilemenumapviewService();
    try {
      KBMobilemenumapviewRecord record = loadFormKBMobilemenumapviewRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      int resultId = service.insertKBMobilemenumapviewRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~" + resultId);
      logger.generateFunctionEndTimerMessage(beginMesssage);
       res.sendRedirect("KBMobilemenumapviewController.jsp");
    }
    catch(Exception e) {
      setActionMessageLn(req, res, "AdminActionMessage", "FailedtoCreate~~KBMobilemenumapviewRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilemenumapviewController.jsp");
    }
  }

  public void processUpdateKBMobilemenumapviewRecord(HttpServletRequest req,
      HttpServletResponse res) throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processUpdateKBMobilemenumapviewRecord", null);
    KBMobilemenumapviewService service = new KBMobilemenumapviewService();
    try {
      KBMobilemenumapviewRecord record = loadFormKBMobilemenumapviewRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.updateKBMobilemenumapviewRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilemenumapviewController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBMobilemenumapviewRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilemenumapviewController.jsp");
    }
  }

  public void processDeleteKBMobilemenumapviewRecord(HttpServletRequest req,
      HttpServletResponse res) throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processDeleteKBMobilemenumapviewRecord", null);
    KBMobilemenumapviewService service = new KBMobilemenumapviewService();
    try {
      KBMobilemenumapviewRecord record = loadFormKBMobilemenumapviewRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.deleteKBMobilemenumapviewRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilemenumapviewController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBMobilemenumapviewRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilemenumapviewController.jsp");
    }
  }

  public void processWebRequest(HttpServletRequest req, HttpServletResponse res, String actionType)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processWebRequest", null);
     logger.trace("Action Type:" + actionType + "");
    if (actionType.equals("InsertMobilemenumapviewRecord")) {
      processInsertKBMobilemenumapviewRecord(req, res);
    }
    if (actionType.equals("UpdateMobilemenumapviewRecord")) {
      processUpdateKBMobilemenumapviewRecord(req, res);
    }
    if (actionType.equals("DeleteMobilemenumapviewRecord")) {
      processDeleteKBMobilemenumapviewRecord(req, res);
    }
    logger.generateFunctionEndTimerMessage(beginMesssage);
  }
}
