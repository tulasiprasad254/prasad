package com.key.mb.controller;

import com.key.mb.common.KBController;
import com.key.mb.service.KBMobilemenumapService;
import com.key.mb.to.KBMobilemenumapRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class KBMobilemenumapController extends KBController {
  public static LogUtils logger = new LogUtils(KBMobilemenumapController.class.getName());

  public KBMobilemenumapRecord loadFormKBMobilemenumapRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadFormKBMobilemenumapRecord", null);
    KBMobilemenumapRecord record = new KBMobilemenumapRecord();
    record.setFtext(getFormFieldValue(req, res, "tfFtext"));
    record.setFfldtype(getFormFieldValue(req, res, "tfFfldtype"));
    record.setAccesscode(getFormFieldValue(req, res, "tfAccesscode"));
    record.setLang2msg(getFormFieldValue(req, res, "tfLang2msg"));
    record.setFseq(getFormFieldValue(req, res, "tfFseq"));
    record.setCreatedat(getFormFieldValue(req, res, "tfCreatedat"));
    record.setActiveflag(getFormFieldValue(req, res, "tfActiveflag"));
    record.setFsesscont(getFormFieldValue(req, res, "tfFsesscont"));
    record.setFfldcode(getFormFieldValue(req, res, "tfFfldcode"));
    record.setLangcode(getFormFieldValue(req, res, "tfLangcode"));
    record.setActionid(getFormFieldValue(req, res, "tfActionid"));
    record.setServiceid(getFormFieldValue(req, res, "tfServiceid"));
    record.setUssd(getFormFieldValue(req, res, "tfUssd"));
    record.setId(getFormFieldValue(req, res, "tfId"));
    record.setNewsess(getFormFieldValue(req, res, "tfNewsess"));
    record.setLang3msg(getFormFieldValue(req, res, "tfLang3msg"));
    record.setModifiedat(getFormFieldValue(req, res, "tfModifiedat"));
    record.setContentlength(getFormFieldValue(req, res, "tfContentlength"));
    record.setExtn4(getFormFieldValue(req, res, "tfExtn4"));
    record.setExtn3(getFormFieldValue(req, res, "tfExtn3"));
    record.setExtn2(getFormFieldValue(req, res, "tfExtn2"));
    record.setLang4msg(getFormFieldValue(req, res, "tfLang4msg"));
    record.setExtn1(getFormFieldValue(req, res, "tfExtn1"));
    record.setMenutype(getFormFieldValue(req, res, "tfMenutype"));
    record.setOverridecode(getFormFieldValue(req, res, "tfOverridecode"));
    record.setWap(getFormFieldValue(req, res, "tfWap"));
    record.setFconttype(getFormFieldValue(req, res, "tfFconttype"));
    record.setFwidth(getFormFieldValue(req, res, "tfFwidth"));
    record.setCreatedby(getFormFieldValue(req, res, "tfCreatedby"));
    record.setRstatus(getFormFieldValue(req, res, "tfRstatus"));
    record.setParentid(getFormFieldValue(req, res, "tfParentid"));
    record.setFfldlen(getFormFieldValue(req, res, "tfFfldlen"));
    record.setModifiedby(getFormFieldValue(req, res, "tfModifiedby"));
    record.setFheight(getFormFieldValue(req, res, "tfFheight"));
    record.setScreenid(getFormFieldValue(req, res, "tfScreenid"));
    logger.trace("loadFormKBMobilemenumapRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBMobilemenumapRecord loadJSONFormKBMobilemenumapRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBMobilemenumapRecord", null);
    KBMobilemenumapRecord record = new KBMobilemenumapRecord();
    record.setFtext(getFormFieldValue(req, res, "ftext"));
    record.setFfldtype(getFormFieldValue(req, res, "ffldtype"));
    record.setAccesscode(getFormFieldValue(req, res, "access_code"));
    record.setLang2msg(getFormFieldValue(req, res, "lang2_msg"));
    record.setFseq(getFormFieldValue(req, res, "fseq"));
    record.setCreatedat(getFormFieldValue(req, res, "created_at"));
    record.setActiveflag(getFormFieldValue(req, res, "active_flag"));
    record.setFsesscont(getFormFieldValue(req, res, "fsesscont"));
    record.setFfldcode(getFormFieldValue(req, res, "ffldcode"));
    record.setLangcode(getFormFieldValue(req, res, "langcode"));
    record.setActionid(getFormFieldValue(req, res, "action_id"));
    record.setServiceid(getFormFieldValue(req, res, "service_id"));
    record.setUssd(getFormFieldValue(req, res, "ussd"));
    record.setId(getFormFieldValue(req, res, "id"));
    record.setNewsess(getFormFieldValue(req, res, "newsess"));
    record.setLang3msg(getFormFieldValue(req, res, "lang3_msg"));
    record.setModifiedat(getFormFieldValue(req, res, "modified_at"));
    record.setContentlength(getFormFieldValue(req, res, "content_length"));
    record.setExtn4(getFormFieldValue(req, res, "extn4"));
    record.setExtn3(getFormFieldValue(req, res, "extn3"));
    record.setExtn2(getFormFieldValue(req, res, "extn2"));
    record.setLang4msg(getFormFieldValue(req, res, "lang4_msg"));
    record.setExtn1(getFormFieldValue(req, res, "extn1"));
    record.setMenutype(getFormFieldValue(req, res, "menu_type"));
    record.setOverridecode(getFormFieldValue(req, res, "override_code"));
    record.setWap(getFormFieldValue(req, res, "wap"));
    record.setFconttype(getFormFieldValue(req, res, "fconttype"));
    record.setFwidth(getFormFieldValue(req, res, "fwidth"));
    record.setCreatedby(getFormFieldValue(req, res, "created_by"));
    record.setRstatus(getFormFieldValue(req, res, "rstatus"));
    record.setParentid(getFormFieldValue(req, res, "parent_id"));
    record.setFfldlen(getFormFieldValue(req, res, "ffldlen"));
    record.setModifiedby(getFormFieldValue(req, res, "modified_by"));
    record.setFheight(getFormFieldValue(req, res, "fheight"));
    record.setScreenid(getFormFieldValue(req, res, "screen_id"));
    logger.trace("loadJSONFormKBMobilemenumapRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBMobilemenumapRecord loadJSONFormKBMobilemenumapRecordEncode(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBMobilemenumapRecordEncode", null);
    KBMobilemenumapRecord record = new KBMobilemenumapRecord();
    record.setFtext(getFormFieldValueEncode(req, res, "ftext"));
    record.setFfldtype(getFormFieldValueEncode(req, res, "ffldtype"));
    record.setAccesscode(getFormFieldValueEncode(req, res, "access_code"));
    record.setLang2msg(getFormFieldValueEncode(req, res, "lang2_msg"));
    record.setFseq(getFormFieldValueEncode(req, res, "fseq"));
    record.setCreatedat(getFormFieldValueEncode(req, res, "created_at"));
    record.setActiveflag(getFormFieldValueEncode(req, res, "active_flag"));
    record.setFsesscont(getFormFieldValueEncode(req, res, "fsesscont"));
    record.setFfldcode(getFormFieldValueEncode(req, res, "ffldcode"));
    record.setLangcode(getFormFieldValueEncode(req, res, "langcode"));
    record.setActionid(getFormFieldValueEncode(req, res, "action_id"));
    record.setServiceid(getFormFieldValueEncode(req, res, "service_id"));
    record.setUssd(getFormFieldValueEncode(req, res, "ussd"));
    record.setId(getFormFieldValueEncode(req, res, "id"));
    record.setNewsess(getFormFieldValueEncode(req, res, "newsess"));
    record.setLang3msg(getFormFieldValueEncode(req, res, "lang3_msg"));
    record.setModifiedat(getFormFieldValueEncode(req, res, "modified_at"));
    record.setContentlength(getFormFieldValueEncode(req, res, "content_length"));
    record.setExtn4(getFormFieldValueEncode(req, res, "extn4"));
    record.setExtn3(getFormFieldValueEncode(req, res, "extn3"));
    record.setExtn2(getFormFieldValueEncode(req, res, "extn2"));
    record.setLang4msg(getFormFieldValueEncode(req, res, "lang4_msg"));
    record.setExtn1(getFormFieldValueEncode(req, res, "extn1"));
    record.setMenutype(getFormFieldValueEncode(req, res, "menu_type"));
    record.setOverridecode(getFormFieldValueEncode(req, res, "override_code"));
    record.setWap(getFormFieldValueEncode(req, res, "wap"));
    record.setFconttype(getFormFieldValueEncode(req, res, "fconttype"));
    record.setFwidth(getFormFieldValueEncode(req, res, "fwidth"));
    record.setCreatedby(getFormFieldValueEncode(req, res, "created_by"));
    record.setRstatus(getFormFieldValueEncode(req, res, "rstatus"));
    record.setParentid(getFormFieldValueEncode(req, res, "parent_id"));
    record.setFfldlen(getFormFieldValueEncode(req, res, "ffldlen"));
    record.setModifiedby(getFormFieldValueEncode(req, res, "modified_by"));
    record.setFheight(getFormFieldValueEncode(req, res, "fheight"));
    record.setScreenid(getFormFieldValueEncode(req, res, "screen_id"));
    logger.trace("loadJSONFormKBMobilemenumapRecordEncode	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBMobilemenumapRecord loadMapKBMobilemenumapRecord(HashMap inputMap) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadMapKBMobilemenumapRecord", null);
    KBMobilemenumapRecord record = new KBMobilemenumapRecord();
    record.setFtext(getMapValue(inputMap,"ftext"));
    record.setFfldtype(getMapValue(inputMap,"ffldtype"));
    record.setAccesscode(getMapValue(inputMap,"access_code"));
    record.setLang2msg(getMapValue(inputMap,"lang2_msg"));
    record.setFseq(getMapValue(inputMap,"fseq"));
    record.setCreatedat(getMapValue(inputMap,"created_at"));
    record.setActiveflag(getMapValue(inputMap,"active_flag"));
    record.setFsesscont(getMapValue(inputMap,"fsesscont"));
    record.setFfldcode(getMapValue(inputMap,"ffldcode"));
    record.setLangcode(getMapValue(inputMap,"langcode"));
    record.setActionid(getMapValue(inputMap,"action_id"));
    record.setServiceid(getMapValue(inputMap,"service_id"));
    record.setUssd(getMapValue(inputMap,"ussd"));
    record.setId(getMapValue(inputMap,"id"));
    record.setNewsess(getMapValue(inputMap,"newsess"));
    record.setLang3msg(getMapValue(inputMap,"lang3_msg"));
    record.setModifiedat(getMapValue(inputMap,"modified_at"));
    record.setContentlength(getMapValue(inputMap,"content_length"));
    record.setExtn4(getMapValue(inputMap,"extn4"));
    record.setExtn3(getMapValue(inputMap,"extn3"));
    record.setExtn2(getMapValue(inputMap,"extn2"));
    record.setLang4msg(getMapValue(inputMap,"lang4_msg"));
    record.setExtn1(getMapValue(inputMap,"extn1"));
    record.setMenutype(getMapValue(inputMap,"menu_type"));
    record.setOverridecode(getMapValue(inputMap,"override_code"));
    record.setWap(getMapValue(inputMap,"wap"));
    record.setFconttype(getMapValue(inputMap,"fconttype"));
    record.setFwidth(getMapValue(inputMap,"fwidth"));
    record.setCreatedby(getMapValue(inputMap,"created_by"));
    record.setRstatus(getMapValue(inputMap,"rstatus"));
    record.setParentid(getMapValue(inputMap,"parent_id"));
    record.setFfldlen(getMapValue(inputMap,"ffldlen"));
    record.setModifiedby(getMapValue(inputMap,"modified_by"));
    record.setFheight(getMapValue(inputMap,"fheight"));
    record.setScreenid(getMapValue(inputMap,"screen_id"));
    logger.trace("loadMapKBMobilemenumapRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public void processInsertKBMobilemenumapRecord(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processInsertKBMobilemenumapRecord", null);
    KBMobilemenumapService service = new KBMobilemenumapService();
    try {
      KBMobilemenumapRecord record = loadFormKBMobilemenumapRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      int resultId = service.insertKBMobilemenumapRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~" + resultId);
      logger.generateFunctionEndTimerMessage(beginMesssage);
       res.sendRedirect("KBMobilemenumapController.jsp");
    }
    catch(Exception e) {
      setActionMessageLn(req, res, "AdminActionMessage", "FailedtoCreate~~KBMobilemenumapRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilemenumapController.jsp");
    }
  }

  public void processUpdateKBMobilemenumapRecord(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processUpdateKBMobilemenumapRecord", null);
    KBMobilemenumapService service = new KBMobilemenumapService();
    try {
      KBMobilemenumapRecord record = loadFormKBMobilemenumapRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.updateKBMobilemenumapRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilemenumapController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBMobilemenumapRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilemenumapController.jsp");
    }
  }

  public void processDeleteKBMobilemenumapRecord(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processDeleteKBMobilemenumapRecord", null);
    KBMobilemenumapService service = new KBMobilemenumapService();
    try {
      KBMobilemenumapRecord record = loadFormKBMobilemenumapRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.deleteKBMobilemenumapRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilemenumapController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBMobilemenumapRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilemenumapController.jsp");
    }
  }

  public void processWebRequest(HttpServletRequest req, HttpServletResponse res, String actionType)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processWebRequest", null);
     logger.trace("Action Type:" + actionType + "");
    if (actionType.equals("InsertMobilemenumapRecord")) {
      processInsertKBMobilemenumapRecord(req, res);
    }
    if (actionType.equals("UpdateMobilemenumapRecord")) {
      processUpdateKBMobilemenumapRecord(req, res);
    }
    if (actionType.equals("DeleteMobilemenumapRecord")) {
      processDeleteKBMobilemenumapRecord(req, res);
    }
    logger.generateFunctionEndTimerMessage(beginMesssage);
  }
}
