package com.key.mb.controller;

import com.key.mb.common.KBController;
import com.key.mb.service.KBCustomerService;
import com.key.mb.to.KBCustomerRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class KBCustomerController extends KBController {
  public static LogUtils logger = new LogUtils(KBCustomerController.class.getName());

  public KBCustomerRecord loadFormKBCustomerRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadFormKBCustomerRecord", null);
    KBCustomerRecord record = new KBCustomerRecord();
    record.setNationalid(getFormFieldValue(req, res, "tfNationalid"));
    record.setCif(getFormFieldValue(req, res, "tfCif"));
    record.setCheckedby(getFormFieldValue(req, res, "tfCheckedby"));
    record.setCname(getFormFieldValue(req, res, "tfCname"));
    record.setTermssigned(getFormFieldValue(req, res, "tfTermssigned"));
    record.setCreatedat(getFormFieldValue(req, res, "tfCreatedat"));
    record.setMakerlastcmt(getFormFieldValue(req, res, "tfMakerlastcmt"));
    record.setPreflang(getFormFieldValue(req, res, "tfPreflang"));
    record.setInstitutionid(getFormFieldValue(req, res, "tfInstitutionid"));
    record.setBlockedflag(getFormFieldValue(req, res, "tfBlockedflag"));
    record.setPassport(getFormFieldValue(req, res, "tfPassport"));
    record.setAuthfailpin(getFormFieldValue(req, res, "tfAuthfailpin"));
    record.setId(getFormFieldValue(req, res, "tfId"));
    record.setModifiedat(getFormFieldValue(req, res, "tfModifiedat"));
    record.setEmail(getFormFieldValue(req, res, "tfEmail"));
    record.setAuthfailtpin(getFormFieldValue(req, res, "tfAuthfailtpin"));
    record.setValacc(getFormFieldValue(req, res, "tfValacc"));
    record.setMadeat(getFormFieldValue(req, res, "tfMadeat"));
    record.setCheckedat(getFormFieldValue(req, res, "tfCheckedat"));
    record.setReportfreq(getFormFieldValue(req, res, "tfReportfreq"));
    record.setMobile(getFormFieldValue(req, res, "tfMobile"));
    record.setAllowedphoneid1(getFormFieldValue(req, res, "tfAllowedphoneid1"));
    record.setAllowedphoneid2(getFormFieldValue(req, res, "tfAllowedphoneid2"));
    record.setAllowedphonetype3(getFormFieldValue(req, res, "tfAllowedphonetype3"));
    record.setIdsubmitted(getFormFieldValue(req, res, "tfIdsubmitted"));
    record.setAllowedphonetype2(getFormFieldValue(req, res, "tfAllowedphonetype2"));
    record.setInitialtpin(getFormFieldValue(req, res, "tfInitialtpin"));
    record.setCreatedby(getFormFieldValue(req, res, "tfCreatedby"));
    record.setIdverified(getFormFieldValue(req, res, "tfIdverified"));
    record.setRstatus(getFormFieldValue(req, res, "tfRstatus"));
    record.setCustcat(getFormFieldValue(req, res, "tfCustcat"));
    record.setCustextn4(getFormFieldValue(req, res, "tfCustextn4"));
    record.setCustextn3(getFormFieldValue(req, res, "tfCustextn3"));
    record.setPinno(getFormFieldValue(req, res, "tfPinno"));
    record.setCurrappstatus(getFormFieldValue(req, res, "tfCurrappstatus"));
    record.setCustextn2(getFormFieldValue(req, res, "tfCustextn2"));
    record.setTpinno(getFormFieldValue(req, res, "tfTpinno"));
    record.setCustextn1(getFormFieldValue(req, res, "tfCustextn1"));
    record.setNationality(getFormFieldValue(req, res, "tfNationality"));
    record.setAllowedphonetype1(getFormFieldValue(req, res, "tfAllowedphonetype1"));
    record.setAdminlastcmt(getFormFieldValue(req, res, "tfAdminlastcmt"));
    record.setAllowedphoneid3(getFormFieldValue(req, res, "tfAllowedphoneid3"));
    record.setInitialmpin(getFormFieldValue(req, res, "tfInitialmpin"));
    record.setModifiedby(getFormFieldValue(req, res, "tfModifiedby"));
    record.setMadeby(getFormFieldValue(req, res, "tfMadeby"));
    record.setUgissued(getFormFieldValue(req, res, "tfUgissued"));
    record.setCheckerlastcmt(getFormFieldValue(req, res, "tfCheckerlastcmt"));
    logger.trace("loadFormKBCustomerRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBCustomerRecord loadJSONFormKBCustomerRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBCustomerRecord", null);
    KBCustomerRecord record = new KBCustomerRecord();
    record.setNationalid(getFormFieldValue(req, res, "national_id"));
    record.setCif(getFormFieldValue(req, res, "cif"));
    record.setCheckedby(getFormFieldValue(req, res, "checked_by"));
    record.setCname(getFormFieldValue(req, res, "cname"));
    record.setTermssigned(getFormFieldValue(req, res, "terms_signed"));
    record.setCreatedat(getFormFieldValue(req, res, "created_at"));
    record.setMakerlastcmt(getFormFieldValue(req, res, "maker_last_cmt"));
    record.setPreflang(getFormFieldValue(req, res, "pref_lang"));
    record.setInstitutionid(getFormFieldValue(req, res, "institution_id"));
    record.setBlockedflag(getFormFieldValue(req, res, "blocked_flag"));
    record.setPassport(getFormFieldValue(req, res, "passport"));
    record.setAuthfailpin(getFormFieldValue(req, res, "auth_fail_pin"));
    record.setId(getFormFieldValue(req, res, "id"));
    record.setModifiedat(getFormFieldValue(req, res, "modified_at"));
    record.setEmail(getFormFieldValue(req, res, "email"));
    record.setAuthfailtpin(getFormFieldValue(req, res, "auth_fail_tpin"));
    record.setValacc(getFormFieldValue(req, res, "val_acc"));
    record.setMadeat(getFormFieldValue(req, res, "made_at"));
    record.setCheckedat(getFormFieldValue(req, res, "checked_at"));
    record.setReportfreq(getFormFieldValue(req, res, "report_freq"));
    record.setMobile(getFormFieldValue(req, res, "mobile"));
    record.setAllowedphoneid1(getFormFieldValue(req, res, "allowed_phone_id1"));
    record.setAllowedphoneid2(getFormFieldValue(req, res, "allowed_phone_id2"));
    record.setAllowedphonetype3(getFormFieldValue(req, res, "allowed_phone_type3"));
    record.setIdsubmitted(getFormFieldValue(req, res, "id_submitted"));
    record.setAllowedphonetype2(getFormFieldValue(req, res, "allowed_phone_type2"));
    record.setInitialtpin(getFormFieldValue(req, res, "initial_tpin"));
    record.setCreatedby(getFormFieldValue(req, res, "created_by"));
    record.setIdverified(getFormFieldValue(req, res, "id_verified"));
    record.setRstatus(getFormFieldValue(req, res, "rstatus"));
    record.setCustcat(getFormFieldValue(req, res, "cust_cat"));
    record.setCustextn4(getFormFieldValue(req, res, "cust_extn4"));
    record.setCustextn3(getFormFieldValue(req, res, "cust_extn3"));
    record.setPinno(getFormFieldValue(req, res, "pin_no"));
    record.setCurrappstatus(getFormFieldValue(req, res, "curr_app_status"));
    record.setCustextn2(getFormFieldValue(req, res, "cust_extn2"));
    record.setTpinno(getFormFieldValue(req, res, "tpin_no"));
    record.setCustextn1(getFormFieldValue(req, res, "cust_extn1"));
    record.setNationality(getFormFieldValue(req, res, "nationality"));
    record.setAllowedphonetype1(getFormFieldValue(req, res, "allowed_phone_type1"));
    record.setAdminlastcmt(getFormFieldValue(req, res, "admin_last_cmt"));
    record.setAllowedphoneid3(getFormFieldValue(req, res, "allowed_phone_id3"));
    record.setInitialmpin(getFormFieldValue(req, res, "initial_mpin"));
    record.setModifiedby(getFormFieldValue(req, res, "modified_by"));
    record.setMadeby(getFormFieldValue(req, res, "made_by"));
    record.setUgissued(getFormFieldValue(req, res, "ug_issued"));
    record.setCheckerlastcmt(getFormFieldValue(req, res, "checker_last_cmt"));
    logger.trace("loadJSONFormKBCustomerRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBCustomerRecord loadJSONFormKBCustomerRecordEncode(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBCustomerRecordEncode", null);
    KBCustomerRecord record = new KBCustomerRecord();
    record.setNationalid(getFormFieldValueEncode(req, res, "national_id"));
    record.setCif(getFormFieldValueEncode(req, res, "cif"));
    record.setCheckedby(getFormFieldValueEncode(req, res, "checked_by"));
    record.setCname(getFormFieldValueEncode(req, res, "cname"));
    record.setTermssigned(getFormFieldValueEncode(req, res, "terms_signed"));
    record.setCreatedat(getFormFieldValueEncode(req, res, "created_at"));
    record.setMakerlastcmt(getFormFieldValueEncode(req, res, "maker_last_cmt"));
    record.setPreflang(getFormFieldValueEncode(req, res, "pref_lang"));
    record.setInstitutionid(getFormFieldValueEncode(req, res, "institution_id"));
    record.setBlockedflag(getFormFieldValueEncode(req, res, "blocked_flag"));
    record.setPassport(getFormFieldValueEncode(req, res, "passport"));
    record.setAuthfailpin(getFormFieldValueEncode(req, res, "auth_fail_pin"));
    record.setId(getFormFieldValueEncode(req, res, "id"));
    record.setModifiedat(getFormFieldValueEncode(req, res, "modified_at"));
    record.setEmail(getFormFieldValueEncode(req, res, "email"));
    record.setAuthfailtpin(getFormFieldValueEncode(req, res, "auth_fail_tpin"));
    record.setValacc(getFormFieldValueEncode(req, res, "val_acc"));
    record.setMadeat(getFormFieldValueEncode(req, res, "made_at"));
    record.setCheckedat(getFormFieldValueEncode(req, res, "checked_at"));
    record.setReportfreq(getFormFieldValueEncode(req, res, "report_freq"));
    record.setMobile(getFormFieldValueEncode(req, res, "mobile"));
    record.setAllowedphoneid1(getFormFieldValueEncode(req, res, "allowed_phone_id1"));
    record.setAllowedphoneid2(getFormFieldValueEncode(req, res, "allowed_phone_id2"));
    record.setAllowedphonetype3(getFormFieldValueEncode(req, res, "allowed_phone_type3"));
    record.setIdsubmitted(getFormFieldValueEncode(req, res, "id_submitted"));
    record.setAllowedphonetype2(getFormFieldValueEncode(req, res, "allowed_phone_type2"));
    record.setInitialtpin(getFormFieldValueEncode(req, res, "initial_tpin"));
    record.setCreatedby(getFormFieldValueEncode(req, res, "created_by"));
    record.setIdverified(getFormFieldValueEncode(req, res, "id_verified"));
    record.setRstatus(getFormFieldValueEncode(req, res, "rstatus"));
    record.setCustcat(getFormFieldValueEncode(req, res, "cust_cat"));
    record.setCustextn4(getFormFieldValueEncode(req, res, "cust_extn4"));
    record.setCustextn3(getFormFieldValueEncode(req, res, "cust_extn3"));
    record.setPinno(getFormFieldValueEncode(req, res, "pin_no"));
    record.setCurrappstatus(getFormFieldValueEncode(req, res, "curr_app_status"));
    record.setCustextn2(getFormFieldValueEncode(req, res, "cust_extn2"));
    record.setTpinno(getFormFieldValueEncode(req, res, "tpin_no"));
    record.setCustextn1(getFormFieldValueEncode(req, res, "cust_extn1"));
    record.setNationality(getFormFieldValueEncode(req, res, "nationality"));
    record.setAllowedphonetype1(getFormFieldValueEncode(req, res, "allowed_phone_type1"));
    record.setAdminlastcmt(getFormFieldValueEncode(req, res, "admin_last_cmt"));
    record.setAllowedphoneid3(getFormFieldValueEncode(req, res, "allowed_phone_id3"));
    record.setInitialmpin(getFormFieldValueEncode(req, res, "initial_mpin"));
    record.setModifiedby(getFormFieldValueEncode(req, res, "modified_by"));
    record.setMadeby(getFormFieldValueEncode(req, res, "made_by"));
    record.setUgissued(getFormFieldValueEncode(req, res, "ug_issued"));
    record.setCheckerlastcmt(getFormFieldValueEncode(req, res, "checker_last_cmt"));
    logger.trace("loadJSONFormKBCustomerRecordEncode	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBCustomerRecord loadMapKBCustomerRecord(HashMap inputMap) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadMapKBCustomerRecord", null);
    KBCustomerRecord record = new KBCustomerRecord();
    record.setNationalid(getMapValue(inputMap,"national_id"));
    record.setCif(getMapValue(inputMap,"cif"));
    record.setCheckedby(getMapValue(inputMap,"checked_by"));
    record.setCname(getMapValue(inputMap,"cname"));
    record.setTermssigned(getMapValue(inputMap,"terms_signed"));
    record.setCreatedat(getMapValue(inputMap,"created_at"));
    record.setMakerlastcmt(getMapValue(inputMap,"maker_last_cmt"));
    record.setPreflang(getMapValue(inputMap,"pref_lang"));
    record.setInstitutionid(getMapValue(inputMap,"institution_id"));
    record.setBlockedflag(getMapValue(inputMap,"blocked_flag"));
    record.setPassport(getMapValue(inputMap,"passport"));
    record.setAuthfailpin(getMapValue(inputMap,"auth_fail_pin"));
    record.setId(getMapValue(inputMap,"id"));
    record.setModifiedat(getMapValue(inputMap,"modified_at"));
    record.setEmail(getMapValue(inputMap,"email"));
    record.setAuthfailtpin(getMapValue(inputMap,"auth_fail_tpin"));
    record.setValacc(getMapValue(inputMap,"val_acc"));
    record.setMadeat(getMapValue(inputMap,"made_at"));
    record.setCheckedat(getMapValue(inputMap,"checked_at"));
    record.setReportfreq(getMapValue(inputMap,"report_freq"));
    record.setMobile(getMapValue(inputMap,"mobile"));
    record.setAllowedphoneid1(getMapValue(inputMap,"allowed_phone_id1"));
    record.setAllowedphoneid2(getMapValue(inputMap,"allowed_phone_id2"));
    record.setAllowedphonetype3(getMapValue(inputMap,"allowed_phone_type3"));
    record.setIdsubmitted(getMapValue(inputMap,"id_submitted"));
    record.setAllowedphonetype2(getMapValue(inputMap,"allowed_phone_type2"));
    record.setInitialtpin(getMapValue(inputMap,"initial_tpin"));
    record.setCreatedby(getMapValue(inputMap,"created_by"));
    record.setIdverified(getMapValue(inputMap,"id_verified"));
    record.setRstatus(getMapValue(inputMap,"rstatus"));
    record.setCustcat(getMapValue(inputMap,"cust_cat"));
    record.setCustextn4(getMapValue(inputMap,"cust_extn4"));
    record.setCustextn3(getMapValue(inputMap,"cust_extn3"));
    record.setPinno(getMapValue(inputMap,"pin_no"));
    record.setCurrappstatus(getMapValue(inputMap,"curr_app_status"));
    record.setCustextn2(getMapValue(inputMap,"cust_extn2"));
    record.setTpinno(getMapValue(inputMap,"tpin_no"));
    record.setCustextn1(getMapValue(inputMap,"cust_extn1"));
    record.setNationality(getMapValue(inputMap,"nationality"));
    record.setAllowedphonetype1(getMapValue(inputMap,"allowed_phone_type1"));
    record.setAdminlastcmt(getMapValue(inputMap,"admin_last_cmt"));
    record.setAllowedphoneid3(getMapValue(inputMap,"allowed_phone_id3"));
    record.setInitialmpin(getMapValue(inputMap,"initial_mpin"));
    record.setModifiedby(getMapValue(inputMap,"modified_by"));
    record.setMadeby(getMapValue(inputMap,"made_by"));
    record.setUgissued(getMapValue(inputMap,"ug_issued"));
    record.setCheckerlastcmt(getMapValue(inputMap,"checker_last_cmt"));
    logger.trace("loadMapKBCustomerRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public void processInsertKBCustomerRecord(HttpServletRequest req, HttpServletResponse res) throws
      Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processInsertKBCustomerRecord", null);
    KBCustomerService service = new KBCustomerService();
    try {
      KBCustomerRecord record = loadFormKBCustomerRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      int resultId = service.insertKBCustomerRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~" + resultId);
      logger.generateFunctionEndTimerMessage(beginMesssage);
       res.sendRedirect("KBCustomerController.jsp");
    }
    catch(Exception e) {
      setActionMessageLn(req, res, "AdminActionMessage", "FailedtoCreate~~KBCustomerRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBCustomerController.jsp");
    }
  }

  public void processUpdateKBCustomerRecord(HttpServletRequest req, HttpServletResponse res) throws
      Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processUpdateKBCustomerRecord", null);
    KBCustomerService service = new KBCustomerService();
    try {
      KBCustomerRecord record = loadFormKBCustomerRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.updateKBCustomerRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBCustomerController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBCustomerRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBCustomerController.jsp");
    }
  }

  public void processDeleteKBCustomerRecord(HttpServletRequest req, HttpServletResponse res) throws
      Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processDeleteKBCustomerRecord", null);
    KBCustomerService service = new KBCustomerService();
    try {
      KBCustomerRecord record = loadFormKBCustomerRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.deleteKBCustomerRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBCustomerController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBCustomerRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBCustomerController.jsp");
    }
  }

  public void processWebRequest(HttpServletRequest req, HttpServletResponse res, String actionType)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processWebRequest", null);
     logger.trace("Action Type:" + actionType + "");
    if (actionType.equals("InsertCustomerRecord")) {
      processInsertKBCustomerRecord(req, res);
    }
    if (actionType.equals("UpdateCustomerRecord")) {
      processUpdateKBCustomerRecord(req, res);
    }
    if (actionType.equals("DeleteCustomerRecord")) {
      processDeleteKBCustomerRecord(req, res);
    }
    logger.generateFunctionEndTimerMessage(beginMesssage);
  }
}
