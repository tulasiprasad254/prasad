package com.key.mb.controller;

import com.key.mb.common.KBController;
import com.key.mb.service.KBServicemapService;
import com.key.mb.to.KBServicemapRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class KBServicemapController extends KBController {
  public static LogUtils logger = new LogUtils(KBServicemapController.class.getName());

  public KBServicemapRecord loadFormKBServicemapRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadFormKBServicemapRecord", null);
    KBServicemapRecord record = new KBServicemapRecord();
    record.setRstatus(getFormFieldValue(req, res, "tfRstatus"));
    record.setServicetitle(getFormFieldValue(req, res, "tfServicetitle"));
    record.setServicemethod(getFormFieldValue(req, res, "tfServicemethod"));
    record.setModifiedby(getFormFieldValue(req, res, "tfModifiedby"));
    record.setServicecode(getFormFieldValue(req, res, "tfServicecode"));
    record.setCreatedat(getFormFieldValue(req, res, "tfCreatedat"));
    record.setId(getFormFieldValue(req, res, "tfId"));
    record.setModifiedat(getFormFieldValue(req, res, "tfModifiedat"));
    record.setCreatedby(getFormFieldValue(req, res, "tfCreatedby"));
    record.setServiceclass(getFormFieldValue(req, res, "tfServiceclass"));
    record.setIntenv(getFormFieldValue(req, res, "tfIntenv"));
    logger.trace("loadFormKBServicemapRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBServicemapRecord loadJSONFormKBServicemapRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBServicemapRecord", null);
    KBServicemapRecord record = new KBServicemapRecord();
    record.setRstatus(getFormFieldValue(req, res, "rstatus"));
    record.setServicetitle(getFormFieldValue(req, res, "service_title"));
    record.setServicemethod(getFormFieldValue(req, res, "service_method"));
    record.setModifiedby(getFormFieldValue(req, res, "modified_by"));
    record.setServicecode(getFormFieldValue(req, res, "service_code"));
    record.setCreatedat(getFormFieldValue(req, res, "created_at"));
    record.setId(getFormFieldValue(req, res, "id"));
    record.setModifiedat(getFormFieldValue(req, res, "modified_at"));
    record.setCreatedby(getFormFieldValue(req, res, "created_by"));
    record.setServiceclass(getFormFieldValue(req, res, "service_class"));
    record.setIntenv(getFormFieldValue(req, res, "int_env"));
    logger.trace("loadJSONFormKBServicemapRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBServicemapRecord loadJSONFormKBServicemapRecordEncode(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBServicemapRecordEncode", null);
    KBServicemapRecord record = new KBServicemapRecord();
    record.setRstatus(getFormFieldValueEncode(req, res, "rstatus"));
    record.setServicetitle(getFormFieldValueEncode(req, res, "service_title"));
    record.setServicemethod(getFormFieldValueEncode(req, res, "service_method"));
    record.setModifiedby(getFormFieldValueEncode(req, res, "modified_by"));
    record.setServicecode(getFormFieldValueEncode(req, res, "service_code"));
    record.setCreatedat(getFormFieldValueEncode(req, res, "created_at"));
    record.setId(getFormFieldValueEncode(req, res, "id"));
    record.setModifiedat(getFormFieldValueEncode(req, res, "modified_at"));
    record.setCreatedby(getFormFieldValueEncode(req, res, "created_by"));
    record.setServiceclass(getFormFieldValueEncode(req, res, "service_class"));
    record.setIntenv(getFormFieldValueEncode(req, res, "int_env"));
    logger.trace("loadJSONFormKBServicemapRecordEncode	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBServicemapRecord loadMapKBServicemapRecord(HashMap inputMap) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadMapKBServicemapRecord", null);
    KBServicemapRecord record = new KBServicemapRecord();
    record.setRstatus(getMapValue(inputMap,"rstatus"));
    record.setServicetitle(getMapValue(inputMap,"service_title"));
    record.setServicemethod(getMapValue(inputMap,"service_method"));
    record.setModifiedby(getMapValue(inputMap,"modified_by"));
    record.setServicecode(getMapValue(inputMap,"service_code"));
    record.setCreatedat(getMapValue(inputMap,"created_at"));
    record.setId(getMapValue(inputMap,"id"));
    record.setModifiedat(getMapValue(inputMap,"modified_at"));
    record.setCreatedby(getMapValue(inputMap,"created_by"));
    record.setServiceclass(getMapValue(inputMap,"service_class"));
    record.setIntenv(getMapValue(inputMap,"int_env"));
    logger.trace("loadMapKBServicemapRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public void processInsertKBServicemapRecord(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processInsertKBServicemapRecord", null);
    KBServicemapService service = new KBServicemapService();
    try {
      KBServicemapRecord record = loadFormKBServicemapRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      int resultId = service.insertKBServicemapRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~" + resultId);
      logger.generateFunctionEndTimerMessage(beginMesssage);
       res.sendRedirect("KBServicemapController.jsp");
    }
    catch(Exception e) {
      setActionMessageLn(req, res, "AdminActionMessage", "FailedtoCreate~~KBServicemapRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBServicemapController.jsp");
    }
  }

  public void processUpdateKBServicemapRecord(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processUpdateKBServicemapRecord", null);
    KBServicemapService service = new KBServicemapService();
    try {
      KBServicemapRecord record = loadFormKBServicemapRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.updateKBServicemapRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBServicemapController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBServicemapRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBServicemapController.jsp");
    }
  }

  public void processDeleteKBServicemapRecord(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processDeleteKBServicemapRecord", null);
    KBServicemapService service = new KBServicemapService();
    try {
      KBServicemapRecord record = loadFormKBServicemapRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.deleteKBServicemapRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBServicemapController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBServicemapRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBServicemapController.jsp");
    }
  }

  public void processWebRequest(HttpServletRequest req, HttpServletResponse res, String actionType)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processWebRequest", null);
     logger.trace("Action Type:" + actionType + "");
    if (actionType.equals("InsertServicemapRecord")) {
      processInsertKBServicemapRecord(req, res);
    }
    if (actionType.equals("UpdateServicemapRecord")) {
      processUpdateKBServicemapRecord(req, res);
    }
    if (actionType.equals("DeleteServicemapRecord")) {
      processDeleteKBServicemapRecord(req, res);
    }
    logger.generateFunctionEndTimerMessage(beginMesssage);
  }
}
