package com.key.mb.controller;

import com.key.mb.common.KBController;
import com.key.mb.service.KBContentmapService;
import com.key.mb.to.KBContentmapRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class KBContentmapController extends KBController {
  public static LogUtils logger = new LogUtils(KBContentmapController.class.getName());

  public KBContentmapRecord loadFormKBContentmapRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadFormKBContentmapRecord", null);
    KBContentmapRecord record = new KBContentmapRecord();
    record.setWap(getFormFieldValue(req, res, "tfWap"));
    record.setCreatedat(getFormFieldValue(req, res, "tfCreatedat"));
    record.setCreatedby(getFormFieldValue(req, res, "tfCreatedby"));
    record.setInstitutionid(getFormFieldValue(req, res, "tfInstitutionid"));
    record.setRstatus(getFormFieldValue(req, res, "tfRstatus"));
    record.setCcode(getFormFieldValue(req, res, "tfCcode"));
    record.setCvalue(getFormFieldValue(req, res, "tfCvalue"));
    record.setCseq(getFormFieldValue(req, res, "tfCseq"));
    record.setCtype(getFormFieldValue(req, res, "tfCtype"));
    record.setCcatg(getFormFieldValue(req, res, "tfCcatg"));
    record.setModifiedby(getFormFieldValue(req, res, "tfModifiedby"));
    record.setUssd(getFormFieldValue(req, res, "tfUssd"));
    record.setId(getFormFieldValue(req, res, "tfId"));
    record.setModifiedat(getFormFieldValue(req, res, "tfModifiedat"));
    logger.trace("loadFormKBContentmapRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBContentmapRecord loadJSONFormKBContentmapRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBContentmapRecord", null);
    KBContentmapRecord record = new KBContentmapRecord();
    record.setWap(getFormFieldValue(req, res, "wap"));
    record.setCreatedat(getFormFieldValue(req, res, "created_at"));
    record.setCreatedby(getFormFieldValue(req, res, "created_by"));
    record.setInstitutionid(getFormFieldValue(req, res, "institution_id"));
    record.setRstatus(getFormFieldValue(req, res, "rstatus"));
    record.setCcode(getFormFieldValue(req, res, "ccode"));
    record.setCvalue(getFormFieldValue(req, res, "cvalue"));
    record.setCseq(getFormFieldValue(req, res, "cseq"));
    record.setCtype(getFormFieldValue(req, res, "ctype"));
    record.setCcatg(getFormFieldValue(req, res, "ccatg"));
    record.setModifiedby(getFormFieldValue(req, res, "modified_by"));
    record.setUssd(getFormFieldValue(req, res, "ussd"));
    record.setId(getFormFieldValue(req, res, "id"));
    record.setModifiedat(getFormFieldValue(req, res, "modified_at"));
    logger.trace("loadJSONFormKBContentmapRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBContentmapRecord loadJSONFormKBContentmapRecordEncode(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBContentmapRecordEncode", null);
    KBContentmapRecord record = new KBContentmapRecord();
    record.setWap(getFormFieldValueEncode(req, res, "wap"));
    record.setCreatedat(getFormFieldValueEncode(req, res, "created_at"));
    record.setCreatedby(getFormFieldValueEncode(req, res, "created_by"));
    record.setInstitutionid(getFormFieldValueEncode(req, res, "institution_id"));
    record.setRstatus(getFormFieldValueEncode(req, res, "rstatus"));
    record.setCcode(getFormFieldValueEncode(req, res, "ccode"));
    record.setCvalue(getFormFieldValueEncode(req, res, "cvalue"));
    record.setCseq(getFormFieldValueEncode(req, res, "cseq"));
    record.setCtype(getFormFieldValueEncode(req, res, "ctype"));
    record.setCcatg(getFormFieldValueEncode(req, res, "ccatg"));
    record.setModifiedby(getFormFieldValueEncode(req, res, "modified_by"));
    record.setUssd(getFormFieldValueEncode(req, res, "ussd"));
    record.setId(getFormFieldValueEncode(req, res, "id"));
    record.setModifiedat(getFormFieldValueEncode(req, res, "modified_at"));
    logger.trace("loadJSONFormKBContentmapRecordEncode	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBContentmapRecord loadMapKBContentmapRecord(HashMap inputMap) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadMapKBContentmapRecord", null);
    KBContentmapRecord record = new KBContentmapRecord();
    record.setWap(getMapValue(inputMap,"wap"));
    record.setCreatedat(getMapValue(inputMap,"created_at"));
    record.setCreatedby(getMapValue(inputMap,"created_by"));
    record.setInstitutionid(getMapValue(inputMap,"institution_id"));
    record.setRstatus(getMapValue(inputMap,"rstatus"));
    record.setCcode(getMapValue(inputMap,"ccode"));
    record.setCvalue(getMapValue(inputMap,"cvalue"));
    record.setCseq(getMapValue(inputMap,"cseq"));
    record.setCtype(getMapValue(inputMap,"ctype"));
    record.setCcatg(getMapValue(inputMap,"ccatg"));
    record.setModifiedby(getMapValue(inputMap,"modified_by"));
    record.setUssd(getMapValue(inputMap,"ussd"));
    record.setId(getMapValue(inputMap,"id"));
    record.setModifiedat(getMapValue(inputMap,"modified_at"));
    logger.trace("loadMapKBContentmapRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public void processInsertKBContentmapRecord(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processInsertKBContentmapRecord", null);
    KBContentmapService service = new KBContentmapService();
    try {
      KBContentmapRecord record = loadFormKBContentmapRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      int resultId = service.insertKBContentmapRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~" + resultId);
      logger.generateFunctionEndTimerMessage(beginMesssage);
       res.sendRedirect("KBContentmapController.jsp");
    }
    catch(Exception e) {
      setActionMessageLn(req, res, "AdminActionMessage", "FailedtoCreate~~KBContentmapRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBContentmapController.jsp");
    }
  }

  public void processUpdateKBContentmapRecord(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processUpdateKBContentmapRecord", null);
    KBContentmapService service = new KBContentmapService();
    try {
      KBContentmapRecord record = loadFormKBContentmapRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.updateKBContentmapRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBContentmapController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBContentmapRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBContentmapController.jsp");
    }
  }

  public void processDeleteKBContentmapRecord(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processDeleteKBContentmapRecord", null);
    KBContentmapService service = new KBContentmapService();
    try {
      KBContentmapRecord record = loadFormKBContentmapRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.deleteKBContentmapRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBContentmapController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBContentmapRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBContentmapController.jsp");
    }
  }

  public void processWebRequest(HttpServletRequest req, HttpServletResponse res, String actionType)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processWebRequest", null);
     logger.trace("Action Type:" + actionType + "");
    if (actionType.equals("InsertContentmapRecord")) {
      processInsertKBContentmapRecord(req, res);
    }
    if (actionType.equals("UpdateContentmapRecord")) {
      processUpdateKBContentmapRecord(req, res);
    }
    if (actionType.equals("DeleteContentmapRecord")) {
      processDeleteKBContentmapRecord(req, res);
    }
    logger.generateFunctionEndTimerMessage(beginMesssage);
  }
}
