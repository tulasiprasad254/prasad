package com.key.mb.controller;

import com.key.mb.common.KBController;
import com.key.mb.service.KBControllermapService;
import com.key.mb.to.KBControllermapRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class KBControllermapController extends KBController {
  public static LogUtils logger = new LogUtils(KBControllermapController.class.getName());

  public KBControllermapRecord loadFormKBControllermapRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadFormKBControllermapRecord", null);
    KBControllermapRecord record = new KBControllermapRecord();
    record.setCode(getFormFieldValue(req, res, "tfCode"));
    record.setClassname(getFormFieldValue(req, res, "tfClassname"));
    record.setId(getFormFieldValue(req, res, "tfId"));
    record.setAuthflag(getFormFieldValue(req, res, "tfAuthflag"));
    logger.trace("loadFormKBControllermapRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBControllermapRecord loadJSONFormKBControllermapRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBControllermapRecord", null);
    KBControllermapRecord record = new KBControllermapRecord();
    record.setCode(getFormFieldValue(req, res, "code"));
    record.setClassname(getFormFieldValue(req, res, "classname"));
    record.setId(getFormFieldValue(req, res, "id"));
    record.setAuthflag(getFormFieldValue(req, res, "auth_flag"));
    logger.trace("loadJSONFormKBControllermapRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBControllermapRecord loadJSONFormKBControllermapRecordEncode(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBControllermapRecordEncode", null);
    KBControllermapRecord record = new KBControllermapRecord();
    record.setCode(getFormFieldValueEncode(req, res, "code"));
    record.setClassname(getFormFieldValueEncode(req, res, "classname"));
    record.setId(getFormFieldValueEncode(req, res, "id"));
    record.setAuthflag(getFormFieldValueEncode(req, res, "auth_flag"));
    logger.trace("loadJSONFormKBControllermapRecordEncode	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBControllermapRecord loadMapKBControllermapRecord(HashMap inputMap) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadMapKBControllermapRecord", null);
    KBControllermapRecord record = new KBControllermapRecord();
    record.setCode(getMapValue(inputMap,"code"));
    record.setClassname(getMapValue(inputMap,"classname"));
    record.setId(getMapValue(inputMap,"id"));
    record.setAuthflag(getMapValue(inputMap,"auth_flag"));
    logger.trace("loadMapKBControllermapRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public void processInsertKBControllermapRecord(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processInsertKBControllermapRecord", null);
    KBControllermapService service = new KBControllermapService();
    try {
      KBControllermapRecord record = loadFormKBControllermapRecord(req, res);
      int resultId = service.insertKBControllermapRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~" + resultId);
      logger.generateFunctionEndTimerMessage(beginMesssage);
       res.sendRedirect("KBControllermapController.jsp");
    }
    catch(Exception e) {
      setActionMessageLn(req, res, "AdminActionMessage", "FailedtoCreate~~KBControllermapRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBControllermapController.jsp");
    }
  }

  public void processUpdateKBControllermapRecord(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processUpdateKBControllermapRecord", null);
    KBControllermapService service = new KBControllermapService();
    try {
      KBControllermapRecord record = loadFormKBControllermapRecord(req, res);
      service.updateKBControllermapRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBControllermapController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBControllermapRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBControllermapController.jsp");
    }
  }

  public void processDeleteKBControllermapRecord(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processDeleteKBControllermapRecord", null);
    KBControllermapService service = new KBControllermapService();
    try {
      KBControllermapRecord record = loadFormKBControllermapRecord(req, res);
      service.deleteKBControllermapRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBControllermapController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBControllermapRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBControllermapController.jsp");
    }
  }

  public void processWebRequest(HttpServletRequest req, HttpServletResponse res, String actionType)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processWebRequest", null);
     logger.trace("Action Type:" + actionType + "");
    if (actionType.equals("InsertControllermapRecord")) {
      processInsertKBControllermapRecord(req, res);
    }
    if (actionType.equals("UpdateControllermapRecord")) {
      processUpdateKBControllermapRecord(req, res);
    }
    if (actionType.equals("DeleteControllermapRecord")) {
      processDeleteKBControllermapRecord(req, res);
    }
    logger.generateFunctionEndTimerMessage(beginMesssage);
  }
}
