package com.key.mb.controller;

import com.key.mb.common.KBController;
import com.key.mb.service.KBMobilesession2Service;
import com.key.mb.to.KBMobilesession2Record;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class KBMobilesession2Controller extends KBController {
  public static LogUtils logger = new LogUtils(KBMobilesession2Controller.class.getName());

  public KBMobilesession2Record loadFormKBMobilesession2Record(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadFormKBMobilesession2Record", null);
    KBMobilesession2Record record = new KBMobilesession2Record();
    record.setLastftamt(getFormFieldValue(req, res, "tfLastftamt"));
    record.setCifno(getFormFieldValue(req, res, "tfCifno"));
    record.setLastphoneid(getFormFieldValue(req, res, "tfLastphoneid"));
    record.setAgentacc(getFormFieldValue(req, res, "tfAgentacc"));
    record.setLastphonetype(getFormFieldValue(req, res, "tfLastphonetype"));
    record.setExtnval4(getFormFieldValue(req, res, "tfExtnval4"));
    record.setCreatedat(getFormFieldValue(req, res, "tfCreatedat"));
    record.setAgentchargesacc(getFormFieldValue(req, res, "tfAgentchargesacc"));
    record.setSessionid(getFormFieldValue(req, res, "tfSessionid"));
    record.setCreatedby(getFormFieldValue(req, res, "tfCreatedby"));
    record.setExtnval1(getFormFieldValue(req, res, "tfExtnval1"));
    record.setExtnval2(getFormFieldValue(req, res, "tfExtnval2"));
    record.setExtnval3(getFormFieldValue(req, res, "tfExtnval3"));
    record.setLastftto(getFormFieldValue(req, res, "tfLastftto"));
    record.setLastftfrom(getFormFieldValue(req, res, "tfLastftfrom"));
    record.setLangcode(getFormFieldValue(req, res, "tfLangcode"));
    record.setNavcont(getFormFieldValue(req, res, "tfNavcont"));
    record.setModifiedby(getFormFieldValue(req, res, "tfModifiedby"));
    record.setLastacc(getFormFieldValue(req, res, "tfLastacc"));
    record.setId(getFormFieldValue(req, res, "tfId"));
    record.setAgentflag(getFormFieldValue(req, res, "tfAgentflag"));
    record.setModifiedat(getFormFieldValue(req, res, "tfModifiedat"));
    record.setLastftremarks(getFormFieldValue(req, res, "tfLastftremarks"));
    record.setStatus(getFormFieldValue(req, res, "tfStatus"));
    logger.trace("loadFormKBMobilesession2Record	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBMobilesession2Record loadJSONFormKBMobilesession2Record(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBMobilesession2Record", null);
    KBMobilesession2Record record = new KBMobilesession2Record();
    record.setLastftamt(getFormFieldValue(req, res, "last_ft_amt"));
    record.setCifno(getFormFieldValue(req, res, "cifno"));
    record.setLastphoneid(getFormFieldValue(req, res, "last_phone_id"));
    record.setAgentacc(getFormFieldValue(req, res, "agent_acc"));
    record.setLastphonetype(getFormFieldValue(req, res, "last_phone_type"));
    record.setExtnval4(getFormFieldValue(req, res, "extn_val_4"));
    record.setCreatedat(getFormFieldValue(req, res, "created_at"));
    record.setAgentchargesacc(getFormFieldValue(req, res, "agent_charges_acc"));
    record.setSessionid(getFormFieldValue(req, res, "sessionid"));
    record.setCreatedby(getFormFieldValue(req, res, "created_by"));
    record.setExtnval1(getFormFieldValue(req, res, "extn_val_1"));
    record.setExtnval2(getFormFieldValue(req, res, "extn_val_2"));
    record.setExtnval3(getFormFieldValue(req, res, "extn_val_3"));
    record.setLastftto(getFormFieldValue(req, res, "last_ft_to"));
    record.setLastftfrom(getFormFieldValue(req, res, "last_ft_from"));
    record.setLangcode(getFormFieldValue(req, res, "lang_code"));
    record.setNavcont(getFormFieldValue(req, res, "navcont"));
    record.setModifiedby(getFormFieldValue(req, res, "modified_by"));
    record.setLastacc(getFormFieldValue(req, res, "lastacc"));
    record.setId(getFormFieldValue(req, res, "id"));
    record.setAgentflag(getFormFieldValue(req, res, "agent_flag"));
    record.setModifiedat(getFormFieldValue(req, res, "modified_at"));
    record.setLastftremarks(getFormFieldValue(req, res, "last_ft_remarks"));
    record.setStatus(getFormFieldValue(req, res, "status"));
    logger.trace("loadJSONFormKBMobilesession2Record	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBMobilesession2Record loadJSONFormKBMobilesession2RecordEncode(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBMobilesession2RecordEncode", null);
    KBMobilesession2Record record = new KBMobilesession2Record();
    record.setLastftamt(getFormFieldValueEncode(req, res, "last_ft_amt"));
    record.setCifno(getFormFieldValueEncode(req, res, "cifno"));
    record.setLastphoneid(getFormFieldValueEncode(req, res, "last_phone_id"));
    record.setAgentacc(getFormFieldValueEncode(req, res, "agent_acc"));
    record.setLastphonetype(getFormFieldValueEncode(req, res, "last_phone_type"));
    record.setExtnval4(getFormFieldValueEncode(req, res, "extn_val_4"));
    record.setCreatedat(getFormFieldValueEncode(req, res, "created_at"));
    record.setAgentchargesacc(getFormFieldValueEncode(req, res, "agent_charges_acc"));
    record.setSessionid(getFormFieldValueEncode(req, res, "sessionid"));
    record.setCreatedby(getFormFieldValueEncode(req, res, "created_by"));
    record.setExtnval1(getFormFieldValueEncode(req, res, "extn_val_1"));
    record.setExtnval2(getFormFieldValueEncode(req, res, "extn_val_2"));
    record.setExtnval3(getFormFieldValueEncode(req, res, "extn_val_3"));
    record.setLastftto(getFormFieldValueEncode(req, res, "last_ft_to"));
    record.setLastftfrom(getFormFieldValueEncode(req, res, "last_ft_from"));
    record.setLangcode(getFormFieldValueEncode(req, res, "lang_code"));
    record.setNavcont(getFormFieldValueEncode(req, res, "navcont"));
    record.setModifiedby(getFormFieldValueEncode(req, res, "modified_by"));
    record.setLastacc(getFormFieldValueEncode(req, res, "lastacc"));
    record.setId(getFormFieldValueEncode(req, res, "id"));
    record.setAgentflag(getFormFieldValueEncode(req, res, "agent_flag"));
    record.setModifiedat(getFormFieldValueEncode(req, res, "modified_at"));
    record.setLastftremarks(getFormFieldValueEncode(req, res, "last_ft_remarks"));
    record.setStatus(getFormFieldValueEncode(req, res, "status"));
    logger.trace("loadJSONFormKBMobilesession2RecordEncode	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBMobilesession2Record loadMapKBMobilesession2Record(HashMap inputMap) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadMapKBMobilesession2Record", null);
    KBMobilesession2Record record = new KBMobilesession2Record();
    record.setLastftamt(getMapValue(inputMap,"last_ft_amt"));
    record.setCifno(getMapValue(inputMap,"cifno"));
    record.setLastphoneid(getMapValue(inputMap,"last_phone_id"));
    record.setAgentacc(getMapValue(inputMap,"agent_acc"));
    record.setLastphonetype(getMapValue(inputMap,"last_phone_type"));
    record.setExtnval4(getMapValue(inputMap,"extn_val_4"));
    record.setCreatedat(getMapValue(inputMap,"created_at"));
    record.setAgentchargesacc(getMapValue(inputMap,"agent_charges_acc"));
    record.setSessionid(getMapValue(inputMap,"sessionid"));
    record.setCreatedby(getMapValue(inputMap,"created_by"));
    record.setExtnval1(getMapValue(inputMap,"extn_val_1"));
    record.setExtnval2(getMapValue(inputMap,"extn_val_2"));
    record.setExtnval3(getMapValue(inputMap,"extn_val_3"));
    record.setLastftto(getMapValue(inputMap,"last_ft_to"));
    record.setLastftfrom(getMapValue(inputMap,"last_ft_from"));
    record.setLangcode(getMapValue(inputMap,"lang_code"));
    record.setNavcont(getMapValue(inputMap,"navcont"));
    record.setModifiedby(getMapValue(inputMap,"modified_by"));
    record.setLastacc(getMapValue(inputMap,"lastacc"));
    record.setId(getMapValue(inputMap,"id"));
    record.setAgentflag(getMapValue(inputMap,"agent_flag"));
    record.setModifiedat(getMapValue(inputMap,"modified_at"));
    record.setLastftremarks(getMapValue(inputMap,"last_ft_remarks"));
    record.setStatus(getMapValue(inputMap,"status"));
    logger.trace("loadMapKBMobilesession2Record	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public void processInsertKBMobilesession2Record(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processInsertKBMobilesession2Record", null);
    KBMobilesession2Service service = new KBMobilesession2Service();
    try {
      KBMobilesession2Record record = loadFormKBMobilesession2Record(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      int resultId = service.insertKBMobilesession2Record(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~" + resultId);
      logger.generateFunctionEndTimerMessage(beginMesssage);
       res.sendRedirect("KBMobilesession2Controller.jsp");
    }
    catch(Exception e) {
      setActionMessageLn(req, res, "AdminActionMessage", "FailedtoCreate~~KBMobilesession2Record~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilesession2Controller.jsp");
    }
  }

  public void processUpdateKBMobilesession2Record(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processUpdateKBMobilesession2Record", null);
    KBMobilesession2Service service = new KBMobilesession2Service();
    try {
      KBMobilesession2Record record = loadFormKBMobilesession2Record(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.updateKBMobilesession2Record(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilesession2Controller.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBMobilesession2Record~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilesession2Controller.jsp");
    }
  }

  public void processDeleteKBMobilesession2Record(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processDeleteKBMobilesession2Record", null);
    KBMobilesession2Service service = new KBMobilesession2Service();
    try {
      KBMobilesession2Record record = loadFormKBMobilesession2Record(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.deleteKBMobilesession2Record(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilesession2Controller.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBMobilesession2Record~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilesession2Controller.jsp");
    }
  }

  public void processWebRequest(HttpServletRequest req, HttpServletResponse res, String actionType)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processWebRequest", null);
     logger.trace("Action Type:" + actionType + "");
    if (actionType.equals("InsertMobilesession2Record")) {
      processInsertKBMobilesession2Record(req, res);
    }
    if (actionType.equals("UpdateMobilesession2Record")) {
      processUpdateKBMobilesession2Record(req, res);
    }
    if (actionType.equals("DeleteMobilesession2Record")) {
      processDeleteKBMobilesession2Record(req, res);
    }
    logger.generateFunctionEndTimerMessage(beginMesssage);
  }
}
