package com.key.mb.controller;

import com.key.mb.common.KBController;
import com.key.mb.service.KBAccountviewService;
import com.key.mb.to.KBAccountviewRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class KBAccountviewController extends KBController {
  public static LogUtils logger = new LogUtils(KBAccountviewController.class.getName());

  public KBAccountviewRecord loadFormKBAccountviewRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadFormKBAccountviewRecord", null);
    KBAccountviewRecord record = new KBAccountviewRecord();
    record.setMadeat(getFormFieldValue(req, res, "tfMadeat"));
    record.setCheckedat(getFormFieldValue(req, res, "tfCheckedat"));
    record.setAccnum(getFormFieldValue(req, res, "tfAccnum"));
    record.setStatusname(getFormFieldValue(req, res, "tfStatusname"));
    record.setCheckedby(getFormFieldValue(req, res, "tfCheckedby"));
    record.setCname(getFormFieldValue(req, res, "tfCname"));
    record.setCreatedat(getFormFieldValue(req, res, "tfCreatedat"));
    record.setMakerlastcmt(getFormFieldValue(req, res, "tfMakerlastcmt"));
    record.setCreatedby(getFormFieldValue(req, res, "tfCreatedby"));
    record.setInstitutionid(getFormFieldValue(req, res, "tfInstitutionid"));
    record.setIname(getFormFieldValue(req, res, "tfIname"));
    record.setRstatus(getFormFieldValue(req, res, "tfRstatus"));
    record.setBlockedflag(getFormFieldValue(req, res, "tfBlockedflag"));
    record.setCurrappstatus(getFormFieldValue(req, res, "tfCurrappstatus"));
    record.setAdminlastcmt(getFormFieldValue(req, res, "tfAdminlastcmt"));
    record.setCurrappstatusname(getFormFieldValue(req, res, "tfCurrappstatusname"));
    record.setModifiedby(getFormFieldValue(req, res, "tfModifiedby"));
    record.setAlias(getFormFieldValue(req, res, "tfAlias"));
    record.setCurrency(getFormFieldValue(req, res, "tfCurrency"));
    record.setId(getFormFieldValue(req, res, "tfId"));
    record.setMadeby(getFormFieldValue(req, res, "tfMadeby"));
    record.setModifiedat(getFormFieldValue(req, res, "tfModifiedat"));
    record.setCustid(getFormFieldValue(req, res, "tfCustid"));
    record.setCheckerlastcmt(getFormFieldValue(req, res, "tfCheckerlastcmt"));
    logger.trace("loadFormKBAccountviewRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBAccountviewRecord loadJSONFormKBAccountviewRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBAccountviewRecord", null);
    KBAccountviewRecord record = new KBAccountviewRecord();
    record.setMadeat(getFormFieldValue(req, res, "made_at"));
    record.setCheckedat(getFormFieldValue(req, res, "checked_at"));
    record.setAccnum(getFormFieldValue(req, res, "acc_num"));
    record.setStatusname(getFormFieldValue(req, res, "status_name"));
    record.setCheckedby(getFormFieldValue(req, res, "checked_by"));
    record.setCname(getFormFieldValue(req, res, "cname"));
    record.setCreatedat(getFormFieldValue(req, res, "created_at"));
    record.setMakerlastcmt(getFormFieldValue(req, res, "maker_last_cmt"));
    record.setCreatedby(getFormFieldValue(req, res, "created_by"));
    record.setInstitutionid(getFormFieldValue(req, res, "institution_id"));
    record.setIname(getFormFieldValue(req, res, "iname"));
    record.setRstatus(getFormFieldValue(req, res, "rstatus"));
    record.setBlockedflag(getFormFieldValue(req, res, "blocked_flag"));
    record.setCurrappstatus(getFormFieldValue(req, res, "curr_app_status"));
    record.setAdminlastcmt(getFormFieldValue(req, res, "admin_last_cmt"));
    record.setCurrappstatusname(getFormFieldValue(req, res, "curr_app_status_name"));
    record.setModifiedby(getFormFieldValue(req, res, "modified_by"));
    record.setAlias(getFormFieldValue(req, res, "alias"));
    record.setCurrency(getFormFieldValue(req, res, "currency"));
    record.setId(getFormFieldValue(req, res, "id"));
    record.setMadeby(getFormFieldValue(req, res, "made_by"));
    record.setModifiedat(getFormFieldValue(req, res, "modified_at"));
    record.setCustid(getFormFieldValue(req, res, "cust_id"));
    record.setCheckerlastcmt(getFormFieldValue(req, res, "checker_last_cmt"));
    logger.trace("loadJSONFormKBAccountviewRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBAccountviewRecord loadJSONFormKBAccountviewRecordEncode(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBAccountviewRecordEncode", null);
    KBAccountviewRecord record = new KBAccountviewRecord();
    record.setMadeat(getFormFieldValueEncode(req, res, "made_at"));
    record.setCheckedat(getFormFieldValueEncode(req, res, "checked_at"));
    record.setAccnum(getFormFieldValueEncode(req, res, "acc_num"));
    record.setStatusname(getFormFieldValueEncode(req, res, "status_name"));
    record.setCheckedby(getFormFieldValueEncode(req, res, "checked_by"));
    record.setCname(getFormFieldValueEncode(req, res, "cname"));
    record.setCreatedat(getFormFieldValueEncode(req, res, "created_at"));
    record.setMakerlastcmt(getFormFieldValueEncode(req, res, "maker_last_cmt"));
    record.setCreatedby(getFormFieldValueEncode(req, res, "created_by"));
    record.setInstitutionid(getFormFieldValueEncode(req, res, "institution_id"));
    record.setIname(getFormFieldValueEncode(req, res, "iname"));
    record.setRstatus(getFormFieldValueEncode(req, res, "rstatus"));
    record.setBlockedflag(getFormFieldValueEncode(req, res, "blocked_flag"));
    record.setCurrappstatus(getFormFieldValueEncode(req, res, "curr_app_status"));
    record.setAdminlastcmt(getFormFieldValueEncode(req, res, "admin_last_cmt"));
    record.setCurrappstatusname(getFormFieldValueEncode(req, res, "curr_app_status_name"));
    record.setModifiedby(getFormFieldValueEncode(req, res, "modified_by"));
    record.setAlias(getFormFieldValueEncode(req, res, "alias"));
    record.setCurrency(getFormFieldValueEncode(req, res, "currency"));
    record.setId(getFormFieldValueEncode(req, res, "id"));
    record.setMadeby(getFormFieldValueEncode(req, res, "made_by"));
    record.setModifiedat(getFormFieldValueEncode(req, res, "modified_at"));
    record.setCustid(getFormFieldValueEncode(req, res, "cust_id"));
    record.setCheckerlastcmt(getFormFieldValueEncode(req, res, "checker_last_cmt"));
    logger.trace("loadJSONFormKBAccountviewRecordEncode	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBAccountviewRecord loadMapKBAccountviewRecord(HashMap inputMap) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadMapKBAccountviewRecord", null);
    KBAccountviewRecord record = new KBAccountviewRecord();
    record.setMadeat(getMapValue(inputMap,"made_at"));
    record.setCheckedat(getMapValue(inputMap,"checked_at"));
    record.setAccnum(getMapValue(inputMap,"acc_num"));
    record.setStatusname(getMapValue(inputMap,"status_name"));
    record.setCheckedby(getMapValue(inputMap,"checked_by"));
    record.setCname(getMapValue(inputMap,"cname"));
    record.setCreatedat(getMapValue(inputMap,"created_at"));
    record.setMakerlastcmt(getMapValue(inputMap,"maker_last_cmt"));
    record.setCreatedby(getMapValue(inputMap,"created_by"));
    record.setInstitutionid(getMapValue(inputMap,"institution_id"));
    record.setIname(getMapValue(inputMap,"iname"));
    record.setRstatus(getMapValue(inputMap,"rstatus"));
    record.setBlockedflag(getMapValue(inputMap,"blocked_flag"));
    record.setCurrappstatus(getMapValue(inputMap,"curr_app_status"));
    record.setAdminlastcmt(getMapValue(inputMap,"admin_last_cmt"));
    record.setCurrappstatusname(getMapValue(inputMap,"curr_app_status_name"));
    record.setModifiedby(getMapValue(inputMap,"modified_by"));
    record.setAlias(getMapValue(inputMap,"alias"));
    record.setCurrency(getMapValue(inputMap,"currency"));
    record.setId(getMapValue(inputMap,"id"));
    record.setMadeby(getMapValue(inputMap,"made_by"));
    record.setModifiedat(getMapValue(inputMap,"modified_at"));
    record.setCustid(getMapValue(inputMap,"cust_id"));
    record.setCheckerlastcmt(getMapValue(inputMap,"checker_last_cmt"));
    logger.trace("loadMapKBAccountviewRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public void processInsertKBAccountviewRecord(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processInsertKBAccountviewRecord", null);
    KBAccountviewService service = new KBAccountviewService();
    try {
      KBAccountviewRecord record = loadFormKBAccountviewRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      int resultId = service.insertKBAccountviewRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~" + resultId);
      logger.generateFunctionEndTimerMessage(beginMesssage);
       res.sendRedirect("KBAccountviewController.jsp");
    }
    catch(Exception e) {
      setActionMessageLn(req, res, "AdminActionMessage", "FailedtoCreate~~KBAccountviewRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBAccountviewController.jsp");
    }
  }

  public void processUpdateKBAccountviewRecord(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processUpdateKBAccountviewRecord", null);
    KBAccountviewService service = new KBAccountviewService();
    try {
      KBAccountviewRecord record = loadFormKBAccountviewRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.updateKBAccountviewRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBAccountviewController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBAccountviewRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBAccountviewController.jsp");
    }
  }

  public void processDeleteKBAccountviewRecord(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processDeleteKBAccountviewRecord", null);
    KBAccountviewService service = new KBAccountviewService();
    try {
      KBAccountviewRecord record = loadFormKBAccountviewRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.deleteKBAccountviewRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBAccountviewController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBAccountviewRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBAccountviewController.jsp");
    }
  }

  public void processWebRequest(HttpServletRequest req, HttpServletResponse res, String actionType)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processWebRequest", null);
     logger.trace("Action Type:" + actionType + "");
    if (actionType.equals("InsertAccountviewRecord")) {
      processInsertKBAccountviewRecord(req, res);
    }
    if (actionType.equals("UpdateAccountviewRecord")) {
      processUpdateKBAccountviewRecord(req, res);
    }
    if (actionType.equals("DeleteAccountviewRecord")) {
      processDeleteKBAccountviewRecord(req, res);
    }
    logger.generateFunctionEndTimerMessage(beginMesssage);
  }
}
