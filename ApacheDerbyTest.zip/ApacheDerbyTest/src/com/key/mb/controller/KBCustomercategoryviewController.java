package com.key.mb.controller;

import com.key.mb.common.KBController;
import com.key.mb.service.KBCustomercategoryviewService;
import com.key.mb.to.KBCustomercategoryviewRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class KBCustomercategoryviewController extends KBController {
  public static LogUtils logger = new LogUtils(KBCustomercategoryviewController.class.getName());

  public KBCustomercategoryviewRecord loadFormKBCustomercategoryviewRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadFormKBCustomercategoryviewRecord", null);
    KBCustomercategoryviewRecord record = new KBCustomercategoryviewRecord();
    record.setMadeat(getFormFieldValue(req, res, "tfMadeat"));
    record.setChargetype(getFormFieldValue(req, res, "tfChargetype"));
    record.setCheckedat(getFormFieldValue(req, res, "tfCheckedat"));
    record.setChargevalue(getFormFieldValue(req, res, "tfChargevalue"));
    record.setStatusname(getFormFieldValue(req, res, "tfStatusname"));
    record.setCheckedby(getFormFieldValue(req, res, "tfCheckedby"));
    record.setCreatedat(getFormFieldValue(req, res, "tfCreatedat"));
    record.setMintranlimit(getFormFieldValue(req, res, "tfMintranlimit"));
    record.setMakerlastcmt(getFormFieldValue(req, res, "tfMakerlastcmt"));
    record.setCreatedby(getFormFieldValue(req, res, "tfCreatedby"));
    record.setInstitutionid(getFormFieldValue(req, res, "tfInstitutionid"));
    record.setIname(getFormFieldValue(req, res, "tfIname"));
    record.setRstatus(getFormFieldValue(req, res, "tfRstatus"));
    record.setCurrappstatus(getFormFieldValue(req, res, "tfCurrappstatus"));
    record.setAdminlastcmt(getFormFieldValue(req, res, "tfAdminlastcmt"));
    record.setPerdaylimit(getFormFieldValue(req, res, "tfPerdaylimit"));
    record.setCurrappstatusname(getFormFieldValue(req, res, "tfCurrappstatusname"));
    record.setModifiedby(getFormFieldValue(req, res, "tfModifiedby"));
    record.setPertranlimit(getFormFieldValue(req, res, "tfPertranlimit"));
    record.setId(getFormFieldValue(req, res, "tfId"));
    record.setCategory(getFormFieldValue(req, res, "tfCategory"));
    record.setMadeby(getFormFieldValue(req, res, "tfMadeby"));
    record.setModifiedat(getFormFieldValue(req, res, "tfModifiedat"));
    record.setCheckerlastcmt(getFormFieldValue(req, res, "tfCheckerlastcmt"));
    logger.trace("loadFormKBCustomercategoryviewRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBCustomercategoryviewRecord loadJSONFormKBCustomercategoryviewRecord(
      HttpServletRequest req, HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBCustomercategoryviewRecord", null);
    KBCustomercategoryviewRecord record = new KBCustomercategoryviewRecord();
    record.setMadeat(getFormFieldValue(req, res, "made_at"));
    record.setChargetype(getFormFieldValue(req, res, "charge_type"));
    record.setCheckedat(getFormFieldValue(req, res, "checked_at"));
    record.setChargevalue(getFormFieldValue(req, res, "charge_value"));
    record.setStatusname(getFormFieldValue(req, res, "status_name"));
    record.setCheckedby(getFormFieldValue(req, res, "checked_by"));
    record.setCreatedat(getFormFieldValue(req, res, "created_at"));
    record.setMintranlimit(getFormFieldValue(req, res, "min_tran_limit"));
    record.setMakerlastcmt(getFormFieldValue(req, res, "maker_last_cmt"));
    record.setCreatedby(getFormFieldValue(req, res, "created_by"));
    record.setInstitutionid(getFormFieldValue(req, res, "institution_id"));
    record.setIname(getFormFieldValue(req, res, "iname"));
    record.setRstatus(getFormFieldValue(req, res, "rstatus"));
    record.setCurrappstatus(getFormFieldValue(req, res, "curr_app_status"));
    record.setAdminlastcmt(getFormFieldValue(req, res, "admin_last_cmt"));
    record.setPerdaylimit(getFormFieldValue(req, res, "per_day_limit"));
    record.setCurrappstatusname(getFormFieldValue(req, res, "curr_app_status_name"));
    record.setModifiedby(getFormFieldValue(req, res, "modified_by"));
    record.setPertranlimit(getFormFieldValue(req, res, "per_tran_limit"));
    record.setId(getFormFieldValue(req, res, "id"));
    record.setCategory(getFormFieldValue(req, res, "category"));
    record.setMadeby(getFormFieldValue(req, res, "made_by"));
    record.setModifiedat(getFormFieldValue(req, res, "modified_at"));
    record.setCheckerlastcmt(getFormFieldValue(req, res, "checker_last_cmt"));
    logger.trace("loadJSONFormKBCustomercategoryviewRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBCustomercategoryviewRecord loadJSONFormKBCustomercategoryviewRecordEncode(
      HttpServletRequest req, HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBCustomercategoryviewRecordEncode", null);
    KBCustomercategoryviewRecord record = new KBCustomercategoryviewRecord();
    record.setMadeat(getFormFieldValueEncode(req, res, "made_at"));
    record.setChargetype(getFormFieldValueEncode(req, res, "charge_type"));
    record.setCheckedat(getFormFieldValueEncode(req, res, "checked_at"));
    record.setChargevalue(getFormFieldValueEncode(req, res, "charge_value"));
    record.setStatusname(getFormFieldValueEncode(req, res, "status_name"));
    record.setCheckedby(getFormFieldValueEncode(req, res, "checked_by"));
    record.setCreatedat(getFormFieldValueEncode(req, res, "created_at"));
    record.setMintranlimit(getFormFieldValueEncode(req, res, "min_tran_limit"));
    record.setMakerlastcmt(getFormFieldValueEncode(req, res, "maker_last_cmt"));
    record.setCreatedby(getFormFieldValueEncode(req, res, "created_by"));
    record.setInstitutionid(getFormFieldValueEncode(req, res, "institution_id"));
    record.setIname(getFormFieldValueEncode(req, res, "iname"));
    record.setRstatus(getFormFieldValueEncode(req, res, "rstatus"));
    record.setCurrappstatus(getFormFieldValueEncode(req, res, "curr_app_status"));
    record.setAdminlastcmt(getFormFieldValueEncode(req, res, "admin_last_cmt"));
    record.setPerdaylimit(getFormFieldValueEncode(req, res, "per_day_limit"));
    record.setCurrappstatusname(getFormFieldValueEncode(req, res, "curr_app_status_name"));
    record.setModifiedby(getFormFieldValueEncode(req, res, "modified_by"));
    record.setPertranlimit(getFormFieldValueEncode(req, res, "per_tran_limit"));
    record.setId(getFormFieldValueEncode(req, res, "id"));
    record.setCategory(getFormFieldValueEncode(req, res, "category"));
    record.setMadeby(getFormFieldValueEncode(req, res, "made_by"));
    record.setModifiedat(getFormFieldValueEncode(req, res, "modified_at"));
    record.setCheckerlastcmt(getFormFieldValueEncode(req, res, "checker_last_cmt"));
    logger.trace("loadJSONFormKBCustomercategoryviewRecordEncode	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBCustomercategoryviewRecord loadMapKBCustomercategoryviewRecord(HashMap inputMap) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadMapKBCustomercategoryviewRecord", null);
    KBCustomercategoryviewRecord record = new KBCustomercategoryviewRecord();
    record.setMadeat(getMapValue(inputMap,"made_at"));
    record.setChargetype(getMapValue(inputMap,"charge_type"));
    record.setCheckedat(getMapValue(inputMap,"checked_at"));
    record.setChargevalue(getMapValue(inputMap,"charge_value"));
    record.setStatusname(getMapValue(inputMap,"status_name"));
    record.setCheckedby(getMapValue(inputMap,"checked_by"));
    record.setCreatedat(getMapValue(inputMap,"created_at"));
    record.setMintranlimit(getMapValue(inputMap,"min_tran_limit"));
    record.setMakerlastcmt(getMapValue(inputMap,"maker_last_cmt"));
    record.setCreatedby(getMapValue(inputMap,"created_by"));
    record.setInstitutionid(getMapValue(inputMap,"institution_id"));
    record.setIname(getMapValue(inputMap,"iname"));
    record.setRstatus(getMapValue(inputMap,"rstatus"));
    record.setCurrappstatus(getMapValue(inputMap,"curr_app_status"));
    record.setAdminlastcmt(getMapValue(inputMap,"admin_last_cmt"));
    record.setPerdaylimit(getMapValue(inputMap,"per_day_limit"));
    record.setCurrappstatusname(getMapValue(inputMap,"curr_app_status_name"));
    record.setModifiedby(getMapValue(inputMap,"modified_by"));
    record.setPertranlimit(getMapValue(inputMap,"per_tran_limit"));
    record.setId(getMapValue(inputMap,"id"));
    record.setCategory(getMapValue(inputMap,"category"));
    record.setMadeby(getMapValue(inputMap,"made_by"));
    record.setModifiedat(getMapValue(inputMap,"modified_at"));
    record.setCheckerlastcmt(getMapValue(inputMap,"checker_last_cmt"));
    logger.trace("loadMapKBCustomercategoryviewRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public void processInsertKBCustomercategoryviewRecord(HttpServletRequest req,
      HttpServletResponse res) throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processInsertKBCustomercategoryviewRecord", null);
    KBCustomercategoryviewService service = new KBCustomercategoryviewService();
    try {
      KBCustomercategoryviewRecord record = loadFormKBCustomercategoryviewRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      int resultId = service.insertKBCustomercategoryviewRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~" + resultId);
      logger.generateFunctionEndTimerMessage(beginMesssage);
       res.sendRedirect("KBCustomercategoryviewController.jsp");
    }
    catch(Exception e) {
      setActionMessageLn(req, res, "AdminActionMessage", "FailedtoCreate~~KBCustomercategoryviewRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBCustomercategoryviewController.jsp");
    }
  }

  public void processUpdateKBCustomercategoryviewRecord(HttpServletRequest req,
      HttpServletResponse res) throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processUpdateKBCustomercategoryviewRecord", null);
    KBCustomercategoryviewService service = new KBCustomercategoryviewService();
    try {
      KBCustomercategoryviewRecord record = loadFormKBCustomercategoryviewRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.updateKBCustomercategoryviewRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBCustomercategoryviewController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBCustomercategoryviewRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBCustomercategoryviewController.jsp");
    }
  }

  public void processDeleteKBCustomercategoryviewRecord(HttpServletRequest req,
      HttpServletResponse res) throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processDeleteKBCustomercategoryviewRecord", null);
    KBCustomercategoryviewService service = new KBCustomercategoryviewService();
    try {
      KBCustomercategoryviewRecord record = loadFormKBCustomercategoryviewRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.deleteKBCustomercategoryviewRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBCustomercategoryviewController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBCustomercategoryviewRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBCustomercategoryviewController.jsp");
    }
  }

  public void processWebRequest(HttpServletRequest req, HttpServletResponse res, String actionType)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processWebRequest", null);
     logger.trace("Action Type:" + actionType + "");
    if (actionType.equals("InsertCustomercategoryviewRecord")) {
      processInsertKBCustomercategoryviewRecord(req, res);
    }
    if (actionType.equals("UpdateCustomercategoryviewRecord")) {
      processUpdateKBCustomercategoryviewRecord(req, res);
    }
    if (actionType.equals("DeleteCustomercategoryviewRecord")) {
      processDeleteKBCustomercategoryviewRecord(req, res);
    }
    logger.generateFunctionEndTimerMessage(beginMesssage);
  }
}
