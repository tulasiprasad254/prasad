package com.key.mb.controller;

import com.key.mb.common.KBController;
import com.key.mb.service.KBAccountService;
import com.key.mb.to.KBAccountRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class KBAccountController extends KBController {
  public static LogUtils logger = new LogUtils(KBAccountController.class.getName());

  public KBAccountRecord loadFormKBAccountRecord(HttpServletRequest req, HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadFormKBAccountRecord", null);
    KBAccountRecord record = new KBAccountRecord();
    record.setMadeat(getFormFieldValue(req, res, "tfMadeat"));
    record.setCheckedat(getFormFieldValue(req, res, "tfCheckedat"));
    record.setAccnum(getFormFieldValue(req, res, "tfAccnum"));
    record.setCheckedby(getFormFieldValue(req, res, "tfCheckedby"));
    record.setCreatedat(getFormFieldValue(req, res, "tfCreatedat"));
    record.setMakerlastcmt(getFormFieldValue(req, res, "tfMakerlastcmt"));
    record.setCreatedby(getFormFieldValue(req, res, "tfCreatedby"));
    record.setInstitutionid(getFormFieldValue(req, res, "tfInstitutionid"));
    record.setRstatus(getFormFieldValue(req, res, "tfRstatus"));
    record.setBlockedflag(getFormFieldValue(req, res, "tfBlockedflag"));
    record.setCurrappstatus(getFormFieldValue(req, res, "tfCurrappstatus"));
    record.setAdminlastcmt(getFormFieldValue(req, res, "tfAdminlastcmt"));
    record.setModifiedby(getFormFieldValue(req, res, "tfModifiedby"));
    record.setAlias(getFormFieldValue(req, res, "tfAlias"));
    record.setCurrency(getFormFieldValue(req, res, "tfCurrency"));
    record.setId(getFormFieldValue(req, res, "tfId"));
    record.setMadeby(getFormFieldValue(req, res, "tfMadeby"));
    record.setModifiedat(getFormFieldValue(req, res, "tfModifiedat"));
    record.setCustid(getFormFieldValue(req, res, "tfCustid"));
    record.setCheckerlastcmt(getFormFieldValue(req, res, "tfCheckerlastcmt"));
    logger.trace("loadFormKBAccountRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBAccountRecord loadJSONFormKBAccountRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBAccountRecord", null);
    KBAccountRecord record = new KBAccountRecord();
    record.setMadeat(getFormFieldValue(req, res, "made_at"));
    record.setCheckedat(getFormFieldValue(req, res, "checked_at"));
    record.setAccnum(getFormFieldValue(req, res, "acc_num"));
    record.setCheckedby(getFormFieldValue(req, res, "checked_by"));
    record.setCreatedat(getFormFieldValue(req, res, "created_at"));
    record.setMakerlastcmt(getFormFieldValue(req, res, "maker_last_cmt"));
    record.setCreatedby(getFormFieldValue(req, res, "created_by"));
    record.setInstitutionid(getFormFieldValue(req, res, "institution_id"));
    record.setRstatus(getFormFieldValue(req, res, "rstatus"));
    record.setBlockedflag(getFormFieldValue(req, res, "blocked_flag"));
    record.setCurrappstatus(getFormFieldValue(req, res, "curr_app_status"));
    record.setAdminlastcmt(getFormFieldValue(req, res, "admin_last_cmt"));
    record.setModifiedby(getFormFieldValue(req, res, "modified_by"));
    record.setAlias(getFormFieldValue(req, res, "alias"));
    record.setCurrency(getFormFieldValue(req, res, "currency"));
    record.setId(getFormFieldValue(req, res, "id"));
    record.setMadeby(getFormFieldValue(req, res, "made_by"));
    record.setModifiedat(getFormFieldValue(req, res, "modified_at"));
    record.setCustid(getFormFieldValue(req, res, "cust_id"));
    record.setCheckerlastcmt(getFormFieldValue(req, res, "checker_last_cmt"));
    logger.trace("loadJSONFormKBAccountRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBAccountRecord loadJSONFormKBAccountRecordEncode(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBAccountRecordEncode", null);
    KBAccountRecord record = new KBAccountRecord();
    record.setMadeat(getFormFieldValueEncode(req, res, "made_at"));
    record.setCheckedat(getFormFieldValueEncode(req, res, "checked_at"));
    record.setAccnum(getFormFieldValueEncode(req, res, "acc_num"));
    record.setCheckedby(getFormFieldValueEncode(req, res, "checked_by"));
    record.setCreatedat(getFormFieldValueEncode(req, res, "created_at"));
    record.setMakerlastcmt(getFormFieldValueEncode(req, res, "maker_last_cmt"));
    record.setCreatedby(getFormFieldValueEncode(req, res, "created_by"));
    record.setInstitutionid(getFormFieldValueEncode(req, res, "institution_id"));
    record.setRstatus(getFormFieldValueEncode(req, res, "rstatus"));
    record.setBlockedflag(getFormFieldValueEncode(req, res, "blocked_flag"));
    record.setCurrappstatus(getFormFieldValueEncode(req, res, "curr_app_status"));
    record.setAdminlastcmt(getFormFieldValueEncode(req, res, "admin_last_cmt"));
    record.setModifiedby(getFormFieldValueEncode(req, res, "modified_by"));
    record.setAlias(getFormFieldValueEncode(req, res, "alias"));
    record.setCurrency(getFormFieldValueEncode(req, res, "currency"));
    record.setId(getFormFieldValueEncode(req, res, "id"));
    record.setMadeby(getFormFieldValueEncode(req, res, "made_by"));
    record.setModifiedat(getFormFieldValueEncode(req, res, "modified_at"));
    record.setCustid(getFormFieldValueEncode(req, res, "cust_id"));
    record.setCheckerlastcmt(getFormFieldValueEncode(req, res, "checker_last_cmt"));
    logger.trace("loadJSONFormKBAccountRecordEncode	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBAccountRecord loadMapKBAccountRecord(HashMap inputMap) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadMapKBAccountRecord", null);
    KBAccountRecord record = new KBAccountRecord();
    record.setMadeat(getMapValue(inputMap,"made_at"));
    record.setCheckedat(getMapValue(inputMap,"checked_at"));
    record.setAccnum(getMapValue(inputMap,"acc_num"));
    record.setCheckedby(getMapValue(inputMap,"checked_by"));
    record.setCreatedat(getMapValue(inputMap,"created_at"));
    record.setMakerlastcmt(getMapValue(inputMap,"maker_last_cmt"));
    record.setCreatedby(getMapValue(inputMap,"created_by"));
    record.setInstitutionid(getMapValue(inputMap,"institution_id"));
    record.setRstatus(getMapValue(inputMap,"rstatus"));
    record.setBlockedflag(getMapValue(inputMap,"blocked_flag"));
    record.setCurrappstatus(getMapValue(inputMap,"curr_app_status"));
    record.setAdminlastcmt(getMapValue(inputMap,"admin_last_cmt"));
    record.setModifiedby(getMapValue(inputMap,"modified_by"));
    record.setAlias(getMapValue(inputMap,"alias"));
    record.setCurrency(getMapValue(inputMap,"currency"));
    record.setId(getMapValue(inputMap,"id"));
    record.setMadeby(getMapValue(inputMap,"made_by"));
    record.setModifiedat(getMapValue(inputMap,"modified_at"));
    record.setCustid(getMapValue(inputMap,"cust_id"));
    record.setCheckerlastcmt(getMapValue(inputMap,"checker_last_cmt"));
    logger.trace("loadMapKBAccountRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public void processInsertKBAccountRecord(HttpServletRequest req, HttpServletResponse res) throws
      Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processInsertKBAccountRecord", null);
    KBAccountService service = new KBAccountService();
    try {
      KBAccountRecord record = loadFormKBAccountRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      int resultId = service.insertKBAccountRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~" + resultId);
      logger.generateFunctionEndTimerMessage(beginMesssage);
       res.sendRedirect("KBAccountController.jsp");
    }
    catch(Exception e) {
      setActionMessageLn(req, res, "AdminActionMessage", "FailedtoCreate~~KBAccountRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBAccountController.jsp");
    }
  }

  public void processUpdateKBAccountRecord(HttpServletRequest req, HttpServletResponse res) throws
      Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processUpdateKBAccountRecord", null);
    KBAccountService service = new KBAccountService();
    try {
      KBAccountRecord record = loadFormKBAccountRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.updateKBAccountRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBAccountController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBAccountRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBAccountController.jsp");
    }
  }

  public void processDeleteKBAccountRecord(HttpServletRequest req, HttpServletResponse res) throws
      Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processDeleteKBAccountRecord", null);
    KBAccountService service = new KBAccountService();
    try {
      KBAccountRecord record = loadFormKBAccountRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.deleteKBAccountRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBAccountController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBAccountRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBAccountController.jsp");
    }
  }

  public void processWebRequest(HttpServletRequest req, HttpServletResponse res, String actionType)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processWebRequest", null);
     logger.trace("Action Type:" + actionType + "");
    if (actionType.equals("InsertAccountRecord")) {
      processInsertKBAccountRecord(req, res);
    }
    if (actionType.equals("UpdateAccountRecord")) {
      processUpdateKBAccountRecord(req, res);
    }
    if (actionType.equals("DeleteAccountRecord")) {
      processDeleteKBAccountRecord(req, res);
    }
    logger.generateFunctionEndTimerMessage(beginMesssage);
  }
}
