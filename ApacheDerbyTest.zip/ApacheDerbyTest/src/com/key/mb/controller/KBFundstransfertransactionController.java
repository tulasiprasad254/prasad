package com.key.mb.controller;

import com.key.mb.common.KBController;
import com.key.mb.service.KBFundstransfertransactionService;
import com.key.mb.to.KBFundstransfertransactionRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class KBFundstransfertransactionController extends KBController {
  public static LogUtils logger = new LogUtils(KBFundstransfertransactionController.class.getName());

  public KBFundstransfertransactionRecord loadFormKBFundstransfertransactionRecord(
      HttpServletRequest req, HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadFormKBFundstransfertransactionRecord", null);
    KBFundstransfertransactionRecord record = new KBFundstransfertransactionRecord();
    record.setFtresultcode(getFormFieldValue(req, res, "tfFtresultcode"));
    record.setFtsessionid(getFormFieldValue(req, res, "tfFtsessionid"));
    record.setFtstepfailed(getFormFieldValue(req, res, "tfFtstepfailed"));
    record.setCreatedat(getFormFieldValue(req, res, "tfCreatedat"));
    record.setBeneficiarymobile(getFormFieldValue(req, res, "tfBeneficiarymobile"));
    record.setResp4(getFormFieldValue(req, res, "tfResp4"));
    record.setResp2(getFormFieldValue(req, res, "tfResp2"));
    record.setResp3(getFormFieldValue(req, res, "tfResp3"));
    record.setResp1(getFormFieldValue(req, res, "tfResp1"));
    record.setFttrantime(getFormFieldValue(req, res, "tfFttrantime"));
    record.setFtfrom(getFormFieldValue(req, res, "tfFtfrom"));
    record.setId(getFormFieldValue(req, res, "tfId"));
    record.setModifiedat(getFormFieldValue(req, res, "tfModifiedat"));
    record.setFtcif(getFormFieldValue(req, res, "tfFtcif"));
    record.setFtsubcharge(getFormFieldValue(req, res, "tfFtsubcharge"));
    record.setFtamount(getFormFieldValue(req, res, "tfFtamount"));
    record.setFtcharge(getFormFieldValue(req, res, "tfFtcharge"));
    record.setFtcomment(getFormFieldValue(req, res, "tfFtcomment"));
    record.setFtrefno(getFormFieldValue(req, res, "tfFtrefno"));
    record.setBeneficiarycurrency(getFormFieldValue(req, res, "tfBeneficiarycurrency"));
    record.setErrmsg(getFormFieldValue(req, res, "tfErrmsg"));
    record.setCreatedby(getFormFieldValue(req, res, "tfCreatedby"));
    record.setBeneficiarybranch(getFormFieldValue(req, res, "tfBeneficiarybranch"));
    record.setFttype(getFormFieldValue(req, res, "tfFttype"));
    record.setRstatus(getFormFieldValue(req, res, "tfRstatus"));
    record.setFtsource(getFormFieldValue(req, res, "tfFtsource"));
    record.setFtresult(getFormFieldValue(req, res, "tfFtresult"));
    record.setFtphoneid(getFormFieldValue(req, res, "tfFtphoneid"));
    record.setModifiedby(getFormFieldValue(req, res, "tfModifiedby"));
    record.setFtto(getFormFieldValue(req, res, "tfFtto"));
    record.setBeneficiarybank(getFormFieldValue(req, res, "tfBeneficiarybank"));
    record.setFtcurrcode(getFormFieldValue(req, res, "tfFtcurrcode"));
    logger.trace("loadFormKBFundstransfertransactionRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBFundstransfertransactionRecord loadJSONFormKBFundstransfertransactionRecord(
      HttpServletRequest req, HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBFundstransfertransactionRecord", null);
    KBFundstransfertransactionRecord record = new KBFundstransfertransactionRecord();
    record.setFtresultcode(getFormFieldValue(req, res, "ftresultcode"));
    record.setFtsessionid(getFormFieldValue(req, res, "ftsessionid"));
    record.setFtstepfailed(getFormFieldValue(req, res, "ftstepfailed"));
    record.setCreatedat(getFormFieldValue(req, res, "created_at"));
    record.setBeneficiarymobile(getFormFieldValue(req, res, "beneficiary_mobile"));
    record.setResp4(getFormFieldValue(req, res, "resp4"));
    record.setResp2(getFormFieldValue(req, res, "resp2"));
    record.setResp3(getFormFieldValue(req, res, "resp3"));
    record.setResp1(getFormFieldValue(req, res, "resp1"));
    record.setFttrantime(getFormFieldValue(req, res, "fttrantime"));
    record.setFtfrom(getFormFieldValue(req, res, "ftfrom"));
    record.setId(getFormFieldValue(req, res, "id"));
    record.setModifiedat(getFormFieldValue(req, res, "modified_at"));
    record.setFtcif(getFormFieldValue(req, res, "ftcif"));
    record.setFtsubcharge(getFormFieldValue(req, res, "ftsubcharge"));
    record.setFtamount(getFormFieldValue(req, res, "ftamount"));
    record.setFtcharge(getFormFieldValue(req, res, "ftcharge"));
    record.setFtcomment(getFormFieldValue(req, res, "ftcomment"));
    record.setFtrefno(getFormFieldValue(req, res, "ftrefno"));
    record.setBeneficiarycurrency(getFormFieldValue(req, res, "beneficiary_currency"));
    record.setErrmsg(getFormFieldValue(req, res, "errmsg"));
    record.setCreatedby(getFormFieldValue(req, res, "created_by"));
    record.setBeneficiarybranch(getFormFieldValue(req, res, "beneficiary_branch"));
    record.setFttype(getFormFieldValue(req, res, "fttype"));
    record.setRstatus(getFormFieldValue(req, res, "rstatus"));
    record.setFtsource(getFormFieldValue(req, res, "ftsource"));
    record.setFtresult(getFormFieldValue(req, res, "ftresult"));
    record.setFtphoneid(getFormFieldValue(req, res, "ftphoneid"));
    record.setModifiedby(getFormFieldValue(req, res, "modified_by"));
    record.setFtto(getFormFieldValue(req, res, "ftto"));
    record.setBeneficiarybank(getFormFieldValue(req, res, "beneficiary_bank"));
    record.setFtcurrcode(getFormFieldValue(req, res, "ftcurrcode"));
    logger.trace("loadJSONFormKBFundstransfertransactionRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBFundstransfertransactionRecord loadJSONFormKBFundstransfertransactionRecordEncode(
      HttpServletRequest req, HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBFundstransfertransactionRecordEncode", null);
    KBFundstransfertransactionRecord record = new KBFundstransfertransactionRecord();
    record.setFtresultcode(getFormFieldValueEncode(req, res, "ftresultcode"));
    record.setFtsessionid(getFormFieldValueEncode(req, res, "ftsessionid"));
    record.setFtstepfailed(getFormFieldValueEncode(req, res, "ftstepfailed"));
    record.setCreatedat(getFormFieldValueEncode(req, res, "created_at"));
    record.setBeneficiarymobile(getFormFieldValueEncode(req, res, "beneficiary_mobile"));
    record.setResp4(getFormFieldValueEncode(req, res, "resp4"));
    record.setResp2(getFormFieldValueEncode(req, res, "resp2"));
    record.setResp3(getFormFieldValueEncode(req, res, "resp3"));
    record.setResp1(getFormFieldValueEncode(req, res, "resp1"));
    record.setFttrantime(getFormFieldValueEncode(req, res, "fttrantime"));
    record.setFtfrom(getFormFieldValueEncode(req, res, "ftfrom"));
    record.setId(getFormFieldValueEncode(req, res, "id"));
    record.setModifiedat(getFormFieldValueEncode(req, res, "modified_at"));
    record.setFtcif(getFormFieldValueEncode(req, res, "ftcif"));
    record.setFtsubcharge(getFormFieldValueEncode(req, res, "ftsubcharge"));
    record.setFtamount(getFormFieldValueEncode(req, res, "ftamount"));
    record.setFtcharge(getFormFieldValueEncode(req, res, "ftcharge"));
    record.setFtcomment(getFormFieldValueEncode(req, res, "ftcomment"));
    record.setFtrefno(getFormFieldValueEncode(req, res, "ftrefno"));
    record.setBeneficiarycurrency(getFormFieldValueEncode(req, res, "beneficiary_currency"));
    record.setErrmsg(getFormFieldValueEncode(req, res, "errmsg"));
    record.setCreatedby(getFormFieldValueEncode(req, res, "created_by"));
    record.setBeneficiarybranch(getFormFieldValueEncode(req, res, "beneficiary_branch"));
    record.setFttype(getFormFieldValueEncode(req, res, "fttype"));
    record.setRstatus(getFormFieldValueEncode(req, res, "rstatus"));
    record.setFtsource(getFormFieldValueEncode(req, res, "ftsource"));
    record.setFtresult(getFormFieldValueEncode(req, res, "ftresult"));
    record.setFtphoneid(getFormFieldValueEncode(req, res, "ftphoneid"));
    record.setModifiedby(getFormFieldValueEncode(req, res, "modified_by"));
    record.setFtto(getFormFieldValueEncode(req, res, "ftto"));
    record.setBeneficiarybank(getFormFieldValueEncode(req, res, "beneficiary_bank"));
    record.setFtcurrcode(getFormFieldValueEncode(req, res, "ftcurrcode"));
    logger.trace("loadJSONFormKBFundstransfertransactionRecordEncode	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBFundstransfertransactionRecord loadMapKBFundstransfertransactionRecord(
      HashMap inputMap) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadMapKBFundstransfertransactionRecord", null);
    KBFundstransfertransactionRecord record = new KBFundstransfertransactionRecord();
    record.setFtresultcode(getMapValue(inputMap,"ftresultcode"));
    record.setFtsessionid(getMapValue(inputMap,"ftsessionid"));
    record.setFtstepfailed(getMapValue(inputMap,"ftstepfailed"));
    record.setCreatedat(getMapValue(inputMap,"created_at"));
    record.setBeneficiarymobile(getMapValue(inputMap,"beneficiary_mobile"));
    record.setResp4(getMapValue(inputMap,"resp4"));
    record.setResp2(getMapValue(inputMap,"resp2"));
    record.setResp3(getMapValue(inputMap,"resp3"));
    record.setResp1(getMapValue(inputMap,"resp1"));
    record.setFttrantime(getMapValue(inputMap,"fttrantime"));
    record.setFtfrom(getMapValue(inputMap,"ftfrom"));
    record.setId(getMapValue(inputMap,"id"));
    record.setModifiedat(getMapValue(inputMap,"modified_at"));
    record.setFtcif(getMapValue(inputMap,"ftcif"));
    record.setFtsubcharge(getMapValue(inputMap,"ftsubcharge"));
    record.setFtamount(getMapValue(inputMap,"ftamount"));
    record.setFtcharge(getMapValue(inputMap,"ftcharge"));
    record.setFtcomment(getMapValue(inputMap,"ftcomment"));
    record.setFtrefno(getMapValue(inputMap,"ftrefno"));
    record.setBeneficiarycurrency(getMapValue(inputMap,"beneficiary_currency"));
    record.setErrmsg(getMapValue(inputMap,"errmsg"));
    record.setCreatedby(getMapValue(inputMap,"created_by"));
    record.setBeneficiarybranch(getMapValue(inputMap,"beneficiary_branch"));
    record.setFttype(getMapValue(inputMap,"fttype"));
    record.setRstatus(getMapValue(inputMap,"rstatus"));
    record.setFtsource(getMapValue(inputMap,"ftsource"));
    record.setFtresult(getMapValue(inputMap,"ftresult"));
    record.setFtphoneid(getMapValue(inputMap,"ftphoneid"));
    record.setModifiedby(getMapValue(inputMap,"modified_by"));
    record.setFtto(getMapValue(inputMap,"ftto"));
    record.setBeneficiarybank(getMapValue(inputMap,"beneficiary_bank"));
    record.setFtcurrcode(getMapValue(inputMap,"ftcurrcode"));
    logger.trace("loadMapKBFundstransfertransactionRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public void processInsertKBFundstransfertransactionRecord(HttpServletRequest req,
      HttpServletResponse res) throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processInsertKBFundstransfertransactionRecord", null);
    KBFundstransfertransactionService service = new KBFundstransfertransactionService();
    try {
      KBFundstransfertransactionRecord record = loadFormKBFundstransfertransactionRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      int resultId = service.insertKBFundstransfertransactionRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~" + resultId);
      logger.generateFunctionEndTimerMessage(beginMesssage);
       res.sendRedirect("KBFundstransfertransactionController.jsp");
    }
    catch(Exception e) {
      setActionMessageLn(req, res, "AdminActionMessage", "FailedtoCreate~~KBFundstransfertransactionRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBFundstransfertransactionController.jsp");
    }
  }

  public void processUpdateKBFundstransfertransactionRecord(HttpServletRequest req,
      HttpServletResponse res) throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processUpdateKBFundstransfertransactionRecord", null);
    KBFundstransfertransactionService service = new KBFundstransfertransactionService();
    try {
      KBFundstransfertransactionRecord record = loadFormKBFundstransfertransactionRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.updateKBFundstransfertransactionRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBFundstransfertransactionController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBFundstransfertransactionRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBFundstransfertransactionController.jsp");
    }
  }

  public void processDeleteKBFundstransfertransactionRecord(HttpServletRequest req,
      HttpServletResponse res) throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processDeleteKBFundstransfertransactionRecord", null);
    KBFundstransfertransactionService service = new KBFundstransfertransactionService();
    try {
      KBFundstransfertransactionRecord record = loadFormKBFundstransfertransactionRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.deleteKBFundstransfertransactionRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBFundstransfertransactionController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBFundstransfertransactionRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBFundstransfertransactionController.jsp");
    }
  }

  public void processWebRequest(HttpServletRequest req, HttpServletResponse res, String actionType)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processWebRequest", null);
     logger.trace("Action Type:" + actionType + "");
    if (actionType.equals("InsertFundstransfertransactionRecord")) {
      processInsertKBFundstransfertransactionRecord(req, res);
    }
    if (actionType.equals("UpdateFundstransfertransactionRecord")) {
      processUpdateKBFundstransfertransactionRecord(req, res);
    }
    if (actionType.equals("DeleteFundstransfertransactionRecord")) {
      processDeleteKBFundstransfertransactionRecord(req, res);
    }
    logger.generateFunctionEndTimerMessage(beginMesssage);
  }
}
