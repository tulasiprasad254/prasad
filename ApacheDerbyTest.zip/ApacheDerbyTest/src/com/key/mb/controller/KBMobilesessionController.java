package com.key.mb.controller;

import com.key.mb.common.KBController;
import com.key.mb.service.KBMobilesessionService;
import com.key.mb.to.KBMobilesessionRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class KBMobilesessionController extends KBController {
  public static LogUtils logger = new LogUtils(KBMobilesessionController.class.getName());

  public KBMobilesessionRecord loadFormKBMobilesessionRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadFormKBMobilesessionRecord", null);
    KBMobilesessionRecord record = new KBMobilesessionRecord();
    record.setRstatus(getFormFieldValue(req, res, "tfRstatus"));
    record.setCifno(getFormFieldValue(req, res, "tfCifno"));
    record.setMobileid(getFormFieldValue(req, res, "tfMobileid"));
    record.setModifiedby(getFormFieldValue(req, res, "tfModifiedby"));
    record.setCreatedat(getFormFieldValue(req, res, "tfCreatedat"));
    record.setLastacc(getFormFieldValue(req, res, "tfLastacc"));
    record.setId(getFormFieldValue(req, res, "tfId"));
    record.setSessionid(getFormFieldValue(req, res, "tfSessionid"));
    record.setModifiedat(getFormFieldValue(req, res, "tfModifiedat"));
    record.setCreatedby(getFormFieldValue(req, res, "tfCreatedby"));
    logger.trace("loadFormKBMobilesessionRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBMobilesessionRecord loadJSONFormKBMobilesessionRecord(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBMobilesessionRecord", null);
    KBMobilesessionRecord record = new KBMobilesessionRecord();
    record.setRstatus(getFormFieldValue(req, res, "rstatus"));
    record.setCifno(getFormFieldValue(req, res, "cifno"));
    record.setMobileid(getFormFieldValue(req, res, "mobileid"));
    record.setModifiedby(getFormFieldValue(req, res, "modified_by"));
    record.setCreatedat(getFormFieldValue(req, res, "created_at"));
    record.setLastacc(getFormFieldValue(req, res, "lastacc"));
    record.setId(getFormFieldValue(req, res, "id"));
    record.setSessionid(getFormFieldValue(req, res, "sessionid"));
    record.setModifiedat(getFormFieldValue(req, res, "modified_at"));
    record.setCreatedby(getFormFieldValue(req, res, "created_by"));
    logger.trace("loadJSONFormKBMobilesessionRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBMobilesessionRecord loadJSONFormKBMobilesessionRecordEncode(HttpServletRequest req,
      HttpServletResponse res) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadJSONFormKBMobilesessionRecordEncode", null);
    KBMobilesessionRecord record = new KBMobilesessionRecord();
    record.setRstatus(getFormFieldValueEncode(req, res, "rstatus"));
    record.setCifno(getFormFieldValueEncode(req, res, "cifno"));
    record.setMobileid(getFormFieldValueEncode(req, res, "mobileid"));
    record.setModifiedby(getFormFieldValueEncode(req, res, "modified_by"));
    record.setCreatedat(getFormFieldValueEncode(req, res, "created_at"));
    record.setLastacc(getFormFieldValueEncode(req, res, "lastacc"));
    record.setId(getFormFieldValueEncode(req, res, "id"));
    record.setSessionid(getFormFieldValueEncode(req, res, "sessionid"));
    record.setModifiedat(getFormFieldValueEncode(req, res, "modified_at"));
    record.setCreatedby(getFormFieldValueEncode(req, res, "created_by"));
    logger.trace("loadJSONFormKBMobilesessionRecordEncode	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public KBMobilesessionRecord loadMapKBMobilesessionRecord(HashMap inputMap) {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("loadMapKBMobilesessionRecord", null);
    KBMobilesessionRecord record = new KBMobilesessionRecord();
    record.setRstatus(getMapValue(inputMap,"rstatus"));
    record.setCifno(getMapValue(inputMap,"cifno"));
    record.setMobileid(getMapValue(inputMap,"mobileid"));
    record.setModifiedby(getMapValue(inputMap,"modified_by"));
    record.setCreatedat(getMapValue(inputMap,"created_at"));
    record.setLastacc(getMapValue(inputMap,"lastacc"));
    record.setId(getMapValue(inputMap,"id"));
    record.setSessionid(getMapValue(inputMap,"sessionid"));
    record.setModifiedat(getMapValue(inputMap,"modified_at"));
    record.setCreatedby(getMapValue(inputMap,"created_by"));
    logger.trace("loadMapKBMobilesessionRecord	" + record + "	");
    logger.generateFunctionEndTimerMessage(beginMesssage);
    return record;
  }

  public void processInsertKBMobilesessionRecord(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processInsertKBMobilesessionRecord", null);
    KBMobilesessionService service = new KBMobilesessionService();
    try {
      KBMobilesessionRecord record = loadFormKBMobilesessionRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      int resultId = service.insertKBMobilesessionRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~" + resultId);
      logger.generateFunctionEndTimerMessage(beginMesssage);
       res.sendRedirect("KBMobilesessionController.jsp");
    }
    catch(Exception e) {
      setActionMessageLn(req, res, "AdminActionMessage", "FailedtoCreate~~KBMobilesessionRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilesessionController.jsp");
    }
  }

  public void processUpdateKBMobilesessionRecord(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processUpdateKBMobilesessionRecord", null);
    KBMobilesessionService service = new KBMobilesessionService();
    try {
      KBMobilesessionRecord record = loadFormKBMobilesessionRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.updateKBMobilesessionRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilesessionController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBMobilesessionRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilesessionController.jsp");
    }
  }

  public void processDeleteKBMobilesessionRecord(HttpServletRequest req, HttpServletResponse res)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processDeleteKBMobilesessionRecord", null);
    KBMobilesessionService service = new KBMobilesessionService();
    try {
      KBMobilesessionRecord record = loadFormKBMobilesessionRecord(req, res);
      record.setCreatedby(getLoggedInUserId(req, res));
      service.deleteKBMobilesessionRecord(record);
      setActionMessage(req, res, "AdminActionMessage", "RecordCreationSuccessful~~");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilesessionController.jsp");
    }
    catch(Exception e) {
      setActionMessage(req, res, "AdminActionMessage", "FailedtoCreate~~KBMobilesessionRecord~~");
      setActionMessage(req, res, "AdminActionMessageException", e);
      logger.error("Failed to Create Customer " + e);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      res.sendRedirect("KBMobilesessionController.jsp");
    }
  }

  public void processWebRequest(HttpServletRequest req, HttpServletResponse res, String actionType)
      throws Exception {
    String beginMesssage = logger.generateFunctionBeginTimerMessage("processWebRequest", null);
     logger.trace("Action Type:" + actionType + "");
    if (actionType.equals("InsertMobilesessionRecord")) {
      processInsertKBMobilesessionRecord(req, res);
    }
    if (actionType.equals("UpdateMobilesessionRecord")) {
      processUpdateKBMobilesessionRecord(req, res);
    }
    if (actionType.equals("DeleteMobilesessionRecord")) {
      processDeleteKBMobilesessionRecord(req, res);
    }
    logger.generateFunctionEndTimerMessage(beginMesssage);
  }
}
