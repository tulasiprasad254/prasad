package com.key.mb.service;

import com.key.mb.common.KBService;
import com.key.mb.dao.KBCustomerDAO;
import com.key.mb.to.KBCustomerRecord;
import com.key.utils.DateUtils;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.HashMap;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class KBCustomerService extends KBService {
  public static LogUtils logger = new LogUtils(KBCustomerService.class.getName());

  public KBCustomerRecord[] loadKBCustomerRecords(String query) throws Exception {
    try {
      logger.trace("loadKBCustomerRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBCustomerRecords", null);
      KBCustomerDAO dao = new KBCustomerDAO();
      KBCustomerRecord[] results = dao.loadKBCustomerRecords(query);
      int resultRecordCount = 0;
      if (results != null) {
        resultRecordCount = results.length;
      }
      logger.trace("loadKBCustomerRecords:Fetched" + resultRecordCount);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return results;
    }
    catch(Exception exception) {
      logger.error("loadKBCustomerRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBCustomerRecord loadFirstKBCustomerRecord(String query) throws Exception {
    try {
      logger.trace("loadKBCustomerRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBCustomerRecords", null);
      KBCustomerDAO dao = new KBCustomerDAO();
      KBCustomerRecord result = dao.loadFirstKBCustomerRecord(query);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadFirstKBCustomerRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBCustomerRecord searchFirstKBCustomerRecord(KBCustomerRecord record) throws Exception {
    try {
      logger.trace("searchFirstKBCustomerRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBCustomerRecords", null);
      KBCustomerDAO dao = new KBCustomerDAO();
      KBCustomerRecord[] records = dao.searchKBCustomerRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBCustomerRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBCustomerRecord searchKBCustomerRecordExactUpper(KBCustomerRecord record) throws
      Exception {
    try {
      logger.trace("searchFirstKBCustomerRecordsExactUpper:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBCustomerRecordsExactUpper", null);
      KBCustomerDAO dao = new KBCustomerDAO();
      KBCustomerRecord[] records = dao.searchKBCustomerRecordsExactUpper(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBCustomerRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBCustomerRecord[] searchKBCustomerRecords(KBCustomerRecord record) throws Exception {
    try {
      logger.trace("searchKBCustomerRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBCustomerRecords", null);
      KBCustomerDAO dao = new KBCustomerDAO();
      KBCustomerRecord[] records = dao.searchKBCustomerRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return records;
    }
    catch(Exception exception) {
      logger.error("searchKBCustomerRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int loadKBCustomerRecordCount(KBCustomerRecord record) throws Exception {
    return loadKBCustomerRecordCount(record, null);
  }

  public int loadKBCustomerRecordCount(KBCustomerRecord record, String customCondition) throws
      Exception {
    try {
      logger.trace("loadKBCustomerRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBCustomerRecordCount", null);
      KBCustomerDAO dao = new KBCustomerDAO();
      dao.setCustomCondition(customCondition);
      int resultcount = dao.loadKBCustomerRecordCount(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultcount;
    }
    catch(Exception exception) {
      logger.error("loadKBCustomerRecordCount" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBCustomerRecord loadKBCustomerRecord(String key) throws Exception {
    try {
      logger.trace("loadKBCustomerRecord:" + key);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBCustomerRecordCount", null);
      KBCustomerDAO dao = new KBCustomerDAO();
      KBCustomerRecord result = dao.loadKBCustomerRecord(key);
      logger.trace("loadKBCustomerRecord:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadKBCustomerRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public JSONObject getJSONKBCustomerRecordSearchResultByPage(KBCustomerRecord record,
      String offset, String maxrows, String orderBy) throws Exception {
    return getJSONKBCustomerRecordSearchResultByPage(record, offset, maxrows, orderBy, null);
  }

  public JSONObject getJSONKBCustomerRecordSearchResultByPage(KBCustomerRecord record,
      String offset, String maxrows, String orderBy, String customCondition) throws Exception {
    try {
      logger.trace("getJSONKBCustomerRecordSearchResultByPage:" + record + " Offset:" + offset + " Maxrows:" + maxrows);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("getJSONKBCustomerRecordSearchResult", null);
      KBCustomerDAO dao = new KBCustomerDAO();
      int totalCount = dao.loadKBCustomerRecordCount(record);
      dao.setLimits(offset, maxrows);
      KBCustomerRecord[] records = null;
      if (totalCount > 0) {
        dao.setOrderBy(orderBy);
        records = dao.searchKBCustomerRecords(record);
      }
      JSONObject resultObject = new JSONObject();
      resultObject.put("total",totalCount + "");
      JSONArray dataArray = new JSONArray();
      int recordCount = 0;
      if (totalCount > 0) {
        recordCount = records.length;
      }
      for (int index = 0; index < recordCount; index++) {
        dataArray.add(records[index].getJSONObjectUI());
      }
      resultObject.put("rows",dataArray);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultObject;
    }
    catch(Exception exception) {
      logger.error("getJSONKBCustomerRecordSearchResult" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int insertKBCustomerRecord(KBCustomerRecord record) throws Exception {
    try {
      logger.trace("insertKBCustomerRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("insertKBCustomerRecord", null);
      KBCustomerDAO dao = new KBCustomerDAO();
      int result = dao.insertKBCustomerRecord(record);
      logger.trace("insertKBCustomerRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomerService", record.getId() + "", "Create", record.getCreatedby(), "Created");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("insertKBCustomerRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBCustomerRecord(KBCustomerRecord record) throws Exception {
    try {
      logger.trace("updateKBCustomerRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBCustomerRecord", null);
      KBCustomerDAO dao = new KBCustomerDAO();
      boolean result = dao.updateKBCustomerRecord(record);
      logger.trace("updateKBCustomerRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomerService", record.getId() + "", "Update", record.getModifiedby(), "Update");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBCustomerRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBCustomerRecordNonNull(KBCustomerRecord inputRecord) throws Exception {
    try {
      logger.trace("updateKBCustomerRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBCustomerRecordNoNull", null);
      KBCustomerDAO dao = new KBCustomerDAO();
      KBCustomerRecord dbRecord = dao.loadKBCustomerRecord(inputRecord.getId());
      if (dbRecord == null) {
        throw new Exception("Record not found");
      }
      dbRecord.loadNonNullContent(inputRecord);
      boolean result = dao.updateKBCustomerRecord(inputRecord);
      createMakerCheckerAuditEntry("KBCustomerService", inputRecord.getId() + "", "Update", inputRecord.getModifiedby(), "UpdateNoNull");
      logger.trace("updateKBCustomerRecordNoNull:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBCustomerRecordNoNull" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean deleteKBCustomerRecord(KBCustomerRecord record) throws Exception {
    try {
      logger.trace("deleteKBCustomerRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("deleteKBCustomerRecord", null);
      KBCustomerDAO dao = new KBCustomerDAO();
      boolean result = dao.deleteKBCustomerRecord(record);
      logger.trace("deleteKBCustomerRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomerService", record.getId(), "Delete", null, "Deleted");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("deleteKBCustomerRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean approveKBCustomerRecord(KBCustomerRecord inputRecord, String updateId,
      String comment) throws Exception {
    try {
      logger.trace("approveKBCustomerRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("approveKBCustomerRecord", null);
      KBCustomerDAO dao = new KBCustomerDAO();
      KBCustomerRecord updateRecord = dao.loadKBCustomerRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForApproval(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot approve - Invalid Status for Approval");
      }
      if (StringUtils.isSame(updateRecord.getMadeby(), updateId)) {
        throw new Exception("MF-ERR-CA-MCS102:Cannot Approve. Maker Checker cannot be same");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("1");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBCustomerRecord(updateRecord);
      logger.trace("approveKBCustomerRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomerService", updateRecord.getId(), "Approve", updateId, comment);
      HashMap approveEventMap = callActionEvent("Event_OnApprovalOf_KBCustomerRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("approveKBCustomerRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean submitKBCustomerRecord(KBCustomerRecord inputRecord, String updateId,
      String comment) throws Exception {
    try {
      logger.trace("submitKBCustomerRecordNoNull:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("submitKBCustomerRecordNoNull", null);
      KBCustomerDAO dao = new KBCustomerDAO();
      KBCustomerRecord updateRecord = dao.loadKBCustomerRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForSubmission(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CS-IS101:Cannot submit - Invalid Status for Submission");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("4");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBCustomerRecord(updateRecord);
      logger.trace("approveKBCustomerRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomerService", updateRecord.getId(), "Submit", updateId, comment);
      HashMap submitEventMap = callActionEvent("Event_OnApprovalOf_KBCustomerRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("submitKBCustomerRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean denyKBCustomerRecord(KBCustomerRecord inputRecord, String updateId, String comment)
      throws Exception {
    try {
      logger.trace("denyKBCustomerRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("denyKBCustomerRecord", null);
      KBCustomerDAO dao = new KBCustomerDAO();
      KBCustomerRecord updateRecord = dao.loadKBCustomerRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForDeny(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot deny - Invalid Status for Deny");
      }
      if (StringUtils.isSame(updateRecord.getMadeby(), updateId)) {
        throw new Exception("MF-ERR-CA-MCS102:Cannot Deny. Maker Checker cannot be same");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("5");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBCustomerRecord(updateRecord);
      logger.trace("approveKBCustomerRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomerService", updateRecord.getId(), "Deny", updateId, comment);
      HashMap denyEventMap = callActionEvent("Event_OnDenyOf_KBCustomerRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("denyKBCustomerRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean denyPermanantKBCustomerRecord(KBCustomerRecord inputRecord, String updateId,
      String comment) throws Exception {
    try {
      logger.trace("denyPKBCustomerRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("denyPKBCustomerRecord", null);
      KBCustomerDAO dao = new KBCustomerDAO();
      KBCustomerRecord updateRecord = dao.loadKBCustomerRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForDeny(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot deny - Invalid Status for Deny");
      }
      if (StringUtils.isSame(updateRecord.getMadeby(), updateId)) {
        throw new Exception("MF-ERR-CA-MCS102:Cannot Deny. Maker Checker cannot be same");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("58");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBCustomerRecord(updateRecord);
      logger.trace("approveKBCustomerRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomerService", updateRecord.getId(), "DenyP", updateId, comment);
      HashMap denyEventMap = callActionEvent("Event_OnDenyPOf_KBCustomerRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("denyPKBCustomerRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean remindApprovalKBCustomerRecord(KBCustomerRecord inputRecord, String updateId,
      String comment) throws Exception {
    try {
      logger.trace("remindApprovalKBCustomerRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("remindApprovalKBCustomerRecord", null);
      KBCustomerDAO dao = new KBCustomerDAO();
      KBCustomerRecord updateRecord = dao.loadKBCustomerRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForApproval(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot Remind - Invalid Status for Reminder");
      }
      createMakerCheckerAuditEntry("KBCustomerService", updateRecord.getId(), "Approval Reminder", updateId, comment);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return true;
    }
    catch(Exception exception) {
      logger.error("remindApprovalKBCustomerRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean resetApprovalKBCustomerRecord(KBCustomerRecord inputRecord, String updateId,
      String comment) throws Exception {
    try {
      logger.trace("resetApprovalKBCustomerRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("resetApprovalKBCustomerRecord", null);
      KBCustomerDAO dao = new KBCustomerDAO();
      KBCustomerRecord updateRecord = dao.loadKBCustomerRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForDeny(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot submit - Invalid Status for Reset");
      }
      updateRecord.setRstatus("0");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("0");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBCustomerRecord(updateRecord);
      logger.trace("approveKBCustomerRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomerService", updateRecord.getId(), "Reset Approval", updateId, comment);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("resetApprovalKBCustomerRecord" + getStackTrace(exception));
      throw exception;
    }
  }
}
