package com.key.mb.service;

import com.key.mb.common.KBService;
import com.key.mb.dao.KBFundstransfertransactionviewDAO;
import com.key.mb.to.KBFundstransfertransactionviewRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class KBFundstransfertransactionviewService extends KBService {
  public static LogUtils logger = new LogUtils(KBFundstransfertransactionviewService.class.getName());

  public KBFundstransfertransactionviewRecord[] loadKBFundstransfertransactionviewRecords(
      String query) throws Exception {
    try {
      logger.trace("loadKBFundstransfertransactionviewRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBFundstransfertransactionviewRecords", null);
      KBFundstransfertransactionviewDAO dao = new KBFundstransfertransactionviewDAO();
      KBFundstransfertransactionviewRecord[] results = dao.loadKBFundstransfertransactionviewRecords(query);
      int resultRecordCount = 0;
      if (results != null) {
        resultRecordCount = results.length;
      }
      logger.trace("loadKBFundstransfertransactionviewRecords:Fetched" + resultRecordCount);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return results;
    }
    catch(Exception exception) {
      logger.error("loadKBFundstransfertransactionviewRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBFundstransfertransactionviewRecord loadFirstKBFundstransfertransactionviewRecord(
      String query) throws Exception {
    try {
      logger.trace("loadKBFundstransfertransactionviewRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBFundstransfertransactionviewRecords", null);
      KBFundstransfertransactionviewDAO dao = new KBFundstransfertransactionviewDAO();
      KBFundstransfertransactionviewRecord result = dao.loadFirstKBFundstransfertransactionviewRecord(query);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadFirstKBFundstransfertransactionviewRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBFundstransfertransactionviewRecord searchFirstKBFundstransfertransactionviewRecord(
      KBFundstransfertransactionviewRecord record) throws Exception {
    try {
      logger.trace("searchFirstKBFundstransfertransactionviewRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBFundstransfertransactionviewRecords", null);
      KBFundstransfertransactionviewDAO dao = new KBFundstransfertransactionviewDAO();
      KBFundstransfertransactionviewRecord[] records = dao.searchKBFundstransfertransactionviewRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBFundstransfertransactionviewRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBFundstransfertransactionviewRecord searchKBFundstransfertransactionviewRecordExactUpper(
      KBFundstransfertransactionviewRecord record) throws Exception {
    try {
      logger.trace("searchFirstKBFundstransfertransactionviewRecordsExactUpper:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBFundstransfertransactionviewRecordsExactUpper", null);
      KBFundstransfertransactionviewDAO dao = new KBFundstransfertransactionviewDAO();
      KBFundstransfertransactionviewRecord[] records = dao.searchKBFundstransfertransactionviewRecordsExactUpper(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBFundstransfertransactionviewRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBFundstransfertransactionviewRecord[] searchKBFundstransfertransactionviewRecords(
      KBFundstransfertransactionviewRecord record) throws Exception {
    try {
      logger.trace("searchKBFundstransfertransactionviewRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBFundstransfertransactionviewRecords", null);
      KBFundstransfertransactionviewDAO dao = new KBFundstransfertransactionviewDAO();
      KBFundstransfertransactionviewRecord[] records = dao.searchKBFundstransfertransactionviewRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return records;
    }
    catch(Exception exception) {
      logger.error("searchKBFundstransfertransactionviewRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int loadKBFundstransfertransactionviewRecordCount(
      KBFundstransfertransactionviewRecord record) throws Exception {
    return loadKBFundstransfertransactionviewRecordCount(record, null);
  }

  public int loadKBFundstransfertransactionviewRecordCount(
      KBFundstransfertransactionviewRecord record, String customCondition) throws Exception {
    try {
      logger.trace("loadKBFundstransfertransactionviewRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBFundstransfertransactionviewRecordCount", null);
      KBFundstransfertransactionviewDAO dao = new KBFundstransfertransactionviewDAO();
      dao.setCustomCondition(customCondition);
      int resultcount = dao.loadKBFundstransfertransactionviewRecordCount(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultcount;
    }
    catch(Exception exception) {
      logger.error("loadKBFundstransfertransactionviewRecordCount" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBFundstransfertransactionviewRecord loadKBFundstransfertransactionviewRecord(String key)
      throws Exception {
    try {
      logger.trace("loadKBFundstransfertransactionviewRecord:" + key);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBFundstransfertransactionviewRecordCount", null);
      KBFundstransfertransactionviewDAO dao = new KBFundstransfertransactionviewDAO();
      KBFundstransfertransactionviewRecord result = dao.loadKBFundstransfertransactionviewRecord(key);
      logger.trace("loadKBFundstransfertransactionviewRecord:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadKBFundstransfertransactionviewRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public JSONObject getJSONKBFundstransfertransactionviewRecordSearchResultByPage(
      KBFundstransfertransactionviewRecord record, String offset, String maxrows, String orderBy)
      throws Exception {
    return getJSONKBFundstransfertransactionviewRecordSearchResultByPage(record, offset, maxrows, orderBy, null);
  }

  public JSONObject getJSONKBFundstransfertransactionviewRecordSearchResultByPage(
      KBFundstransfertransactionviewRecord record, String offset, String maxrows, String orderBy,
      String customCondition) throws Exception {
    try {
      logger.trace("getJSONKBFundstransfertransactionviewRecordSearchResultByPage:" + record + " Offset:" + offset + " Maxrows:" + maxrows);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("getJSONKBFundstransfertransactionviewRecordSearchResult", null);
      KBFundstransfertransactionviewDAO dao = new KBFundstransfertransactionviewDAO();
      int totalCount = dao.loadKBFundstransfertransactionviewRecordCount(record);
      dao.setLimits(offset, maxrows);
      KBFundstransfertransactionviewRecord[] records = null;
      if (totalCount > 0) {
        dao.setOrderBy(orderBy);
        records = dao.searchKBFundstransfertransactionviewRecords(record);
      }
      JSONObject resultObject = new JSONObject();
      resultObject.put("total",totalCount + "");
      JSONArray dataArray = new JSONArray();
      int recordCount = 0;
      if (totalCount > 0) {
        recordCount = records.length;
      }
      for (int index = 0; index < recordCount; index++) {
        dataArray.add(records[index].getJSONObjectUI());
      }
      resultObject.put("rows",dataArray);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultObject;
    }
    catch(Exception exception) {
      logger.error("getJSONKBFundstransfertransactionviewRecordSearchResult" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int insertKBFundstransfertransactionviewRecord(KBFundstransfertransactionviewRecord record)
      throws Exception {
    try {
      logger.trace("insertKBFundstransfertransactionviewRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("insertKBFundstransfertransactionviewRecord", null);
      KBFundstransfertransactionviewDAO dao = new KBFundstransfertransactionviewDAO();
      int result = dao.insertKBFundstransfertransactionviewRecord(record);
      logger.trace("insertKBFundstransfertransactionviewRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("insertKBFundstransfertransactionviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBFundstransfertransactionviewRecord(
      KBFundstransfertransactionviewRecord record) throws Exception {
    try {
      logger.trace("updateKBFundstransfertransactionviewRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBFundstransfertransactionviewRecord", null);
      KBFundstransfertransactionviewDAO dao = new KBFundstransfertransactionviewDAO();
      boolean result = dao.updateKBFundstransfertransactionviewRecord(record);
      logger.trace("updateKBFundstransfertransactionviewRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBFundstransfertransactionviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBFundstransfertransactionviewRecordNonNull(
      KBFundstransfertransactionviewRecord inputRecord) throws Exception {
    try {
      logger.trace("updateKBFundstransfertransactionviewRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBFundstransfertransactionviewRecordNoNull", null);
      KBFundstransfertransactionviewDAO dao = new KBFundstransfertransactionviewDAO();
      KBFundstransfertransactionviewRecord dbRecord = dao.loadKBFundstransfertransactionviewRecord(inputRecord.getId());
      if (dbRecord == null) {
        throw new Exception("Record not found");
      }
      dbRecord.loadNonNullContent(inputRecord);
      boolean result = dao.updateKBFundstransfertransactionviewRecord(inputRecord);
      logger.trace("updateKBFundstransfertransactionviewRecordNoNull:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBFundstransfertransactionviewRecordNoNull" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean deleteKBFundstransfertransactionviewRecord(
      KBFundstransfertransactionviewRecord record) throws Exception {
    try {
      logger.trace("deleteKBFundstransfertransactionviewRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("deleteKBFundstransfertransactionviewRecord", null);
      KBFundstransfertransactionviewDAO dao = new KBFundstransfertransactionviewDAO();
      boolean result = dao.deleteKBFundstransfertransactionviewRecord(record);
      logger.trace("deleteKBFundstransfertransactionviewRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("deleteKBFundstransfertransactionviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }
}
