package com.key.mb.service;

import com.key.mb.common.KBService;
import com.key.mb.dao.KBMobilesessionDAO;
import com.key.mb.to.KBMobilesessionRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class KBMobilesessionService extends KBService {
  public static LogUtils logger = new LogUtils(KBMobilesessionService.class.getName());

  public KBMobilesessionRecord[] loadKBMobilesessionRecords(String query) throws Exception {
    try {
      logger.trace("loadKBMobilesessionRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilesessionRecords", null);
      KBMobilesessionDAO dao = new KBMobilesessionDAO();
      KBMobilesessionRecord[] results = dao.loadKBMobilesessionRecords(query);
      int resultRecordCount = 0;
      if (results != null) {
        resultRecordCount = results.length;
      }
      logger.trace("loadKBMobilesessionRecords:Fetched" + resultRecordCount);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return results;
    }
    catch(Exception exception) {
      logger.error("loadKBMobilesessionRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilesessionRecord loadFirstKBMobilesessionRecord(String query) throws Exception {
    try {
      logger.trace("loadKBMobilesessionRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilesessionRecords", null);
      KBMobilesessionDAO dao = new KBMobilesessionDAO();
      KBMobilesessionRecord result = dao.loadFirstKBMobilesessionRecord(query);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadFirstKBMobilesessionRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilesessionRecord searchFirstKBMobilesessionRecord(KBMobilesessionRecord record) throws
      Exception {
    try {
      logger.trace("searchFirstKBMobilesessionRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBMobilesessionRecords", null);
      KBMobilesessionDAO dao = new KBMobilesessionDAO();
      KBMobilesessionRecord[] records = dao.searchKBMobilesessionRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBMobilesessionRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilesessionRecord searchKBMobilesessionRecordExactUpper(KBMobilesessionRecord record)
      throws Exception {
    try {
      logger.trace("searchFirstKBMobilesessionRecordsExactUpper:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBMobilesessionRecordsExactUpper", null);
      KBMobilesessionDAO dao = new KBMobilesessionDAO();
      KBMobilesessionRecord[] records = dao.searchKBMobilesessionRecordsExactUpper(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBMobilesessionRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilesessionRecord[] searchKBMobilesessionRecords(KBMobilesessionRecord record) throws
      Exception {
    try {
      logger.trace("searchKBMobilesessionRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilesessionRecords", null);
      KBMobilesessionDAO dao = new KBMobilesessionDAO();
      KBMobilesessionRecord[] records = dao.searchKBMobilesessionRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return records;
    }
    catch(Exception exception) {
      logger.error("searchKBMobilesessionRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int loadKBMobilesessionRecordCount(KBMobilesessionRecord record) throws Exception {
    return loadKBMobilesessionRecordCount(record, null);
  }

  public int loadKBMobilesessionRecordCount(KBMobilesessionRecord record, String customCondition)
      throws Exception {
    try {
      logger.trace("loadKBMobilesessionRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilesessionRecordCount", null);
      KBMobilesessionDAO dao = new KBMobilesessionDAO();
      dao.setCustomCondition(customCondition);
      int resultcount = dao.loadKBMobilesessionRecordCount(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultcount;
    }
    catch(Exception exception) {
      logger.error("loadKBMobilesessionRecordCount" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilesessionRecord loadKBMobilesessionRecord(String key) throws Exception {
    try {
      logger.trace("loadKBMobilesessionRecord:" + key);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilesessionRecordCount", null);
      KBMobilesessionDAO dao = new KBMobilesessionDAO();
      KBMobilesessionRecord result = dao.loadKBMobilesessionRecord(key);
      logger.trace("loadKBMobilesessionRecord:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadKBMobilesessionRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public JSONObject getJSONKBMobilesessionRecordSearchResultByPage(KBMobilesessionRecord record,
      String offset, String maxrows, String orderBy) throws Exception {
    return getJSONKBMobilesessionRecordSearchResultByPage(record, offset, maxrows, orderBy, null);
  }

  public JSONObject getJSONKBMobilesessionRecordSearchResultByPage(KBMobilesessionRecord record,
      String offset, String maxrows, String orderBy, String customCondition) throws Exception {
    try {
      logger.trace("getJSONKBMobilesessionRecordSearchResultByPage:" + record + " Offset:" + offset + " Maxrows:" + maxrows);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("getJSONKBMobilesessionRecordSearchResult", null);
      KBMobilesessionDAO dao = new KBMobilesessionDAO();
      int totalCount = dao.loadKBMobilesessionRecordCount(record);
      dao.setLimits(offset, maxrows);
      KBMobilesessionRecord[] records = null;
      if (totalCount > 0) {
        dao.setOrderBy(orderBy);
        records = dao.searchKBMobilesessionRecords(record);
      }
      JSONObject resultObject = new JSONObject();
      resultObject.put("total",totalCount + "");
      JSONArray dataArray = new JSONArray();
      int recordCount = 0;
      if (totalCount > 0) {
        recordCount = records.length;
      }
      for (int index = 0; index < recordCount; index++) {
        dataArray.add(records[index].getJSONObjectUI());
      }
      resultObject.put("rows",dataArray);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultObject;
    }
    catch(Exception exception) {
      logger.error("getJSONKBMobilesessionRecordSearchResult" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int insertKBMobilesessionRecord(KBMobilesessionRecord record) throws Exception {
    try {
      logger.trace("insertKBMobilesessionRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("insertKBMobilesessionRecord", null);
      KBMobilesessionDAO dao = new KBMobilesessionDAO();
      int result = dao.insertKBMobilesessionRecord(record);
      logger.trace("insertKBMobilesessionRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("insertKBMobilesessionRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBMobilesessionRecord(KBMobilesessionRecord record) throws Exception {
    try {
      logger.trace("updateKBMobilesessionRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBMobilesessionRecord", null);
      KBMobilesessionDAO dao = new KBMobilesessionDAO();
      boolean result = dao.updateKBMobilesessionRecord(record);
      logger.trace("updateKBMobilesessionRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBMobilesessionRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBMobilesessionRecordNonNull(KBMobilesessionRecord inputRecord) throws
      Exception {
    try {
      logger.trace("updateKBMobilesessionRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBMobilesessionRecordNoNull", null);
      KBMobilesessionDAO dao = new KBMobilesessionDAO();
      KBMobilesessionRecord dbRecord = dao.loadKBMobilesessionRecord(inputRecord.getId());
      if (dbRecord == null) {
        throw new Exception("Record not found");
      }
      dbRecord.loadNonNullContent(inputRecord);
      boolean result = dao.updateKBMobilesessionRecord(inputRecord);
      logger.trace("updateKBMobilesessionRecordNoNull:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBMobilesessionRecordNoNull" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean deleteKBMobilesessionRecord(KBMobilesessionRecord record) throws Exception {
    try {
      logger.trace("deleteKBMobilesessionRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("deleteKBMobilesessionRecord", null);
      KBMobilesessionDAO dao = new KBMobilesessionDAO();
      boolean result = dao.deleteKBMobilesessionRecord(record);
      logger.trace("deleteKBMobilesessionRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("deleteKBMobilesessionRecord" + getStackTrace(exception));
      throw exception;
    }
  }
}
