package com.key.mb.service;

import com.key.mb.common.KBService;
import com.key.mb.dao.KBMobilemenumapDAO;
import com.key.mb.to.KBMobilemenumapRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class KBMobilemenumapService extends KBService {
  public static LogUtils logger = new LogUtils(KBMobilemenumapService.class.getName());

  public KBMobilemenumapRecord[] loadKBMobilemenumapRecords(String query) throws Exception {
    try {
      logger.trace("loadKBMobilemenumapRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilemenumapRecords", null);
      KBMobilemenumapDAO dao = new KBMobilemenumapDAO();
      KBMobilemenumapRecord[] results = dao.loadKBMobilemenumapRecords(query);
      int resultRecordCount = 0;
      if (results != null) {
        resultRecordCount = results.length;
      }
      logger.trace("loadKBMobilemenumapRecords:Fetched" + resultRecordCount);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return results;
    }
    catch(Exception exception) {
      logger.error("loadKBMobilemenumapRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilemenumapRecord loadFirstKBMobilemenumapRecord(String query) throws Exception {
    try {
      logger.trace("loadKBMobilemenumapRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilemenumapRecords", null);
      KBMobilemenumapDAO dao = new KBMobilemenumapDAO();
      KBMobilemenumapRecord result = dao.loadFirstKBMobilemenumapRecord(query);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadFirstKBMobilemenumapRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilemenumapRecord searchFirstKBMobilemenumapRecord(KBMobilemenumapRecord record) throws
      Exception {
    try {
      logger.trace("searchFirstKBMobilemenumapRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBMobilemenumapRecords", null);
      KBMobilemenumapDAO dao = new KBMobilemenumapDAO();
      KBMobilemenumapRecord[] records = dao.searchKBMobilemenumapRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBMobilemenumapRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilemenumapRecord searchKBMobilemenumapRecordExactUpper(KBMobilemenumapRecord record)
      throws Exception {
    try {
      logger.trace("searchFirstKBMobilemenumapRecordsExactUpper:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBMobilemenumapRecordsExactUpper", null);
      KBMobilemenumapDAO dao = new KBMobilemenumapDAO();
      KBMobilemenumapRecord[] records = dao.searchKBMobilemenumapRecordsExactUpper(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBMobilemenumapRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilemenumapRecord[] searchKBMobilemenumapRecords(KBMobilemenumapRecord record) throws
      Exception {
    try {
      logger.trace("searchKBMobilemenumapRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilemenumapRecords", null);
      KBMobilemenumapDAO dao = new KBMobilemenumapDAO();
      KBMobilemenumapRecord[] records = dao.searchKBMobilemenumapRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return records;
    }
    catch(Exception exception) {
      logger.error("searchKBMobilemenumapRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int loadKBMobilemenumapRecordCount(KBMobilemenumapRecord record) throws Exception {
    return loadKBMobilemenumapRecordCount(record, null);
  }

  public int loadKBMobilemenumapRecordCount(KBMobilemenumapRecord record, String customCondition)
      throws Exception {
    try {
      logger.trace("loadKBMobilemenumapRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilemenumapRecordCount", null);
      KBMobilemenumapDAO dao = new KBMobilemenumapDAO();
      dao.setCustomCondition(customCondition);
      int resultcount = dao.loadKBMobilemenumapRecordCount(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultcount;
    }
    catch(Exception exception) {
      logger.error("loadKBMobilemenumapRecordCount" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilemenumapRecord loadKBMobilemenumapRecord(String key) throws Exception {
    try {
      logger.trace("loadKBMobilemenumapRecord:" + key);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilemenumapRecordCount", null);
      KBMobilemenumapDAO dao = new KBMobilemenumapDAO();
      KBMobilemenumapRecord result = dao.loadKBMobilemenumapRecord(key);
      logger.trace("loadKBMobilemenumapRecord:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadKBMobilemenumapRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public JSONObject getJSONKBMobilemenumapRecordSearchResultByPage(KBMobilemenumapRecord record,
      String offset, String maxrows, String orderBy) throws Exception {
    return getJSONKBMobilemenumapRecordSearchResultByPage(record, offset, maxrows, orderBy, null);
  }

  public JSONObject getJSONKBMobilemenumapRecordSearchResultByPage(KBMobilemenumapRecord record,
      String offset, String maxrows, String orderBy, String customCondition) throws Exception {
    try {
      logger.trace("getJSONKBMobilemenumapRecordSearchResultByPage:" + record + " Offset:" + offset + " Maxrows:" + maxrows);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("getJSONKBMobilemenumapRecordSearchResult", null);
      KBMobilemenumapDAO dao = new KBMobilemenumapDAO();
      int totalCount = dao.loadKBMobilemenumapRecordCount(record);
      dao.setLimits(offset, maxrows);
      KBMobilemenumapRecord[] records = null;
      if (totalCount > 0) {
        dao.setOrderBy(orderBy);
        records = dao.searchKBMobilemenumapRecords(record);
      }
      JSONObject resultObject = new JSONObject();
      resultObject.put("total",totalCount + "");
      JSONArray dataArray = new JSONArray();
      int recordCount = 0;
      if (totalCount > 0) {
        recordCount = records.length;
      }
      for (int index = 0; index < recordCount; index++) {
        dataArray.add(records[index].getJSONObjectUI());
      }
      resultObject.put("rows",dataArray);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultObject;
    }
    catch(Exception exception) {
      logger.error("getJSONKBMobilemenumapRecordSearchResult" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int insertKBMobilemenumapRecord(KBMobilemenumapRecord record) throws Exception {
    try {
      logger.trace("insertKBMobilemenumapRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("insertKBMobilemenumapRecord", null);
      KBMobilemenumapDAO dao = new KBMobilemenumapDAO();
      int result = dao.insertKBMobilemenumapRecord(record);
      logger.trace("insertKBMobilemenumapRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("insertKBMobilemenumapRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBMobilemenumapRecord(KBMobilemenumapRecord record) throws Exception {
    try {
      logger.trace("updateKBMobilemenumapRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBMobilemenumapRecord", null);
      KBMobilemenumapDAO dao = new KBMobilemenumapDAO();
      boolean result = dao.updateKBMobilemenumapRecord(record);
      logger.trace("updateKBMobilemenumapRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBMobilemenumapRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBMobilemenumapRecordNonNull(KBMobilemenumapRecord inputRecord) throws
      Exception {
    try {
      logger.trace("updateKBMobilemenumapRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBMobilemenumapRecordNoNull", null);
      KBMobilemenumapDAO dao = new KBMobilemenumapDAO();
      KBMobilemenumapRecord dbRecord = dao.loadKBMobilemenumapRecord(inputRecord.getId());
      if (dbRecord == null) {
        throw new Exception("Record not found");
      }
      dbRecord.loadNonNullContent(inputRecord);
      boolean result = dao.updateKBMobilemenumapRecord(inputRecord);
      logger.trace("updateKBMobilemenumapRecordNoNull:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBMobilemenumapRecordNoNull" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean deleteKBMobilemenumapRecord(KBMobilemenumapRecord record) throws Exception {
    try {
      logger.trace("deleteKBMobilemenumapRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("deleteKBMobilemenumapRecord", null);
      KBMobilemenumapDAO dao = new KBMobilemenumapDAO();
      boolean result = dao.deleteKBMobilemenumapRecord(record);
      logger.trace("deleteKBMobilemenumapRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("deleteKBMobilemenumapRecord" + getStackTrace(exception));
      throw exception;
    }
  }
}
