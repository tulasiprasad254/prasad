package com.key.mb.service;

import com.key.mb.common.KBService;
import com.key.mb.dao.KBControllermapDAO;
import com.key.mb.to.KBControllermapRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class KBControllermapService extends KBService {
  public static LogUtils logger = new LogUtils(KBControllermapService.class.getName());

  public KBControllermapRecord[] loadKBControllermapRecords(String query) throws Exception {
    try {
      logger.trace("loadKBControllermapRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBControllermapRecords", null);
      KBControllermapDAO dao = new KBControllermapDAO();
      KBControllermapRecord[] results = dao.loadKBControllermapRecords(query);
      int resultRecordCount = 0;
      if (results != null) {
        resultRecordCount = results.length;
      }
      logger.trace("loadKBControllermapRecords:Fetched" + resultRecordCount);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return results;
    }
    catch(Exception exception) {
      logger.error("loadKBControllermapRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBControllermapRecord loadFirstKBControllermapRecord(String query) throws Exception {
    try {
      logger.trace("loadKBControllermapRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBControllermapRecords", null);
      KBControllermapDAO dao = new KBControllermapDAO();
      KBControllermapRecord result = dao.loadFirstKBControllermapRecord(query);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadFirstKBControllermapRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBControllermapRecord searchFirstKBControllermapRecord(KBControllermapRecord record) throws
      Exception {
    try {
      logger.trace("searchFirstKBControllermapRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBControllermapRecords", null);
      KBControllermapDAO dao = new KBControllermapDAO();
      KBControllermapRecord[] records = dao.searchKBControllermapRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBControllermapRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBControllermapRecord searchKBControllermapRecordExactUpper(KBControllermapRecord record)
      throws Exception {
    try {
      logger.trace("searchFirstKBControllermapRecordsExactUpper:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBControllermapRecordsExactUpper", null);
      KBControllermapDAO dao = new KBControllermapDAO();
      KBControllermapRecord[] records = dao.searchKBControllermapRecordsExactUpper(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBControllermapRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBControllermapRecord[] searchKBControllermapRecords(KBControllermapRecord record) throws
      Exception {
    try {
      logger.trace("searchKBControllermapRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBControllermapRecords", null);
      KBControllermapDAO dao = new KBControllermapDAO();
      KBControllermapRecord[] records = dao.searchKBControllermapRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return records;
    }
    catch(Exception exception) {
      logger.error("searchKBControllermapRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int loadKBControllermapRecordCount(KBControllermapRecord record) throws Exception {
    return loadKBControllermapRecordCount(record, null);
  }

  public int loadKBControllermapRecordCount(KBControllermapRecord record, String customCondition)
      throws Exception {
    try {
      logger.trace("loadKBControllermapRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBControllermapRecordCount", null);
      KBControllermapDAO dao = new KBControllermapDAO();
      dao.setCustomCondition(customCondition);
      int resultcount = dao.loadKBControllermapRecordCount(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultcount;
    }
    catch(Exception exception) {
      logger.error("loadKBControllermapRecordCount" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBControllermapRecord loadKBControllermapRecord(String key) throws Exception {
    try {
      logger.trace("loadKBControllermapRecord:" + key);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBControllermapRecordCount", null);
      KBControllermapDAO dao = new KBControllermapDAO();
      KBControllermapRecord result = dao.loadKBControllermapRecord(key);
      logger.trace("loadKBControllermapRecord:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadKBControllermapRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public JSONObject getJSONKBControllermapRecordSearchResultByPage(KBControllermapRecord record,
      String offset, String maxrows, String orderBy) throws Exception {
    return getJSONKBControllermapRecordSearchResultByPage(record, offset, maxrows, orderBy, null);
  }

  public JSONObject getJSONKBControllermapRecordSearchResultByPage(KBControllermapRecord record,
      String offset, String maxrows, String orderBy, String customCondition) throws Exception {
    try {
      logger.trace("getJSONKBControllermapRecordSearchResultByPage:" + record + " Offset:" + offset + " Maxrows:" + maxrows);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("getJSONKBControllermapRecordSearchResult", null);
      KBControllermapDAO dao = new KBControllermapDAO();
      int totalCount = dao.loadKBControllermapRecordCount(record);
      dao.setLimits(offset, maxrows);
      KBControllermapRecord[] records = null;
      if (totalCount > 0) {
        dao.setOrderBy(orderBy);
        records = dao.searchKBControllermapRecords(record);
      }
      JSONObject resultObject = new JSONObject();
      resultObject.put("total",totalCount + "");
      JSONArray dataArray = new JSONArray();
      int recordCount = 0;
      if (totalCount > 0) {
        recordCount = records.length;
      }
      for (int index = 0; index < recordCount; index++) {
        dataArray.add(records[index].getJSONObjectUI());
      }
      resultObject.put("rows",dataArray);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultObject;
    }
    catch(Exception exception) {
      logger.error("getJSONKBControllermapRecordSearchResult" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int insertKBControllermapRecord(KBControllermapRecord record) throws Exception {
    try {
      logger.trace("insertKBControllermapRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("insertKBControllermapRecord", null);
      KBControllermapDAO dao = new KBControllermapDAO();
      int result = dao.insertKBControllermapRecord(record);
      logger.trace("insertKBControllermapRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("insertKBControllermapRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBControllermapRecord(KBControllermapRecord record) throws Exception {
    try {
      logger.trace("updateKBControllermapRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBControllermapRecord", null);
      KBControllermapDAO dao = new KBControllermapDAO();
      boolean result = dao.updateKBControllermapRecord(record);
      logger.trace("updateKBControllermapRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBControllermapRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBControllermapRecordNonNull(KBControllermapRecord inputRecord) throws
      Exception {
    try {
      logger.trace("updateKBControllermapRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBControllermapRecordNoNull", null);
      KBControllermapDAO dao = new KBControllermapDAO();
      KBControllermapRecord dbRecord = dao.loadKBControllermapRecord(inputRecord.getId());
      if (dbRecord == null) {
        throw new Exception("Record not found");
      }
      dbRecord.loadNonNullContent(inputRecord);
      boolean result = dao.updateKBControllermapRecord(inputRecord);
      logger.trace("updateKBControllermapRecordNoNull:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBControllermapRecordNoNull" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean deleteKBControllermapRecord(KBControllermapRecord record) throws Exception {
    try {
      logger.trace("deleteKBControllermapRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("deleteKBControllermapRecord", null);
      KBControllermapDAO dao = new KBControllermapDAO();
      boolean result = dao.deleteKBControllermapRecord(record);
      logger.trace("deleteKBControllermapRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("deleteKBControllermapRecord" + getStackTrace(exception));
      throw exception;
    }
  }
}
