package com.key.mb.service;

import com.key.mb.common.KBService;
import com.key.mb.dao.KBCustomercategoryDAO;
import com.key.mb.to.KBCustomercategoryRecord;
import com.key.utils.DateUtils;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.HashMap;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class KBCustomercategoryService extends KBService {
  public static LogUtils logger = new LogUtils(KBCustomercategoryService.class.getName());

  public KBCustomercategoryRecord[] loadKBCustomercategoryRecords(String query) throws Exception {
    try {
      logger.trace("loadKBCustomercategoryRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBCustomercategoryRecords", null);
      KBCustomercategoryDAO dao = new KBCustomercategoryDAO();
      KBCustomercategoryRecord[] results = dao.loadKBCustomercategoryRecords(query);
      int resultRecordCount = 0;
      if (results != null) {
        resultRecordCount = results.length;
      }
      logger.trace("loadKBCustomercategoryRecords:Fetched" + resultRecordCount);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return results;
    }
    catch(Exception exception) {
      logger.error("loadKBCustomercategoryRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBCustomercategoryRecord loadFirstKBCustomercategoryRecord(String query) throws Exception {
    try {
      logger.trace("loadKBCustomercategoryRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBCustomercategoryRecords", null);
      KBCustomercategoryDAO dao = new KBCustomercategoryDAO();
      KBCustomercategoryRecord result = dao.loadFirstKBCustomercategoryRecord(query);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadFirstKBCustomercategoryRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBCustomercategoryRecord searchFirstKBCustomercategoryRecord(
      KBCustomercategoryRecord record) throws Exception {
    try {
      logger.trace("searchFirstKBCustomercategoryRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBCustomercategoryRecords", null);
      KBCustomercategoryDAO dao = new KBCustomercategoryDAO();
      KBCustomercategoryRecord[] records = dao.searchKBCustomercategoryRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBCustomercategoryRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBCustomercategoryRecord searchKBCustomercategoryRecordExactUpper(
      KBCustomercategoryRecord record) throws Exception {
    try {
      logger.trace("searchFirstKBCustomercategoryRecordsExactUpper:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBCustomercategoryRecordsExactUpper", null);
      KBCustomercategoryDAO dao = new KBCustomercategoryDAO();
      KBCustomercategoryRecord[] records = dao.searchKBCustomercategoryRecordsExactUpper(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBCustomercategoryRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBCustomercategoryRecord[] searchKBCustomercategoryRecords(KBCustomercategoryRecord record)
      throws Exception {
    try {
      logger.trace("searchKBCustomercategoryRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBCustomercategoryRecords", null);
      KBCustomercategoryDAO dao = new KBCustomercategoryDAO();
      KBCustomercategoryRecord[] records = dao.searchKBCustomercategoryRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return records;
    }
    catch(Exception exception) {
      logger.error("searchKBCustomercategoryRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int loadKBCustomercategoryRecordCount(KBCustomercategoryRecord record) throws Exception {
    return loadKBCustomercategoryRecordCount(record, null);
  }

  public int loadKBCustomercategoryRecordCount(KBCustomercategoryRecord record,
      String customCondition) throws Exception {
    try {
      logger.trace("loadKBCustomercategoryRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBCustomercategoryRecordCount", null);
      KBCustomercategoryDAO dao = new KBCustomercategoryDAO();
      dao.setCustomCondition(customCondition);
      int resultcount = dao.loadKBCustomercategoryRecordCount(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultcount;
    }
    catch(Exception exception) {
      logger.error("loadKBCustomercategoryRecordCount" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBCustomercategoryRecord loadKBCustomercategoryRecord(String key) throws Exception {
    try {
      logger.trace("loadKBCustomercategoryRecord:" + key);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBCustomercategoryRecordCount", null);
      KBCustomercategoryDAO dao = new KBCustomercategoryDAO();
      KBCustomercategoryRecord result = dao.loadKBCustomercategoryRecord(key);
      logger.trace("loadKBCustomercategoryRecord:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadKBCustomercategoryRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public JSONObject getJSONKBCustomercategoryRecordSearchResultByPage(
      KBCustomercategoryRecord record, String offset, String maxrows, String orderBy) throws
      Exception {
    return getJSONKBCustomercategoryRecordSearchResultByPage(record, offset, maxrows, orderBy, null);
  }

  public JSONObject getJSONKBCustomercategoryRecordSearchResultByPage(
      KBCustomercategoryRecord record, String offset, String maxrows, String orderBy,
      String customCondition) throws Exception {
    try {
      logger.trace("getJSONKBCustomercategoryRecordSearchResultByPage:" + record + " Offset:" + offset + " Maxrows:" + maxrows);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("getJSONKBCustomercategoryRecordSearchResult", null);
      KBCustomercategoryDAO dao = new KBCustomercategoryDAO();
      int totalCount = dao.loadKBCustomercategoryRecordCount(record);
      dao.setLimits(offset, maxrows);
      KBCustomercategoryRecord[] records = null;
      if (totalCount > 0) {
        dao.setOrderBy(orderBy);
        records = dao.searchKBCustomercategoryRecords(record);
      }
      JSONObject resultObject = new JSONObject();
      resultObject.put("total",totalCount + "");
      JSONArray dataArray = new JSONArray();
      int recordCount = 0;
      if (totalCount > 0) {
        recordCount = records.length;
      }
      for (int index = 0; index < recordCount; index++) {
        dataArray.add(records[index].getJSONObjectUI());
      }
      resultObject.put("rows",dataArray);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultObject;
    }
    catch(Exception exception) {
      logger.error("getJSONKBCustomercategoryRecordSearchResult" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int insertKBCustomercategoryRecord(KBCustomercategoryRecord record) throws Exception {
    try {
      logger.trace("insertKBCustomercategoryRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("insertKBCustomercategoryRecord", null);
      KBCustomercategoryDAO dao = new KBCustomercategoryDAO();
      int result = dao.insertKBCustomercategoryRecord(record);
      logger.trace("insertKBCustomercategoryRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomercategoryService", record.getId() + "", "Create", record.getCreatedby(), "Created");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("insertKBCustomercategoryRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBCustomercategoryRecord(KBCustomercategoryRecord record) throws Exception {
    try {
      logger.trace("updateKBCustomercategoryRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBCustomercategoryRecord", null);
      KBCustomercategoryDAO dao = new KBCustomercategoryDAO();
      boolean result = dao.updateKBCustomercategoryRecord(record);
      logger.trace("updateKBCustomercategoryRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomercategoryService", record.getId() + "", "Update", record.getModifiedby(), "Update");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBCustomercategoryRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBCustomercategoryRecordNonNull(KBCustomercategoryRecord inputRecord) throws
      Exception {
    try {
      logger.trace("updateKBCustomercategoryRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBCustomercategoryRecordNoNull", null);
      KBCustomercategoryDAO dao = new KBCustomercategoryDAO();
      KBCustomercategoryRecord dbRecord = dao.loadKBCustomercategoryRecord(inputRecord.getId());
      if (dbRecord == null) {
        throw new Exception("Record not found");
      }
      dbRecord.loadNonNullContent(inputRecord);
      boolean result = dao.updateKBCustomercategoryRecord(inputRecord);
      createMakerCheckerAuditEntry("KBCustomercategoryService", inputRecord.getId() + "", "Update", inputRecord.getModifiedby(), "UpdateNoNull");
      logger.trace("updateKBCustomercategoryRecordNoNull:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBCustomercategoryRecordNoNull" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean deleteKBCustomercategoryRecord(KBCustomercategoryRecord record) throws Exception {
    try {
      logger.trace("deleteKBCustomercategoryRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("deleteKBCustomercategoryRecord", null);
      KBCustomercategoryDAO dao = new KBCustomercategoryDAO();
      boolean result = dao.deleteKBCustomercategoryRecord(record);
      logger.trace("deleteKBCustomercategoryRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomercategoryService", record.getId(), "Delete", null, "Deleted");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("deleteKBCustomercategoryRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean approveKBCustomercategoryRecord(KBCustomercategoryRecord inputRecord,
      String updateId, String comment) throws Exception {
    try {
      logger.trace("approveKBCustomercategoryRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("approveKBCustomercategoryRecord", null);
      KBCustomercategoryDAO dao = new KBCustomercategoryDAO();
      KBCustomercategoryRecord updateRecord = dao.loadKBCustomercategoryRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForApproval(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot approve - Invalid Status for Approval");
      }
      if (StringUtils.isSame(updateRecord.getMadeby(), updateId)) {
        throw new Exception("MF-ERR-CA-MCS102:Cannot Approve. Maker Checker cannot be same");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("1");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBCustomercategoryRecord(updateRecord);
      logger.trace("approveKBCustomercategoryRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomercategoryService", updateRecord.getId(), "Approve", updateId, comment);
      HashMap approveEventMap = callActionEvent("Event_OnApprovalOf_KBCustomercategoryRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("approveKBCustomercategoryRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean submitKBCustomercategoryRecord(KBCustomercategoryRecord inputRecord,
      String updateId, String comment) throws Exception {
    try {
      logger.trace("submitKBCustomercategoryRecordNoNull:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("submitKBCustomercategoryRecordNoNull", null);
      KBCustomercategoryDAO dao = new KBCustomercategoryDAO();
      KBCustomercategoryRecord updateRecord = dao.loadKBCustomercategoryRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForSubmission(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CS-IS101:Cannot submit - Invalid Status for Submission");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("4");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBCustomercategoryRecord(updateRecord);
      logger.trace("approveKBCustomercategoryRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomercategoryService", updateRecord.getId(), "Submit", updateId, comment);
      HashMap submitEventMap = callActionEvent("Event_OnApprovalOf_KBCustomercategoryRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("submitKBCustomercategoryRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean denyKBCustomercategoryRecord(KBCustomercategoryRecord inputRecord, String updateId,
      String comment) throws Exception {
    try {
      logger.trace("denyKBCustomercategoryRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("denyKBCustomercategoryRecord", null);
      KBCustomercategoryDAO dao = new KBCustomercategoryDAO();
      KBCustomercategoryRecord updateRecord = dao.loadKBCustomercategoryRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForDeny(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot deny - Invalid Status for Deny");
      }
      if (StringUtils.isSame(updateRecord.getMadeby(), updateId)) {
        throw new Exception("MF-ERR-CA-MCS102:Cannot Deny. Maker Checker cannot be same");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("5");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBCustomercategoryRecord(updateRecord);
      logger.trace("approveKBCustomercategoryRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomercategoryService", updateRecord.getId(), "Deny", updateId, comment);
      HashMap denyEventMap = callActionEvent("Event_OnDenyOf_KBCustomercategoryRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("denyKBCustomercategoryRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean denyPermanantKBCustomercategoryRecord(KBCustomercategoryRecord inputRecord,
      String updateId, String comment) throws Exception {
    try {
      logger.trace("denyPKBCustomercategoryRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("denyPKBCustomercategoryRecord", null);
      KBCustomercategoryDAO dao = new KBCustomercategoryDAO();
      KBCustomercategoryRecord updateRecord = dao.loadKBCustomercategoryRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForDeny(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot deny - Invalid Status for Deny");
      }
      if (StringUtils.isSame(updateRecord.getMadeby(), updateId)) {
        throw new Exception("MF-ERR-CA-MCS102:Cannot Deny. Maker Checker cannot be same");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("58");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBCustomercategoryRecord(updateRecord);
      logger.trace("approveKBCustomercategoryRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomercategoryService", updateRecord.getId(), "DenyP", updateId, comment);
      HashMap denyEventMap = callActionEvent("Event_OnDenyPOf_KBCustomercategoryRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("denyPKBCustomercategoryRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean remindApprovalKBCustomercategoryRecord(KBCustomercategoryRecord inputRecord,
      String updateId, String comment) throws Exception {
    try {
      logger.trace("remindApprovalKBCustomercategoryRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("remindApprovalKBCustomercategoryRecord", null);
      KBCustomercategoryDAO dao = new KBCustomercategoryDAO();
      KBCustomercategoryRecord updateRecord = dao.loadKBCustomercategoryRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForApproval(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot Remind - Invalid Status for Reminder");
      }
      createMakerCheckerAuditEntry("KBCustomercategoryService", updateRecord.getId(), "Approval Reminder", updateId, comment);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return true;
    }
    catch(Exception exception) {
      logger.error("remindApprovalKBCustomercategoryRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean resetApprovalKBCustomercategoryRecord(KBCustomercategoryRecord inputRecord,
      String updateId, String comment) throws Exception {
    try {
      logger.trace("resetApprovalKBCustomercategoryRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("resetApprovalKBCustomercategoryRecord", null);
      KBCustomercategoryDAO dao = new KBCustomercategoryDAO();
      KBCustomercategoryRecord updateRecord = dao.loadKBCustomercategoryRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForDeny(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot submit - Invalid Status for Reset");
      }
      updateRecord.setRstatus("0");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("0");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBCustomercategoryRecord(updateRecord);
      logger.trace("approveKBCustomercategoryRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomercategoryService", updateRecord.getId(), "Reset Approval", updateId, comment);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("resetApprovalKBCustomercategoryRecord" + getStackTrace(exception));
      throw exception;
    }
  }
}
