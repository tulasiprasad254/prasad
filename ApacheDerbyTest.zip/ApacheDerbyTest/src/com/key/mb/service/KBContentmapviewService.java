package com.key.mb.service;

import com.key.mb.common.KBService;
import com.key.mb.dao.KBContentmapviewDAO;
import com.key.mb.to.KBContentmapviewRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class KBContentmapviewService extends KBService {
  public static LogUtils logger = new LogUtils(KBContentmapviewService.class.getName());

  public KBContentmapviewRecord[] loadKBContentmapviewRecords(String query) throws Exception {
    try {
      logger.trace("loadKBContentmapviewRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBContentmapviewRecords", null);
      KBContentmapviewDAO dao = new KBContentmapviewDAO();
      KBContentmapviewRecord[] results = dao.loadKBContentmapviewRecords(query);
      int resultRecordCount = 0;
      if (results != null) {
        resultRecordCount = results.length;
      }
      logger.trace("loadKBContentmapviewRecords:Fetched" + resultRecordCount);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return results;
    }
    catch(Exception exception) {
      logger.error("loadKBContentmapviewRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBContentmapviewRecord loadFirstKBContentmapviewRecord(String query) throws Exception {
    try {
      logger.trace("loadKBContentmapviewRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBContentmapviewRecords", null);
      KBContentmapviewDAO dao = new KBContentmapviewDAO();
      KBContentmapviewRecord result = dao.loadFirstKBContentmapviewRecord(query);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadFirstKBContentmapviewRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBContentmapviewRecord searchFirstKBContentmapviewRecord(KBContentmapviewRecord record)
      throws Exception {
    try {
      logger.trace("searchFirstKBContentmapviewRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBContentmapviewRecords", null);
      KBContentmapviewDAO dao = new KBContentmapviewDAO();
      KBContentmapviewRecord[] records = dao.searchKBContentmapviewRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBContentmapviewRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBContentmapviewRecord searchKBContentmapviewRecordExactUpper(
      KBContentmapviewRecord record) throws Exception {
    try {
      logger.trace("searchFirstKBContentmapviewRecordsExactUpper:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBContentmapviewRecordsExactUpper", null);
      KBContentmapviewDAO dao = new KBContentmapviewDAO();
      KBContentmapviewRecord[] records = dao.searchKBContentmapviewRecordsExactUpper(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBContentmapviewRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBContentmapviewRecord[] searchKBContentmapviewRecords(KBContentmapviewRecord record)
      throws Exception {
    try {
      logger.trace("searchKBContentmapviewRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBContentmapviewRecords", null);
      KBContentmapviewDAO dao = new KBContentmapviewDAO();
      KBContentmapviewRecord[] records = dao.searchKBContentmapviewRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return records;
    }
    catch(Exception exception) {
      logger.error("searchKBContentmapviewRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int loadKBContentmapviewRecordCount(KBContentmapviewRecord record) throws Exception {
    return loadKBContentmapviewRecordCount(record, null);
  }

  public int loadKBContentmapviewRecordCount(KBContentmapviewRecord record, String customCondition)
      throws Exception {
    try {
      logger.trace("loadKBContentmapviewRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBContentmapviewRecordCount", null);
      KBContentmapviewDAO dao = new KBContentmapviewDAO();
      dao.setCustomCondition(customCondition);
      int resultcount = dao.loadKBContentmapviewRecordCount(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultcount;
    }
    catch(Exception exception) {
      logger.error("loadKBContentmapviewRecordCount" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBContentmapviewRecord loadKBContentmapviewRecord(String key) throws Exception {
    try {
      logger.trace("loadKBContentmapviewRecord:" + key);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBContentmapviewRecordCount", null);
      KBContentmapviewDAO dao = new KBContentmapviewDAO();
      KBContentmapviewRecord result = dao.loadKBContentmapviewRecord(key);
      logger.trace("loadKBContentmapviewRecord:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadKBContentmapviewRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public JSONObject getJSONKBContentmapviewRecordSearchResultByPage(KBContentmapviewRecord record,
      String offset, String maxrows, String orderBy) throws Exception {
    return getJSONKBContentmapviewRecordSearchResultByPage(record, offset, maxrows, orderBy, null);
  }

  public JSONObject getJSONKBContentmapviewRecordSearchResultByPage(KBContentmapviewRecord record,
      String offset, String maxrows, String orderBy, String customCondition) throws Exception {
    try {
      logger.trace("getJSONKBContentmapviewRecordSearchResultByPage:" + record + " Offset:" + offset + " Maxrows:" + maxrows);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("getJSONKBContentmapviewRecordSearchResult", null);
      KBContentmapviewDAO dao = new KBContentmapviewDAO();
      int totalCount = dao.loadKBContentmapviewRecordCount(record);
      dao.setLimits(offset, maxrows);
      KBContentmapviewRecord[] records = null;
      if (totalCount > 0) {
        dao.setOrderBy(orderBy);
        records = dao.searchKBContentmapviewRecords(record);
      }
      JSONObject resultObject = new JSONObject();
      resultObject.put("total",totalCount + "");
      JSONArray dataArray = new JSONArray();
      int recordCount = 0;
      if (totalCount > 0) {
        recordCount = records.length;
      }
      for (int index = 0; index < recordCount; index++) {
        dataArray.add(records[index].getJSONObjectUI());
      }
      resultObject.put("rows",dataArray);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultObject;
    }
    catch(Exception exception) {
      logger.error("getJSONKBContentmapviewRecordSearchResult" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int insertKBContentmapviewRecord(KBContentmapviewRecord record) throws Exception {
    try {
      logger.trace("insertKBContentmapviewRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("insertKBContentmapviewRecord", null);
      KBContentmapviewDAO dao = new KBContentmapviewDAO();
      int result = dao.insertKBContentmapviewRecord(record);
      logger.trace("insertKBContentmapviewRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("insertKBContentmapviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBContentmapviewRecord(KBContentmapviewRecord record) throws Exception {
    try {
      logger.trace("updateKBContentmapviewRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBContentmapviewRecord", null);
      KBContentmapviewDAO dao = new KBContentmapviewDAO();
      boolean result = dao.updateKBContentmapviewRecord(record);
      logger.trace("updateKBContentmapviewRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBContentmapviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBContentmapviewRecordNonNull(KBContentmapviewRecord inputRecord) throws
      Exception {
    try {
      logger.trace("updateKBContentmapviewRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBContentmapviewRecordNoNull", null);
      KBContentmapviewDAO dao = new KBContentmapviewDAO();
      KBContentmapviewRecord dbRecord = dao.loadKBContentmapviewRecord(inputRecord.getId());
      if (dbRecord == null) {
        throw new Exception("Record not found");
      }
      dbRecord.loadNonNullContent(inputRecord);
      boolean result = dao.updateKBContentmapviewRecord(inputRecord);
      logger.trace("updateKBContentmapviewRecordNoNull:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBContentmapviewRecordNoNull" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean deleteKBContentmapviewRecord(KBContentmapviewRecord record) throws Exception {
    try {
      logger.trace("deleteKBContentmapviewRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("deleteKBContentmapviewRecord", null);
      KBContentmapviewDAO dao = new KBContentmapviewDAO();
      boolean result = dao.deleteKBContentmapviewRecord(record);
      logger.trace("deleteKBContentmapviewRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("deleteKBContentmapviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }
}
