package com.key.mb.service;

import com.key.mb.common.KBService;
import com.key.mb.dao.KBAccountDAO;
import com.key.mb.to.KBAccountRecord;
import com.key.utils.DateUtils;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.HashMap;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class KBAccountService extends KBService {
  public static LogUtils logger = new LogUtils(KBAccountService.class.getName());

  public KBAccountRecord[] loadKBAccountRecords(String query) throws Exception {
    try {
      logger.trace("loadKBAccountRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBAccountRecords", null);
      KBAccountDAO dao = new KBAccountDAO();
      KBAccountRecord[] results = dao.loadKBAccountRecords(query);
      int resultRecordCount = 0;
      if (results != null) {
        resultRecordCount = results.length;
      }
      logger.trace("loadKBAccountRecords:Fetched" + resultRecordCount);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return results;
    }
    catch(Exception exception) {
      logger.error("loadKBAccountRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBAccountRecord loadFirstKBAccountRecord(String query) throws Exception {
    try {
      logger.trace("loadKBAccountRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBAccountRecords", null);
      KBAccountDAO dao = new KBAccountDAO();
      KBAccountRecord result = dao.loadFirstKBAccountRecord(query);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadFirstKBAccountRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBAccountRecord searchFirstKBAccountRecord(KBAccountRecord record) throws Exception {
    try {
      logger.trace("searchFirstKBAccountRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBAccountRecords", null);
      KBAccountDAO dao = new KBAccountDAO();
      KBAccountRecord[] records = dao.searchKBAccountRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBAccountRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBAccountRecord searchKBAccountRecordExactUpper(KBAccountRecord record) throws Exception {
    try {
      logger.trace("searchFirstKBAccountRecordsExactUpper:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBAccountRecordsExactUpper", null);
      KBAccountDAO dao = new KBAccountDAO();
      KBAccountRecord[] records = dao.searchKBAccountRecordsExactUpper(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBAccountRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBAccountRecord[] searchKBAccountRecords(KBAccountRecord record) throws Exception {
    try {
      logger.trace("searchKBAccountRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBAccountRecords", null);
      KBAccountDAO dao = new KBAccountDAO();
      KBAccountRecord[] records = dao.searchKBAccountRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return records;
    }
    catch(Exception exception) {
      logger.error("searchKBAccountRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int loadKBAccountRecordCount(KBAccountRecord record) throws Exception {
    return loadKBAccountRecordCount(record, null);
  }

  public int loadKBAccountRecordCount(KBAccountRecord record, String customCondition) throws
      Exception {
    try {
      logger.trace("loadKBAccountRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBAccountRecordCount", null);
      KBAccountDAO dao = new KBAccountDAO();
      dao.setCustomCondition(customCondition);
      int resultcount = dao.loadKBAccountRecordCount(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultcount;
    }
    catch(Exception exception) {
      logger.error("loadKBAccountRecordCount" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBAccountRecord loadKBAccountRecord(String key) throws Exception {
    try {
      logger.trace("loadKBAccountRecord:" + key);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBAccountRecordCount", null);
      KBAccountDAO dao = new KBAccountDAO();
      KBAccountRecord result = dao.loadKBAccountRecord(key);
      logger.trace("loadKBAccountRecord:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadKBAccountRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public JSONObject getJSONKBAccountRecordSearchResultByPage(KBAccountRecord record, String offset,
      String maxrows, String orderBy) throws Exception {
    return getJSONKBAccountRecordSearchResultByPage(record, offset, maxrows, orderBy, null);
  }

  public JSONObject getJSONKBAccountRecordSearchResultByPage(KBAccountRecord record, String offset,
      String maxrows, String orderBy, String customCondition) throws Exception {
    try {
      logger.trace("getJSONKBAccountRecordSearchResultByPage:" + record + " Offset:" + offset + " Maxrows:" + maxrows);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("getJSONKBAccountRecordSearchResult", null);
      KBAccountDAO dao = new KBAccountDAO();
      int totalCount = dao.loadKBAccountRecordCount(record);
      dao.setLimits(offset, maxrows);
      KBAccountRecord[] records = null;
      if (totalCount > 0) {
        dao.setOrderBy(orderBy);
        records = dao.searchKBAccountRecords(record);
      }
      JSONObject resultObject = new JSONObject();
      resultObject.put("total",totalCount + "");
      JSONArray dataArray = new JSONArray();
      int recordCount = 0;
      if (totalCount > 0) {
        recordCount = records.length;
      }
      for (int index = 0; index < recordCount; index++) {
        dataArray.add(records[index].getJSONObjectUI());
      }
      resultObject.put("rows",dataArray);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultObject;
    }
    catch(Exception exception) {
      logger.error("getJSONKBAccountRecordSearchResult" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int insertKBAccountRecord(KBAccountRecord record) throws Exception {
    try {
      logger.trace("insertKBAccountRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("insertKBAccountRecord", null);
      KBAccountDAO dao = new KBAccountDAO();
      int result = dao.insertKBAccountRecord(record);
      logger.trace("insertKBAccountRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBAccountService", record.getId() + "", "Create", record.getCreatedby(), "Created");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("insertKBAccountRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBAccountRecord(KBAccountRecord record) throws Exception {
    try {
      logger.trace("updateKBAccountRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBAccountRecord", null);
      KBAccountDAO dao = new KBAccountDAO();
      boolean result = dao.updateKBAccountRecord(record);
      logger.trace("updateKBAccountRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBAccountService", record.getId() + "", "Update", record.getModifiedby(), "Update");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBAccountRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBAccountRecordNonNull(KBAccountRecord inputRecord) throws Exception {
    try {
      logger.trace("updateKBAccountRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBAccountRecordNoNull", null);
      KBAccountDAO dao = new KBAccountDAO();
      KBAccountRecord dbRecord = dao.loadKBAccountRecord(inputRecord.getId());
      if (dbRecord == null) {
        throw new Exception("Record not found");
      }
      dbRecord.loadNonNullContent(inputRecord);
      boolean result = dao.updateKBAccountRecord(inputRecord);
      createMakerCheckerAuditEntry("KBAccountService", inputRecord.getId() + "", "Update", inputRecord.getModifiedby(), "UpdateNoNull");
      logger.trace("updateKBAccountRecordNoNull:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBAccountRecordNoNull" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean deleteKBAccountRecord(KBAccountRecord record) throws Exception {
    try {
      logger.trace("deleteKBAccountRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("deleteKBAccountRecord", null);
      KBAccountDAO dao = new KBAccountDAO();
      boolean result = dao.deleteKBAccountRecord(record);
      logger.trace("deleteKBAccountRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBAccountService", record.getId(), "Delete", null, "Deleted");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("deleteKBAccountRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean approveKBAccountRecord(KBAccountRecord inputRecord, String updateId,
      String comment) throws Exception {
    try {
      logger.trace("approveKBAccountRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("approveKBAccountRecord", null);
      KBAccountDAO dao = new KBAccountDAO();
      KBAccountRecord updateRecord = dao.loadKBAccountRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForApproval(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot approve - Invalid Status for Approval");
      }
      if (StringUtils.isSame(updateRecord.getMadeby(), updateId)) {
        throw new Exception("MF-ERR-CA-MCS102:Cannot Approve. Maker Checker cannot be same");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("1");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBAccountRecord(updateRecord);
      logger.trace("approveKBAccountRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBAccountService", updateRecord.getId(), "Approve", updateId, comment);
      HashMap approveEventMap = callActionEvent("Event_OnApprovalOf_KBAccountRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("approveKBAccountRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean submitKBAccountRecord(KBAccountRecord inputRecord, String updateId, String comment)
      throws Exception {
    try {
      logger.trace("submitKBAccountRecordNoNull:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("submitKBAccountRecordNoNull", null);
      KBAccountDAO dao = new KBAccountDAO();
      KBAccountRecord updateRecord = dao.loadKBAccountRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForSubmission(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CS-IS101:Cannot submit - Invalid Status for Submission");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("4");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBAccountRecord(updateRecord);
      logger.trace("approveKBAccountRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBAccountService", updateRecord.getId(), "Submit", updateId, comment);
      HashMap submitEventMap = callActionEvent("Event_OnApprovalOf_KBAccountRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("submitKBAccountRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean denyKBAccountRecord(KBAccountRecord inputRecord, String updateId, String comment)
      throws Exception {
    try {
      logger.trace("denyKBAccountRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("denyKBAccountRecord", null);
      KBAccountDAO dao = new KBAccountDAO();
      KBAccountRecord updateRecord = dao.loadKBAccountRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForDeny(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot deny - Invalid Status for Deny");
      }
      if (StringUtils.isSame(updateRecord.getMadeby(), updateId)) {
        throw new Exception("MF-ERR-CA-MCS102:Cannot Deny. Maker Checker cannot be same");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("5");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBAccountRecord(updateRecord);
      logger.trace("approveKBAccountRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBAccountService", updateRecord.getId(), "Deny", updateId, comment);
      HashMap denyEventMap = callActionEvent("Event_OnDenyOf_KBAccountRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("denyKBAccountRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean denyPermanantKBAccountRecord(KBAccountRecord inputRecord, String updateId,
      String comment) throws Exception {
    try {
      logger.trace("denyPKBAccountRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("denyPKBAccountRecord", null);
      KBAccountDAO dao = new KBAccountDAO();
      KBAccountRecord updateRecord = dao.loadKBAccountRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForDeny(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot deny - Invalid Status for Deny");
      }
      if (StringUtils.isSame(updateRecord.getMadeby(), updateId)) {
        throw new Exception("MF-ERR-CA-MCS102:Cannot Deny. Maker Checker cannot be same");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("58");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBAccountRecord(updateRecord);
      logger.trace("approveKBAccountRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBAccountService", updateRecord.getId(), "DenyP", updateId, comment);
      HashMap denyEventMap = callActionEvent("Event_OnDenyPOf_KBAccountRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("denyPKBAccountRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean remindApprovalKBAccountRecord(KBAccountRecord inputRecord, String updateId,
      String comment) throws Exception {
    try {
      logger.trace("remindApprovalKBAccountRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("remindApprovalKBAccountRecord", null);
      KBAccountDAO dao = new KBAccountDAO();
      KBAccountRecord updateRecord = dao.loadKBAccountRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForApproval(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot Remind - Invalid Status for Reminder");
      }
      createMakerCheckerAuditEntry("KBAccountService", updateRecord.getId(), "Approval Reminder", updateId, comment);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return true;
    }
    catch(Exception exception) {
      logger.error("remindApprovalKBAccountRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean resetApprovalKBAccountRecord(KBAccountRecord inputRecord, String updateId,
      String comment) throws Exception {
    try {
      logger.trace("resetApprovalKBAccountRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("resetApprovalKBAccountRecord", null);
      KBAccountDAO dao = new KBAccountDAO();
      KBAccountRecord updateRecord = dao.loadKBAccountRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForDeny(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot submit - Invalid Status for Reset");
      }
      updateRecord.setRstatus("0");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("0");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBAccountRecord(updateRecord);
      logger.trace("approveKBAccountRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBAccountService", updateRecord.getId(), "Reset Approval", updateId, comment);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("resetApprovalKBAccountRecord" + getStackTrace(exception));
      throw exception;
    }
  }
}
