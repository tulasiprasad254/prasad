package com.key.mb.service;

import com.key.mb.common.KBService;
import com.key.mb.dao.KBFundstransfertransactionDAO;
import com.key.mb.to.KBFundstransfertransactionRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class KBFundstransfertransactionService extends KBService {
  public static LogUtils logger = new LogUtils(KBFundstransfertransactionService.class.getName());

  public KBFundstransfertransactionRecord[] loadKBFundstransfertransactionRecords(String query)
      throws Exception {
    try {
      logger.trace("loadKBFundstransfertransactionRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBFundstransfertransactionRecords", null);
      KBFundstransfertransactionDAO dao = new KBFundstransfertransactionDAO();
      KBFundstransfertransactionRecord[] results = dao.loadKBFundstransfertransactionRecords(query);
      int resultRecordCount = 0;
      if (results != null) {
        resultRecordCount = results.length;
      }
      logger.trace("loadKBFundstransfertransactionRecords:Fetched" + resultRecordCount);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return results;
    }
    catch(Exception exception) {
      logger.error("loadKBFundstransfertransactionRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBFundstransfertransactionRecord loadFirstKBFundstransfertransactionRecord(String query)
      throws Exception {
    try {
      logger.trace("loadKBFundstransfertransactionRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBFundstransfertransactionRecords", null);
      KBFundstransfertransactionDAO dao = new KBFundstransfertransactionDAO();
      KBFundstransfertransactionRecord result = dao.loadFirstKBFundstransfertransactionRecord(query);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadFirstKBFundstransfertransactionRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBFundstransfertransactionRecord searchFirstKBFundstransfertransactionRecord(
      KBFundstransfertransactionRecord record) throws Exception {
    try {
      logger.trace("searchFirstKBFundstransfertransactionRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBFundstransfertransactionRecords", null);
      KBFundstransfertransactionDAO dao = new KBFundstransfertransactionDAO();
      KBFundstransfertransactionRecord[] records = dao.searchKBFundstransfertransactionRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBFundstransfertransactionRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBFundstransfertransactionRecord searchKBFundstransfertransactionRecordExactUpper(
      KBFundstransfertransactionRecord record) throws Exception {
    try {
      logger.trace("searchFirstKBFundstransfertransactionRecordsExactUpper:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBFundstransfertransactionRecordsExactUpper", null);
      KBFundstransfertransactionDAO dao = new KBFundstransfertransactionDAO();
      KBFundstransfertransactionRecord[] records = dao.searchKBFundstransfertransactionRecordsExactUpper(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBFundstransfertransactionRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBFundstransfertransactionRecord[] searchKBFundstransfertransactionRecords(
      KBFundstransfertransactionRecord record) throws Exception {
    try {
      logger.trace("searchKBFundstransfertransactionRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBFundstransfertransactionRecords", null);
      KBFundstransfertransactionDAO dao = new KBFundstransfertransactionDAO();
      KBFundstransfertransactionRecord[] records = dao.searchKBFundstransfertransactionRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return records;
    }
    catch(Exception exception) {
      logger.error("searchKBFundstransfertransactionRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int loadKBFundstransfertransactionRecordCount(KBFundstransfertransactionRecord record)
      throws Exception {
    return loadKBFundstransfertransactionRecordCount(record, null);
  }

  public int loadKBFundstransfertransactionRecordCount(KBFundstransfertransactionRecord record,
      String customCondition) throws Exception {
    try {
      logger.trace("loadKBFundstransfertransactionRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBFundstransfertransactionRecordCount", null);
      KBFundstransfertransactionDAO dao = new KBFundstransfertransactionDAO();
      dao.setCustomCondition(customCondition);
      int resultcount = dao.loadKBFundstransfertransactionRecordCount(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultcount;
    }
    catch(Exception exception) {
      logger.error("loadKBFundstransfertransactionRecordCount" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBFundstransfertransactionRecord loadKBFundstransfertransactionRecord(String key) throws
      Exception {
    try {
      logger.trace("loadKBFundstransfertransactionRecord:" + key);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBFundstransfertransactionRecordCount", null);
      KBFundstransfertransactionDAO dao = new KBFundstransfertransactionDAO();
      KBFundstransfertransactionRecord result = dao.loadKBFundstransfertransactionRecord(key);
      logger.trace("loadKBFundstransfertransactionRecord:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadKBFundstransfertransactionRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public JSONObject getJSONKBFundstransfertransactionRecordSearchResultByPage(
      KBFundstransfertransactionRecord record, String offset, String maxrows, String orderBy) throws
      Exception {
    return getJSONKBFundstransfertransactionRecordSearchResultByPage(record, offset, maxrows, orderBy, null);
  }

  public JSONObject getJSONKBFundstransfertransactionRecordSearchResultByPage(
      KBFundstransfertransactionRecord record, String offset, String maxrows, String orderBy,
      String customCondition) throws Exception {
    try {
      logger.trace("getJSONKBFundstransfertransactionRecordSearchResultByPage:" + record + " Offset:" + offset + " Maxrows:" + maxrows);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("getJSONKBFundstransfertransactionRecordSearchResult", null);
      KBFundstransfertransactionDAO dao = new KBFundstransfertransactionDAO();
      int totalCount = dao.loadKBFundstransfertransactionRecordCount(record);
      dao.setLimits(offset, maxrows);
      KBFundstransfertransactionRecord[] records = null;
      if (totalCount > 0) {
        dao.setOrderBy(orderBy);
        records = dao.searchKBFundstransfertransactionRecords(record);
      }
      JSONObject resultObject = new JSONObject();
      resultObject.put("total",totalCount + "");
      JSONArray dataArray = new JSONArray();
      int recordCount = 0;
      if (totalCount > 0) {
        recordCount = records.length;
      }
      for (int index = 0; index < recordCount; index++) {
        dataArray.add(records[index].getJSONObjectUI());
      }
      resultObject.put("rows",dataArray);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultObject;
    }
    catch(Exception exception) {
      logger.error("getJSONKBFundstransfertransactionRecordSearchResult" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int insertKBFundstransfertransactionRecord(KBFundstransfertransactionRecord record) throws
      Exception {
    try {
      logger.trace("insertKBFundstransfertransactionRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("insertKBFundstransfertransactionRecord", null);
      KBFundstransfertransactionDAO dao = new KBFundstransfertransactionDAO();
      int result = dao.insertKBFundstransfertransactionRecord(record);
      logger.trace("insertKBFundstransfertransactionRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("insertKBFundstransfertransactionRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBFundstransfertransactionRecord(KBFundstransfertransactionRecord record)
      throws Exception {
    try {
      logger.trace("updateKBFundstransfertransactionRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBFundstransfertransactionRecord", null);
      KBFundstransfertransactionDAO dao = new KBFundstransfertransactionDAO();
      boolean result = dao.updateKBFundstransfertransactionRecord(record);
      logger.trace("updateKBFundstransfertransactionRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBFundstransfertransactionRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBFundstransfertransactionRecordNonNull(
      KBFundstransfertransactionRecord inputRecord) throws Exception {
    try {
      logger.trace("updateKBFundstransfertransactionRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBFundstransfertransactionRecordNoNull", null);
      KBFundstransfertransactionDAO dao = new KBFundstransfertransactionDAO();
      KBFundstransfertransactionRecord dbRecord = dao.loadKBFundstransfertransactionRecord(inputRecord.getId());
      if (dbRecord == null) {
        throw new Exception("Record not found");
      }
      dbRecord.loadNonNullContent(inputRecord);
      boolean result = dao.updateKBFundstransfertransactionRecord(inputRecord);
      logger.trace("updateKBFundstransfertransactionRecordNoNull:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBFundstransfertransactionRecordNoNull" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean deleteKBFundstransfertransactionRecord(KBFundstransfertransactionRecord record)
      throws Exception {
    try {
      logger.trace("deleteKBFundstransfertransactionRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("deleteKBFundstransfertransactionRecord", null);
      KBFundstransfertransactionDAO dao = new KBFundstransfertransactionDAO();
      boolean result = dao.deleteKBFundstransfertransactionRecord(record);
      logger.trace("deleteKBFundstransfertransactionRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("deleteKBFundstransfertransactionRecord" + getStackTrace(exception));
      throw exception;
    }
  }
}
