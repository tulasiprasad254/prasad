package com.key.mb.service;

import com.key.mb.common.KBService;
import com.key.mb.dao.KBMobilejsonrequestDAO;
import com.key.mb.to.KBMobilejsonrequestRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class KBMobilejsonrequestService extends KBService {
  public static LogUtils logger = new LogUtils(KBMobilejsonrequestService.class.getName());

  public KBMobilejsonrequestRecord[] loadKBMobilejsonrequestRecords(String query) throws Exception {
    try {
      logger.trace("loadKBMobilejsonrequestRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilejsonrequestRecords", null);
      KBMobilejsonrequestDAO dao = new KBMobilejsonrequestDAO();
      KBMobilejsonrequestRecord[] results = dao.loadKBMobilejsonrequestRecords(query);
      int resultRecordCount = 0;
      if (results != null) {
        resultRecordCount = results.length;
      }
      logger.trace("loadKBMobilejsonrequestRecords:Fetched" + resultRecordCount);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return results;
    }
    catch(Exception exception) {
      logger.error("loadKBMobilejsonrequestRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilejsonrequestRecord loadFirstKBMobilejsonrequestRecord(String query) throws
      Exception {
    try {
      logger.trace("loadKBMobilejsonrequestRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilejsonrequestRecords", null);
      KBMobilejsonrequestDAO dao = new KBMobilejsonrequestDAO();
      KBMobilejsonrequestRecord result = dao.loadFirstKBMobilejsonrequestRecord(query);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadFirstKBMobilejsonrequestRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilejsonrequestRecord searchFirstKBMobilejsonrequestRecord(
      KBMobilejsonrequestRecord record) throws Exception {
    try {
      logger.trace("searchFirstKBMobilejsonrequestRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBMobilejsonrequestRecords", null);
      KBMobilejsonrequestDAO dao = new KBMobilejsonrequestDAO();
      KBMobilejsonrequestRecord[] records = dao.searchKBMobilejsonrequestRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBMobilejsonrequestRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilejsonrequestRecord searchKBMobilejsonrequestRecordExactUpper(
      KBMobilejsonrequestRecord record) throws Exception {
    try {
      logger.trace("searchFirstKBMobilejsonrequestRecordsExactUpper:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBMobilejsonrequestRecordsExactUpper", null);
      KBMobilejsonrequestDAO dao = new KBMobilejsonrequestDAO();
      KBMobilejsonrequestRecord[] records = dao.searchKBMobilejsonrequestRecordsExactUpper(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBMobilejsonrequestRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilejsonrequestRecord[] searchKBMobilejsonrequestRecords(
      KBMobilejsonrequestRecord record) throws Exception {
    try {
      logger.trace("searchKBMobilejsonrequestRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilejsonrequestRecords", null);
      KBMobilejsonrequestDAO dao = new KBMobilejsonrequestDAO();
      KBMobilejsonrequestRecord[] records = dao.searchKBMobilejsonrequestRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return records;
    }
    catch(Exception exception) {
      logger.error("searchKBMobilejsonrequestRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int loadKBMobilejsonrequestRecordCount(KBMobilejsonrequestRecord record) throws Exception {
    return loadKBMobilejsonrequestRecordCount(record, null);
  }

  public int loadKBMobilejsonrequestRecordCount(KBMobilejsonrequestRecord record,
      String customCondition) throws Exception {
    try {
      logger.trace("loadKBMobilejsonrequestRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilejsonrequestRecordCount", null);
      KBMobilejsonrequestDAO dao = new KBMobilejsonrequestDAO();
      dao.setCustomCondition(customCondition);
      int resultcount = dao.loadKBMobilejsonrequestRecordCount(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultcount;
    }
    catch(Exception exception) {
      logger.error("loadKBMobilejsonrequestRecordCount" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilejsonrequestRecord loadKBMobilejsonrequestRecord(String key) throws Exception {
    try {
      logger.trace("loadKBMobilejsonrequestRecord:" + key);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilejsonrequestRecordCount", null);
      KBMobilejsonrequestDAO dao = new KBMobilejsonrequestDAO();
      KBMobilejsonrequestRecord result = dao.loadKBMobilejsonrequestRecord(key);
      logger.trace("loadKBMobilejsonrequestRecord:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadKBMobilejsonrequestRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public JSONObject getJSONKBMobilejsonrequestRecordSearchResultByPage(
      KBMobilejsonrequestRecord record, String offset, String maxrows, String orderBy) throws
      Exception {
    return getJSONKBMobilejsonrequestRecordSearchResultByPage(record, offset, maxrows, orderBy, null);
  }

  public JSONObject getJSONKBMobilejsonrequestRecordSearchResultByPage(
      KBMobilejsonrequestRecord record, String offset, String maxrows, String orderBy,
      String customCondition) throws Exception {
    try {
      logger.trace("getJSONKBMobilejsonrequestRecordSearchResultByPage:" + record + " Offset:" + offset + " Maxrows:" + maxrows);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("getJSONKBMobilejsonrequestRecordSearchResult", null);
      KBMobilejsonrequestDAO dao = new KBMobilejsonrequestDAO();
      int totalCount = dao.loadKBMobilejsonrequestRecordCount(record);
      dao.setLimits(offset, maxrows);
      KBMobilejsonrequestRecord[] records = null;
      if (totalCount > 0) {
        dao.setOrderBy(orderBy);
        records = dao.searchKBMobilejsonrequestRecords(record);
      }
      JSONObject resultObject = new JSONObject();
      resultObject.put("total",totalCount + "");
      JSONArray dataArray = new JSONArray();
      int recordCount = 0;
      if (totalCount > 0) {
        recordCount = records.length;
      }
      for (int index = 0; index < recordCount; index++) {
        dataArray.add(records[index].getJSONObjectUI());
      }
      resultObject.put("rows",dataArray);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultObject;
    }
    catch(Exception exception) {
      logger.error("getJSONKBMobilejsonrequestRecordSearchResult" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int insertKBMobilejsonrequestRecord(KBMobilejsonrequestRecord record) throws Exception {
    try {
      logger.trace("insertKBMobilejsonrequestRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("insertKBMobilejsonrequestRecord", null);
      KBMobilejsonrequestDAO dao = new KBMobilejsonrequestDAO();
      int result = dao.insertKBMobilejsonrequestRecord(record);
      logger.trace("insertKBMobilejsonrequestRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("insertKBMobilejsonrequestRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBMobilejsonrequestRecord(KBMobilejsonrequestRecord record) throws
      Exception {
    try {
      logger.trace("updateKBMobilejsonrequestRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBMobilejsonrequestRecord", null);
      KBMobilejsonrequestDAO dao = new KBMobilejsonrequestDAO();
      boolean result = dao.updateKBMobilejsonrequestRecord(record);
      logger.trace("updateKBMobilejsonrequestRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBMobilejsonrequestRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBMobilejsonrequestRecordNonNull(KBMobilejsonrequestRecord inputRecord)
      throws Exception {
    try {
      logger.trace("updateKBMobilejsonrequestRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBMobilejsonrequestRecordNoNull", null);
      KBMobilejsonrequestDAO dao = new KBMobilejsonrequestDAO();
      KBMobilejsonrequestRecord dbRecord = dao.loadKBMobilejsonrequestRecord(inputRecord.getId());
      if (dbRecord == null) {
        throw new Exception("Record not found");
      }
      dbRecord.loadNonNullContent(inputRecord);
      boolean result = dao.updateKBMobilejsonrequestRecord(inputRecord);
      logger.trace("updateKBMobilejsonrequestRecordNoNull:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBMobilejsonrequestRecordNoNull" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean deleteKBMobilejsonrequestRecord(KBMobilejsonrequestRecord record) throws
      Exception {
    try {
      logger.trace("deleteKBMobilejsonrequestRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("deleteKBMobilejsonrequestRecord", null);
      KBMobilejsonrequestDAO dao = new KBMobilejsonrequestDAO();
      boolean result = dao.deleteKBMobilejsonrequestRecord(record);
      logger.trace("deleteKBMobilejsonrequestRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("deleteKBMobilejsonrequestRecord" + getStackTrace(exception));
      throw exception;
    }
  }
}
