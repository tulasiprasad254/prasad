package com.key.mb.service;

import com.key.mb.common.KBService;
import com.key.mb.dao.KBServicemapDAO;
import com.key.mb.to.KBServicemapRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class KBServicemapService extends KBService {
  public static LogUtils logger = new LogUtils(KBServicemapService.class.getName());

  public KBServicemapRecord[] loadKBServicemapRecords(String query) throws Exception {
    try {
      logger.trace("loadKBServicemapRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBServicemapRecords", null);
      KBServicemapDAO dao = new KBServicemapDAO();
      KBServicemapRecord[] results = dao.loadKBServicemapRecords(query);
      int resultRecordCount = 0;
      if (results != null) {
        resultRecordCount = results.length;
      }
      logger.trace("loadKBServicemapRecords:Fetched" + resultRecordCount);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return results;
    }
    catch(Exception exception) {
      logger.error("loadKBServicemapRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBServicemapRecord loadFirstKBServicemapRecord(String query) throws Exception {
    try {
      logger.trace("loadKBServicemapRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBServicemapRecords", null);
      KBServicemapDAO dao = new KBServicemapDAO();
      KBServicemapRecord result = dao.loadFirstKBServicemapRecord(query);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadFirstKBServicemapRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBServicemapRecord searchFirstKBServicemapRecord(KBServicemapRecord record) throws
      Exception {
    try {
      logger.trace("searchFirstKBServicemapRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBServicemapRecords", null);
      KBServicemapDAO dao = new KBServicemapDAO();
      KBServicemapRecord[] records = dao.searchKBServicemapRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBServicemapRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBServicemapRecord searchKBServicemapRecordExactUpper(KBServicemapRecord record) throws
      Exception {
    try {
      logger.trace("searchFirstKBServicemapRecordsExactUpper:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBServicemapRecordsExactUpper", null);
      KBServicemapDAO dao = new KBServicemapDAO();
      KBServicemapRecord[] records = dao.searchKBServicemapRecordsExactUpper(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBServicemapRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBServicemapRecord[] searchKBServicemapRecords(KBServicemapRecord record) throws
      Exception {
    try {
      logger.trace("searchKBServicemapRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBServicemapRecords", null);
      KBServicemapDAO dao = new KBServicemapDAO();
      KBServicemapRecord[] records = dao.searchKBServicemapRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return records;
    }
    catch(Exception exception) {
      logger.error("searchKBServicemapRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int loadKBServicemapRecordCount(KBServicemapRecord record) throws Exception {
    return loadKBServicemapRecordCount(record, null);
  }

  public int loadKBServicemapRecordCount(KBServicemapRecord record, String customCondition) throws
      Exception {
    try {
      logger.trace("loadKBServicemapRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBServicemapRecordCount", null);
      KBServicemapDAO dao = new KBServicemapDAO();
      dao.setCustomCondition(customCondition);
      int resultcount = dao.loadKBServicemapRecordCount(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultcount;
    }
    catch(Exception exception) {
      logger.error("loadKBServicemapRecordCount" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBServicemapRecord loadKBServicemapRecord(String key) throws Exception {
    try {
      logger.trace("loadKBServicemapRecord:" + key);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBServicemapRecordCount", null);
      KBServicemapDAO dao = new KBServicemapDAO();
      KBServicemapRecord result = dao.loadKBServicemapRecord(key);
      logger.trace("loadKBServicemapRecord:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadKBServicemapRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public JSONObject getJSONKBServicemapRecordSearchResultByPage(KBServicemapRecord record,
      String offset, String maxrows, String orderBy) throws Exception {
    return getJSONKBServicemapRecordSearchResultByPage(record, offset, maxrows, orderBy, null);
  }

  public JSONObject getJSONKBServicemapRecordSearchResultByPage(KBServicemapRecord record,
      String offset, String maxrows, String orderBy, String customCondition) throws Exception {
    try {
      logger.trace("getJSONKBServicemapRecordSearchResultByPage:" + record + " Offset:" + offset + " Maxrows:" + maxrows);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("getJSONKBServicemapRecordSearchResult", null);
      KBServicemapDAO dao = new KBServicemapDAO();
      int totalCount = dao.loadKBServicemapRecordCount(record);
      dao.setLimits(offset, maxrows);
      KBServicemapRecord[] records = null;
      if (totalCount > 0) {
        dao.setOrderBy(orderBy);
        records = dao.searchKBServicemapRecords(record);
      }
      JSONObject resultObject = new JSONObject();
      resultObject.put("total",totalCount + "");
      JSONArray dataArray = new JSONArray();
      int recordCount = 0;
      if (totalCount > 0) {
        recordCount = records.length;
      }
      for (int index = 0; index < recordCount; index++) {
        dataArray.add(records[index].getJSONObjectUI());
      }
      resultObject.put("rows",dataArray);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultObject;
    }
    catch(Exception exception) {
      logger.error("getJSONKBServicemapRecordSearchResult" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int insertKBServicemapRecord(KBServicemapRecord record) throws Exception {
    try {
      logger.trace("insertKBServicemapRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("insertKBServicemapRecord", null);
      KBServicemapDAO dao = new KBServicemapDAO();
      int result = dao.insertKBServicemapRecord(record);
      logger.trace("insertKBServicemapRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("insertKBServicemapRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBServicemapRecord(KBServicemapRecord record) throws Exception {
    try {
      logger.trace("updateKBServicemapRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBServicemapRecord", null);
      KBServicemapDAO dao = new KBServicemapDAO();
      boolean result = dao.updateKBServicemapRecord(record);
      logger.trace("updateKBServicemapRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBServicemapRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBServicemapRecordNonNull(KBServicemapRecord inputRecord) throws Exception {
    try {
      logger.trace("updateKBServicemapRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBServicemapRecordNoNull", null);
      KBServicemapDAO dao = new KBServicemapDAO();
      KBServicemapRecord dbRecord = dao.loadKBServicemapRecord(inputRecord.getId());
      if (dbRecord == null) {
        throw new Exception("Record not found");
      }
      dbRecord.loadNonNullContent(inputRecord);
      boolean result = dao.updateKBServicemapRecord(inputRecord);
      logger.trace("updateKBServicemapRecordNoNull:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBServicemapRecordNoNull" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean deleteKBServicemapRecord(KBServicemapRecord record) throws Exception {
    try {
      logger.trace("deleteKBServicemapRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("deleteKBServicemapRecord", null);
      KBServicemapDAO dao = new KBServicemapDAO();
      boolean result = dao.deleteKBServicemapRecord(record);
      logger.trace("deleteKBServicemapRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("deleteKBServicemapRecord" + getStackTrace(exception));
      throw exception;
    }
  }
}
