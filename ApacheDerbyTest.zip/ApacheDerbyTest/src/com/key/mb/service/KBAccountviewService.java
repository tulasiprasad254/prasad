package com.key.mb.service;

import com.key.mb.common.KBService;
import com.key.mb.dao.KBAccountviewDAO;
import com.key.mb.to.KBAccountviewRecord;
import com.key.utils.DateUtils;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.HashMap;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class KBAccountviewService extends KBService {
  public static LogUtils logger = new LogUtils(KBAccountviewService.class.getName());

  public KBAccountviewRecord[] loadKBAccountviewRecords(String query) throws Exception {
    try {
      logger.trace("loadKBAccountviewRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBAccountviewRecords", null);
      KBAccountviewDAO dao = new KBAccountviewDAO();
      KBAccountviewRecord[] results = dao.loadKBAccountviewRecords(query);
      int resultRecordCount = 0;
      if (results != null) {
        resultRecordCount = results.length;
      }
      logger.trace("loadKBAccountviewRecords:Fetched" + resultRecordCount);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return results;
    }
    catch(Exception exception) {
      logger.error("loadKBAccountviewRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBAccountviewRecord loadFirstKBAccountviewRecord(String query) throws Exception {
    try {
      logger.trace("loadKBAccountviewRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBAccountviewRecords", null);
      KBAccountviewDAO dao = new KBAccountviewDAO();
      KBAccountviewRecord result = dao.loadFirstKBAccountviewRecord(query);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadFirstKBAccountviewRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBAccountviewRecord searchFirstKBAccountviewRecord(KBAccountviewRecord record) throws
      Exception {
    try {
      logger.trace("searchFirstKBAccountviewRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBAccountviewRecords", null);
      KBAccountviewDAO dao = new KBAccountviewDAO();
      KBAccountviewRecord[] records = dao.searchKBAccountviewRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBAccountviewRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBAccountviewRecord searchKBAccountviewRecordExactUpper(KBAccountviewRecord record) throws
      Exception {
    try {
      logger.trace("searchFirstKBAccountviewRecordsExactUpper:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBAccountviewRecordsExactUpper", null);
      KBAccountviewDAO dao = new KBAccountviewDAO();
      KBAccountviewRecord[] records = dao.searchKBAccountviewRecordsExactUpper(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBAccountviewRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBAccountviewRecord[] searchKBAccountviewRecords(KBAccountviewRecord record) throws
      Exception {
    try {
      logger.trace("searchKBAccountviewRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBAccountviewRecords", null);
      KBAccountviewDAO dao = new KBAccountviewDAO();
      KBAccountviewRecord[] records = dao.searchKBAccountviewRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return records;
    }
    catch(Exception exception) {
      logger.error("searchKBAccountviewRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int loadKBAccountviewRecordCount(KBAccountviewRecord record) throws Exception {
    return loadKBAccountviewRecordCount(record, null);
  }

  public int loadKBAccountviewRecordCount(KBAccountviewRecord record, String customCondition) throws
      Exception {
    try {
      logger.trace("loadKBAccountviewRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBAccountviewRecordCount", null);
      KBAccountviewDAO dao = new KBAccountviewDAO();
      dao.setCustomCondition(customCondition);
      int resultcount = dao.loadKBAccountviewRecordCount(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultcount;
    }
    catch(Exception exception) {
      logger.error("loadKBAccountviewRecordCount" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBAccountviewRecord loadKBAccountviewRecord(String key) throws Exception {
    try {
      logger.trace("loadKBAccountviewRecord:" + key);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBAccountviewRecordCount", null);
      KBAccountviewDAO dao = new KBAccountviewDAO();
      KBAccountviewRecord result = dao.loadKBAccountviewRecord(key);
      logger.trace("loadKBAccountviewRecord:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadKBAccountviewRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public JSONObject getJSONKBAccountviewRecordSearchResultByPage(KBAccountviewRecord record,
      String offset, String maxrows, String orderBy) throws Exception {
    return getJSONKBAccountviewRecordSearchResultByPage(record, offset, maxrows, orderBy, null);
  }

  public JSONObject getJSONKBAccountviewRecordSearchResultByPage(KBAccountviewRecord record,
      String offset, String maxrows, String orderBy, String customCondition) throws Exception {
    try {
      logger.trace("getJSONKBAccountviewRecordSearchResultByPage:" + record + " Offset:" + offset + " Maxrows:" + maxrows);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("getJSONKBAccountviewRecordSearchResult", null);
      KBAccountviewDAO dao = new KBAccountviewDAO();
      int totalCount = dao.loadKBAccountviewRecordCount(record);
      dao.setLimits(offset, maxrows);
      KBAccountviewRecord[] records = null;
      if (totalCount > 0) {
        dao.setOrderBy(orderBy);
        records = dao.searchKBAccountviewRecords(record);
      }
      JSONObject resultObject = new JSONObject();
      resultObject.put("total",totalCount + "");
      JSONArray dataArray = new JSONArray();
      int recordCount = 0;
      if (totalCount > 0) {
        recordCount = records.length;
      }
      for (int index = 0; index < recordCount; index++) {
        dataArray.add(records[index].getJSONObjectUI());
      }
      resultObject.put("rows",dataArray);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultObject;
    }
    catch(Exception exception) {
      logger.error("getJSONKBAccountviewRecordSearchResult" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int insertKBAccountviewRecord(KBAccountviewRecord record) throws Exception {
    try {
      logger.trace("insertKBAccountviewRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("insertKBAccountviewRecord", null);
      KBAccountviewDAO dao = new KBAccountviewDAO();
      int result = dao.insertKBAccountviewRecord(record);
      logger.trace("insertKBAccountviewRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBAccountviewService", record.getId() + "", "Create", record.getCreatedby(), "Created");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("insertKBAccountviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBAccountviewRecord(KBAccountviewRecord record) throws Exception {
    try {
      logger.trace("updateKBAccountviewRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBAccountviewRecord", null);
      KBAccountviewDAO dao = new KBAccountviewDAO();
      boolean result = dao.updateKBAccountviewRecord(record);
      logger.trace("updateKBAccountviewRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBAccountviewService", record.getId() + "", "Update", record.getModifiedby(), "Update");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBAccountviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBAccountviewRecordNonNull(KBAccountviewRecord inputRecord) throws
      Exception {
    try {
      logger.trace("updateKBAccountviewRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBAccountviewRecordNoNull", null);
      KBAccountviewDAO dao = new KBAccountviewDAO();
      KBAccountviewRecord dbRecord = dao.loadKBAccountviewRecord(inputRecord.getId());
      if (dbRecord == null) {
        throw new Exception("Record not found");
      }
      dbRecord.loadNonNullContent(inputRecord);
      boolean result = dao.updateKBAccountviewRecord(inputRecord);
      createMakerCheckerAuditEntry("KBAccountviewService", inputRecord.getId() + "", "Update", inputRecord.getModifiedby(), "UpdateNoNull");
      logger.trace("updateKBAccountviewRecordNoNull:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBAccountviewRecordNoNull" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean deleteKBAccountviewRecord(KBAccountviewRecord record) throws Exception {
    try {
      logger.trace("deleteKBAccountviewRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("deleteKBAccountviewRecord", null);
      KBAccountviewDAO dao = new KBAccountviewDAO();
      boolean result = dao.deleteKBAccountviewRecord(record);
      logger.trace("deleteKBAccountviewRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBAccountviewService", record.getId(), "Delete", null, "Deleted");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("deleteKBAccountviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean approveKBAccountviewRecord(KBAccountviewRecord inputRecord, String updateId,
      String comment) throws Exception {
    try {
      logger.trace("approveKBAccountviewRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("approveKBAccountviewRecord", null);
      KBAccountviewDAO dao = new KBAccountviewDAO();
      KBAccountviewRecord updateRecord = dao.loadKBAccountviewRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForApproval(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot approve - Invalid Status for Approval");
      }
      if (StringUtils.isSame(updateRecord.getMadeby(), updateId)) {
        throw new Exception("MF-ERR-CA-MCS102:Cannot Approve. Maker Checker cannot be same");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("1");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBAccountviewRecord(updateRecord);
      logger.trace("approveKBAccountviewRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBAccountviewService", updateRecord.getId(), "Approve", updateId, comment);
      HashMap approveEventMap = callActionEvent("Event_OnApprovalOf_KBAccountviewRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("approveKBAccountviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean submitKBAccountviewRecord(KBAccountviewRecord inputRecord, String updateId,
      String comment) throws Exception {
    try {
      logger.trace("submitKBAccountviewRecordNoNull:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("submitKBAccountviewRecordNoNull", null);
      KBAccountviewDAO dao = new KBAccountviewDAO();
      KBAccountviewRecord updateRecord = dao.loadKBAccountviewRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForSubmission(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CS-IS101:Cannot submit - Invalid Status for Submission");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("4");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBAccountviewRecord(updateRecord);
      logger.trace("approveKBAccountviewRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBAccountviewService", updateRecord.getId(), "Submit", updateId, comment);
      HashMap submitEventMap = callActionEvent("Event_OnApprovalOf_KBAccountviewRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("submitKBAccountviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean denyKBAccountviewRecord(KBAccountviewRecord inputRecord, String updateId,
      String comment) throws Exception {
    try {
      logger.trace("denyKBAccountviewRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("denyKBAccountviewRecord", null);
      KBAccountviewDAO dao = new KBAccountviewDAO();
      KBAccountviewRecord updateRecord = dao.loadKBAccountviewRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForDeny(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot deny - Invalid Status for Deny");
      }
      if (StringUtils.isSame(updateRecord.getMadeby(), updateId)) {
        throw new Exception("MF-ERR-CA-MCS102:Cannot Deny. Maker Checker cannot be same");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("5");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBAccountviewRecord(updateRecord);
      logger.trace("approveKBAccountviewRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBAccountviewService", updateRecord.getId(), "Deny", updateId, comment);
      HashMap denyEventMap = callActionEvent("Event_OnDenyOf_KBAccountviewRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("denyKBAccountviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean denyPermanantKBAccountviewRecord(KBAccountviewRecord inputRecord, String updateId,
      String comment) throws Exception {
    try {
      logger.trace("denyPKBAccountviewRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("denyPKBAccountviewRecord", null);
      KBAccountviewDAO dao = new KBAccountviewDAO();
      KBAccountviewRecord updateRecord = dao.loadKBAccountviewRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForDeny(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot deny - Invalid Status for Deny");
      }
      if (StringUtils.isSame(updateRecord.getMadeby(), updateId)) {
        throw new Exception("MF-ERR-CA-MCS102:Cannot Deny. Maker Checker cannot be same");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("58");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBAccountviewRecord(updateRecord);
      logger.trace("approveKBAccountviewRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBAccountviewService", updateRecord.getId(), "DenyP", updateId, comment);
      HashMap denyEventMap = callActionEvent("Event_OnDenyPOf_KBAccountviewRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("denyPKBAccountviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean remindApprovalKBAccountviewRecord(KBAccountviewRecord inputRecord, String updateId,
      String comment) throws Exception {
    try {
      logger.trace("remindApprovalKBAccountviewRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("remindApprovalKBAccountviewRecord", null);
      KBAccountviewDAO dao = new KBAccountviewDAO();
      KBAccountviewRecord updateRecord = dao.loadKBAccountviewRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForApproval(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot Remind - Invalid Status for Reminder");
      }
      createMakerCheckerAuditEntry("KBAccountviewService", updateRecord.getId(), "Approval Reminder", updateId, comment);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return true;
    }
    catch(Exception exception) {
      logger.error("remindApprovalKBAccountviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean resetApprovalKBAccountviewRecord(KBAccountviewRecord inputRecord, String updateId,
      String comment) throws Exception {
    try {
      logger.trace("resetApprovalKBAccountviewRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("resetApprovalKBAccountviewRecord", null);
      KBAccountviewDAO dao = new KBAccountviewDAO();
      KBAccountviewRecord updateRecord = dao.loadKBAccountviewRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForDeny(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot submit - Invalid Status for Reset");
      }
      updateRecord.setRstatus("0");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("0");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBAccountviewRecord(updateRecord);
      logger.trace("approveKBAccountviewRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBAccountviewService", updateRecord.getId(), "Reset Approval", updateId, comment);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("resetApprovalKBAccountviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }
}
