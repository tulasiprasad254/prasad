package com.key.mb.service;

import com.key.mb.common.KBService;
import com.key.mb.dao.KBAgencyDAO;
import com.key.mb.to.KBAgencyRecord;
import com.key.utils.DateUtils;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.HashMap;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class KBAgencyService extends KBService {
  public static LogUtils logger = new LogUtils(KBAgencyService.class.getName());

  public KBAgencyRecord[] loadKBAgencyRecords(String query) throws Exception {
    try {
      logger.trace("loadKBAgencyRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBAgencyRecords", null);
      KBAgencyDAO dao = new KBAgencyDAO();
      KBAgencyRecord[] results = dao.loadKBAgencyRecords(query);
      int resultRecordCount = 0;
      if (results != null) {
        resultRecordCount = results.length;
      }
      logger.trace("loadKBAgencyRecords:Fetched" + resultRecordCount);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return results;
    }
    catch(Exception exception) {
      logger.error("loadKBAgencyRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBAgencyRecord loadFirstKBAgencyRecord(String query) throws Exception {
    try {
      logger.trace("loadKBAgencyRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBAgencyRecords", null);
      KBAgencyDAO dao = new KBAgencyDAO();
      KBAgencyRecord result = dao.loadFirstKBAgencyRecord(query);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadFirstKBAgencyRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBAgencyRecord searchFirstKBAgencyRecord(KBAgencyRecord record) throws Exception {
    try {
      logger.trace("searchFirstKBAgencyRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBAgencyRecords", null);
      KBAgencyDAO dao = new KBAgencyDAO();
      KBAgencyRecord[] records = dao.searchKBAgencyRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBAgencyRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBAgencyRecord searchKBAgencyRecordExactUpper(KBAgencyRecord record) throws Exception {
    try {
      logger.trace("searchFirstKBAgencyRecordsExactUpper:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBAgencyRecordsExactUpper", null);
      KBAgencyDAO dao = new KBAgencyDAO();
      KBAgencyRecord[] records = dao.searchKBAgencyRecordsExactUpper(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBAgencyRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBAgencyRecord[] searchKBAgencyRecords(KBAgencyRecord record) throws Exception {
    try {
      logger.trace("searchKBAgencyRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBAgencyRecords", null);
      KBAgencyDAO dao = new KBAgencyDAO();
      KBAgencyRecord[] records = dao.searchKBAgencyRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return records;
    }
    catch(Exception exception) {
      logger.error("searchKBAgencyRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int loadKBAgencyRecordCount(KBAgencyRecord record) throws Exception {
    return loadKBAgencyRecordCount(record, null);
  }

  public int loadKBAgencyRecordCount(KBAgencyRecord record, String customCondition) throws
      Exception {
    try {
      logger.trace("loadKBAgencyRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBAgencyRecordCount", null);
      KBAgencyDAO dao = new KBAgencyDAO();
      dao.setCustomCondition(customCondition);
      int resultcount = dao.loadKBAgencyRecordCount(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultcount;
    }
    catch(Exception exception) {
      logger.error("loadKBAgencyRecordCount" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBAgencyRecord loadKBAgencyRecord(String key) throws Exception {
    try {
      logger.trace("loadKBAgencyRecord:" + key);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBAgencyRecordCount", null);
      KBAgencyDAO dao = new KBAgencyDAO();
      KBAgencyRecord result = dao.loadKBAgencyRecord(key);
      logger.trace("loadKBAgencyRecord:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadKBAgencyRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public JSONObject getJSONKBAgencyRecordSearchResultByPage(KBAgencyRecord record, String offset,
      String maxrows, String orderBy) throws Exception {
    return getJSONKBAgencyRecordSearchResultByPage(record, offset, maxrows, orderBy, null);
  }

  public JSONObject getJSONKBAgencyRecordSearchResultByPage(KBAgencyRecord record, String offset,
      String maxrows, String orderBy, String customCondition) throws Exception {
    try {
      logger.trace("getJSONKBAgencyRecordSearchResultByPage:" + record + " Offset:" + offset + " Maxrows:" + maxrows);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("getJSONKBAgencyRecordSearchResult", null);
      KBAgencyDAO dao = new KBAgencyDAO();
      int totalCount = dao.loadKBAgencyRecordCount(record);
      dao.setLimits(offset, maxrows);
      KBAgencyRecord[] records = null;
      if (totalCount > 0) {
        dao.setOrderBy(orderBy);
        records = dao.searchKBAgencyRecords(record);
      }
      JSONObject resultObject = new JSONObject();
      resultObject.put("total",totalCount + "");
      JSONArray dataArray = new JSONArray();
      int recordCount = 0;
      if (totalCount > 0) {
        recordCount = records.length;
      }
      for (int index = 0; index < recordCount; index++) {
        dataArray.add(records[index].getJSONObjectUI());
      }
      resultObject.put("rows",dataArray);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultObject;
    }
    catch(Exception exception) {
      logger.error("getJSONKBAgencyRecordSearchResult" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int insertKBAgencyRecord(KBAgencyRecord record) throws Exception {
    try {
      logger.trace("insertKBAgencyRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("insertKBAgencyRecord", null);
      KBAgencyDAO dao = new KBAgencyDAO();
      int result = dao.insertKBAgencyRecord(record);
      logger.trace("insertKBAgencyRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBAgencyService", record.getId() + "", "Create", record.getCreatedby(), "Created");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("insertKBAgencyRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBAgencyRecord(KBAgencyRecord record) throws Exception {
    try {
      logger.trace("updateKBAgencyRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBAgencyRecord", null);
      KBAgencyDAO dao = new KBAgencyDAO();
      boolean result = dao.updateKBAgencyRecord(record);
      logger.trace("updateKBAgencyRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBAgencyService", record.getId() + "", "Update", record.getModifiedby(), "Update");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBAgencyRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBAgencyRecordNonNull(KBAgencyRecord inputRecord) throws Exception {
    try {
      logger.trace("updateKBAgencyRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBAgencyRecordNoNull", null);
      KBAgencyDAO dao = new KBAgencyDAO();
      KBAgencyRecord dbRecord = dao.loadKBAgencyRecord(inputRecord.getId());
      if (dbRecord == null) {
        throw new Exception("Record not found");
      }
      dbRecord.loadNonNullContent(inputRecord);
      boolean result = dao.updateKBAgencyRecord(inputRecord);
      createMakerCheckerAuditEntry("KBAgencyService", inputRecord.getId() + "", "Update", inputRecord.getModifiedby(), "UpdateNoNull");
      logger.trace("updateKBAgencyRecordNoNull:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBAgencyRecordNoNull" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean deleteKBAgencyRecord(KBAgencyRecord record) throws Exception {
    try {
      logger.trace("deleteKBAgencyRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("deleteKBAgencyRecord", null);
      KBAgencyDAO dao = new KBAgencyDAO();
      boolean result = dao.deleteKBAgencyRecord(record);
      logger.trace("deleteKBAgencyRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBAgencyService", record.getId(), "Delete", null, "Deleted");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("deleteKBAgencyRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean approveKBAgencyRecord(KBAgencyRecord inputRecord, String updateId, String comment)
      throws Exception {
    try {
      logger.trace("approveKBAgencyRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("approveKBAgencyRecord", null);
      KBAgencyDAO dao = new KBAgencyDAO();
      KBAgencyRecord updateRecord = dao.loadKBAgencyRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForApproval(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot approve - Invalid Status for Approval");
      }
      if (StringUtils.isSame(updateRecord.getMadeby(), updateId)) {
        throw new Exception("MF-ERR-CA-MCS102:Cannot Approve. Maker Checker cannot be same");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("1");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBAgencyRecord(updateRecord);
      logger.trace("approveKBAgencyRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBAgencyService", updateRecord.getId(), "Approve", updateId, comment);
      HashMap approveEventMap = callActionEvent("Event_OnApprovalOf_KBAgencyRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("approveKBAgencyRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean submitKBAgencyRecord(KBAgencyRecord inputRecord, String updateId, String comment)
      throws Exception {
    try {
      logger.trace("submitKBAgencyRecordNoNull:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("submitKBAgencyRecordNoNull", null);
      KBAgencyDAO dao = new KBAgencyDAO();
      KBAgencyRecord updateRecord = dao.loadKBAgencyRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForSubmission(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CS-IS101:Cannot submit - Invalid Status for Submission");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("4");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBAgencyRecord(updateRecord);
      logger.trace("approveKBAgencyRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBAgencyService", updateRecord.getId(), "Submit", updateId, comment);
      HashMap submitEventMap = callActionEvent("Event_OnApprovalOf_KBAgencyRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("submitKBAgencyRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean denyKBAgencyRecord(KBAgencyRecord inputRecord, String updateId, String comment)
      throws Exception {
    try {
      logger.trace("denyKBAgencyRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("denyKBAgencyRecord", null);
      KBAgencyDAO dao = new KBAgencyDAO();
      KBAgencyRecord updateRecord = dao.loadKBAgencyRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForDeny(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot deny - Invalid Status for Deny");
      }
      if (StringUtils.isSame(updateRecord.getMadeby(), updateId)) {
        throw new Exception("MF-ERR-CA-MCS102:Cannot Deny. Maker Checker cannot be same");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("5");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBAgencyRecord(updateRecord);
      logger.trace("approveKBAgencyRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBAgencyService", updateRecord.getId(), "Deny", updateId, comment);
      HashMap denyEventMap = callActionEvent("Event_OnDenyOf_KBAgencyRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("denyKBAgencyRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean denyPermanantKBAgencyRecord(KBAgencyRecord inputRecord, String updateId,
      String comment) throws Exception {
    try {
      logger.trace("denyPKBAgencyRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("denyPKBAgencyRecord", null);
      KBAgencyDAO dao = new KBAgencyDAO();
      KBAgencyRecord updateRecord = dao.loadKBAgencyRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForDeny(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot deny - Invalid Status for Deny");
      }
      if (StringUtils.isSame(updateRecord.getMadeby(), updateId)) {
        throw new Exception("MF-ERR-CA-MCS102:Cannot Deny. Maker Checker cannot be same");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("58");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBAgencyRecord(updateRecord);
      logger.trace("approveKBAgencyRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBAgencyService", updateRecord.getId(), "DenyP", updateId, comment);
      HashMap denyEventMap = callActionEvent("Event_OnDenyPOf_KBAgencyRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("denyPKBAgencyRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean remindApprovalKBAgencyRecord(KBAgencyRecord inputRecord, String updateId,
      String comment) throws Exception {
    try {
      logger.trace("remindApprovalKBAgencyRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("remindApprovalKBAgencyRecord", null);
      KBAgencyDAO dao = new KBAgencyDAO();
      KBAgencyRecord updateRecord = dao.loadKBAgencyRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForApproval(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot Remind - Invalid Status for Reminder");
      }
      createMakerCheckerAuditEntry("KBAgencyService", updateRecord.getId(), "Approval Reminder", updateId, comment);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return true;
    }
    catch(Exception exception) {
      logger.error("remindApprovalKBAgencyRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean resetApprovalKBAgencyRecord(KBAgencyRecord inputRecord, String updateId,
      String comment) throws Exception {
    try {
      logger.trace("resetApprovalKBAgencyRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("resetApprovalKBAgencyRecord", null);
      KBAgencyDAO dao = new KBAgencyDAO();
      KBAgencyRecord updateRecord = dao.loadKBAgencyRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForDeny(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot submit - Invalid Status for Reset");
      }
      updateRecord.setRstatus("0");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("0");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBAgencyRecord(updateRecord);
      logger.trace("approveKBAgencyRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBAgencyService", updateRecord.getId(), "Reset Approval", updateId, comment);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("resetApprovalKBAgencyRecord" + getStackTrace(exception));
      throw exception;
    }
  }
}
