package com.key.mb.service;

import com.key.mb.common.KBService;
import com.key.mb.dao.KBCustomercategoryviewDAO;
import com.key.mb.to.KBCustomercategoryviewRecord;
import com.key.utils.DateUtils;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.HashMap;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class KBCustomercategoryviewService extends KBService {
  public static LogUtils logger = new LogUtils(KBCustomercategoryviewService.class.getName());

  public KBCustomercategoryviewRecord[] loadKBCustomercategoryviewRecords(String query) throws
      Exception {
    try {
      logger.trace("loadKBCustomercategoryviewRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBCustomercategoryviewRecords", null);
      KBCustomercategoryviewDAO dao = new KBCustomercategoryviewDAO();
      KBCustomercategoryviewRecord[] results = dao.loadKBCustomercategoryviewRecords(query);
      int resultRecordCount = 0;
      if (results != null) {
        resultRecordCount = results.length;
      }
      logger.trace("loadKBCustomercategoryviewRecords:Fetched" + resultRecordCount);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return results;
    }
    catch(Exception exception) {
      logger.error("loadKBCustomercategoryviewRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBCustomercategoryviewRecord loadFirstKBCustomercategoryviewRecord(String query) throws
      Exception {
    try {
      logger.trace("loadKBCustomercategoryviewRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBCustomercategoryviewRecords", null);
      KBCustomercategoryviewDAO dao = new KBCustomercategoryviewDAO();
      KBCustomercategoryviewRecord result = dao.loadFirstKBCustomercategoryviewRecord(query);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadFirstKBCustomercategoryviewRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBCustomercategoryviewRecord searchFirstKBCustomercategoryviewRecord(
      KBCustomercategoryviewRecord record) throws Exception {
    try {
      logger.trace("searchFirstKBCustomercategoryviewRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBCustomercategoryviewRecords", null);
      KBCustomercategoryviewDAO dao = new KBCustomercategoryviewDAO();
      KBCustomercategoryviewRecord[] records = dao.searchKBCustomercategoryviewRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBCustomercategoryviewRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBCustomercategoryviewRecord searchKBCustomercategoryviewRecordExactUpper(
      KBCustomercategoryviewRecord record) throws Exception {
    try {
      logger.trace("searchFirstKBCustomercategoryviewRecordsExactUpper:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBCustomercategoryviewRecordsExactUpper", null);
      KBCustomercategoryviewDAO dao = new KBCustomercategoryviewDAO();
      KBCustomercategoryviewRecord[] records = dao.searchKBCustomercategoryviewRecordsExactUpper(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBCustomercategoryviewRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBCustomercategoryviewRecord[] searchKBCustomercategoryviewRecords(
      KBCustomercategoryviewRecord record) throws Exception {
    try {
      logger.trace("searchKBCustomercategoryviewRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBCustomercategoryviewRecords", null);
      KBCustomercategoryviewDAO dao = new KBCustomercategoryviewDAO();
      KBCustomercategoryviewRecord[] records = dao.searchKBCustomercategoryviewRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return records;
    }
    catch(Exception exception) {
      logger.error("searchKBCustomercategoryviewRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int loadKBCustomercategoryviewRecordCount(KBCustomercategoryviewRecord record) throws
      Exception {
    return loadKBCustomercategoryviewRecordCount(record, null);
  }

  public int loadKBCustomercategoryviewRecordCount(KBCustomercategoryviewRecord record,
      String customCondition) throws Exception {
    try {
      logger.trace("loadKBCustomercategoryviewRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBCustomercategoryviewRecordCount", null);
      KBCustomercategoryviewDAO dao = new KBCustomercategoryviewDAO();
      dao.setCustomCondition(customCondition);
      int resultcount = dao.loadKBCustomercategoryviewRecordCount(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultcount;
    }
    catch(Exception exception) {
      logger.error("loadKBCustomercategoryviewRecordCount" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBCustomercategoryviewRecord loadKBCustomercategoryviewRecord(String key) throws
      Exception {
    try {
      logger.trace("loadKBCustomercategoryviewRecord:" + key);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBCustomercategoryviewRecordCount", null);
      KBCustomercategoryviewDAO dao = new KBCustomercategoryviewDAO();
      KBCustomercategoryviewRecord result = dao.loadKBCustomercategoryviewRecord(key);
      logger.trace("loadKBCustomercategoryviewRecord:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadKBCustomercategoryviewRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public JSONObject getJSONKBCustomercategoryviewRecordSearchResultByPage(
      KBCustomercategoryviewRecord record, String offset, String maxrows, String orderBy) throws
      Exception {
    return getJSONKBCustomercategoryviewRecordSearchResultByPage(record, offset, maxrows, orderBy, null);
  }

  public JSONObject getJSONKBCustomercategoryviewRecordSearchResultByPage(
      KBCustomercategoryviewRecord record, String offset, String maxrows, String orderBy,
      String customCondition) throws Exception {
    try {
      logger.trace("getJSONKBCustomercategoryviewRecordSearchResultByPage:" + record + " Offset:" + offset + " Maxrows:" + maxrows);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("getJSONKBCustomercategoryviewRecordSearchResult", null);
      KBCustomercategoryviewDAO dao = new KBCustomercategoryviewDAO();
      int totalCount = dao.loadKBCustomercategoryviewRecordCount(record);
      dao.setLimits(offset, maxrows);
      KBCustomercategoryviewRecord[] records = null;
      if (totalCount > 0) {
        dao.setOrderBy(orderBy);
        records = dao.searchKBCustomercategoryviewRecords(record);
      }
      JSONObject resultObject = new JSONObject();
      resultObject.put("total",totalCount + "");
      JSONArray dataArray = new JSONArray();
      int recordCount = 0;
      if (totalCount > 0) {
        recordCount = records.length;
      }
      for (int index = 0; index < recordCount; index++) {
        dataArray.add(records[index].getJSONObjectUI());
      }
      resultObject.put("rows",dataArray);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultObject;
    }
    catch(Exception exception) {
      logger.error("getJSONKBCustomercategoryviewRecordSearchResult" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int insertKBCustomercategoryviewRecord(KBCustomercategoryviewRecord record) throws
      Exception {
    try {
      logger.trace("insertKBCustomercategoryviewRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("insertKBCustomercategoryviewRecord", null);
      KBCustomercategoryviewDAO dao = new KBCustomercategoryviewDAO();
      int result = dao.insertKBCustomercategoryviewRecord(record);
      logger.trace("insertKBCustomercategoryviewRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomercategoryviewService", record.getId() + "", "Create", record.getCreatedby(), "Created");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("insertKBCustomercategoryviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBCustomercategoryviewRecord(KBCustomercategoryviewRecord record) throws
      Exception {
    try {
      logger.trace("updateKBCustomercategoryviewRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBCustomercategoryviewRecord", null);
      KBCustomercategoryviewDAO dao = new KBCustomercategoryviewDAO();
      boolean result = dao.updateKBCustomercategoryviewRecord(record);
      logger.trace("updateKBCustomercategoryviewRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomercategoryviewService", record.getId() + "", "Update", record.getModifiedby(), "Update");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBCustomercategoryviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBCustomercategoryviewRecordNonNull(KBCustomercategoryviewRecord inputRecord)
      throws Exception {
    try {
      logger.trace("updateKBCustomercategoryviewRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBCustomercategoryviewRecordNoNull", null);
      KBCustomercategoryviewDAO dao = new KBCustomercategoryviewDAO();
      KBCustomercategoryviewRecord dbRecord = dao.loadKBCustomercategoryviewRecord(inputRecord.getId());
      if (dbRecord == null) {
        throw new Exception("Record not found");
      }
      dbRecord.loadNonNullContent(inputRecord);
      boolean result = dao.updateKBCustomercategoryviewRecord(inputRecord);
      createMakerCheckerAuditEntry("KBCustomercategoryviewService", inputRecord.getId() + "", "Update", inputRecord.getModifiedby(), "UpdateNoNull");
      logger.trace("updateKBCustomercategoryviewRecordNoNull:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBCustomercategoryviewRecordNoNull" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean deleteKBCustomercategoryviewRecord(KBCustomercategoryviewRecord record) throws
      Exception {
    try {
      logger.trace("deleteKBCustomercategoryviewRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("deleteKBCustomercategoryviewRecord", null);
      KBCustomercategoryviewDAO dao = new KBCustomercategoryviewDAO();
      boolean result = dao.deleteKBCustomercategoryviewRecord(record);
      logger.trace("deleteKBCustomercategoryviewRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomercategoryviewService", record.getId(), "Delete", null, "Deleted");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("deleteKBCustomercategoryviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean approveKBCustomercategoryviewRecord(KBCustomercategoryviewRecord inputRecord,
      String updateId, String comment) throws Exception {
    try {
      logger.trace("approveKBCustomercategoryviewRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("approveKBCustomercategoryviewRecord", null);
      KBCustomercategoryviewDAO dao = new KBCustomercategoryviewDAO();
      KBCustomercategoryviewRecord updateRecord = dao.loadKBCustomercategoryviewRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForApproval(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot approve - Invalid Status for Approval");
      }
      if (StringUtils.isSame(updateRecord.getMadeby(), updateId)) {
        throw new Exception("MF-ERR-CA-MCS102:Cannot Approve. Maker Checker cannot be same");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("1");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBCustomercategoryviewRecord(updateRecord);
      logger.trace("approveKBCustomercategoryviewRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomercategoryviewService", updateRecord.getId(), "Approve", updateId, comment);
      HashMap approveEventMap = callActionEvent("Event_OnApprovalOf_KBCustomercategoryviewRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("approveKBCustomercategoryviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean submitKBCustomercategoryviewRecord(KBCustomercategoryviewRecord inputRecord,
      String updateId, String comment) throws Exception {
    try {
      logger.trace("submitKBCustomercategoryviewRecordNoNull:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("submitKBCustomercategoryviewRecordNoNull", null);
      KBCustomercategoryviewDAO dao = new KBCustomercategoryviewDAO();
      KBCustomercategoryviewRecord updateRecord = dao.loadKBCustomercategoryviewRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForSubmission(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CS-IS101:Cannot submit - Invalid Status for Submission");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("4");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBCustomercategoryviewRecord(updateRecord);
      logger.trace("approveKBCustomercategoryviewRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomercategoryviewService", updateRecord.getId(), "Submit", updateId, comment);
      HashMap submitEventMap = callActionEvent("Event_OnApprovalOf_KBCustomercategoryviewRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("submitKBCustomercategoryviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean denyKBCustomercategoryviewRecord(KBCustomercategoryviewRecord inputRecord,
      String updateId, String comment) throws Exception {
    try {
      logger.trace("denyKBCustomercategoryviewRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("denyKBCustomercategoryviewRecord", null);
      KBCustomercategoryviewDAO dao = new KBCustomercategoryviewDAO();
      KBCustomercategoryviewRecord updateRecord = dao.loadKBCustomercategoryviewRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForDeny(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot deny - Invalid Status for Deny");
      }
      if (StringUtils.isSame(updateRecord.getMadeby(), updateId)) {
        throw new Exception("MF-ERR-CA-MCS102:Cannot Deny. Maker Checker cannot be same");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("5");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBCustomercategoryviewRecord(updateRecord);
      logger.trace("approveKBCustomercategoryviewRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomercategoryviewService", updateRecord.getId(), "Deny", updateId, comment);
      HashMap denyEventMap = callActionEvent("Event_OnDenyOf_KBCustomercategoryviewRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("denyKBCustomercategoryviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean denyPermanantKBCustomercategoryviewRecord(KBCustomercategoryviewRecord inputRecord,
      String updateId, String comment) throws Exception {
    try {
      logger.trace("denyPKBCustomercategoryviewRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("denyPKBCustomercategoryviewRecord", null);
      KBCustomercategoryviewDAO dao = new KBCustomercategoryviewDAO();
      KBCustomercategoryviewRecord updateRecord = dao.loadKBCustomercategoryviewRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForDeny(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot deny - Invalid Status for Deny");
      }
      if (StringUtils.isSame(updateRecord.getMadeby(), updateId)) {
        throw new Exception("MF-ERR-CA-MCS102:Cannot Deny. Maker Checker cannot be same");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("58");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBCustomercategoryviewRecord(updateRecord);
      logger.trace("approveKBCustomercategoryviewRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomercategoryviewService", updateRecord.getId(), "DenyP", updateId, comment);
      HashMap denyEventMap = callActionEvent("Event_OnDenyPOf_KBCustomercategoryviewRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("denyPKBCustomercategoryviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean remindApprovalKBCustomercategoryviewRecord(
      KBCustomercategoryviewRecord inputRecord, String updateId, String comment) throws Exception {
    try {
      logger.trace("remindApprovalKBCustomercategoryviewRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("remindApprovalKBCustomercategoryviewRecord", null);
      KBCustomercategoryviewDAO dao = new KBCustomercategoryviewDAO();
      KBCustomercategoryviewRecord updateRecord = dao.loadKBCustomercategoryviewRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForApproval(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot Remind - Invalid Status for Reminder");
      }
      createMakerCheckerAuditEntry("KBCustomercategoryviewService", updateRecord.getId(), "Approval Reminder", updateId, comment);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return true;
    }
    catch(Exception exception) {
      logger.error("remindApprovalKBCustomercategoryviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean resetApprovalKBCustomercategoryviewRecord(KBCustomercategoryviewRecord inputRecord,
      String updateId, String comment) throws Exception {
    try {
      logger.trace("resetApprovalKBCustomercategoryviewRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("resetApprovalKBCustomercategoryviewRecord", null);
      KBCustomercategoryviewDAO dao = new KBCustomercategoryviewDAO();
      KBCustomercategoryviewRecord updateRecord = dao.loadKBCustomercategoryviewRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForDeny(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot submit - Invalid Status for Reset");
      }
      updateRecord.setRstatus("0");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("0");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBCustomercategoryviewRecord(updateRecord);
      logger.trace("approveKBCustomercategoryviewRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomercategoryviewService", updateRecord.getId(), "Reset Approval", updateId, comment);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("resetApprovalKBCustomercategoryviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }
}
