package com.key.mb.service;

import com.key.mb.common.KBService;
import com.key.mb.dao.KBMobilemenumapviewDAO;
import com.key.mb.to.KBMobilemenumapviewRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class KBMobilemenumapviewService extends KBService {
  public static LogUtils logger = new LogUtils(KBMobilemenumapviewService.class.getName());

  public KBMobilemenumapviewRecord[] loadKBMobilemenumapviewRecords(String query) throws Exception {
    try {
      logger.trace("loadKBMobilemenumapviewRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilemenumapviewRecords", null);
      KBMobilemenumapviewDAO dao = new KBMobilemenumapviewDAO();
      KBMobilemenumapviewRecord[] results = dao.loadKBMobilemenumapviewRecords(query);
      int resultRecordCount = 0;
      if (results != null) {
        resultRecordCount = results.length;
      }
      logger.trace("loadKBMobilemenumapviewRecords:Fetched" + resultRecordCount);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return results;
    }
    catch(Exception exception) {
      logger.error("loadKBMobilemenumapviewRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilemenumapviewRecord loadFirstKBMobilemenumapviewRecord(String query) throws
      Exception {
    try {
      logger.trace("loadKBMobilemenumapviewRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilemenumapviewRecords", null);
      KBMobilemenumapviewDAO dao = new KBMobilemenumapviewDAO();
      KBMobilemenumapviewRecord result = dao.loadFirstKBMobilemenumapviewRecord(query);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadFirstKBMobilemenumapviewRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilemenumapviewRecord searchFirstKBMobilemenumapviewRecord(
      KBMobilemenumapviewRecord record) throws Exception {
    try {
      logger.trace("searchFirstKBMobilemenumapviewRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBMobilemenumapviewRecords", null);
      KBMobilemenumapviewDAO dao = new KBMobilemenumapviewDAO();
      KBMobilemenumapviewRecord[] records = dao.searchKBMobilemenumapviewRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBMobilemenumapviewRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilemenumapviewRecord searchKBMobilemenumapviewRecordExactUpper(
      KBMobilemenumapviewRecord record) throws Exception {
    try {
      logger.trace("searchFirstKBMobilemenumapviewRecordsExactUpper:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBMobilemenumapviewRecordsExactUpper", null);
      KBMobilemenumapviewDAO dao = new KBMobilemenumapviewDAO();
      KBMobilemenumapviewRecord[] records = dao.searchKBMobilemenumapviewRecordsExactUpper(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBMobilemenumapviewRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilemenumapviewRecord[] searchKBMobilemenumapviewRecords(
      KBMobilemenumapviewRecord record) throws Exception {
    try {
      logger.trace("searchKBMobilemenumapviewRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilemenumapviewRecords", null);
      KBMobilemenumapviewDAO dao = new KBMobilemenumapviewDAO();
      KBMobilemenumapviewRecord[] records = dao.searchKBMobilemenumapviewRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return records;
    }
    catch(Exception exception) {
      logger.error("searchKBMobilemenumapviewRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int loadKBMobilemenumapviewRecordCount(KBMobilemenumapviewRecord record) throws Exception {
    return loadKBMobilemenumapviewRecordCount(record, null);
  }

  public int loadKBMobilemenumapviewRecordCount(KBMobilemenumapviewRecord record,
      String customCondition) throws Exception {
    try {
      logger.trace("loadKBMobilemenumapviewRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilemenumapviewRecordCount", null);
      KBMobilemenumapviewDAO dao = new KBMobilemenumapviewDAO();
      dao.setCustomCondition(customCondition);
      int resultcount = dao.loadKBMobilemenumapviewRecordCount(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultcount;
    }
    catch(Exception exception) {
      logger.error("loadKBMobilemenumapviewRecordCount" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilemenumapviewRecord loadKBMobilemenumapviewRecord(String key) throws Exception {
    try {
      logger.trace("loadKBMobilemenumapviewRecord:" + key);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilemenumapviewRecordCount", null);
      KBMobilemenumapviewDAO dao = new KBMobilemenumapviewDAO();
      KBMobilemenumapviewRecord result = dao.loadKBMobilemenumapviewRecord(key);
      logger.trace("loadKBMobilemenumapviewRecord:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadKBMobilemenumapviewRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public JSONObject getJSONKBMobilemenumapviewRecordSearchResultByPage(
      KBMobilemenumapviewRecord record, String offset, String maxrows, String orderBy) throws
      Exception {
    return getJSONKBMobilemenumapviewRecordSearchResultByPage(record, offset, maxrows, orderBy, null);
  }

  public JSONObject getJSONKBMobilemenumapviewRecordSearchResultByPage(
      KBMobilemenumapviewRecord record, String offset, String maxrows, String orderBy,
      String customCondition) throws Exception {
    try {
      logger.trace("getJSONKBMobilemenumapviewRecordSearchResultByPage:" + record + " Offset:" + offset + " Maxrows:" + maxrows);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("getJSONKBMobilemenumapviewRecordSearchResult", null);
      KBMobilemenumapviewDAO dao = new KBMobilemenumapviewDAO();
      int totalCount = dao.loadKBMobilemenumapviewRecordCount(record);
      dao.setLimits(offset, maxrows);
      KBMobilemenumapviewRecord[] records = null;
      if (totalCount > 0) {
        dao.setOrderBy(orderBy);
        records = dao.searchKBMobilemenumapviewRecords(record);
      }
      JSONObject resultObject = new JSONObject();
      resultObject.put("total",totalCount + "");
      JSONArray dataArray = new JSONArray();
      int recordCount = 0;
      if (totalCount > 0) {
        recordCount = records.length;
      }
      for (int index = 0; index < recordCount; index++) {
        dataArray.add(records[index].getJSONObjectUI());
      }
      resultObject.put("rows",dataArray);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultObject;
    }
    catch(Exception exception) {
      logger.error("getJSONKBMobilemenumapviewRecordSearchResult" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int insertKBMobilemenumapviewRecord(KBMobilemenumapviewRecord record) throws Exception {
    try {
      logger.trace("insertKBMobilemenumapviewRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("insertKBMobilemenumapviewRecord", null);
      KBMobilemenumapviewDAO dao = new KBMobilemenumapviewDAO();
      int result = dao.insertKBMobilemenumapviewRecord(record);
      logger.trace("insertKBMobilemenumapviewRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("insertKBMobilemenumapviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBMobilemenumapviewRecord(KBMobilemenumapviewRecord record) throws
      Exception {
    try {
      logger.trace("updateKBMobilemenumapviewRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBMobilemenumapviewRecord", null);
      KBMobilemenumapviewDAO dao = new KBMobilemenumapviewDAO();
      boolean result = dao.updateKBMobilemenumapviewRecord(record);
      logger.trace("updateKBMobilemenumapviewRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBMobilemenumapviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBMobilemenumapviewRecordNonNull(KBMobilemenumapviewRecord inputRecord)
      throws Exception {
    try {
      logger.trace("updateKBMobilemenumapviewRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBMobilemenumapviewRecordNoNull", null);
      KBMobilemenumapviewDAO dao = new KBMobilemenumapviewDAO();
      KBMobilemenumapviewRecord dbRecord = dao.loadKBMobilemenumapviewRecord(inputRecord.getId());
      if (dbRecord == null) {
        throw new Exception("Record not found");
      }
      dbRecord.loadNonNullContent(inputRecord);
      boolean result = dao.updateKBMobilemenumapviewRecord(inputRecord);
      logger.trace("updateKBMobilemenumapviewRecordNoNull:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBMobilemenumapviewRecordNoNull" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean deleteKBMobilemenumapviewRecord(KBMobilemenumapviewRecord record) throws
      Exception {
    try {
      logger.trace("deleteKBMobilemenumapviewRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("deleteKBMobilemenumapviewRecord", null);
      KBMobilemenumapviewDAO dao = new KBMobilemenumapviewDAO();
      boolean result = dao.deleteKBMobilemenumapviewRecord(record);
      logger.trace("deleteKBMobilemenumapviewRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("deleteKBMobilemenumapviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }
}
