package com.key.mb.service;

import com.key.mb.common.KBService;
import com.key.mb.dao.KBMobilejsonresponseDAO;
import com.key.mb.to.KBMobilejsonresponseRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class KBMobilejsonresponseService extends KBService {
  public static LogUtils logger = new LogUtils(KBMobilejsonresponseService.class.getName());

  public KBMobilejsonresponseRecord[] loadKBMobilejsonresponseRecords(String query) throws
      Exception {
    try {
      logger.trace("loadKBMobilejsonresponseRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilejsonresponseRecords", null);
      KBMobilejsonresponseDAO dao = new KBMobilejsonresponseDAO();
      KBMobilejsonresponseRecord[] results = dao.loadKBMobilejsonresponseRecords(query);
      int resultRecordCount = 0;
      if (results != null) {
        resultRecordCount = results.length;
      }
      logger.trace("loadKBMobilejsonresponseRecords:Fetched" + resultRecordCount);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return results;
    }
    catch(Exception exception) {
      logger.error("loadKBMobilejsonresponseRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilejsonresponseRecord loadFirstKBMobilejsonresponseRecord(String query) throws
      Exception {
    try {
      logger.trace("loadKBMobilejsonresponseRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilejsonresponseRecords", null);
      KBMobilejsonresponseDAO dao = new KBMobilejsonresponseDAO();
      KBMobilejsonresponseRecord result = dao.loadFirstKBMobilejsonresponseRecord(query);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadFirstKBMobilejsonresponseRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilejsonresponseRecord searchFirstKBMobilejsonresponseRecord(
      KBMobilejsonresponseRecord record) throws Exception {
    try {
      logger.trace("searchFirstKBMobilejsonresponseRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBMobilejsonresponseRecords", null);
      KBMobilejsonresponseDAO dao = new KBMobilejsonresponseDAO();
      KBMobilejsonresponseRecord[] records = dao.searchKBMobilejsonresponseRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBMobilejsonresponseRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilejsonresponseRecord searchKBMobilejsonresponseRecordExactUpper(
      KBMobilejsonresponseRecord record) throws Exception {
    try {
      logger.trace("searchFirstKBMobilejsonresponseRecordsExactUpper:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBMobilejsonresponseRecordsExactUpper", null);
      KBMobilejsonresponseDAO dao = new KBMobilejsonresponseDAO();
      KBMobilejsonresponseRecord[] records = dao.searchKBMobilejsonresponseRecordsExactUpper(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBMobilejsonresponseRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilejsonresponseRecord[] searchKBMobilejsonresponseRecords(
      KBMobilejsonresponseRecord record) throws Exception {
    try {
      logger.trace("searchKBMobilejsonresponseRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilejsonresponseRecords", null);
      KBMobilejsonresponseDAO dao = new KBMobilejsonresponseDAO();
      KBMobilejsonresponseRecord[] records = dao.searchKBMobilejsonresponseRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return records;
    }
    catch(Exception exception) {
      logger.error("searchKBMobilejsonresponseRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int loadKBMobilejsonresponseRecordCount(KBMobilejsonresponseRecord record) throws
      Exception {
    return loadKBMobilejsonresponseRecordCount(record, null);
  }

  public int loadKBMobilejsonresponseRecordCount(KBMobilejsonresponseRecord record,
      String customCondition) throws Exception {
    try {
      logger.trace("loadKBMobilejsonresponseRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilejsonresponseRecordCount", null);
      KBMobilejsonresponseDAO dao = new KBMobilejsonresponseDAO();
      dao.setCustomCondition(customCondition);
      int resultcount = dao.loadKBMobilejsonresponseRecordCount(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultcount;
    }
    catch(Exception exception) {
      logger.error("loadKBMobilejsonresponseRecordCount" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilejsonresponseRecord loadKBMobilejsonresponseRecord(String key) throws Exception {
    try {
      logger.trace("loadKBMobilejsonresponseRecord:" + key);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilejsonresponseRecordCount", null);
      KBMobilejsonresponseDAO dao = new KBMobilejsonresponseDAO();
      KBMobilejsonresponseRecord result = dao.loadKBMobilejsonresponseRecord(key);
      logger.trace("loadKBMobilejsonresponseRecord:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadKBMobilejsonresponseRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public JSONObject getJSONKBMobilejsonresponseRecordSearchResultByPage(
      KBMobilejsonresponseRecord record, String offset, String maxrows, String orderBy) throws
      Exception {
    return getJSONKBMobilejsonresponseRecordSearchResultByPage(record, offset, maxrows, orderBy, null);
  }

  public JSONObject getJSONKBMobilejsonresponseRecordSearchResultByPage(
      KBMobilejsonresponseRecord record, String offset, String maxrows, String orderBy,
      String customCondition) throws Exception {
    try {
      logger.trace("getJSONKBMobilejsonresponseRecordSearchResultByPage:" + record + " Offset:" + offset + " Maxrows:" + maxrows);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("getJSONKBMobilejsonresponseRecordSearchResult", null);
      KBMobilejsonresponseDAO dao = new KBMobilejsonresponseDAO();
      int totalCount = dao.loadKBMobilejsonresponseRecordCount(record);
      dao.setLimits(offset, maxrows);
      KBMobilejsonresponseRecord[] records = null;
      if (totalCount > 0) {
        dao.setOrderBy(orderBy);
        records = dao.searchKBMobilejsonresponseRecords(record);
      }
      JSONObject resultObject = new JSONObject();
      resultObject.put("total",totalCount + "");
      JSONArray dataArray = new JSONArray();
      int recordCount = 0;
      if (totalCount > 0) {
        recordCount = records.length;
      }
      for (int index = 0; index < recordCount; index++) {
        dataArray.add(records[index].getJSONObjectUI());
      }
      resultObject.put("rows",dataArray);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultObject;
    }
    catch(Exception exception) {
      logger.error("getJSONKBMobilejsonresponseRecordSearchResult" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int insertKBMobilejsonresponseRecord(KBMobilejsonresponseRecord record) throws Exception {
    try {
      logger.trace("insertKBMobilejsonresponseRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("insertKBMobilejsonresponseRecord", null);
      KBMobilejsonresponseDAO dao = new KBMobilejsonresponseDAO();
      int result = dao.insertKBMobilejsonresponseRecord(record);
      logger.trace("insertKBMobilejsonresponseRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("insertKBMobilejsonresponseRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBMobilejsonresponseRecord(KBMobilejsonresponseRecord record) throws
      Exception {
    try {
      logger.trace("updateKBMobilejsonresponseRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBMobilejsonresponseRecord", null);
      KBMobilejsonresponseDAO dao = new KBMobilejsonresponseDAO();
      boolean result = dao.updateKBMobilejsonresponseRecord(record);
      logger.trace("updateKBMobilejsonresponseRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBMobilejsonresponseRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBMobilejsonresponseRecordNonNull(KBMobilejsonresponseRecord inputRecord)
      throws Exception {
    try {
      logger.trace("updateKBMobilejsonresponseRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBMobilejsonresponseRecordNoNull", null);
      KBMobilejsonresponseDAO dao = new KBMobilejsonresponseDAO();
      KBMobilejsonresponseRecord dbRecord = dao.loadKBMobilejsonresponseRecord(inputRecord.getId());
      if (dbRecord == null) {
        throw new Exception("Record not found");
      }
      dbRecord.loadNonNullContent(inputRecord);
      boolean result = dao.updateKBMobilejsonresponseRecord(inputRecord);
      logger.trace("updateKBMobilejsonresponseRecordNoNull:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBMobilejsonresponseRecordNoNull" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean deleteKBMobilejsonresponseRecord(KBMobilejsonresponseRecord record) throws
      Exception {
    try {
      logger.trace("deleteKBMobilejsonresponseRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("deleteKBMobilejsonresponseRecord", null);
      KBMobilejsonresponseDAO dao = new KBMobilejsonresponseDAO();
      boolean result = dao.deleteKBMobilejsonresponseRecord(record);
      logger.trace("deleteKBMobilejsonresponseRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("deleteKBMobilejsonresponseRecord" + getStackTrace(exception));
      throw exception;
    }
  }
}
