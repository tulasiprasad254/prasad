package com.key.mb.service;

import com.key.mb.common.KBService;
import com.key.mb.dao.KBCustomerviewDAO;
import com.key.mb.to.KBCustomerviewRecord;
import com.key.utils.DateUtils;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.util.HashMap;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class KBCustomerviewService extends KBService {
  public static LogUtils logger = new LogUtils(KBCustomerviewService.class.getName());

  public KBCustomerviewRecord[] loadKBCustomerviewRecords(String query) throws Exception {
    try {
      logger.trace("loadKBCustomerviewRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBCustomerviewRecords", null);
      KBCustomerviewDAO dao = new KBCustomerviewDAO();
      KBCustomerviewRecord[] results = dao.loadKBCustomerviewRecords(query);
      int resultRecordCount = 0;
      if (results != null) {
        resultRecordCount = results.length;
      }
      logger.trace("loadKBCustomerviewRecords:Fetched" + resultRecordCount);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return results;
    }
    catch(Exception exception) {
      logger.error("loadKBCustomerviewRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBCustomerviewRecord loadFirstKBCustomerviewRecord(String query) throws Exception {
    try {
      logger.trace("loadKBCustomerviewRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBCustomerviewRecords", null);
      KBCustomerviewDAO dao = new KBCustomerviewDAO();
      KBCustomerviewRecord result = dao.loadFirstKBCustomerviewRecord(query);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadFirstKBCustomerviewRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBCustomerviewRecord searchFirstKBCustomerviewRecord(KBCustomerviewRecord record) throws
      Exception {
    try {
      logger.trace("searchFirstKBCustomerviewRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBCustomerviewRecords", null);
      KBCustomerviewDAO dao = new KBCustomerviewDAO();
      KBCustomerviewRecord[] records = dao.searchKBCustomerviewRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBCustomerviewRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBCustomerviewRecord searchKBCustomerviewRecordExactUpper(KBCustomerviewRecord record)
      throws Exception {
    try {
      logger.trace("searchFirstKBCustomerviewRecordsExactUpper:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBCustomerviewRecordsExactUpper", null);
      KBCustomerviewDAO dao = new KBCustomerviewDAO();
      KBCustomerviewRecord[] records = dao.searchKBCustomerviewRecordsExactUpper(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBCustomerviewRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBCustomerviewRecord[] searchKBCustomerviewRecords(KBCustomerviewRecord record) throws
      Exception {
    try {
      logger.trace("searchKBCustomerviewRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBCustomerviewRecords", null);
      KBCustomerviewDAO dao = new KBCustomerviewDAO();
      KBCustomerviewRecord[] records = dao.searchKBCustomerviewRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return records;
    }
    catch(Exception exception) {
      logger.error("searchKBCustomerviewRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int loadKBCustomerviewRecordCount(KBCustomerviewRecord record) throws Exception {
    return loadKBCustomerviewRecordCount(record, null);
  }

  public int loadKBCustomerviewRecordCount(KBCustomerviewRecord record, String customCondition)
      throws Exception {
    try {
      logger.trace("loadKBCustomerviewRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBCustomerviewRecordCount", null);
      KBCustomerviewDAO dao = new KBCustomerviewDAO();
      dao.setCustomCondition(customCondition);
      int resultcount = dao.loadKBCustomerviewRecordCount(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultcount;
    }
    catch(Exception exception) {
      logger.error("loadKBCustomerviewRecordCount" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBCustomerviewRecord loadKBCustomerviewRecord(String key) throws Exception {
    try {
      logger.trace("loadKBCustomerviewRecord:" + key);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBCustomerviewRecordCount", null);
      KBCustomerviewDAO dao = new KBCustomerviewDAO();
      KBCustomerviewRecord result = dao.loadKBCustomerviewRecord(key);
      logger.trace("loadKBCustomerviewRecord:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadKBCustomerviewRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public JSONObject getJSONKBCustomerviewRecordSearchResultByPage(KBCustomerviewRecord record,
      String offset, String maxrows, String orderBy) throws Exception {
    return getJSONKBCustomerviewRecordSearchResultByPage(record, offset, maxrows, orderBy, null);
  }

  public JSONObject getJSONKBCustomerviewRecordSearchResultByPage(KBCustomerviewRecord record,
      String offset, String maxrows, String orderBy, String customCondition) throws Exception {
    try {
      logger.trace("getJSONKBCustomerviewRecordSearchResultByPage:" + record + " Offset:" + offset + " Maxrows:" + maxrows);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("getJSONKBCustomerviewRecordSearchResult", null);
      KBCustomerviewDAO dao = new KBCustomerviewDAO();
      int totalCount = dao.loadKBCustomerviewRecordCount(record);
      dao.setLimits(offset, maxrows);
      KBCustomerviewRecord[] records = null;
      if (totalCount > 0) {
        dao.setOrderBy(orderBy);
        records = dao.searchKBCustomerviewRecords(record);
      }
      JSONObject resultObject = new JSONObject();
      resultObject.put("total",totalCount + "");
      JSONArray dataArray = new JSONArray();
      int recordCount = 0;
      if (totalCount > 0) {
        recordCount = records.length;
      }
      for (int index = 0; index < recordCount; index++) {
        dataArray.add(records[index].getJSONObjectUI());
      }
      resultObject.put("rows",dataArray);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultObject;
    }
    catch(Exception exception) {
      logger.error("getJSONKBCustomerviewRecordSearchResult" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int insertKBCustomerviewRecord(KBCustomerviewRecord record) throws Exception {
    try {
      logger.trace("insertKBCustomerviewRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("insertKBCustomerviewRecord", null);
      KBCustomerviewDAO dao = new KBCustomerviewDAO();
      int result = dao.insertKBCustomerviewRecord(record);
      logger.trace("insertKBCustomerviewRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomerviewService", record.getId() + "", "Create", record.getCreatedby(), "Created");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("insertKBCustomerviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBCustomerviewRecord(KBCustomerviewRecord record) throws Exception {
    try {
      logger.trace("updateKBCustomerviewRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBCustomerviewRecord", null);
      KBCustomerviewDAO dao = new KBCustomerviewDAO();
      boolean result = dao.updateKBCustomerviewRecord(record);
      logger.trace("updateKBCustomerviewRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomerviewService", record.getId() + "", "Update", record.getModifiedby(), "Update");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBCustomerviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBCustomerviewRecordNonNull(KBCustomerviewRecord inputRecord) throws
      Exception {
    try {
      logger.trace("updateKBCustomerviewRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBCustomerviewRecordNoNull", null);
      KBCustomerviewDAO dao = new KBCustomerviewDAO();
      KBCustomerviewRecord dbRecord = dao.loadKBCustomerviewRecord(inputRecord.getId());
      if (dbRecord == null) {
        throw new Exception("Record not found");
      }
      dbRecord.loadNonNullContent(inputRecord);
      boolean result = dao.updateKBCustomerviewRecord(inputRecord);
      createMakerCheckerAuditEntry("KBCustomerviewService", inputRecord.getId() + "", "Update", inputRecord.getModifiedby(), "UpdateNoNull");
      logger.trace("updateKBCustomerviewRecordNoNull:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBCustomerviewRecordNoNull" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean deleteKBCustomerviewRecord(KBCustomerviewRecord record) throws Exception {
    try {
      logger.trace("deleteKBCustomerviewRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("deleteKBCustomerviewRecord", null);
      KBCustomerviewDAO dao = new KBCustomerviewDAO();
      boolean result = dao.deleteKBCustomerviewRecord(record);
      logger.trace("deleteKBCustomerviewRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomerviewService", record.getId(), "Delete", null, "Deleted");
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("deleteKBCustomerviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean approveKBCustomerviewRecord(KBCustomerviewRecord inputRecord, String updateId,
      String comment) throws Exception {
    try {
      logger.trace("approveKBCustomerviewRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("approveKBCustomerviewRecord", null);
      KBCustomerviewDAO dao = new KBCustomerviewDAO();
      KBCustomerviewRecord updateRecord = dao.loadKBCustomerviewRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForApproval(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot approve - Invalid Status for Approval");
      }
      if (StringUtils.isSame(updateRecord.getMadeby(), updateId)) {
        throw new Exception("MF-ERR-CA-MCS102:Cannot Approve. Maker Checker cannot be same");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("1");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBCustomerviewRecord(updateRecord);
      logger.trace("approveKBCustomerviewRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomerviewService", updateRecord.getId(), "Approve", updateId, comment);
      HashMap approveEventMap = callActionEvent("Event_OnApprovalOf_KBCustomerviewRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("approveKBCustomerviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean submitKBCustomerviewRecord(KBCustomerviewRecord inputRecord, String updateId,
      String comment) throws Exception {
    try {
      logger.trace("submitKBCustomerviewRecordNoNull:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("submitKBCustomerviewRecordNoNull", null);
      KBCustomerviewDAO dao = new KBCustomerviewDAO();
      KBCustomerviewRecord updateRecord = dao.loadKBCustomerviewRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForSubmission(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CS-IS101:Cannot submit - Invalid Status for Submission");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("4");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBCustomerviewRecord(updateRecord);
      logger.trace("approveKBCustomerviewRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomerviewService", updateRecord.getId(), "Submit", updateId, comment);
      HashMap submitEventMap = callActionEvent("Event_OnApprovalOf_KBCustomerviewRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("submitKBCustomerviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean denyKBCustomerviewRecord(KBCustomerviewRecord inputRecord, String updateId,
      String comment) throws Exception {
    try {
      logger.trace("denyKBCustomerviewRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("denyKBCustomerviewRecord", null);
      KBCustomerviewDAO dao = new KBCustomerviewDAO();
      KBCustomerviewRecord updateRecord = dao.loadKBCustomerviewRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForDeny(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot deny - Invalid Status for Deny");
      }
      if (StringUtils.isSame(updateRecord.getMadeby(), updateId)) {
        throw new Exception("MF-ERR-CA-MCS102:Cannot Deny. Maker Checker cannot be same");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("5");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBCustomerviewRecord(updateRecord);
      logger.trace("approveKBCustomerviewRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomerviewService", updateRecord.getId(), "Deny", updateId, comment);
      HashMap denyEventMap = callActionEvent("Event_OnDenyOf_KBCustomerviewRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("denyKBCustomerviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean denyPermanantKBCustomerviewRecord(KBCustomerviewRecord inputRecord,
      String updateId, String comment) throws Exception {
    try {
      logger.trace("denyPKBCustomerviewRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("denyPKBCustomerviewRecord", null);
      KBCustomerviewDAO dao = new KBCustomerviewDAO();
      KBCustomerviewRecord updateRecord = dao.loadKBCustomerviewRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForDeny(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot deny - Invalid Status for Deny");
      }
      if (StringUtils.isSame(updateRecord.getMadeby(), updateId)) {
        throw new Exception("MF-ERR-CA-MCS102:Cannot Deny. Maker Checker cannot be same");
      }
      updateRecord.setRstatus("1");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("58");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBCustomerviewRecord(updateRecord);
      logger.trace("approveKBCustomerviewRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomerviewService", updateRecord.getId(), "DenyP", updateId, comment);
      HashMap denyEventMap = callActionEvent("Event_OnDenyPOf_KBCustomerviewRecord", updateRecord.getId());
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("denyPKBCustomerviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean remindApprovalKBCustomerviewRecord(KBCustomerviewRecord inputRecord,
      String updateId, String comment) throws Exception {
    try {
      logger.trace("remindApprovalKBCustomerviewRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("remindApprovalKBCustomerviewRecord", null);
      KBCustomerviewDAO dao = new KBCustomerviewDAO();
      KBCustomerviewRecord updateRecord = dao.loadKBCustomerviewRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForApproval(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot Remind - Invalid Status for Reminder");
      }
      createMakerCheckerAuditEntry("KBCustomerviewService", updateRecord.getId(), "Approval Reminder", updateId, comment);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return true;
    }
    catch(Exception exception) {
      logger.error("remindApprovalKBCustomerviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean resetApprovalKBCustomerviewRecord(KBCustomerviewRecord inputRecord,
      String updateId, String comment) throws Exception {
    try {
      logger.trace("resetApprovalKBCustomerviewRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("resetApprovalKBCustomerviewRecord", null);
      KBCustomerviewDAO dao = new KBCustomerviewDAO();
      KBCustomerviewRecord updateRecord = dao.loadKBCustomerviewRecord(inputRecord.getId());
      if (updateRecord == null) {
        throw new Exception("MF-ERR-CA-RNFA104:Record not found");
      }
      if (!isValidStatusForDeny(updateRecord.getCurrappstatus())) {
        throw new Exception("MF-ERR-CA-IS101:Cannot submit - Invalid Status for Reset");
      }
      updateRecord.setRstatus("0");
      updateRecord.setCheckerlastcmt(comment);
      updateRecord.setCurrappstatus("0");
      updateRecord.setModifiedat(DateUtils.getCurrentDateTime());
      updateRecord.setModifiedby(updateId);
      updateRecord.setCheckedat(DateUtils.getCurrentDateTime());
      updateRecord.setCheckedby(updateId);
      boolean result = dao.updateKBCustomerviewRecord(updateRecord);
      logger.trace("approveKBCustomerviewRecord:Result:" + result);
      createMakerCheckerAuditEntry("KBCustomerviewService", updateRecord.getId(), "Reset Approval", updateId, comment);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("resetApprovalKBCustomerviewRecord" + getStackTrace(exception));
      throw exception;
    }
  }
}
