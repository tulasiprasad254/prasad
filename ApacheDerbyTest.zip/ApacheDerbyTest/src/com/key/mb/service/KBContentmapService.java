package com.key.mb.service;

import com.key.mb.common.KBService;
import com.key.mb.dao.KBContentmapDAO;
import com.key.mb.to.KBContentmapRecord;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class KBContentmapService extends KBService {
  public static LogUtils logger = new LogUtils(KBContentmapService.class.getName());

  public KBContentmapRecord[] loadKBContentmapRecords(String query) throws Exception {
    try {
      logger.trace("loadKBContentmapRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBContentmapRecords", null);
      KBContentmapDAO dao = new KBContentmapDAO();
      KBContentmapRecord[] results = dao.loadKBContentmapRecords(query);
      int resultRecordCount = 0;
      if (results != null) {
        resultRecordCount = results.length;
      }
      logger.trace("loadKBContentmapRecords:Fetched" + resultRecordCount);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return results;
    }
    catch(Exception exception) {
      logger.error("loadKBContentmapRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBContentmapRecord loadFirstKBContentmapRecord(String query) throws Exception {
    try {
      logger.trace("loadKBContentmapRecords:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBContentmapRecords", null);
      KBContentmapDAO dao = new KBContentmapDAO();
      KBContentmapRecord result = dao.loadFirstKBContentmapRecord(query);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadFirstKBContentmapRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBContentmapRecord searchFirstKBContentmapRecord(KBContentmapRecord record) throws
      Exception {
    try {
      logger.trace("searchFirstKBContentmapRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBContentmapRecords", null);
      KBContentmapDAO dao = new KBContentmapDAO();
      KBContentmapRecord[] records = dao.searchKBContentmapRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBContentmapRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBContentmapRecord searchKBContentmapRecordExactUpper(KBContentmapRecord record) throws
      Exception {
    try {
      logger.trace("searchFirstKBContentmapRecordsExactUpper:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBContentmapRecordsExactUpper", null);
      KBContentmapDAO dao = new KBContentmapDAO();
      KBContentmapRecord[] records = dao.searchKBContentmapRecordsExactUpper(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBContentmapRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBContentmapRecord[] searchKBContentmapRecords(KBContentmapRecord record) throws
      Exception {
    try {
      logger.trace("searchKBContentmapRecords:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBContentmapRecords", null);
      KBContentmapDAO dao = new KBContentmapDAO();
      KBContentmapRecord[] records = dao.searchKBContentmapRecords(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return records;
    }
    catch(Exception exception) {
      logger.error("searchKBContentmapRecords" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int loadKBContentmapRecordCount(KBContentmapRecord record) throws Exception {
    return loadKBContentmapRecordCount(record, null);
  }

  public int loadKBContentmapRecordCount(KBContentmapRecord record, String customCondition) throws
      Exception {
    try {
      logger.trace("loadKBContentmapRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBContentmapRecordCount", null);
      KBContentmapDAO dao = new KBContentmapDAO();
      dao.setCustomCondition(customCondition);
      int resultcount = dao.loadKBContentmapRecordCount(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultcount;
    }
    catch(Exception exception) {
      logger.error("loadKBContentmapRecordCount" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBContentmapRecord loadKBContentmapRecord(String key) throws Exception {
    try {
      logger.trace("loadKBContentmapRecord:" + key);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBContentmapRecordCount", null);
      KBContentmapDAO dao = new KBContentmapDAO();
      KBContentmapRecord result = dao.loadKBContentmapRecord(key);
      logger.trace("loadKBContentmapRecord:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadKBContentmapRecord" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public JSONObject getJSONKBContentmapRecordSearchResultByPage(KBContentmapRecord record,
      String offset, String maxrows, String orderBy) throws Exception {
    return getJSONKBContentmapRecordSearchResultByPage(record, offset, maxrows, orderBy, null);
  }

  public JSONObject getJSONKBContentmapRecordSearchResultByPage(KBContentmapRecord record,
      String offset, String maxrows, String orderBy, String customCondition) throws Exception {
    try {
      logger.trace("getJSONKBContentmapRecordSearchResultByPage:" + record + " Offset:" + offset + " Maxrows:" + maxrows);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("getJSONKBContentmapRecordSearchResult", null);
      KBContentmapDAO dao = new KBContentmapDAO();
      int totalCount = dao.loadKBContentmapRecordCount(record);
      dao.setLimits(offset, maxrows);
      KBContentmapRecord[] records = null;
      if (totalCount > 0) {
        dao.setOrderBy(orderBy);
        records = dao.searchKBContentmapRecords(record);
      }
      JSONObject resultObject = new JSONObject();
      resultObject.put("total",totalCount + "");
      JSONArray dataArray = new JSONArray();
      int recordCount = 0;
      if (totalCount > 0) {
        recordCount = records.length;
      }
      for (int index = 0; index < recordCount; index++) {
        dataArray.add(records[index].getJSONObjectUI());
      }
      resultObject.put("rows",dataArray);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultObject;
    }
    catch(Exception exception) {
      logger.error("getJSONKBContentmapRecordSearchResult" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int insertKBContentmapRecord(KBContentmapRecord record) throws Exception {
    try {
      logger.trace("insertKBContentmapRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("insertKBContentmapRecord", null);
      KBContentmapDAO dao = new KBContentmapDAO();
      int result = dao.insertKBContentmapRecord(record);
      logger.trace("insertKBContentmapRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("insertKBContentmapRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBContentmapRecord(KBContentmapRecord record) throws Exception {
    try {
      logger.trace("updateKBContentmapRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBContentmapRecord", null);
      KBContentmapDAO dao = new KBContentmapDAO();
      boolean result = dao.updateKBContentmapRecord(record);
      logger.trace("updateKBContentmapRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBContentmapRecord" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBContentmapRecordNonNull(KBContentmapRecord inputRecord) throws Exception {
    try {
      logger.trace("updateKBContentmapRecord:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBContentmapRecordNoNull", null);
      KBContentmapDAO dao = new KBContentmapDAO();
      KBContentmapRecord dbRecord = dao.loadKBContentmapRecord(inputRecord.getId());
      if (dbRecord == null) {
        throw new Exception("Record not found");
      }
      dbRecord.loadNonNullContent(inputRecord);
      boolean result = dao.updateKBContentmapRecord(inputRecord);
      logger.trace("updateKBContentmapRecordNoNull:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBContentmapRecordNoNull" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean deleteKBContentmapRecord(KBContentmapRecord record) throws Exception {
    try {
      logger.trace("deleteKBContentmapRecord:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("deleteKBContentmapRecord", null);
      KBContentmapDAO dao = new KBContentmapDAO();
      boolean result = dao.deleteKBContentmapRecord(record);
      logger.trace("deleteKBContentmapRecord:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("deleteKBContentmapRecord" + getStackTrace(exception));
      throw exception;
    }
  }
}
