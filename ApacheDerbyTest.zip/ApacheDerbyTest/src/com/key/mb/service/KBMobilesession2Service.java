package com.key.mb.service;

import com.key.mb.common.KBService;
import com.key.mb.dao.KBMobilesession2DAO;
import com.key.mb.to.KBMobilesession2Record;
import com.key.utils.LogUtils;
import java.lang.Exception;
import java.lang.String;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class KBMobilesession2Service extends KBService {
  public static LogUtils logger = new LogUtils(KBMobilesession2Service.class.getName());

  public KBMobilesession2Record[] loadKBMobilesession2Records(String query) throws Exception {
    try {
      logger.trace("loadKBMobilesession2Records:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilesession2Records", null);
      KBMobilesession2DAO dao = new KBMobilesession2DAO();
      KBMobilesession2Record[] results = dao.loadKBMobilesession2Records(query);
      int resultRecordCount = 0;
      if (results != null) {
        resultRecordCount = results.length;
      }
      logger.trace("loadKBMobilesession2Records:Fetched" + resultRecordCount);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return results;
    }
    catch(Exception exception) {
      logger.error("loadKBMobilesession2Records" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilesession2Record loadFirstKBMobilesession2Record(String query) throws Exception {
    try {
      logger.trace("loadKBMobilesession2Records:" + query);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilesession2Records", null);
      KBMobilesession2DAO dao = new KBMobilesession2DAO();
      KBMobilesession2Record result = dao.loadFirstKBMobilesession2Record(query);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadFirstKBMobilesession2Record" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilesession2Record searchFirstKBMobilesession2Record(KBMobilesession2Record record)
      throws Exception {
    try {
      logger.trace("searchFirstKBMobilesession2Records:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBMobilesession2Records", null);
      KBMobilesession2DAO dao = new KBMobilesession2DAO();
      KBMobilesession2Record[] records = dao.searchKBMobilesession2Records(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBMobilesession2Records" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilesession2Record searchKBMobilesession2RecordExactUpper(
      KBMobilesession2Record record) throws Exception {
    try {
      logger.trace("searchFirstKBMobilesession2RecordsExactUpper:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("searchFirstKBMobilesession2RecordsExactUpper", null);
      KBMobilesession2DAO dao = new KBMobilesession2DAO();
      KBMobilesession2Record[] records = dao.searchKBMobilesession2RecordsExactUpper(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      if(records == null) {
        return null;
      }
      if(records.length < 1) {
        return null;
      }
      return records[0];
    }
    catch(Exception exception) {
      logger.error("searchFirstKBMobilesession2Records" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilesession2Record[] searchKBMobilesession2Records(KBMobilesession2Record record)
      throws Exception {
    try {
      logger.trace("searchKBMobilesession2Records:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilesession2Records", null);
      KBMobilesession2DAO dao = new KBMobilesession2DAO();
      KBMobilesession2Record[] records = dao.searchKBMobilesession2Records(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return records;
    }
    catch(Exception exception) {
      logger.error("searchKBMobilesession2Records" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int loadKBMobilesession2RecordCount(KBMobilesession2Record record) throws Exception {
    return loadKBMobilesession2RecordCount(record, null);
  }

  public int loadKBMobilesession2RecordCount(KBMobilesession2Record record, String customCondition)
      throws Exception {
    try {
      logger.trace("loadKBMobilesession2Record:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilesession2RecordCount", null);
      KBMobilesession2DAO dao = new KBMobilesession2DAO();
      dao.setCustomCondition(customCondition);
      int resultcount = dao.loadKBMobilesession2RecordCount(record);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultcount;
    }
    catch(Exception exception) {
      logger.error("loadKBMobilesession2RecordCount" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public KBMobilesession2Record loadKBMobilesession2Record(String key) throws Exception {
    try {
      logger.trace("loadKBMobilesession2Record:" + key);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("loadKBMobilesession2RecordCount", null);
      KBMobilesession2DAO dao = new KBMobilesession2DAO();
      KBMobilesession2Record result = dao.loadKBMobilesession2Record(key);
      logger.trace("loadKBMobilesession2Record:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("loadKBMobilesession2Record" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public JSONObject getJSONKBMobilesession2RecordSearchResultByPage(KBMobilesession2Record record,
      String offset, String maxrows, String orderBy) throws Exception {
    return getJSONKBMobilesession2RecordSearchResultByPage(record, offset, maxrows, orderBy, null);
  }

  public JSONObject getJSONKBMobilesession2RecordSearchResultByPage(KBMobilesession2Record record,
      String offset, String maxrows, String orderBy, String customCondition) throws Exception {
    try {
      logger.trace("getJSONKBMobilesession2RecordSearchResultByPage:" + record + " Offset:" + offset + " Maxrows:" + maxrows);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("getJSONKBMobilesession2RecordSearchResult", null);
      KBMobilesession2DAO dao = new KBMobilesession2DAO();
      int totalCount = dao.loadKBMobilesession2RecordCount(record);
      dao.setLimits(offset, maxrows);
      KBMobilesession2Record[] records = null;
      if (totalCount > 0) {
        dao.setOrderBy(orderBy);
        records = dao.searchKBMobilesession2Records(record);
      }
      JSONObject resultObject = new JSONObject();
      resultObject.put("total",totalCount + "");
      JSONArray dataArray = new JSONArray();
      int recordCount = 0;
      if (totalCount > 0) {
        recordCount = records.length;
      }
      for (int index = 0; index < recordCount; index++) {
        dataArray.add(records[index].getJSONObjectUI());
      }
      resultObject.put("rows",dataArray);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return resultObject;
    }
    catch(Exception exception) {
      logger.error("getJSONKBMobilesession2RecordSearchResult" + getStackTrace(exception));
      throw new Exception("MFException:" + getErrorMessage(exception));
    }
  }

  public int insertKBMobilesession2Record(KBMobilesession2Record record) throws Exception {
    try {
      logger.trace("insertKBMobilesession2Record:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("insertKBMobilesession2Record", null);
      KBMobilesession2DAO dao = new KBMobilesession2DAO();
      int result = dao.insertKBMobilesession2Record(record);
      logger.trace("insertKBMobilesession2Record:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("insertKBMobilesession2Record" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBMobilesession2Record(KBMobilesession2Record record) throws Exception {
    try {
      logger.trace("updateKBMobilesession2Record:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBMobilesession2Record", null);
      KBMobilesession2DAO dao = new KBMobilesession2DAO();
      boolean result = dao.updateKBMobilesession2Record(record);
      logger.trace("updateKBMobilesession2Record:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBMobilesession2Record" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean updateKBMobilesession2RecordNonNull(KBMobilesession2Record inputRecord) throws
      Exception {
    try {
      logger.trace("updateKBMobilesession2Record:" + inputRecord);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("updateKBMobilesession2RecordNoNull", null);
      KBMobilesession2DAO dao = new KBMobilesession2DAO();
      KBMobilesession2Record dbRecord = dao.loadKBMobilesession2Record(inputRecord.getId());
      if (dbRecord == null) {
        throw new Exception("Record not found");
      }
      dbRecord.loadNonNullContent(inputRecord);
      boolean result = dao.updateKBMobilesession2Record(inputRecord);
      logger.trace("updateKBMobilesession2RecordNoNull:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("updateKBMobilesession2RecordNoNull" + getStackTrace(exception));
      throw exception;
    }
  }

  public boolean deleteKBMobilesession2Record(KBMobilesession2Record record) throws Exception {
    try {
      logger.trace("deleteKBMobilesession2Record:" + record);
      String beginMesssage = logger.generateFunctionBeginTimerMessage("deleteKBMobilesession2Record", null);
      KBMobilesession2DAO dao = new KBMobilesession2DAO();
      boolean result = dao.deleteKBMobilesession2Record(record);
      logger.trace("deleteKBMobilesession2Record:Result:" + result);
      logger.generateFunctionEndTimerMessage(beginMesssage);
      return result;
    }
    catch(Exception exception) {
      logger.error("deleteKBMobilesession2Record" + getStackTrace(exception));
      throw exception;
    }
  }
}
