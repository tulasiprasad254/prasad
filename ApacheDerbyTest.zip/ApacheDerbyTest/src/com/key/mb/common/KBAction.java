package com.key.mb.common;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Method;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.key.mb.service.KBControllermapService;
import com.key.mb.to.KBControllermapRecord;
import com.key.utils.LogUtils;

public class KBAction extends HttpServlet{

	static LogUtils logger = new LogUtils(KBAction.class.getName());

	public KBAction() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		out.println("<H1><c>KeyBank</H1>");
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		try {
			HttpServletRequest req = request;
			HttpServletResponse res = response;
			String actionType = request.getParameter("hiddenActionType");
			response.setContentType("text/html");
			
			String tableCode = actionType.substring(0,
					actionType.lastIndexOf('-') + 1);
			String actionCode = actionType.substring(actionType
					.lastIndexOf('-') + 1);

			logger.debug("\nTable Code:" + tableCode + "\nAction Type:"
					+ actionType + "\nAction Code:" + actionCode);

			KBControllermapService service = new KBControllermapService();
			KBControllermapRecord searchRecord = new KBControllermapRecord();
			searchRecord.setCode(tableCode);
			KBControllermapRecord[] records = service
					.searchKBControllermapRecords(searchRecord);

			logger.debug("\nClass being called:" + records[0].getClassname());

			Class c = Class.forName(records[0].getClassname());
			Method m = c.getDeclaredMethod("processWebRequest", new Class[] {
					javax.servlet.http.HttpServletRequest.class,
					javax.servlet.http.HttpServletResponse.class,
					java.lang.String.class });

			Object i = c.newInstance();
			Object r = m.invoke(i,
					new Object[] { request, response, actionCode });
		} 
		catch (Exception exception) 
		{
			out.println("Unauthorized Access");
			out.println("<H1><c>KeyBank</H1>");
			exception.printStackTrace();
		}
	}


}
