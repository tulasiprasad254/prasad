package com.key.mb.common;


import com.key.utils.LogUtils;

public class KBRecord {

	static LogUtils logger = new LogUtils(KBRecord.class.getName());

	private boolean noNullFlag = false;

	public void enableNoNull()
	{
		noNullFlag = true;
	}
	
	public void disableNoNull()
	{
		noNullFlag = false;
	}
	
	public boolean isNoNullEnabled()
	{
		return noNullFlag;
	}
	
	private boolean noNullHTMLFlag = false;

	public void enableNoNullHTML()
	{
		noNullHTMLFlag = true;
	}
	
	public void disableNoNullHTML()
	{
		noNullHTMLFlag = false;
	}
	
	public boolean isNoNullForHTMLEnabled()
	{
		return noNullHTMLFlag;
	}	



}
