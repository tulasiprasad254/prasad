package com.key.mb.common;

import java.lang.reflect.Method;
import java.security.SecureRandom;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.key.mb.common.KBDAO;
import com.key.mb.common.KBService;
import com.key.mb.service.KBServicemapService;
import com.key.mb.to.KBCustomerviewRecord;
import com.key.mb.to.KBServicemapRecord;
import com.key.utils.DateUtils;
import com.key.utils.LogUtils;
import com.key.utils.PropertyUtil;
import com.key.utils.StringUtils;

public class KBService {
	static LogUtils logger = new LogUtils(KBService.class.getName());
	StringUtils utils = new StringUtils();

	public String getStackTrace(Exception e)
	{
		return StringUtils.getStackTrace(e);
	}
	
	public HashMap callService(String className, String methodName, HashMap input)
	throws Exception
	{
		try
		{
			Class c = Class.forName(className);
			Method m = c.getDeclaredMethod(methodName, new Class[] {java.util.HashMap.class });
			Object i = c.newInstance();
			Object r = m.invoke(i,new Object[] { input });
			HashMap outputMap = (HashMap)r;
			return outputMap;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			logger.log(StringUtils.getStackTrace(exception), LogUtils.ERROR);
			throw exception;
		}
	}
	
	public String applyGenericCodes(String message, KBCustomerviewRecord customerViewRecord)
	throws Exception
	{
		message = StringUtils.noNull(message);
		message = StringUtils.replaceString(message, "#CUSTOMERLOGINNAME#", customerViewRecord.getCif(), true);
		message = StringUtils.replaceString(message, "#CUSTOMERNAME#", customerViewRecord.getCname(), true);		
		message = StringUtils.replaceString(message, "#CUSTOMERPHONE#", customerViewRecord.getMobile(), true);
		message = StringUtils.replaceString(message, "#CUSTOMEREMAIL#", customerViewRecord.getEmail(), true);
		message = StringUtils.replaceString(message, "#CURRENTDATE#", DateUtils.getCurrentTime("dd-MMM-yyyy"), true);
		message = StringUtils.replaceString(message, "#CURRENTTIME#", DateUtils.getCurrentTime("HH:mm:ss"), true);

		String collectionDate = DateUtils.formatDate(DateUtils.addToDate(new java.util.Date(), Calendar.DAY_OF_MONTH, 7),"dd-MMM-yyyy");
		message = StringUtils.replaceString(message, "#CHQCLTNDATE#", collectionDate, true);
		return message;
	}
	
	public KBServicemapRecord loadServiceMap(String serviceCode)
	throws Exception
	{
		String integratedEnvironment = PropertyUtil.getProperty("IntegratedEnvironment");
		KBServicemapService service = new KBServicemapService();
		KBServicemapRecord searchServiceRecord = new KBServicemapRecord();
		searchServiceRecord.setIntenv(integratedEnvironment);
		searchServiceRecord.setRstatus("1");
		searchServiceRecord.setServicecode(serviceCode);
		KBServicemapRecord resultRecord = service.searchFirstKBServicemapRecord(searchServiceRecord);
		return resultRecord;
	}

	public String getCharges(String serviceCode, String amount)
	throws Exception
	{
				
		return "";
	}

	public String recordRequest(KBServicemapRecord serviceMapRecord, HashMap inputHashMap)
	throws Exception
	{
		
		return "";
	}

	public void recordResponse(String requestId, HashMap outputHashMap)
	throws Exception
	{
		
	}	

	
	public boolean isSuccessfulTransaction(HashMap inputHashMap)
	{
		if (inputHashMap ==null) inputHashMap = new HashMap();
		if (inputHashMap.containsKey("ErrorMessage"))
		{
			String errorMessage = StringUtils.noNull(inputHashMap.get("ErrorMessage"));
			if (!StringUtils.isNullOrEmpty(errorMessage))
			{
				return false;
			}
		}
		return true;
	}

	public String getHashMapValue(HashMap inputHashMap,String inputKey)
	{
		if (inputHashMap ==null) inputHashMap = new HashMap();
		if (!inputHashMap.containsKey(inputKey)) return "";
		String inputValue = StringUtils.noNull(inputHashMap.get(inputKey));
		return inputValue;
	}

	public boolean isValidStatusForDeny(String inputStatus)
	{
		if (StringUtils.isNull(inputStatus)) return false;
		inputStatus = inputStatus.trim();
		if (inputStatus.equals("4")) return true;
		return false;
	}

	public boolean isValidStatusForPasswordReset(String inputStatus)
	{
		if (StringUtils.isNull(inputStatus)) return false;
		inputStatus = inputStatus.trim();
		if (inputStatus.equals("1")) return true;
		return false;
	}

	public boolean isValidStatusForPinReset(String inputStatus)
	{
		if (StringUtils.isNull(inputStatus)) return false;
		inputStatus = inputStatus.trim();
		if (inputStatus.equals("1")) return true;
		return false;
	}	
	
	public boolean isValidStatusForBlock(String inputStatus)
	{
		if (StringUtils.isNull(inputStatus)) return false;
		inputStatus = inputStatus.trim();
		if (inputStatus.equals("1")) return true;
		return false;
	}

	public boolean isValidStatusForApproval(String inputStatus)
	{
		if (StringUtils.isNull(inputStatus)) return false;
		inputStatus = inputStatus.trim();
		if (inputStatus.equals("4")) return true;
		return false;
	}

	public boolean isValidStatusForReset(String inputStatus)
	{
		if (StringUtils.isNull(inputStatus)) return false;
		inputStatus = inputStatus.trim();
		if (inputStatus.equals("0")) return true;
		if (inputStatus.equals("1")) return true;
		if (inputStatus.equals("2")) return true;
		return false;		
	}

	public boolean isValidStatusForSubmission(String inputStatus)
	{
		if (StringUtils.isNull(inputStatus)) return true;
		inputStatus = inputStatus.trim();
		if (inputStatus.equals("-1")) return true;
		if (inputStatus.equals("3")) return true;
		if (inputStatus.equals("5")) return true;
		return false;
	}		
	
    public String getErrorMessage(Exception e)
    {
    	e.printStackTrace();
    	String message = e.toString();
    	message = message.toLowerCase();
    	
    	if (message.indexOf("sqlintegrityconstraintviolation") > -1)
    	{
			return "Duplicate Record";    		
    	}
    	return message;
    }
    
    public String getTableNameDescription(String tableName)
    {
    	if (StringUtils.isNull(tableName)) return tableName;
    	if (tableName.equalsIgnoreCase("CUSTOMER_CATG")) return "Customer Category";
    	if (tableName.equalsIgnoreCase("customer_info")) return "Customer";
    	if (tableName.equalsIgnoreCase("account")) return "Account";
    	if (tableName.equalsIgnoreCase("institution_info")) return "Institution";
    	if (tableName.equalsIgnoreCase("user_info")) return "User";
    	return tableName;    	
    }
    
    
	/*public void createMakerCheckerAuditEntry(String tableName, String recordId, String actionName, String createID, String comments)
	throws Exception
	{
		try
		{
			processSendNotifications(tableName, recordId, actionName, createID, comments);
			String tableNamedescription = getTableNameDescription(tableName);
			MFMakercheckerauditService service = new  MFMakercheckerauditService();
			MFMakercheckerauditRecord record = new MFMakercheckerauditRecord();
			record.setRecid(recordId);
			record.setTabname(tableName);
			record.setActionname(actionName);
			record.setTablelabel(tableNamedescription);
			record.setCreatedat(DateUtils.getCurrentDateTime());
			record.setCreatedby(createID);
			record.setComments(comments);
			service.insertMFMakercheckerauditRecord(record);
		}
		catch(Exception exception)
		{
			logger.error("createMakerCheckerAuditEntry" + getStackTrace(exception));
			throw exception;
		}
	}
	
	public void processSendNotifications(String tableName, String recordId, String actionName, String createID, String comments)
	{
		try
		{
			MFNotificationService notificationService = new MFNotificationService();
//			MFUserinfoService userService = new MFUserinfoService();
//			if (tableName.equals("user_info"))
//			{
//				if (actionName.equals("Approve"))
//				{
//					MFUserinfoRecord userRecord = userService.loadMFUserinfoRecord(recordId);
//					if (userRecord == null) return;
//					notificationService.sendPassword(userRecord.getEmail(), true);
//				}
//			}
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			logger.error("processSendNotifications" + getStackTrace(exception));
		}
	}*/
	
	public boolean isCurrentSessionValid(String sessionId, String userId)
	{
		try
		{
			String query = "";
			query += "SELECT SERVICE, TIMESTAMPDIFF(MINUTE,MODIFIED_AT,NOW()) DT FROM WEB_ACCESS_LOG ";
			query += "WHERE (SESSIONID = '" + sessionId + "') ";
			query += "AND (USER_ID = '" + userId + "') ";			
			query += "ORDER BY CREATED_AT DESC ";
			query += "LIMIT 1		 ";
			
			KBDAO dao = new KBDAO();
			Map inputMap = dao.loadMap(query, "SERVICE", "DT", false);
			if (inputMap.isEmpty()) return true;

			if (inputMap.containsKey("Log Off")) return false;

			Iterator iterator = inputMap.keySet().iterator();
	
			int timeDiff = 0;
			while(iterator.hasNext())
			{
				String key = iterator.next().toString();
				timeDiff = Integer.parseInt(inputMap.get(key).toString());
			}
	
			int maxTimeDiff = Integer.parseInt(PropertyUtil.getProperty("websessiontimeout"));
			if (timeDiff > maxTimeDiff)
			{
				return false;
			}	
			return true;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			logger.error("isCurrentSessionValid" + getStackTrace(exception));			
			return false;
		}
	}

	public boolean isDuplicateSession(String userId)
	{
		try
		{
			String query = "";
			int maxTimeDiff = Integer.parseInt(PropertyUtil.getProperty("websessiontimeout"));

			query +="SELECT count(*) CNT FROM WEB_SESSION ";
			query +="WHERE (TIMESTAMPDIFF(MINUTE,LASTACC,NOW()) < '" + maxTimeDiff + "') ";
			query +="AND (UPPER(USER_ID) = UPPER('" + userId + "')) ";
			KBDAO dao = new KBDAO();
			int count = dao.loadCount(query);
			return (count > 0);
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			logger.error("isDuplicateSession" + getStackTrace(exception));			
			return false;
		}
	}
	
	public boolean isValidSession(String userId, String sessionId)
	{
		try
		{
			String query = "";
			int maxTimeDiff = Integer.parseInt(PropertyUtil.getProperty("websessiontimeout"));

			query +="SELECT count(*) CNT FROM WEB_SESSION ";
			query +="WHERE (TIMESTAMPDIFF(MINUTE,LASTACC,NOW()) < '" + maxTimeDiff + "') ";
			query +="AND (UPPER(USER_ID) = UPPER('" + userId + "')) ";
			query +="AND (UPPER(SESSIONID) = UPPER('" + sessionId + "')) ";

			KBDAO dao = new KBDAO();
			int count = dao.loadCount(query);
			return (count > 0);
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			logger.error("isValidSession" + getStackTrace(exception));			
			return false;
		}
	}	
	
	public void clearOldWebSessions(String userId)
	{
		try
		{
			String query = "DELETE FROM WEB_SESSION ";
			query +="WHERE (UPPER(USER_ID) = UPPER('" + userId + "')) ";
			KBDAO dao = new KBDAO();
			dao.executeUpdateQuery(query);
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			logger.error("clearOldWebSessions" + getStackTrace(exception));			
		}
	}
	
	public static String formatAmountNoDecimal(String inputAmount)
	{
		String result = formatAmount(inputAmount);
		result = StringUtils.replaceString(result, ".", "", true);
		return result;
	}

	public static String formatAmount(String inputAmount)
	{
		try
		{
			double amount = Double.parseDouble(inputAmount);
		    DecimalFormat df = new DecimalFormat("##.00");
		    return df.format(amount);
		}
		catch(Exception exception)
		{
			//exception.printStackTrace();
			return inputAmount;
		}
	}
	
	public static String addDecimalToCurrentAmount(String inputAmount)
	{
		String mainValue = inputAmount.substring(0,inputAmount.length() - 2);
		String decimalValue = inputAmount.substring(inputAmount.length() - 2);
		return mainValue + "." + decimalValue;
	}
	
	/*public static void main(String[] args)
	throws Exception
	{
		MBService service = new MBService();
		System.out.println("=>" + service.getCharges("GET_ACCOUNT_DETAIL", "1000"));
		System.out.println("=>" + service.getCharges("GET_TREASURY_RATES", "1000"));
		System.out.println("=>" + service.getCharges("SEND_SMS", "1000"));
		System.out.println("=>" + service.getCharges("FT_TO_OTHER_BANK_ACCOUNT", "1000"));
		System.out.println("=>" + service.getCharges("FT_TO_OTHER_BANK_ACCOUNT", "2000"));
		System.out.println("=>" + service.getCharges("PAY_BILL", "2000"));
		
		System.out.println(service.addDecimalToCurrentAmount("00"));
		System.out.println(service.addDecimalToCurrentAmount("232311"));
		System.out.println(service.addDecimalToCurrentAmount("23231121"));
		System.out.println(service.addDecimalToCurrentAmount("23231123"));
		
//		MFService service = new MFService();
//		service.createMakerCheckerAuditEntry("user_info","1096", "Approve","","");
//		MFPrimeBankTransactionService service = new MFPrimeBankTransactionService();
//		String balanceEnquiry = service.processBalanceEnquiry("0010010051002");
//		System.out.println("Balance Enquiry:" + balanceEnquiry);
//		
//		MFService service = new MFService();
//		System.out.println(service.isDuplicateSession("7E1CEAA52F32F8DC8BF8ABBE3C1E62C0", "globaladmin"));
	}*/
	/**
	    * Creates an entry to MAKERCHECKERAUDIT table. Used for audit purpose.
	    * @param tableName - Table over which Maker or Checker is worked over Ex: account.
	    * @param recordId - ID of record over which Maker or Checker is worked over .
	    * @param actionName - Action of Maker or Checker Ex: UPDATE.
	    * @param createID - ID creating this record.
	    * @param comments - comments if any.
	    * @return void.
	    */

	public void createMakerCheckerAuditEntry(String tableName, String recordId, String actionName, String createID, String comments)
	throws Exception
	{
		try
		{
			//processSendNotifications(tableName, recordId, actionName, createID, comments);
			if(PropertyUtil.isPropertyEquals("IGNOREMAKERCHECKERAUDIT", "Y")) return;
			String tableNamedescription = getTableNameDescription(tableName);
			KBMakercheckerauditService service = new  KBMakercheckerauditService();
			KBMakercheckerauditRecord record = new KBMakercheckerauditRecord();
			record.setRecid(recordId);
			record.setTabname(tableName);
			record.setActionname(actionName);
			record.setTablelabel(tableNamedescription);
			record.setCreatedat(DateUtils.getCurrentDateTime());
			record.setCreatedby(createID);
			record.setComments(comments);
			service.insertMFMakercheckerauditRecord(record);
		}
		catch(Exception exception)
		{
			logger.error("createMakerCheckerAuditEntry" + getStackTrace(exception));
			throw exception;
		}
	}
	//Commented As part of Fine Tuning Pradeep N 15 july
	/*public void processSendNotifications(String tableName, String recordId, String actionName, String createID, String comments)
	{
		try
		{
			MFNotificationService notificationService = new MFNotificationService();
//			MFUserinfoService userService = new MFUserinfoService();
//			if (tableName.equals("user_info"))
//			{
//				if (actionName.equals("Approve"))
//				{
//					MFUserinfoRecord userRecord = userService.loadMFUserinfoRecord(recordId);
//					if (userRecord == null) return;
//					notificationService.sendPassword(userRecord.getEmail(), true);
//				}
//			}
		}
		catch(Exception exception)
		{
			logger.error(exception);
			logger.error("processSendNotifications" + getStackTrace(exception));
		}
	}*/
	
	/**
	    * Calls the action upon some event like updating a table. service_map record having Event name mapped  
	    * will be picked and class & method mapped to that name will be called. Output of the method called will be returned.
	    * @param eventName ID of the event 
	    * @param recordID Record ID of the event, If not known pass ""
	    * @return  HashMap returned from class called upon.
	    */
	
	public HashMap callActionEvent(String eventName, String recordID)
	{
		HashMap inputMap = new HashMap();
		inputMap.put("EventRecordID", recordID);
		inputMap.put("EventName", eventName);

		if (!ServiceMapUtil.isServiceRegistered(eventName))
		{
			//Commented As part of Fine Tuning Pradeep N 15 july
			/*HashMap failedMap = new HashMap(inputMap);
			failedMap.put("ErrorMessage", "No Event registered for Service " + eventName);*/
			inputMap.put("ErrorMessage", "No Event registered for Service " + eventName);
			return inputMap;
		}

		try
		{
			HashMap outputMap = callServiceIfExists(eventName, inputMap);
			return outputMap;
		}
		catch(Exception e)
		{
			logger.error(e);

			HashMap failedMap = new HashMap(inputMap);
			failedMap.put("ErrorMessage", "Failed to execute " + e);
			return failedMap;
		}
	}
	
	/**
	    * Checks if the Service Map record exists for the code passed. Calls the class file linked to service map code by passing the hash map.
	    * @param serviceCode - Service Map Table Code.
	    * @param inputHashMap - Input HashMap.
	    * @return HashMap - Hash Map which is output from the java file called.
	    */
	

	public HashMap callServiceIfExists(String serviceCode, HashMap inputHashMap)
	throws Exception
	{
		KBServicemapRecord serviceMapRecord = loadServiceMap(serviceCode);
		if (serviceMapRecord == null)
		{
			return inputHashMap;
		}
		return callService(serviceCode, inputHashMap, false);
	}

	
	/**
	    * Calls the class file linked to service map code by passing the hash map.
	    * @param serviceCode - Service Map Table Code.
	    * @param inputHashMap - Input HashMap.
	    * @return HashMap - Hash Map which is output from the java file called.
	    */
	

	public HashMap callService(String serviceCode, HashMap inputHashMap)
	throws Exception
	{
		serviceCode =  getWalletServiceCode(serviceCode, inputHashMap);
		return callService( serviceCode, inputHashMap,false);
	}
	
	/**
	    * Fetches the Wallet Service code linked for the Service code passed.
	    * @param serviceCode - Service Map Table Code.
	    * @param inputHashMap - Input HashMap.
	    * @return String - Wallet service code.
	    */
	

	public String getWalletServiceCode(String serviceCode, HashMap inputHashMap)
	{
		if (!PropertyUtil.isPropertyEquals("EnableWalletService", "Y")) return serviceCode;

		if (StringUtils.isNullOrEmpty(serviceCode)) return serviceCode;
		String accNum = "";
		if (inputHashMap.containsKey("AccountNumber")) accNum = StringUtils.getMapValue(inputHashMap, "AccountNumber");
		if (inputHashMap.containsKey("FromAccountNumber")) accNum = StringUtils.getMapValue(inputHashMap, "FromAccountNumber");
		if (!PropertyUtil.isPropertyEquals("WalletAccountLength", accNum.length() + "")) return serviceCode;

		return "WALLET_" + serviceCode;
	}
	
	/**
	    * Calls the class file linked to service map code by passing the hash map. Stores the response of the call if skipStorage is false
	    * @param serviceCode - Service Map Table Code.
	    * @param inputHashMap - Input HashMap.
	    * @param skipStorage - Boolean which represents either to store the response or not.
	    * @return HashMap - Hash Map which is output from the java file called.
	    */
	
	public HashMap callService(String serviceCode, HashMap inputHashMap, boolean skipStorage)
	throws Exception
	{
		LogUtils.println("Request Service:" + serviceCode);
		if(!serviceCode.equals("SEND_SMS"))
		LogUtils.println("Request Map:" + inputHashMap);

		inputHashMap.put("ServiceCode", serviceCode);
		
		KBServicemapRecord serviceMapRecord = new KBServicemapRecord();
		if(PropertyUtil.isPropertyEquals("MULTIINSTSERVMAP", "Y") && inputHashMap.containsKey("SessionRecord"))
		{
			KBMobilesession2Record sessionRecord = (KBMobilesession2Record)inputHashMap.get("SessionRecord");
			String source = sessionRecord.getLastphonetype();
			serviceMapRecord = loadServiceMap(serviceCode,source);
		}
		else
		serviceMapRecord = loadServiceMap(serviceCode);
		
		if (serviceMapRecord == null)
		{
			throw new Exception("Service Configuration Error:Missing Configuration for:" + serviceCode);
		}
		
		

		if (!inputHashMap.containsKey("Charges"))
		{
			inputHashMap.put("Charges", "0");
		}

		String requestID = "";
		if(PropertyUtil.isPropertyEquals("SKIPINTERFACESTORAGE", "Y"))
		{
			SecureRandom sr = SecureRandom.getInstance("SHA1PRNG");  
	    	int randomNumber = sr.nextInt(1234567);
	    	String formattedRandomNumber6 = StringUtils.trimLeadingSize(randomNumber + "", 6);
	    	inputHashMap.put("AuditNumber", formattedRandomNumber6);
		}
		
		if(!PropertyUtil.isPropertyEquals("SKIPINTERFACESTORAGE", "Y"))
		{
				if (!skipStorage)
				{
					requestID = recordRequest(serviceMapRecord, inputHashMap);
					inputHashMap.put("AuditNumber", requestID);
				}
		}

		try
		{
			LogUtils.println("Check 6 - 11:" + serviceMapRecord.getServiceclass());
			LogUtils.println("Check 6 - 12:" + serviceMapRecord.getServicemethod());
			HashMap outputMap = new HashMap();
		
			//Start -  If Wallet Account don't allow to transact based on service map field 
			
			if(StringUtils.noNullString(serviceMapRecord.getExtn3fld()).equals("N") 
					&& PropertyUtil.isPropertyEqualsIC("SERVICEBLOCKFORWALLET", "Y"))
			{
				
				String accountNumber = getHashMapValue(inputHashMap, "OPT_ACCOUNT_SELECT");
				if(isMFSWalletAccount(accountNumber))
				{
					outputMap.put("ErrorMessage", MFMessageCodeUtil.getConsoleMessageCode("WALLET_DISABLED_FUNCTION","Dear Customer, Unable to process this transaction for Wallet Account"));
					return  outputMap;
				}
			}
			
			//End -  If Wallet Account don't allow to transact based on service map field 
			
			//Implement Remember Me Feature Here

			if (isJointAccountApprovalToBeRecorded(serviceMapRecord,inputHashMap))
			{
				inputHashMap.put("ServiceCode",serviceMapRecord.getServicecode());
				inputHashMap.put("ServiceTitle",serviceMapRecord.getServicetitle());
				inputHashMap.put("agentcall", "Y");// For boa ug pin check suppress at integration layer
				inputHashMap.put("FullMap",convertToJSONDataMap(inputHashMap));
				String sessionRecord = StringUtils.getMapValue(inputHashMap, "SessionRecord");
				inputHashMap.put("sessionRecord", sessionRecord);
				if(PropertyUtil.isPropertyEquals("JAPREREQUISITECHECK", "Y"))
				{
					LogUtils.println("Pre req chk 1");
					outputMap = callService("PREREQ_JOINT_ACCOUNT_APRROVAL", inputHashMap);
					LogUtils.println("Pre req chk 2:" + outputMap);

					if(outputMap.containsKey("ErrorMessage"))
					{
						LogUtils.println("Pre req chk 3");

						return  outputMap;
					}
					else
						outputMap = callService("RECORD_JOINT_ACCOUNT_APRROVAL", inputHashMap);


				}
				else
				outputMap = callService("RECORD_JOINT_ACCOUNT_APRROVAL", inputHashMap);
			}
			else
			{
				if (isAsyncServiceToBeRecorded(serviceMapRecord, inputHashMap))
				{
					outputMap = recordAsyncRequestRecord(serviceMapRecord, inputHashMap);
				}
				else
				{
					inputHashMap.put("ServiceMapID",serviceMapRecord.getId());
					outputMap= callService(serviceMapRecord.getServiceclass(), serviceMapRecord.getServicemethod(), inputHashMap);

					String serviceCode1 = StringUtils.noNull(serviceMapRecord.getServicecode());
					if (isSuccessfulTransaction(outputMap))
					{
						recordExternalServiceAccess(serviceCode1, "ServiceCall", "Success");
					}
					else
					{
						recordExternalServiceAccess(serviceCode1, "ServiceCall", "Failure");
					}
				}
			}
			if(!PropertyUtil.isPropertyEquals("SKIPINTERFACESTORAGE", "Y"))
			{
				
			if (!skipStorage)
			{
				recordResponse(requestID, outputMap);
			}
			}
			return outputMap;
		}
		catch(Exception exception)
		{
			HashMap outputMap = new HashMap(inputHashMap);
			logger.error(exception);
			outputMap.put("ErrorMessage", "Could not process request at this time");
			if(!PropertyUtil.isPropertyEquals("SKIPINTERFACESTORAGE", "Y"))
			{
				
			if (!skipStorage)
			{
				recordResponse(requestID, outputMap);
			}
			}
			throw exception;
		}
	}

}
