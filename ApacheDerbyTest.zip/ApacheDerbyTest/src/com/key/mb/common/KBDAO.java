package com.key.mb.common;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Vector;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.key.mb.common.KBDAO;
import com.key.utils.DateUtils;
import com.key.utils.LogUtils;
import com.key.utils.KBHickaryDAO;
import com.key.utils.KBSecurityUtil;
import com.key.utils.PropertyUtil;
import com.key.utils.StringUtils;

public class KBDAO {

	static LogUtils logger = new LogUtils(KBDAO.class.getName());

	protected DateUtils fd = new DateUtils();
	protected String MAX_RECORD_LIMIT_APPENDER = "";
	protected String ORDERBYSTRING = "1";
	protected String CUSTOM_CONDITION=""; 
	protected String OUTER_CUSTOM_CONDITION="";	
	
	public KBDAO()
	{
		
	}
	
	
   
    
	
    static String dbtabquery[] =
    {
        "select * from sysobjects where (name not like 'sys%')and(name not like '%_PK%')and(name not like '%_FK%')and(name not like '%FK_%')and(name not like '%PK_%')and(name not like '%UQ_%')and(name not like '%uniq_%')",
        "select * from tab",
        "select TABNAME from SYSCAT.TABLES WHERE (TABSCHEMA = '2012')",
        "SHOW FULL TABLES"
    };
    
    
    /*public MFCategoryRecord[] loadMFCategoryDistinctRecords(String query, Connection con, boolean closeConnection)
	throws Exception
	{
		PreparedStatement ps = null;
		ResultSet rs = null;
		try
		{
			if (con == null)
			{
				con = getCPDatabaseConnection();
			}
			query = query + MAX_RECORD_LIMIT_APPENDER;
			query = updateQuery(query);
			logger.trace("loadMFCategoryRecords\t" + closeConnection + "\t" + query);
			ps = con.prepareStatement(query);
			rs = ps.executeQuery();
			ArrayList recordSet = new ArrayList();
			while(rs.next())
			{
				MFCategoryRecord record = new MFCategoryRecord();
				record.setCatid(rs.getString("CAT_ID"));
				record.setCategory(rs.getString("CATEGORY"));
				record.setSubcatid(rs.getString("SUBCAT_ID"));
				record.setSubcategory(rs.getString("SUB_CATEGORY"));
				//record.setExt1(rs.getString("EXT1"));
				//record.setExt2(rs.getString("EXT2"));
				//record.setExt3(rs.getString("EXT3"));
				//recordSet.add(record);
			}
			logger.trace("loadMFCategoryRecords:Records Fetched:" + recordSet.size());
			MFCategoryRecord[] tempMFCategoryRecords = new MFCategoryRecord[recordSet.size()];
			for (int index = 0; index < recordSet.size(); index++)
			{
				tempMFCategoryRecords[index] = (MFCategoryRecord)(recordSet.get(index));
			}
			ps.close();
			releaseDatabaseConnection(con, closeConnection);
			return tempMFCategoryRecords;
		}
		finally
		{
			releaseDatabaseConnection(con, closeConnection);
		}
	}
 */
    
    public boolean isOracleDatabase()
    {
    	String dbms = PropertyUtil.getProperty("DBMS");
    	LogUtils.println("DBMS Property:" + dbms);
		return dbms.equalsIgnoreCase("ORACLE");    	
    }

	public ArrayList getTableList(Connection conn,int queryCode)
	throws Exception
	{
		ArrayList list = new ArrayList();
		PreparedStatement ps = conn.prepareStatement(dbtabquery[queryCode]);
		ResultSet rs = ps.executeQuery();
        while(rs.next())
        {
        	list.add(rs.getString(1).toLowerCase());
        }
		rs.close();
		ps.close();
		return list;
	}

	public ArrayList getColumnList(Connection conn,String tableName, String limitcode)
	throws Exception
	{
		String query = "select * from " + tableName + " " + limitcode;
		ArrayList list = new ArrayList();
		PreparedStatement ps = conn.prepareStatement(query);
		ResultSet rs = ps.executeQuery();
		
        ResultSetMetaData rsmetadata = rs.getMetaData();
        int colCount = rsmetadata.getColumnCount();
        for (int index = 1; index <= colCount; index++)
        {
            String ColName = rsmetadata.getColumnName(index);
            list.add(ColName);
        }   
		rs.close();
		ps.close();
		return list;
	}

	public void setLimits(String offset, String rowcount)
	{
		if (StringUtils.isNullOrEmpty(offset)) offset = "0";
		if (StringUtils.isNullOrEmpty(rowcount)) rowcount = "20";

		MAX_RECORD_LIMIT_APPENDER = " limit " + offset + "," + rowcount;
		
		if (isMSSQL())
		{
			MAX_RECORD_LIMIT_APPENDER = " OFFSET " + offset + " ROWS FETCH NEXT " + rowcount + " ROWS ONLY";
//			OFFSET 0 ROWS FETCH NEXT 10 ROWS ONLY
		}
		
		if (isMSSQL8())
		{
			MAX_RECORD_LIMIT_APPENDER = "";
			CUSTOM_CONDITION += " AND (rownum >= $LMTOFFSET$) AND  (rownum <= ($LMTOFFSET$ + $LMTROWCNT$))";
			CUSTOM_CONDITION = StringUtils.replaceString(CUSTOM_CONDITION, "$LMTOFFSET$", offset, true);
			CUSTOM_CONDITION = StringUtils.replaceString(CUSTOM_CONDITION, "$LMTROWCNT$", rowcount, true);
		}
		
		if (isOracleDatabase())
		{
			MAX_RECORD_LIMIT_APPENDER = "";
			OUTER_CUSTOM_CONDITION = "";
			OUTER_CUSTOM_CONDITION += " AND (R between  $LMTOFFSET$ AND ($LMTOFFSET$ + $LMTROWCNT$))";
			OUTER_CUSTOM_CONDITION = StringUtils.replaceString(OUTER_CUSTOM_CONDITION, "$LMTOFFSET$", offset, true);
			OUTER_CUSTOM_CONDITION = StringUtils.replaceString(OUTER_CUSTOM_CONDITION, "$LMTROWCNT$", rowcount, true);
			LogUtils.println("OUTER_CUSTOM_CONDITION:" + OUTER_CUSTOM_CONDITION);
		}				
	}
	
	public static String DBMS = "";
	
	public static boolean isMSSQL()
	{
    	String dbms = PropertyUtil.getProperty("DBMS");
		return dbms.equalsIgnoreCase("MSSQL");    	
	}
	
	public static boolean isMSSQL8()
	{
    	String dbms = PropertyUtil.getProperty("DBMS");
		return dbms.equalsIgnoreCase("MSSQL8");    	
	}	

	public String updateQuery(String query)
	{
		//LogUtils.println("DBMS:" + DBMS);
		LogUtils.println("DBMS1:" + PropertyUtil.getProperty("DBMS"));
		//LogUtils.println("DBMS:" + PropertyUtil.getProperty("DBMS"));
		
		

		if (isOracleDatabase())
		{			
			if (query.toLowerCase().contains("convert("))
			{
				if (query.toLowerCase().contains(",decimal"))
				{
					query = StringUtils.replaceString(query, "CONVERT(",  "CAST(", true);
					query = StringUtils.replaceString(query, ",DECIMAL",  " AS DECIMAL", true);
					query = StringUtils.replaceString(query, "convert(",  "CAST(", true);
					query = StringUtils.replaceString(query, ",decimal",  " AS decimal", true);		
					query = StringUtils.replaceString(query, ", decimal",  " AS decimal", true);
				}
			}
		}
		
		LogUtils.println("Query:" + query);

		return query;
	}
	
	
	
	public void setCustomCondition(String customCond)
	{
		CUSTOM_CONDITION ="";
		
		if (!StringUtils.isNullOrEmpty(customCond))
		{
			CUSTOM_CONDITION =customCond;
		}
	}
	
	public String getCustomCondition()
	{
		return CUSTOM_CONDITION;
	}
	
	public boolean hasCustomCondition()
	{
		if (StringUtils.isNullOrEmpty(getCustomCondition())) return false;
		return true;
	}
	
	public void setOrderBy(String orderByString)
	{
		ORDERBYSTRING = "1";
		if (!StringUtils.isNullOrEmpty(orderByString))
		{
			ORDERBYSTRING = orderByString;
		}
		
		if (isMSSQL8())
		{
			if (ORDERBYSTRING.equals("1"))
			{
				ORDERBYSTRING = "ID";
			}
		}
	}
	
	public String formatSearchField(String inputValue)
	{
		if (StringUtils.isNullOrEmpty(inputValue)) return inputValue;
		String resultValue = StringUtils.replaceString(inputValue, "'", "", true);
		return resultValue;
	}
	
	static ArrayList excludeTableList = new ArrayList();
	
	public boolean isTableToBeExcluded(String inputTableName)
	{
		try
		{
			inputTableName = StringUtils.noNull(inputTableName);
			inputTableName = inputTableName.toLowerCase();

			if (inputTableName.equals("audit_log")) return true;
			if (inputTableName.equals("intf_call_log")) return true;
			if (inputTableName.equals("mobilejsonrequest")) return true;
			if (inputTableName.equals("mobilejsonresponse")) return true;
			if (inputTableName.equals("mail_mesg")) return true;
			if (inputTableName.equals("health_check_stat")) return true;
			
			if (inputTableName.equals("web_session")) return true;
			if (inputTableName.equals("web_access_log")) return true;			
			
			
			
			if (inputTableName.equals("sms_mesg")) return true;
			if (inputTableName.equals("maker_checker_audit")) return true;

			if (excludeTableList.isEmpty())
			{
				String query = "select distinct cvalue from content_map where (ctype = 'EXCLUDE_FROM_AUDIT_LOG')";

				Connection con = getDatabaseConnection();
				PreparedStatement ps = con.prepareStatement(query);
				ResultSet rs = ps.executeQuery();
				while(rs.next())
				{
					String column = StringUtils.noNull(rs.getString("cvalue")).toLowerCase();
				}
				rs.close();
				ps.close();
				releaseDatabaseConnection(con);
				
				if (excludeTableList.isEmpty()) excludeTableList.add("audit_log");
			}

			return excludeTableList.contains(inputTableName);
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			return false;
		}
	}

	
	

	
	
	public void storeRequestResponse(String requestId, String message)
	{
		try
		{
			String fileName = StringUtils.noNull(PropertyUtil.getProperty("AuditLogFolder"));
			StringUtils.writeStringToFile(message, fileName + requestId + ".txt");
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
		}
	}

	public Connection getDatabaseConnection(String driver, String url, String uid, String pwd)
    {
        try
        {
		    Class.forName(driver);
		    Connection con = DriverManager.getConnection(url, uid, pwd);
		    return con;
		}
		catch(Exception e)
		{
		    e.printStackTrace();
		    return null;
		}
    }
	
	public Connection getCPDatabaseConnection()
    {
		LogUtils.println("Connection Pool Flag:" + PropertyUtil.getProperty("UseCP"));
		if (PropertyUtil.isPropertyEquals("UseCP", "Y"))
		{
			return KBHickaryDAO.getConnection();
		}
		else
		{
			return getDirectDatabaseConnection();
		}
    }

	public Connection getDatabaseConnection()
    {
		return getCPDatabaseConnection();
    }

	public Connection getDirectDatabaseConnection()
    {
        try
        {
		    Class.forName(PropertyUtil.getDbdriver());
		    Connection con = DriverManager.getConnection(PropertyUtil.getDburl(), PropertyUtil.getDbuid(), (new KBSecurityUtil()).decryptRegular(PropertyUtil.getDbpwd()));
		    return con;
		}
		catch(Exception e)
		{
		    e.printStackTrace();
		    return null;
		}
    }

	public Connection getCBDatabaseConnection()
    {
        try
        {
		    Class.forName(PropertyUtil.getProperty("CoreBankingDBDriver"));
		    Connection con = DriverManager.getConnection(PropertyUtil.getProperty("CoreBankingDBURL"), PropertyUtil.getProperty("CoreBankingDBUID"), PropertyUtil.getProperty("CoreBankingDBPWD"));
		    return con;
		}
		catch(Exception e)
		{
		    e.printStackTrace();
		    return null;
		}
    }	
	
	public Connection getSecondDatabaseConnection()
    {
        try
        {
		    Class.forName(PropertyUtil.getProperty("DBDriver2"));
		    Connection con = DriverManager.getConnection(PropertyUtil.getProperty("DBURL2"), PropertyUtil.getProperty("DBUid2"), (new KBSecurityUtil()).decryptRegular(PropertyUtil.getProperty("DBPwd2")));
		    return con;
		}
		catch(Exception e)
		{
		    e.printStackTrace();
		    return null;
		}
    }	
	
	public void releaseDatabaseConnection(Connection con)
	{
		releaseConnection(con);
	}
	
	public void releaseDatabaseConnection(Connection con, boolean releaseConnection)
	{
		if (releaseConnection)
		{
			releaseConnection(con);
		}
	}	
	
	public void releaseConnection(Connection con)
    {
        try
        {
        	if (PropertyUtil.isPropertyEquals("UseCP", "Y"))
    		{
    			KBHickaryDAO.releaseConnection(con);
    		}
    		else
    		{
    			con.close();
    			
    		}
            
        }
        catch(Exception e)
        {
        	e.printStackTrace();
        }
    }
	
	
	public void releaseDatabaseConnection(ResultSet rs, PreparedStatement ps, Connection con, boolean closeConnectionConnection)
	  {
	     closePreparedStatement(ps);
	     releaseDatabaseConnection(con, closeConnectionConnection);
	   }
	
	/*public void releaseDatabaseConnection(ResultSet rs, PreparedStatement ps, Connection con, boolean releaseConnection)
	{
		if (releaseConnection)
		{
			releaseDatabaseConnection(rs,ps,con);
		}
	}*/
	
	public void closePreparedStatement(PreparedStatement ps)
	   {
	     try
	     {
	       if (ps != null) { ps.close();
	       }
	     }
	     catch (Exception localException) {}
	   }
	
	public void releaseDatabaseConnection(ResultSet rs, PreparedStatement ps, Connection con)
    {
        try
        {
        	if (PropertyUtil.isPropertyEquals("UseCP", "Y"))
    		{
    			KBHickaryDAO.releaseConnection(con);
    		}
    		else
    		{
    			
    			con.close();
    			ps.close();
    			rs.close();
    		}
            
        }
        catch(Exception e)
        {
        	//e.printStackTrace();
        }
    }
    
	//**********************************************************************************************
	//Utility Methods
	//**********************************************************************************************
	    public boolean isNull(String value)
	    {
	        if (value == null) return true;
	        if (value.trim().length() < 1) return true;
	        return false;
	    }
	    
	    public String encodeBit(String Value)
	    {
	        if (Value == null) return "0";
	        if (Value.equals("Y"))
	        return "1";
	        else
	        return "0";
	    }
	    
	    public String getYN(boolean flag)
	    {
	        if (flag == true) return "Y";
	        return "N";
	    }	    
	    
	    public String decodeBit(String Value)
	    {
	        if (Value == null) return "N";
	        if (Value.equals("1")) return "Y";
	        else
	        return "N";
	    }
	    
	    public String getCheckBoxValue(String Value)
	    {
	        if (Value == null) return "N";
	        else
	        return Value;
	    }

		public String loadSequenceID(String Query, String Column)
		throws Exception
		{
			Connection con = getDatabaseConnection();
			PreparedStatement ps = con.prepareStatement(Query);
			ResultSet rs = ps.executeQuery();
			String result = "";
			while(rs.next())
			{
			    result = rs.getString(Column);
			}
			rs.close();
			ps.close();
			releaseDatabaseConnection(con);
			return result;
		}

	    public String noNull(Object value)
	    {
	        if (value == null) return "";
	        return value.toString();
	    }

	    public String noNull(String value)
	    {
	        if (value == null) return "";
	        return value;
	    }
	    
	    public String noNull(String value, String defaultVal)
	    {
	    	if (isNull(value)) return defaultVal;
	        return noNull(value);
	    }	    

	    public void setDateValue(PreparedStatement ps, int index, java.sql.Date value)
	    throws Exception
	    {
	        if (value == null)
	        {
	            ps.setNull(index, java.sql.Types.DATE);
	        }
	        else
	        {
	        	java.sql.Timestamp ts = new java.sql.Timestamp(value.getTime());
	        	ps.setTimestamp(index, ts);
	        }
	    }
	    
	    public void setStringValue(PreparedStatement ps, int index, String value)
	    throws Exception
	    {
	        if (value == null)
	        {
	            ps.setNull(index, java.sql.Types.VARCHAR);
	        }
	        else if (value.trim().length() < 1)
	        {
	            ps.setNull(index, java.sql.Types.VARCHAR);
	        }	        
	        else
	        {
	        	if (value.equals("-")) value = "";
	        	ps.setString(index, value);
	        }
	    }	
	    
	    public void setIntValue(PreparedStatement ps, int index, String value)
	    	    throws Exception
	    	    {
	    	        if (value == null)
	    	        {
	    	            ps.setNull(index, java.sql.Types.INTEGER);
	    	        }
	    	        else if (value.trim().length() < 1)
	    	        {
	    	            ps.setNull(index, java.sql.Types.INTEGER);
	    	        }	        
	    	        else
	    	        {
	    	        	if (value.equals("-")) value = "";
	    	        	ps.setString(index, value);
	    	        }
	    	    }	
	    
	    

		public boolean executeUpdateQuery(Connection con, String Query)
		throws Exception
		{
			Query = updateQuery(Query);
			PreparedStatement ps = con.prepareStatement(Query);
			boolean result = ps.execute();
			ps.close();
			return result;
		}
		
	    public boolean executeUpdateQuery(String Query)
		throws Exception
		{
	    	Query = updateQuery(Query);
	    	LogUtils.println("Update Query:" + Query);
			Connection con = getDatabaseConnection();
			PreparedStatement ps = con.prepareStatement(Query);
			boolean result = ps.execute();
			ps.close();
			releaseDatabaseConnection(con);
			return result;
		}

		public String loadString(String Query, String columnName)
		throws Exception
		{
			Query = updateQuery(Query);
			Connection con = getDatabaseConnection();
			PreparedStatement ps = con.prepareStatement(Query);
			ResultSet rs = ps.executeQuery();
			String value = null;
			if (rs.next())
			{
			    value = rs.getString(columnName);
			}
			rs.close();
			ps.close();
			releaseDatabaseConnection(con);
			return value;
		}
		
		public JSONArray loadColumnListAsJSON(String Query, String Column, boolean insertBlank)
		throws Exception
		{
			Query = updateQuery(Query);
			Connection con = getDatabaseConnection();
			PreparedStatement ps = con.prepareStatement(Query);
			ResultSet rs = ps.executeQuery();
			JSONArray arrayList = new JSONArray();
			if (insertBlank)
			{
				arrayList.add("");
			}

			while(rs.next())
			{
				arrayList.add(rs.getString(Column));
			}
			rs.close();
			ps.close();
			releaseDatabaseConnection(con);
			return arrayList;
		}
		
		public JSONArray loadColumnListAsJSONCount(String Query, boolean insertBlank)
		throws Exception
		{
			Query = updateQuery(Query);
			Connection con = getDatabaseConnection();
			PreparedStatement ps = con.prepareStatement(Query);
			ResultSet rs = ps.executeQuery();
			JSONArray arrayList = new JSONArray();
			if (insertBlank)
			{
				arrayList.add("");
			}

			while(rs.next())
			{
				arrayList.add(rs.getString("count")+"-"+rs.getString("LOCATION"));
			}
			rs.close();
			ps.close();
			releaseDatabaseConnection(con);
			return arrayList;
		}

		public JSONArray loadColumnListAsJSONCountCategory(String Query, boolean insertBlank)
		throws Exception
		{
			Query = updateQuery(Query);
			Connection con = getDatabaseConnection();
			PreparedStatement ps = con.prepareStatement(Query);
			ResultSet rs = ps.executeQuery();
			JSONArray arrayList = new JSONArray();
			if (insertBlank)
			{
				arrayList.add("");
			}

			while(rs.next())
			{
				
				arrayList.add(rs.getString("count")+"-"+rs.getString("cat_id"));
			}
			rs.close();
			ps.close();
			releaseDatabaseConnection(con);
			return arrayList;
		}


		public String loadString(Connection con, String Query)
		throws Exception
		{
			Query = updateQuery(Query);
			PreparedStatement ps = con.prepareStatement(Query);
			ResultSet rs = ps.executeQuery();
			String value = null;
			if (rs.next())
			{
			    value = rs.getString(1);
			}
			rs.close();
			ps.close();
			releaseDatabaseConnection(con);
			return value;
		}
		
		public String loadString(String Query)
		throws Exception
		{
			Query = updateQuery(Query);
			Connection con = getDatabaseConnection();
			PreparedStatement ps = con.prepareStatement(Query);
			ResultSet rs = ps.executeQuery();
			String value = null;
			if (rs.next())
			{
			    value = rs.getString(1);
			}
			rs.close();
			ps.close();
			releaseDatabaseConnection(con);
			return value;
		}
		
		public JSONArray loadStringtrip(String Query)
		throws Exception
		{
			Query = updateQuery(Query);
			Connection con = getDatabaseConnection();
			PreparedStatement ps = con.prepareStatement(Query);
			ResultSet rs = ps.executeQuery();
			JSONArray arrayList = new JSONArray();
			
			while(rs.next())
			{
				arrayList.add(rs.getString(1));
			}
			rs.close();
			ps.close();
			releaseDatabaseConnection(con);
			return arrayList;
		}
		

		public int loadRecordCount(Connection con, String Query)
		throws Exception
		{
			return loadRecordCount(con, Query, false);
		}
		
		public int loadRecordCount(Connection con, String Query, boolean closeConn)
		throws Exception
		{
			Query = updateQuery(Query);
			PreparedStatement ps = con.prepareStatement(Query);
			ResultSet rs = ps.executeQuery();
			int count = 0;
			if (rs.next())
			{
			    count = (int)Double.parseDouble(rs.getString(1));
			}
			rs.close();
			ps.close();
			releaseDatabaseConnection(con,closeConn);
			return count;
		}
		
		public int loadCount(String Query)
		throws Exception
		{
			Query = updateQuery(Query);
			LogUtils.println("Count Query:" + Query);
			Connection con = getDatabaseConnection();
			PreparedStatement ps = con.prepareStatement(Query);
			ResultSet rs = ps.executeQuery();
			int count = 0;
			if (rs.next())
			{
				if (isOracleDatabase())
				{
					count = rs.getInt(1);
				}
				else
				{
					count = (int)Double.parseDouble(rs.getString(1));
				}
			}
			rs.close();
			ps.close();
			releaseDatabaseConnection(con);
			LogUtils.println("Count Query:" + Query + " Result:" + count);			
			return count;
		}

		public int loadCount(Connection con, String Query)
		throws Exception
		{
			Query = updateQuery(Query);
			PreparedStatement ps = con.prepareStatement(Query);
			ResultSet rs = ps.executeQuery();
			int count = 0;
			if (rs.next())
			{
				if (isOracleDatabase())
				{
					count = rs.getInt(1);
				}
				else
				{
					count = (int)Double.parseDouble(rs.getString(1));
				}
			}
			rs.close();
			ps.close();
			return count;
		}		

		

		public Vector loadDoubleColumn(String Query, String Column1, String Column2, boolean insertBlank)
		throws Exception
		{
			Query = updateQuery(Query);
			Connection con = getDatabaseConnection();
			PreparedStatement ps = con.prepareStatement(Query);
			ResultSet rs = ps.executeQuery();
			Vector aVectorResult = new Vector();
			if (insertBlank)
			{
			    Vector aVector = new Vector();
			    aVector.addElement("");
			    aVector.addElement("");
			    aVectorResult.addElement(aVector);
			}

			while(rs.next())
			{
			    Vector aVector = new Vector();		    
			    aVector.addElement(rs.getString(Column1));
			    aVector.addElement(rs.getString(Column2));		    
			    aVectorResult.addElement(aVector);		    
			}
			rs.close();
			ps.close();
			releaseDatabaseConnection(con);
			return aVectorResult;
		}

		public String loadSingleColumnAsString(String Query, String Column, boolean insertBlank)
		throws Exception
		{
			Query = updateQuery(Query);
		    StringBuffer sb = new StringBuffer();
			Connection con = getDatabaseConnection();
			PreparedStatement ps = con.prepareStatement(Query);
			ResultSet rs = ps.executeQuery();
			if (insertBlank)
			{
			    sb.append("\n");
			}

			while(rs.next())
			{
	            sb.append(rs.getString(Column) + "\n");		    
			}
			rs.close();
			ps.close();
			releaseDatabaseConnection(con);
			return sb.toString();
		}

		public Vector loadSingleColumn(String Query, String Column, boolean insertBlank)
		throws Exception
		{
			Query = updateQuery(Query);
			Connection con = getDatabaseConnection();
			PreparedStatement ps = con.prepareStatement(Query);
			ResultSet rs = ps.executeQuery();
			Vector aVector = new Vector();
			if (insertBlank)
			{
			    aVector.addElement("");
			}

			while(rs.next())
			{
			    aVector.addElement(rs.getString(Column));
			}
			rs.close();
			ps.close();
			releaseDatabaseConnection(con);
			return aVector;
		}
		
		
		public ArrayList loadColumnList(Connection conn, String Query, boolean insertBlank)
		throws Exception
		{
			Query = updateQuery(Query);
			PreparedStatement ps = conn.prepareStatement(Query);
			ResultSet rs = ps.executeQuery();
			ArrayList arrayList = new ArrayList();
			if (insertBlank)
			{
				arrayList.add("");
			}

			while(rs.next())
			{
				arrayList.add(rs.getString(1));
			}
			rs.close();
			ps.close();

			return arrayList;
		}
		public ArrayList loadColumnList(String Query, String Column, boolean insertBlank)
		throws Exception
		{
			Query = updateQuery(Query);
			Connection con = getCPDatabaseConnection();
			PreparedStatement ps = con.prepareStatement(Query);
			ResultSet rs = ps.executeQuery();
			ArrayList arrayList = new ArrayList();
			if (insertBlank)
			{
				arrayList.add("");
			}

			while(rs.next())
			{
				arrayList.add(rs.getString(Column));
			}
			rs.close();
			ps.close();
			releaseDatabaseConnection(con);
			return arrayList;
		}
		
		public JSONArray load3Vals(String Query, String column1Title, String column1,  String column2Title, String column2, String column3Title,  String column3)
		throws Exception
		{
			Query = updateQuery(Query);
			Connection con = getCPDatabaseConnection();
			JSONArray resultArray = new JSONArray();
			PreparedStatement ps = con.prepareStatement(Query);
			ResultSet rs = ps.executeQuery();
			Vector aVectorResult = new Vector();
			while(rs.next())
			{
				JSONObject object = new JSONObject();
				object.put(column1Title, rs.getString(column1));
				object.put(column2Title, rs.getString(column2));
				object.put(column3Title, rs.getString(column3));
				resultArray.add(object);
			}
			rs.close();
			ps.close();
			releaseDatabaseConnection(con);
			return resultArray;
		}
		
		public JSONArray load4Vals(String Query, String column1Title, String column1,  String column2Title, String column2, String column3Title,  String column3, String column4Title,  String column4)
		throws Exception
		{
			Query = updateQuery(Query);
			Connection con = getDatabaseConnection();
			JSONArray resultArray = new JSONArray();
			PreparedStatement ps = con.prepareStatement(Query);
			ResultSet rs = ps.executeQuery();
			Vector aVectorResult = new Vector();
			while(rs.next())
			{
				JSONObject object = new JSONObject();
				object.put(column1Title, rs.getString(column1));
				object.put(column2Title, rs.getString(column2));
				object.put(column3Title, rs.getString(column3));
				object.put(column4Title, rs.getString(column4));
				resultArray.add(object);
			}
			rs.close();
			ps.close();
			releaseDatabaseConnection(con);
			return resultArray;
		}	
		
		public JSONArray load2Vals(String Query, String column1Title, String column1,  String column2Title, String column2)
		throws Exception
		{
			Query = updateQuery(Query);
			Connection con = getDatabaseConnection();
			JSONArray resultArray = new JSONArray();
			PreparedStatement ps = con.prepareStatement(Query);
			ResultSet rs = ps.executeQuery();
			Vector aVectorResult = new Vector();
			while(rs.next())
			{
				JSONObject object = new JSONObject();
				object.put(column1Title, rs.getString(column1));
				object.put(column2Title, rs.getString(column2));
				resultArray.add(object);
			}
			rs.close();
			ps.close();
			releaseDatabaseConnection(con);
			return resultArray;
		}

		public Map loadMap(String Query, String Column1, String Column2, boolean insertBlank)
		throws Exception
		{
			Query = updateQuery(Query);
			Connection con = getDatabaseConnection();
			Map hashMap = new LinkedHashMap();
			PreparedStatement ps = con.prepareStatement(Query);
			ResultSet rs = ps.executeQuery();
			Vector aVectorResult = new Vector();
			if (insertBlank)
			{
				hashMap.put("","");
			}

			while(rs.next())
			{
				hashMap.put(rs.getString(Column1),rs.getString(Column2));
			}
			rs.close();
			ps.close();
			releaseDatabaseConnection(con);
			return hashMap;
		}
		public String addInCodition(String Condition, String Structure, String NullStructure, String columnName, String value)
		{
			 String ResultCondition = "";
		        if (!isNull(value))
		        {
		            //Structure = StringUtils.replaceString(Structure, "$COLNAME$", columnName, true);
		            Structure = StringUtils.replaceString(Structure, "$COLVAL$", value, true);        
		            ResultCondition = Structure;
		        }
		        else
		        {
		           // NullStructure = StringUtils.replaceString(NullStructure, "$COLNAME$", columnName, true);
		            NullStructure = StringUtils.replaceString(NullStructure, "$COLVAL$", value, true);
		            ResultCondition = NullStructure;            
		        }
			return addSetCondition(Condition, ResultCondition);
		}

	    public String addSearchCondition(String Condition, String Structure, String NullStructure, String columnName, String value)
	    {
	        String ResultCondition = "";
	        if (!isNull(value))
	        {
	            Structure = StringUtils.replaceString(Structure, "$COLNAME$", columnName, true);
	            Structure = StringUtils.replaceString(Structure, "$COLVAL$", value, true);        
	            ResultCondition = Structure;
	        }
	        else
	        {
	            NullStructure = StringUtils.replaceString(NullStructure, "$COLNAME$", columnName, true);
	            NullStructure = StringUtils.replaceString(NullStructure, "$COLVAL$", value, true);
	            ResultCondition = NullStructure;            
	        }
	        return addSearchCondition(Condition, ResultCondition);
	    }
	    
	    public String addSearchCondition(String Condition, String newCondition)
	    {
	        if (isNull(Condition))
	            return newCondition;
	        if (isNull(newCondition))
	            return Condition;
	        return Condition + "AND" + newCondition;
	    }
	    
	    
	    /*
	     * 
	     */
	    public String addSetCondition(String Condition, String Structure, String NullStructure, String columnName, String value)
	    {
	        String ResultCondition = "";
	        if (!isNull(value))
	        {
	            Structure = StringUtils.replaceString(Structure, "$COLNAME$", columnName, true);
	            Structure = StringUtils.replaceString(Structure, "$COLVAL$", value, true);        
	            ResultCondition = Structure;
	        }
	        else
	        {
	            NullStructure = StringUtils.replaceString(NullStructure, "$COLNAME$", columnName, true);
	            NullStructure = StringUtils.replaceString(NullStructure, "$COLVAL$", value, true);
	            ResultCondition = NullStructure;            
	        }
	        return addSetCondition(Condition, ResultCondition);
	    }
	    
	    public String addSetCondition(String Condition, String newCondition)
	    {
	        if (isNull(Condition))
	            return newCondition;
	        if (isNull(newCondition))
	            return Condition;
	        return Condition + "," + newCondition;
	    }
	    
	    
	    public static void main(String[] args) throws Exception
	    {
	    	LogUtils.println("Test 123");
	    	KBDAO dao = new KBDAO();
	    	HashMap obnj=dao.load2ValsStoreList("","alpha","STORE_NAME");
	    	System.out.println("Values *** "+obnj.toString());
	    	/*dao.getDatabaseConnection();
	    	LogUtils.println("Connected");
	    	
	    	String classname=PropertyUtil.getIntegrationProperty("TS_DASHBOARD");
	    	LogUtils.println("classsnem : :"+classname);*/
	    	
	    }

	    public String formatDate(java.sql.Date anDate)
	    throws Exception
	    {
	        if (anDate == null) return "";
	        SimpleDateFormat sd = new SimpleDateFormat("yyyyMMddHHmmss");
	        return sd.format(anDate);
	    }
	    
	    public String formatDBDateTime(java.sql.Timestamp anDate)
	    throws Exception
	    {
	        if (anDate == null) return "";
	        SimpleDateFormat sd = new SimpleDateFormat("yyyyMMddHHmmss");
	        return sd.format(anDate);
	    }
	    
	    public String loadMSSQL8OrderByID(String inputCol)
	    {
	    	return "ID";
	    }
	    
	    public String getOuterLimitCondition()
	    {
	    	return OUTER_CUSTOM_CONDITION;
	    }
	    
	    public String loadOracleOrderByID(String inputCol)
	    {
	    	return "ID";
	    }
	    
	    
	    public JSONObject load2ValsStoreList(String Query, String column1, String column2)
		throws Exception
		{
			Query = updateQuery(Query);
			Connection con = getDatabaseConnection();
			//JSONArray resultArray = new JSONArray();
			PreparedStatement ps = con.prepareStatement(Query);
			ResultSet rs = ps.executeQuery();
			JSONObject jsonobject = new JSONObject();
			
			//Vector aVectorResult = new Vector();
			while(rs.next())
			{
				
				String alpha=rs.getString(column1);
				String storeName= rs.getString(column2);
				
				if(jsonobject.containsKey(alpha))
				{
					String arrayvalues=(String)jsonobject.get(alpha);
		        	arrayvalues=addingAndParsing(arrayvalues,storeName);
		        	jsonobject.put(alpha, arrayvalues);
				}
				else
				{
					JSONArray arrayobj=new JSONArray();
					arrayobj.add(storeName);
					jsonobject.put(alpha, arrayobj.toString());
				}
					
			}
			rs.close();
			ps.close();
			releaseDatabaseConnection(con);
			return jsonobject;
		}
	    
	    public String addingAndParsing(String arrayparse,String newValue) throws ParseException, org.json.simple.parser.ParseException
	    {
	    	JSONParser parser=new JSONParser();
	    	JSONArray array=(JSONArray) parser.parse(arrayparse) ;
	    	array.add(newValue);
	    	
			return array.toString();
	    }
	    
	    
	    
	    public JSONArray allowedCities(String Query, String column1, String column2)
		throws Exception
		{
			Query = updateQuery(Query);
			Connection con = getDatabaseConnection();
			JSONArray resultArray = new JSONArray();
			PreparedStatement ps = con.prepareStatement(Query);
			ResultSet rs = ps.executeQuery();
			//Vector aVectorResult = new Vector();
			while(rs.next())
			{
				String data=rs.getString(column1)+"-"+rs.getString(column2);
				/*JSONObject object = new JSONObject();
				object.put(column1Title, rs.getString(column1));
				object.put(column2Title, rs.getString(column2));*/
				resultArray.add(data);
			}
			rs.close();
			ps.close();
			releaseDatabaseConnection(con);
			return resultArray;
		}
	    
	    
	 /*   --------------------------------------*/
	    
	    /**
		    * Creates an audit record entry with the details passed. AUDIT_LOG is the table where these details would be stored.
		    * @param tableName - Name of the table which needs to audit.
		    * @param operation - Kind of operation Ex: Update, Insert.
		    * @param createdBy - If admin console creation activity then system user id who is creating the record.
		    * @param modifiedBy - If admin console modify activity then system user id who is modifying the record.
		    * @param createdAt - Record created Time Stamp.
		    * @param modifiedAt - Record modified Time Stamp.
		    * @param message - Table Record to audit in String format.
		    * @param institutionId -Institution Id.
		    * @return  void
		    */
		
		/*public void createAuditRecord(String tableName, String operation, String createdBy, String modifiedBy, String createdAt, String modifiedAt, String message, String institutionId)
		{
			createAuditRecord(tableName, operation, createdBy, modifiedBy, createdAt, modifiedAt, message, institutionId,null, null);
		}*/
		
		/**
		    * Creates an audit record entry with the details passed. AUDIT_LOG is the table where these details would be stored.
		    * @param tableName - Name of the table which needs to audit.
		    * @param operation - Kind of operation Ex: Update, Insert.
		    * @param createdBy - If admin console creation activity then system user id who is creating the record.
		    * @param modifiedBy - If admin console modify activity then system user id who is modifying the record.
		    * @param createdAt - Record created Time Stamp.
		    * @param modifiedAt - Record modified Time Stamp.
		    * @param message - Table Record to audit in String format.
		    * @param institutionId -Institution Id.
		    * @param source - Source of Request.
		    * @return  void
		    */
		
		/*public void createAuditRecord(String tableName, String operation, String createdBy, String modifiedBy, String createdAt, String modifiedAt, String message, String institutionId, String source)
		{
			createAuditRecord(tableName, operation, createdBy, modifiedBy, createdAt, modifiedAt, message, institutionId,null, source);
		}*/
		
		/**
		    * Fetches name of system user
		    * @param record - System user Record (MFSystemuserRecord) whose name has to be fetched.
		    * @param operation - Kind of operation Ex: Update, Insert.
		    * @param createdBy - If admin console creation activity then system user id who is creating the record.
		    * @param modifiedBy - If admin console modify activity then system user id who is modifying the record.
		    * @param createdAt - Record created Time Stamp.
		    * @param modifiedAt - Record modified Time Stamp.
		    * @param message - Table Record to audit in String format.
		    * @param institutionId -Institution Id.
		    * @return  String - System user name
		    */
		
		/*private String getFullName(MTSystemuserRecord record)
		{
			String result = "";
			if (!StringUtils.isNullOrEmpty(record.getFirstname()))
			{
				result = record.getFirstname();
				result = result + " ";
			}
			
			if (!StringUtils.isNullOrEmpty(record.getMiddlename()))
			{
				result += record.getMiddlename();
				result = result + " ";
			}		

			if (!StringUtils.isNullOrEmpty(record.getLastname()))
			{
				result += record.getLastname();
			}
			return result;
		}*/

		/**
		    * Creates an audit record entry with the details passed. AUDIT_LOG is the table where these details would be stored.
		    * @param tableName - Name of the table which needs to audit.
		    * @param operation - Kind of operation Ex: Update, Insert.
		    * @param createdBy - If admin console creation activity then system user id who is creating the record.
		    * @param modifiedBy - If admin console modify activity then system user id who is modifying the record.
		    * @param createdAt - Record created Time Stamp.
		    * @param modifiedAt - Record modified Time Stamp.
		    * @param message - Table Record to audit in String format.
		    * @param currentRecordContent- Existing Record Content
		    * @param institutionId -Institution Id.
		    * @param source - Source of Request.
		    * @return  void
		    */
		
		/*public void createAuditRecord(String tableName, String operation, String createdBy, String modifiedBy, String createdAt, String modifiedAt, String message, String institutionId, String currentRecordContent, String source)
		{
			if (isTableToBeExcluded(tableName)) return;
			if (message.toUpperCase().contains("SEND_SMS")) return;
			if (message.toUpperCase().contains("SEND_MAIL")) return;
			if (message.toUpperCase().contains("LOGINREQUEST")) return;// Not to audit login requests


			if (!StringUtils.isSame(PropertyUtil.getProperty("dbauditenabled"), "Y")) return;
			

			String userName = "";

			try
			{
				MTSystemuserService systemUserService = new MTSystemuserService();
				MTSystemuserRecord systemUserRecord = (MTSystemuserRecord)systemUserService.loadMTSystemuserRecord(createdBy);
				userName = StringUtils.noNull(systemUserRecord.getUserid()) + "-" + StringUtils.noNull(getFullName(systemUserRecord));
			}
			catch(Exception e)
			{
				
			}
			LogUtils.println("Fetched User Name " + userName);
			LogUtils.println("Source " + source);

			MTAuditlogDAO auditLogDAO = new MTAuditlogDAO();
			try
			{
				MTAuditlogRecord auditLogRecord = new MTAuditlogRecord();
				auditLogRecord.setCreatedat(createdAt);
				auditLogRecord.setCreatedby(createdBy);
				auditLogRecord.setModifiedat(modifiedAt);
				auditLogRecord.setModifiedby(modifiedBy);
				auditLogRecord.setUserid(userName);
				if (source != null)
				{
					auditLogRecord.setSourceid(source);
				}
				
				if (institutionId != null)
				{
					auditLogRecord.setInstitutionid(institutionId);
				}
				auditLogRecord.setEntityname(tableName);
				auditLogRecord.setActiontype(operation);
				String shortDateCode = DateUtils.getCurrentDate();
				int recordId = auditLogDAO.insertMTAuditlogRecord(auditLogRecord);

				if (!StringUtils.isNullOrEmpty(currentRecordContent))
				{
					if (StringUtils.noNull(operation).equals("UPDATE"))
					{
						String optMessage = "\n\nRequest Source " + source;
						optMessage = optMessage + "\n\nUser " + userName;

						message = optMessage + message;
						message = message + "\n\nOriginal Record:\n\n" + currentRecordContent;
					}
				}
				
				storeRequestResponse(recordId + "", shortDateCode, message);
				
			}
			catch(Exception exception)
			{
				logger.error(exception);
				logger.error(StringUtils.getStackTrace(exception));
			}
		}*/
		
		static String initialDateCode = "";
		
		/**
		* Ignore for now
		*/

		
		public String createAuditDirIfRequired(String fileName, String dateCode)
		{
			String newFileName = fileName + dateCode + "/";
			if (!dateCode.equals(initialDateCode))
			{
				try
				{
					File f = new File(newFileName);
					f.mkdirs();
				}
				catch(Exception e)
				{
					
				}
			}
			return newFileName;
		}
		
		/**
		    * Stores the request and response in a flat file. File will be create inside a directory with todays date at path mentioned in key "AuditLogFolder" in property file 
		    * @param requestId - ID of the request.
		    * @param dateCode - Date of operation.
		    * @param message - Request or response data.
		    * @return  void
		    */
		
		public void storeRequestResponse(String requestId, String dateCode, String message)
		{
			try
			{
				if (StringUtils.isSame(PropertyUtil.getProperty("DISABLEAUDITFILECREATION"), "Y")) return;
				
				dateCode = StringUtils.noNull(dateCode);
				initialDateCode = StringUtils.noNull(initialDateCode);
				String fileName = StringUtils.noNull(PropertyUtil.getProperty("AuditLogFolder"));
				if(message.contains("TXT_ACCOUNT15"))
				{
					message = "access screen";
				}
				fileName = createAuditDirIfRequired(fileName, dateCode);
				StringUtils.writeStringToFile(message, fileName + requestId + ".txt");
			}
			catch(Exception exception)
			{
				logger.error(exception);
			}
		}
		
		/**
		    * Calculates the total amount (in Double) of transaction customer done on that day . Transactions stored in FUNDS_TRANSFER_TRANSACTION is considered. 
		    * @param cif - Customer CIF
		    * @return  double - Total amount transacted per day
		    */
		
		public double  getDayTransactionTotal(String cif)
		throws Exception
		{
			String query = "";
			query += "SELECT SUM(FTAMOUNT) TOTAMT ";
			query += "FROM FUNDS_TRANSFER_TRANSACTION ";
			query += "WHERE (FTCIF = '#CIFNO#') ";
			query += "AND (DATE_FORMAT(FTTRANTIME,'%Y%m%d') = '#DATECODE#') ";
			query += "AND (FTRESULTCODE = '1')";
			
			query = StringUtils.replaceString(query, "#CIFNO#", cif, true);
			query = StringUtils.replaceString(query, "#DATECODE#", DateUtils.getCurrentDate(), true);
			
			KBDAO dao = new KBDAO();
			String totalString = dao.loadString(query);
			
			double total = 0;
			try
			{
				total = Double.parseDouble(totalString);
			}
			catch(Exception e)
			{
				total = 0;
			}
			return total;
		}
		
	    


}
