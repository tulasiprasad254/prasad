// Author Tulasi Vara Prasad
package com.key.mb.dao;

import com.key.mb.common.KBDAO;
import com.key.mb.to.KBContentmapviewRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class KBContentmapviewDAO extends KBDAO {
  public static LogUtils logger = new LogUtils(KBContentmapviewDAO.class.getName());

  public KBContentmapviewRecord[] loadKBContentmapviewRecords(String query, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      query = query + MAX_RECORD_LIMIT_APPENDER;
      query = updateQuery(query);
      logger.trace("loadKBContentmapviewRecords	" + closeConnection + "	" + query);
      ps = con.prepareStatement(query);
      rs = ps.executeQuery();
      ArrayList recordSet = new ArrayList();
      while(rs.next()) {
        KBContentmapviewRecord record = new KBContentmapviewRecord();
        record.setStatusname(rs.getString("STATUS_NAME"));
        record.setCreatedat(rs.getString("CREATED_AT"));
        record.setCreatedby(rs.getString("CREATED_BY"));
        record.setInstitutionid(rs.getString("INSTITUTION_ID"));
        record.setIname(rs.getString("INAME"));
        record.setRstatus(rs.getString("RSTATUS"));
        record.setCcode(rs.getString("CCODE"));
        record.setCvalue(rs.getString("CVALUE"));
        record.setCseq(rs.getString("CSEQ"));
        record.setCtype(rs.getString("CTYPE"));
        record.setCcatg(rs.getString("CCATG"));
        record.setModifiedby(rs.getString("MODIFIED_BY"));
        record.setId(rs.getString("ID"));
        record.setModifiedat(rs.getString("MODIFIED_AT"));
        recordSet.add(record);
      }
      logger.trace("loadKBContentmapviewRecords:Records Fetched:" + recordSet.size());
      KBContentmapviewRecord[] tempKBContentmapviewRecords = new KBContentmapviewRecord[recordSet.size()];
      for (int index = 0; index < recordSet.size(); index++) {
        tempKBContentmapviewRecords[index] = (KBContentmapviewRecord)(recordSet.get(index));
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return tempKBContentmapviewRecords;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBContentmapviewRecord[] loadKBContentmapviewRecords(String query) throws Exception {
    return loadKBContentmapviewRecords(query, null, true);
  }

  public KBContentmapviewRecord loadFirstKBContentmapviewRecord(String query) throws Exception {
    KBContentmapviewRecord[] results = loadKBContentmapviewRecords(query);
    if (results == null) {
      return null;
    }
    if(results.length < 1) {
      return null;
    }
    return results[0];
  }

  public KBContentmapviewRecord loadKBContentmapviewRecord(String id, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      String Query = "SELECT * FROM content_map_view WHERE (ID = ?)";
      Query = updateQuery(Query);
      logger.trace("loadKBContentmapviewRecords	" + closeConnection + "	" + id);
      ps = con.prepareStatement(Query);
      ps.setString(1,id);
      rs = ps.executeQuery();
      if (!rs.next()) {
        ps.close();
        releaseDatabaseConnection(con, closeConnection);
        return null;
      }
      KBContentmapviewRecord record = new KBContentmapviewRecord();
      record.setStatusname(rs.getString("STATUS_NAME"));
      record.setCreatedat(rs.getString("CREATED_AT"));
      record.setCreatedby(rs.getString("CREATED_BY"));
      record.setInstitutionid(rs.getString("INSTITUTION_ID"));
      record.setIname(rs.getString("INAME"));
      record.setRstatus(rs.getString("RSTATUS"));
      record.setCcode(rs.getString("CCODE"));
      record.setCvalue(rs.getString("CVALUE"));
      record.setCseq(rs.getString("CSEQ"));
      record.setCtype(rs.getString("CTYPE"));
      record.setCcatg(rs.getString("CCATG"));
      record.setModifiedby(rs.getString("MODIFIED_BY"));
      record.setId(rs.getString("ID"));
      record.setModifiedat(rs.getString("MODIFIED_AT"));
      ps.close();
      logger.trace("loadKBContentmapviewRecord	" + record + "	");
      releaseDatabaseConnection(con, closeConnection);
      return record;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBContentmapviewRecord loadKBContentmapviewRecord(String id) throws Exception {
    return loadKBContentmapviewRecord(id, null, true);
  }

  public int insertKBContentmapviewRecord(KBContentmapviewRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query ="INSERT INTO content_map_view ";
      Query +="(";
      Query +="STATUS_NAME,CREATED_AT,CREATED_BY,INSTITUTION_ID,INAME,RSTATUS,CCODE,CVALUE,CSEQ,CTYPE,CCATG,MODIFIED_BY,ID,MODIFIED_AT";
      Query +=")";
      Query += " VALUES " ;
      Query +="(";
      Query +="?,?,?,?,?,?,?,?,?,?,?,?,?,?";
      Query +=")";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("insertKBContentmapviewRecords	" + closeConnection + "	" + Query);
      if (isOracleDatabase()) {
        ps = con.prepareStatement(Query,new String[]{"ID"});
      }
      else {
        ps = con.prepareStatement(Query,Statement.RETURN_GENERATED_KEYS);
      }
      setStringValue(ps, 1, record.getStatusname());
      setDateValue(ps, 2, fd.getSQLDateObject(record.getCreatedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 3, record.getCreatedby());
      setStringValue(ps, 4, record.getInstitutionid());
      setStringValue(ps, 5, record.getIname());
      setStringValue(ps, 6, record.getRstatus());
      setStringValue(ps, 7, record.getCcode());
      setStringValue(ps, 8, record.getCvalue());
      setStringValue(ps, 9, record.getCseq());
      setStringValue(ps, 10, record.getCtype());
      setStringValue(ps, 11, record.getCcatg());
      setStringValue(ps, 12, record.getModifiedby());
      setStringValue(ps, 13, record.getId());
      setDateValue(ps, 14, fd.getSQLDateObject(record.getModifiedat(), "yyyyMMddHHmmss"));
      boolean result = ps.execute();
      logger.trace("insertKBContentmapviewRecord	" + result + "	");
      int resultID = -1;
      rs = ps.getGeneratedKeys();
      if (rs.next()) {
        resultID = rs.getInt(1);
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return resultID;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public int insertKBContentmapviewRecord(KBContentmapviewRecord record) throws Exception {
    return insertKBContentmapviewRecord(record, null, true);
  }

  public boolean updateKBContentmapviewRecord(KBContentmapviewRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      KBContentmapviewRecord currentRecord = loadKBContentmapviewRecord(record.getId());
      String currentRecordContent = StringUtils.noNull(currentRecord);
      String Query = "UPDATE content_map_view SET ";
      Query += "STATUS_NAME = ?,";
          Query += "CREATED_AT = ?,";
          Query += "CREATED_BY = ?,";
          Query += "INSTITUTION_ID = ?,";
          Query += "INAME = ?,";
          Query += "RSTATUS = ?,";
          Query += "CCODE = ?,";
          Query += "CVALUE = ?,";
          Query += "CSEQ = ?,";
          Query += "CTYPE = ?,";
          Query += "CCATG = ?,";
          Query += "MODIFIED_BY = ?,";
          Query += "MODIFIED_AT = ?";
      Query += " WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("updateKBContentmapviewRecord	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      setStringValue(ps, 1, record.getStatusname());
      setDateValue(ps, 2, fd.getSQLDateObject(record.getCreatedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 3, record.getCreatedby());
      setStringValue(ps, 4, record.getInstitutionid());
      setStringValue(ps, 5, record.getIname());
      setStringValue(ps, 6, record.getRstatus());
      setStringValue(ps, 7, record.getCcode());
      setStringValue(ps, 8, record.getCvalue());
      setStringValue(ps, 9, record.getCseq());
      setStringValue(ps, 10, record.getCtype());
      setStringValue(ps, 11, record.getCcatg());
      setStringValue(ps, 12, record.getModifiedby());
      setDateValue(ps, 13, fd.getSQLDateObject(record.getModifiedat(), "yyyyMMddHHmmss"));
      ps.setString(14, StringUtils.noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("updateKBContentmapviewRecord	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean updateKBContentmapviewRecord(KBContentmapviewRecord record) throws Exception {
    return updateKBContentmapviewRecord(record, null, true);
  }

  public boolean deleteKBContentmapviewRecord(KBContentmapviewRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query = "DELETE FROM content_map_view WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("deleteKBContentmapviewRecord	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      ps.setString(1, noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("deleteKBContentmapviewRecord	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean deleteKBContentmapviewRecord(KBContentmapviewRecord record) throws Exception {
    return deleteKBContentmapviewRecord(record, null, true);
  }

  public KBContentmapviewRecord[] searchKBContentmapviewRecords(KBContentmapviewRecord searchRecord)
      throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "STATUS_NAME", formatSearchField(searchRecord.getStatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "INAME", formatSearchField(searchRecord.getIname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CCODE", formatSearchField(searchRecord.getCcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CVALUE", formatSearchField(searchRecord.getCvalue()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CSEQ", formatSearchField(searchRecord.getCseq()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CTYPE", formatSearchField(searchRecord.getCtype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CCATG", formatSearchField(searchRecord.getCcatg()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from content_map_view " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM content_map_view ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM content_map_view $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBContentmapviewRecords(Query);
  }

  public KBContentmapviewRecord[] searchKBContentmapviewRecordsExactUpper(
      KBContentmapviewRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "STATUS_NAME", formatSearchField(searchRecord.getStatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "INAME", formatSearchField(searchRecord.getIname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CCODE", formatSearchField(searchRecord.getCcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CVALUE", formatSearchField(searchRecord.getCvalue()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CSEQ", formatSearchField(searchRecord.getCseq()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CTYPE", formatSearchField(searchRecord.getCtype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CCATG", formatSearchField(searchRecord.getCcatg()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from content_map_view " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM content_map_view ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM content_map_view $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBContentmapviewRecords(Query);
  }

  public int loadKBContentmapviewRecordCount(KBContentmapviewRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "STATUS_NAME", formatSearchField(searchRecord.getStatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "INAME", formatSearchField(searchRecord.getIname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CCODE", formatSearchField(searchRecord.getCcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CVALUE", formatSearchField(searchRecord.getCvalue()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CSEQ", formatSearchField(searchRecord.getCseq()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CTYPE", formatSearchField(searchRecord.getCtype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CCATG", formatSearchField(searchRecord.getCcatg()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from content_map_view " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }

  public int loadKBContentmapviewRecordCountExact(KBContentmapviewRecord searchRecord) throws
      Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "STATUS_NAME", formatSearchField(searchRecord.getStatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "INAME", formatSearchField(searchRecord.getIname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CCODE", formatSearchField(searchRecord.getCcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CVALUE", formatSearchField(searchRecord.getCvalue()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CSEQ", formatSearchField(searchRecord.getCseq()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CTYPE", formatSearchField(searchRecord.getCtype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CCATG", formatSearchField(searchRecord.getCcatg()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from content_map_view " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }
}
