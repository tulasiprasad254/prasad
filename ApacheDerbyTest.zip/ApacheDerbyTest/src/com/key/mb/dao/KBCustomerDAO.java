// Author Tulasi Vara Prasad
package com.key.mb.dao;

import com.key.mb.common.KBDAO;
import com.key.mb.to.KBCustomerRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class KBCustomerDAO extends KBDAO {
  public static LogUtils logger = new LogUtils(KBCustomerDAO.class.getName());

  public KBCustomerRecord[] loadKBCustomerRecords(String query, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      query = query + MAX_RECORD_LIMIT_APPENDER;
      query = updateQuery(query);
      logger.trace("loadKBCustomerRecords	" + closeConnection + "	" + query);
      ps = con.prepareStatement(query);
      rs = ps.executeQuery();
      ArrayList recordSet = new ArrayList();
      while(rs.next()) {
        KBCustomerRecord record = new KBCustomerRecord();
        record.setNationalid(rs.getString("NATIONAL_ID"));
        record.setCif(rs.getString("CIF"));
        record.setCheckedby(rs.getString("CHECKED_BY"));
        record.setCname(rs.getString("CNAME"));
        record.setTermssigned(rs.getString("TERMS_SIGNED"));
        record.setCreatedat(rs.getString("CREATED_AT"));
        record.setMakerlastcmt(rs.getString("MAKER_LAST_CMT"));
        record.setPreflang(rs.getString("PREF_LANG"));
        record.setInstitutionid(rs.getString("INSTITUTION_ID"));
        record.setBlockedflag(rs.getString("BLOCKED_FLAG"));
        record.setPassport(rs.getString("PASSPORT"));
        record.setAuthfailpin(rs.getString("AUTH_FAIL_PIN"));
        record.setId(rs.getString("ID"));
        record.setModifiedat(rs.getString("MODIFIED_AT"));
        record.setEmail(rs.getString("EMAIL"));
        record.setAuthfailtpin(rs.getString("AUTH_FAIL_TPIN"));
        record.setValacc(rs.getString("VAL_ACC"));
        record.setMadeat(rs.getString("MADE_AT"));
        record.setCheckedat(rs.getString("CHECKED_AT"));
        record.setReportfreq(rs.getString("REPORT_FREQ"));
        record.setMobile(rs.getString("MOBILE"));
        record.setAllowedphoneid1(rs.getString("ALLOWED_PHONE_ID1"));
        record.setAllowedphoneid2(rs.getString("ALLOWED_PHONE_ID2"));
        record.setAllowedphonetype3(rs.getString("ALLOWED_PHONE_TYPE3"));
        record.setIdsubmitted(rs.getString("ID_SUBMITTED"));
        record.setAllowedphonetype2(rs.getString("ALLOWED_PHONE_TYPE2"));
        record.setInitialtpin(rs.getString("INITIAL_TPIN"));
        record.setCreatedby(rs.getString("CREATED_BY"));
        record.setIdverified(rs.getString("ID_VERIFIED"));
        record.setRstatus(rs.getString("RSTATUS"));
        record.setCustcat(rs.getString("CUST_CAT"));
        record.setCustextn4(rs.getString("CUST_EXTN4"));
        record.setCustextn3(rs.getString("CUST_EXTN3"));
        record.setPinno(rs.getString("PIN_NO"));
        record.setCurrappstatus(rs.getString("CURR_APP_STATUS"));
        record.setCustextn2(rs.getString("CUST_EXTN2"));
        record.setTpinno(rs.getString("TPIN_NO"));
        record.setCustextn1(rs.getString("CUST_EXTN1"));
        record.setNationality(rs.getString("NATIONALITY"));
        record.setAllowedphonetype1(rs.getString("ALLOWED_PHONE_TYPE1"));
        record.setAdminlastcmt(rs.getString("ADMIN_LAST_CMT"));
        record.setAllowedphoneid3(rs.getString("ALLOWED_PHONE_ID3"));
        record.setInitialmpin(rs.getString("INITIAL_MPIN"));
        record.setModifiedby(rs.getString("MODIFIED_BY"));
        record.setMadeby(rs.getString("MADE_BY"));
        record.setUgissued(rs.getString("UG_ISSUED"));
        record.setCheckerlastcmt(rs.getString("CHECKER_LAST_CMT"));
        recordSet.add(record);
      }
      logger.trace("loadKBCustomerRecords:Records Fetched:" + recordSet.size());
      KBCustomerRecord[] tempKBCustomerRecords = new KBCustomerRecord[recordSet.size()];
      for (int index = 0; index < recordSet.size(); index++) {
        tempKBCustomerRecords[index] = (KBCustomerRecord)(recordSet.get(index));
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return tempKBCustomerRecords;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBCustomerRecord[] loadKBCustomerRecords(String query) throws Exception {
    return loadKBCustomerRecords(query, null, true);
  }

  public KBCustomerRecord loadFirstKBCustomerRecord(String query) throws Exception {
    KBCustomerRecord[] results = loadKBCustomerRecords(query);
    if (results == null) {
      return null;
    }
    if(results.length < 1) {
      return null;
    }
    return results[0];
  }

  public KBCustomerRecord loadKBCustomerRecord(String id, Connection con, boolean closeConnection)
      throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      String Query = "SELECT * FROM customer WHERE (ID = ?)";
      Query = updateQuery(Query);
      logger.trace("loadKBCustomerRecords	" + closeConnection + "	" + id);
      ps = con.prepareStatement(Query);
      ps.setString(1,id);
      rs = ps.executeQuery();
      if (!rs.next()) {
        ps.close();
        releaseDatabaseConnection(con, closeConnection);
        return null;
      }
      KBCustomerRecord record = new KBCustomerRecord();
      record.setNationalid(rs.getString("NATIONAL_ID"));
      record.setCif(rs.getString("CIF"));
      record.setCheckedby(rs.getString("CHECKED_BY"));
      record.setCname(rs.getString("CNAME"));
      record.setTermssigned(rs.getString("TERMS_SIGNED"));
      record.setCreatedat(rs.getString("CREATED_AT"));
      record.setMakerlastcmt(rs.getString("MAKER_LAST_CMT"));
      record.setPreflang(rs.getString("PREF_LANG"));
      record.setInstitutionid(rs.getString("INSTITUTION_ID"));
      record.setBlockedflag(rs.getString("BLOCKED_FLAG"));
      record.setPassport(rs.getString("PASSPORT"));
      record.setAuthfailpin(rs.getString("AUTH_FAIL_PIN"));
      record.setId(rs.getString("ID"));
      record.setModifiedat(rs.getString("MODIFIED_AT"));
      record.setEmail(rs.getString("EMAIL"));
      record.setAuthfailtpin(rs.getString("AUTH_FAIL_TPIN"));
      record.setValacc(rs.getString("VAL_ACC"));
      record.setMadeat(rs.getString("MADE_AT"));
      record.setCheckedat(rs.getString("CHECKED_AT"));
      record.setReportfreq(rs.getString("REPORT_FREQ"));
      record.setMobile(rs.getString("MOBILE"));
      record.setAllowedphoneid1(rs.getString("ALLOWED_PHONE_ID1"));
      record.setAllowedphoneid2(rs.getString("ALLOWED_PHONE_ID2"));
      record.setAllowedphonetype3(rs.getString("ALLOWED_PHONE_TYPE3"));
      record.setIdsubmitted(rs.getString("ID_SUBMITTED"));
      record.setAllowedphonetype2(rs.getString("ALLOWED_PHONE_TYPE2"));
      record.setInitialtpin(rs.getString("INITIAL_TPIN"));
      record.setCreatedby(rs.getString("CREATED_BY"));
      record.setIdverified(rs.getString("ID_VERIFIED"));
      record.setRstatus(rs.getString("RSTATUS"));
      record.setCustcat(rs.getString("CUST_CAT"));
      record.setCustextn4(rs.getString("CUST_EXTN4"));
      record.setCustextn3(rs.getString("CUST_EXTN3"));
      record.setPinno(rs.getString("PIN_NO"));
      record.setCurrappstatus(rs.getString("CURR_APP_STATUS"));
      record.setCustextn2(rs.getString("CUST_EXTN2"));
      record.setTpinno(rs.getString("TPIN_NO"));
      record.setCustextn1(rs.getString("CUST_EXTN1"));
      record.setNationality(rs.getString("NATIONALITY"));
      record.setAllowedphonetype1(rs.getString("ALLOWED_PHONE_TYPE1"));
      record.setAdminlastcmt(rs.getString("ADMIN_LAST_CMT"));
      record.setAllowedphoneid3(rs.getString("ALLOWED_PHONE_ID3"));
      record.setInitialmpin(rs.getString("INITIAL_MPIN"));
      record.setModifiedby(rs.getString("MODIFIED_BY"));
      record.setMadeby(rs.getString("MADE_BY"));
      record.setUgissued(rs.getString("UG_ISSUED"));
      record.setCheckerlastcmt(rs.getString("CHECKER_LAST_CMT"));
      ps.close();
      logger.trace("loadKBCustomerRecord	" + record + "	");
      releaseDatabaseConnection(con, closeConnection);
      return record;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBCustomerRecord loadKBCustomerRecord(String id) throws Exception {
    return loadKBCustomerRecord(id, null, true);
  }

  public int insertKBCustomerRecord(KBCustomerRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query ="INSERT INTO customer ";
      Query +="(";
      Query +="NATIONAL_ID,CIF,CHECKED_BY,CNAME,TERMS_SIGNED,CREATED_AT,MAKER_LAST_CMT,PREF_LANG,INSTITUTION_ID,BLOCKED_FLAG,PASSPORT,AUTH_FAIL_PIN,ID,MODIFIED_AT,EMAIL,AUTH_FAIL_TPIN,VAL_ACC,MADE_AT,CHECKED_AT,REPORT_FREQ,MOBILE,ALLOWED_PHONE_ID1,ALLOWED_PHONE_ID2,ALLOWED_PHONE_TYPE3,ID_SUBMITTED,ALLOWED_PHONE_TYPE2,INITIAL_TPIN,CREATED_BY,ID_VERIFIED,RSTATUS,CUST_CAT,CUST_EXTN4,CUST_EXTN3,PIN_NO,CURR_APP_STATUS,CUST_EXTN2,TPIN_NO,CUST_EXTN1,NATIONALITY,ALLOWED_PHONE_TYPE1,ADMIN_LAST_CMT,ALLOWED_PHONE_ID3,INITIAL_MPIN,MODIFIED_BY,MADE_BY,UG_ISSUED,CHECKER_LAST_CMT";
      Query +=")";
      Query += " VALUES " ;
      Query +="(";
      Query +="?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?";
      Query +=")";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("insertKBCustomerRecords	" + closeConnection + "	" + Query);
      if (isOracleDatabase()) {
        ps = con.prepareStatement(Query,new String[]{"ID"});
      }
      else {
        ps = con.prepareStatement(Query,Statement.RETURN_GENERATED_KEYS);
      }
      setStringValue(ps, 1, record.getNationalid());
      setStringValue(ps, 2, record.getCif());
      setStringValue(ps, 3, record.getCheckedby());
      setStringValue(ps, 4, record.getCname());
      setStringValue(ps, 5, record.getTermssigned());
      setDateValue(ps, 6, fd.getSQLDateObject(record.getCreatedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 7, record.getMakerlastcmt());
      setStringValue(ps, 8, record.getPreflang());
      setStringValue(ps, 9, record.getInstitutionid());
      setStringValue(ps, 10, record.getBlockedflag());
      setStringValue(ps, 11, record.getPassport());
      setStringValue(ps, 12, record.getAuthfailpin());
      setStringValue(ps, 13, record.getId());
      setDateValue(ps, 14, fd.getSQLDateObject(record.getModifiedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 15, record.getEmail());
      setStringValue(ps, 16, record.getAuthfailtpin());
      setStringValue(ps, 17, record.getValacc());
      setStringValue(ps, 18, record.getMadeat());
      setStringValue(ps, 19, record.getCheckedat());
      setStringValue(ps, 20, record.getReportfreq());
      setStringValue(ps, 21, record.getMobile());
      setStringValue(ps, 22, record.getAllowedphoneid1());
      setStringValue(ps, 23, record.getAllowedphoneid2());
      setStringValue(ps, 24, record.getAllowedphonetype3());
      setStringValue(ps, 25, record.getIdsubmitted());
      setStringValue(ps, 26, record.getAllowedphonetype2());
      setStringValue(ps, 27, record.getInitialtpin());
      setStringValue(ps, 28, record.getCreatedby());
      setStringValue(ps, 29, record.getIdverified());
      setStringValue(ps, 30, record.getRstatus());
      setStringValue(ps, 31, record.getCustcat());
      setStringValue(ps, 32, record.getCustextn4());
      setStringValue(ps, 33, record.getCustextn3());
      setStringValue(ps, 34, record.getPinno());
      setStringValue(ps, 35, record.getCurrappstatus());
      setStringValue(ps, 36, record.getCustextn2());
      setStringValue(ps, 37, record.getTpinno());
      setStringValue(ps, 38, record.getCustextn1());
      setStringValue(ps, 39, record.getNationality());
      setStringValue(ps, 40, record.getAllowedphonetype1());
      setStringValue(ps, 41, record.getAdminlastcmt());
      setStringValue(ps, 42, record.getAllowedphoneid3());
      setStringValue(ps, 43, record.getInitialmpin());
      setStringValue(ps, 44, record.getModifiedby());
      setStringValue(ps, 45, record.getMadeby());
      setStringValue(ps, 46, record.getUgissued());
      setStringValue(ps, 47, record.getCheckerlastcmt());
      boolean result = ps.execute();
      logger.trace("insertKBCustomerRecord	" + result + "	");
      int resultID = -1;
      rs = ps.getGeneratedKeys();
      if (rs.next()) {
        resultID = rs.getInt(1);
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return resultID;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public int insertKBCustomerRecord(KBCustomerRecord record) throws Exception {
    return insertKBCustomerRecord(record, null, true);
  }

  public boolean updateKBCustomerRecord(KBCustomerRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      KBCustomerRecord currentRecord = loadKBCustomerRecord(record.getId());
      String currentRecordContent = StringUtils.noNull(currentRecord);
      String Query = "UPDATE customer SET ";
      Query += "NATIONAL_ID = ?,";
          Query += "CIF = ?,";
          Query += "CHECKED_BY = ?,";
          Query += "CNAME = ?,";
          Query += "TERMS_SIGNED = ?,";
          Query += "CREATED_AT = ?,";
          Query += "MAKER_LAST_CMT = ?,";
          Query += "PREF_LANG = ?,";
          Query += "INSTITUTION_ID = ?,";
          Query += "BLOCKED_FLAG = ?,";
          Query += "PASSPORT = ?,";
          Query += "AUTH_FAIL_PIN = ?,";
          Query += "MODIFIED_AT = ?,";
          Query += "EMAIL = ?,";
          Query += "AUTH_FAIL_TPIN = ?,";
          Query += "VAL_ACC = ?,";
          Query += "MADE_AT = ?,";
          Query += "CHECKED_AT = ?,";
          Query += "REPORT_FREQ = ?,";
          Query += "MOBILE = ?,";
          Query += "ALLOWED_PHONE_ID1 = ?,";
          Query += "ALLOWED_PHONE_ID2 = ?,";
          Query += "ALLOWED_PHONE_TYPE3 = ?,";
          Query += "ID_SUBMITTED = ?,";
          Query += "ALLOWED_PHONE_TYPE2 = ?,";
          Query += "INITIAL_TPIN = ?,";
          Query += "CREATED_BY = ?,";
          Query += "ID_VERIFIED = ?,";
          Query += "RSTATUS = ?,";
          Query += "CUST_CAT = ?,";
          Query += "CUST_EXTN4 = ?,";
          Query += "CUST_EXTN3 = ?,";
          Query += "PIN_NO = ?,";
          Query += "CURR_APP_STATUS = ?,";
          Query += "CUST_EXTN2 = ?,";
          Query += "TPIN_NO = ?,";
          Query += "CUST_EXTN1 = ?,";
          Query += "NATIONALITY = ?,";
          Query += "ALLOWED_PHONE_TYPE1 = ?,";
          Query += "ADMIN_LAST_CMT = ?,";
          Query += "ALLOWED_PHONE_ID3 = ?,";
          Query += "INITIAL_MPIN = ?,";
          Query += "MODIFIED_BY = ?,";
          Query += "MADE_BY = ?,";
          Query += "UG_ISSUED = ?,";
          Query += "CHECKER_LAST_CMT = ?";
      Query += " WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("updateKBCustomerRecord	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      setStringValue(ps, 1, record.getNationalid());
      setStringValue(ps, 2, record.getCif());
      setStringValue(ps, 3, record.getCheckedby());
      setStringValue(ps, 4, record.getCname());
      setStringValue(ps, 5, record.getTermssigned());
      setDateValue(ps, 6, fd.getSQLDateObject(record.getCreatedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 7, record.getMakerlastcmt());
      setStringValue(ps, 8, record.getPreflang());
      setStringValue(ps, 9, record.getInstitutionid());
      setStringValue(ps, 10, record.getBlockedflag());
      setStringValue(ps, 11, record.getPassport());
      setStringValue(ps, 12, record.getAuthfailpin());
      setDateValue(ps, 13, fd.getSQLDateObject(record.getModifiedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 14, record.getEmail());
      setStringValue(ps, 15, record.getAuthfailtpin());
      setStringValue(ps, 16, record.getValacc());
      setStringValue(ps, 17, record.getMadeat());
      setStringValue(ps, 18, record.getCheckedat());
      setStringValue(ps, 19, record.getReportfreq());
      setStringValue(ps, 20, record.getMobile());
      setStringValue(ps, 21, record.getAllowedphoneid1());
      setStringValue(ps, 22, record.getAllowedphoneid2());
      setStringValue(ps, 23, record.getAllowedphonetype3());
      setStringValue(ps, 24, record.getIdsubmitted());
      setStringValue(ps, 25, record.getAllowedphonetype2());
      setStringValue(ps, 26, record.getInitialtpin());
      setStringValue(ps, 27, record.getCreatedby());
      setStringValue(ps, 28, record.getIdverified());
      setStringValue(ps, 29, record.getRstatus());
      setStringValue(ps, 30, record.getCustcat());
      setStringValue(ps, 31, record.getCustextn4());
      setStringValue(ps, 32, record.getCustextn3());
      setStringValue(ps, 33, record.getPinno());
      setStringValue(ps, 34, record.getCurrappstatus());
      setStringValue(ps, 35, record.getCustextn2());
      setStringValue(ps, 36, record.getTpinno());
      setStringValue(ps, 37, record.getCustextn1());
      setStringValue(ps, 38, record.getNationality());
      setStringValue(ps, 39, record.getAllowedphonetype1());
      setStringValue(ps, 40, record.getAdminlastcmt());
      setStringValue(ps, 41, record.getAllowedphoneid3());
      setStringValue(ps, 42, record.getInitialmpin());
      setStringValue(ps, 43, record.getModifiedby());
      setStringValue(ps, 44, record.getMadeby());
      setStringValue(ps, 45, record.getUgissued());
      setStringValue(ps, 46, record.getCheckerlastcmt());
      ps.setString(47, StringUtils.noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("updateKBCustomerRecord	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean updateKBCustomerRecord(KBCustomerRecord record) throws Exception {
    return updateKBCustomerRecord(record, null, true);
  }

  public boolean deleteKBCustomerRecord(KBCustomerRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query = "DELETE FROM customer WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("deleteKBCustomerRecord	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      ps.setString(1, noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("deleteKBCustomerRecord	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean deleteKBCustomerRecord(KBCustomerRecord record) throws Exception {
    return deleteKBCustomerRecord(record, null, true);
  }

  public KBCustomerRecord[] searchKBCustomerRecords(KBCustomerRecord searchRecord) throws
      Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "NATIONAL_ID", formatSearchField(searchRecord.getNationalid()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CIF", formatSearchField(searchRecord.getCif()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CHECKED_BY", formatSearchField(searchRecord.getCheckedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CNAME", formatSearchField(searchRecord.getCname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "TERMS_SIGNED", formatSearchField(searchRecord.getTermssigned()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MAKER_LAST_CMT", formatSearchField(searchRecord.getMakerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PREF_LANG", formatSearchField(searchRecord.getPreflang()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "BLOCKED_FLAG", formatSearchField(searchRecord.getBlockedflag()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PASSPORT", formatSearchField(searchRecord.getPassport()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "AUTH_FAIL_PIN", formatSearchField(searchRecord.getAuthfailpin()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EMAIL", formatSearchField(searchRecord.getEmail()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "AUTH_FAIL_TPIN", formatSearchField(searchRecord.getAuthfailtpin()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "VAL_ACC", formatSearchField(searchRecord.getValacc()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MADE_AT", formatSearchField(searchRecord.getMadeat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHECKED_AT", formatSearchField(searchRecord.getCheckedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "REPORT_FREQ", formatSearchField(searchRecord.getReportfreq()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MOBILE", formatSearchField(searchRecord.getMobile()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ALLOWED_PHONE_ID1", formatSearchField(searchRecord.getAllowedphoneid1()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ALLOWED_PHONE_ID2", formatSearchField(searchRecord.getAllowedphoneid2()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ALLOWED_PHONE_TYPE3", formatSearchField(searchRecord.getAllowedphonetype3()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID_SUBMITTED", formatSearchField(searchRecord.getIdsubmitted()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ALLOWED_PHONE_TYPE2", formatSearchField(searchRecord.getAllowedphonetype2()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "INITIAL_TPIN", formatSearchField(searchRecord.getInitialtpin()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID_VERIFIED", formatSearchField(searchRecord.getIdverified()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CUST_CAT", formatSearchField(searchRecord.getCustcat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CUST_EXTN4", formatSearchField(searchRecord.getCustextn4()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CUST_EXTN3", formatSearchField(searchRecord.getCustextn3()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "PIN_NO", formatSearchField(searchRecord.getPinno()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CURR_APP_STATUS", formatSearchField(searchRecord.getCurrappstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CUST_EXTN2", formatSearchField(searchRecord.getCustextn2()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "TPIN_NO", formatSearchField(searchRecord.getTpinno()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CUST_EXTN1", formatSearchField(searchRecord.getCustextn1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "NATIONALITY", formatSearchField(searchRecord.getNationality()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ALLOWED_PHONE_TYPE1", formatSearchField(searchRecord.getAllowedphonetype1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "ADMIN_LAST_CMT", formatSearchField(searchRecord.getAdminlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ALLOWED_PHONE_ID3", formatSearchField(searchRecord.getAllowedphoneid3()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "INITIAL_MPIN", formatSearchField(searchRecord.getInitialmpin()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MADE_BY", formatSearchField(searchRecord.getMadeby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "UG_ISSUED", formatSearchField(searchRecord.getUgissued()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHECKER_LAST_CMT", formatSearchField(searchRecord.getCheckerlastcmt()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from customer " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM customer ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM customer $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBCustomerRecords(Query);
  }

  public KBCustomerRecord[] searchKBCustomerRecordsExactUpper(KBCustomerRecord searchRecord) throws
      Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "NATIONAL_ID", formatSearchField(searchRecord.getNationalid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CIF", formatSearchField(searchRecord.getCif()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKED_BY", formatSearchField(searchRecord.getCheckedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CNAME", formatSearchField(searchRecord.getCname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "TERMS_SIGNED", formatSearchField(searchRecord.getTermssigned()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MAKER_LAST_CMT", formatSearchField(searchRecord.getMakerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PREF_LANG", formatSearchField(searchRecord.getPreflang()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "BLOCKED_FLAG", formatSearchField(searchRecord.getBlockedflag()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PASSPORT", formatSearchField(searchRecord.getPassport()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "AUTH_FAIL_PIN", formatSearchField(searchRecord.getAuthfailpin()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EMAIL", formatSearchField(searchRecord.getEmail()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "AUTH_FAIL_TPIN", formatSearchField(searchRecord.getAuthfailtpin()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "VAL_ACC", formatSearchField(searchRecord.getValacc()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MADE_AT", formatSearchField(searchRecord.getMadeat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKED_AT", formatSearchField(searchRecord.getCheckedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "REPORT_FREQ", formatSearchField(searchRecord.getReportfreq()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MOBILE", formatSearchField(searchRecord.getMobile()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ALLOWED_PHONE_ID1", formatSearchField(searchRecord.getAllowedphoneid1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ALLOWED_PHONE_ID2", formatSearchField(searchRecord.getAllowedphoneid2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ALLOWED_PHONE_TYPE3", formatSearchField(searchRecord.getAllowedphonetype3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID_SUBMITTED", formatSearchField(searchRecord.getIdsubmitted()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ALLOWED_PHONE_TYPE2", formatSearchField(searchRecord.getAllowedphonetype2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "INITIAL_TPIN", formatSearchField(searchRecord.getInitialtpin()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID_VERIFIED", formatSearchField(searchRecord.getIdverified()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CUST_CAT", formatSearchField(searchRecord.getCustcat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CUST_EXTN4", formatSearchField(searchRecord.getCustextn4()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CUST_EXTN3", formatSearchField(searchRecord.getCustextn3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PIN_NO", formatSearchField(searchRecord.getPinno()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CURR_APP_STATUS", formatSearchField(searchRecord.getCurrappstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CUST_EXTN2", formatSearchField(searchRecord.getCustextn2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "TPIN_NO", formatSearchField(searchRecord.getTpinno()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CUST_EXTN1", formatSearchField(searchRecord.getCustextn1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "NATIONALITY", formatSearchField(searchRecord.getNationality()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ALLOWED_PHONE_TYPE1", formatSearchField(searchRecord.getAllowedphonetype1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ADMIN_LAST_CMT", formatSearchField(searchRecord.getAdminlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ALLOWED_PHONE_ID3", formatSearchField(searchRecord.getAllowedphoneid3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "INITIAL_MPIN", formatSearchField(searchRecord.getInitialmpin()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MADE_BY", formatSearchField(searchRecord.getMadeby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "UG_ISSUED", formatSearchField(searchRecord.getUgissued()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKER_LAST_CMT", formatSearchField(searchRecord.getCheckerlastcmt()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from customer " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM customer ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM customer $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBCustomerRecords(Query);
  }

  public int loadKBCustomerRecordCount(KBCustomerRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "NATIONAL_ID", formatSearchField(searchRecord.getNationalid()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CIF", formatSearchField(searchRecord.getCif()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CHECKED_BY", formatSearchField(searchRecord.getCheckedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CNAME", formatSearchField(searchRecord.getCname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "TERMS_SIGNED", formatSearchField(searchRecord.getTermssigned()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MAKER_LAST_CMT", formatSearchField(searchRecord.getMakerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PREF_LANG", formatSearchField(searchRecord.getPreflang()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "BLOCKED_FLAG", formatSearchField(searchRecord.getBlockedflag()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PASSPORT", formatSearchField(searchRecord.getPassport()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "AUTH_FAIL_PIN", formatSearchField(searchRecord.getAuthfailpin()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EMAIL", formatSearchField(searchRecord.getEmail()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "AUTH_FAIL_TPIN", formatSearchField(searchRecord.getAuthfailtpin()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "VAL_ACC", formatSearchField(searchRecord.getValacc()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MADE_AT", formatSearchField(searchRecord.getMadeat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHECKED_AT", formatSearchField(searchRecord.getCheckedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "REPORT_FREQ", formatSearchField(searchRecord.getReportfreq()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MOBILE", formatSearchField(searchRecord.getMobile()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ALLOWED_PHONE_ID1", formatSearchField(searchRecord.getAllowedphoneid1()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ALLOWED_PHONE_ID2", formatSearchField(searchRecord.getAllowedphoneid2()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ALLOWED_PHONE_TYPE3", formatSearchField(searchRecord.getAllowedphonetype3()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID_SUBMITTED", formatSearchField(searchRecord.getIdsubmitted()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ALLOWED_PHONE_TYPE2", formatSearchField(searchRecord.getAllowedphonetype2()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "INITIAL_TPIN", formatSearchField(searchRecord.getInitialtpin()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID_VERIFIED", formatSearchField(searchRecord.getIdverified()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CUST_CAT", formatSearchField(searchRecord.getCustcat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CUST_EXTN4", formatSearchField(searchRecord.getCustextn4()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CUST_EXTN3", formatSearchField(searchRecord.getCustextn3()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "PIN_NO", formatSearchField(searchRecord.getPinno()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CURR_APP_STATUS", formatSearchField(searchRecord.getCurrappstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CUST_EXTN2", formatSearchField(searchRecord.getCustextn2()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "TPIN_NO", formatSearchField(searchRecord.getTpinno()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CUST_EXTN1", formatSearchField(searchRecord.getCustextn1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "NATIONALITY", formatSearchField(searchRecord.getNationality()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ALLOWED_PHONE_TYPE1", formatSearchField(searchRecord.getAllowedphonetype1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "ADMIN_LAST_CMT", formatSearchField(searchRecord.getAdminlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ALLOWED_PHONE_ID3", formatSearchField(searchRecord.getAllowedphoneid3()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "INITIAL_MPIN", formatSearchField(searchRecord.getInitialmpin()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MADE_BY", formatSearchField(searchRecord.getMadeby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "UG_ISSUED", formatSearchField(searchRecord.getUgissued()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHECKER_LAST_CMT", formatSearchField(searchRecord.getCheckerlastcmt()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from customer " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }

  public int loadKBCustomerRecordCountExact(KBCustomerRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "NATIONAL_ID", formatSearchField(searchRecord.getNationalid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CIF", formatSearchField(searchRecord.getCif()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKED_BY", formatSearchField(searchRecord.getCheckedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CNAME", formatSearchField(searchRecord.getCname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "TERMS_SIGNED", formatSearchField(searchRecord.getTermssigned()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MAKER_LAST_CMT", formatSearchField(searchRecord.getMakerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PREF_LANG", formatSearchField(searchRecord.getPreflang()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "BLOCKED_FLAG", formatSearchField(searchRecord.getBlockedflag()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PASSPORT", formatSearchField(searchRecord.getPassport()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "AUTH_FAIL_PIN", formatSearchField(searchRecord.getAuthfailpin()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EMAIL", formatSearchField(searchRecord.getEmail()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "AUTH_FAIL_TPIN", formatSearchField(searchRecord.getAuthfailtpin()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "VAL_ACC", formatSearchField(searchRecord.getValacc()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MADE_AT", formatSearchField(searchRecord.getMadeat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKED_AT", formatSearchField(searchRecord.getCheckedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "REPORT_FREQ", formatSearchField(searchRecord.getReportfreq()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MOBILE", formatSearchField(searchRecord.getMobile()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ALLOWED_PHONE_ID1", formatSearchField(searchRecord.getAllowedphoneid1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ALLOWED_PHONE_ID2", formatSearchField(searchRecord.getAllowedphoneid2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ALLOWED_PHONE_TYPE3", formatSearchField(searchRecord.getAllowedphonetype3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID_SUBMITTED", formatSearchField(searchRecord.getIdsubmitted()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ALLOWED_PHONE_TYPE2", formatSearchField(searchRecord.getAllowedphonetype2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "INITIAL_TPIN", formatSearchField(searchRecord.getInitialtpin()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID_VERIFIED", formatSearchField(searchRecord.getIdverified()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CUST_CAT", formatSearchField(searchRecord.getCustcat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CUST_EXTN4", formatSearchField(searchRecord.getCustextn4()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CUST_EXTN3", formatSearchField(searchRecord.getCustextn3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PIN_NO", formatSearchField(searchRecord.getPinno()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CURR_APP_STATUS", formatSearchField(searchRecord.getCurrappstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CUST_EXTN2", formatSearchField(searchRecord.getCustextn2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "TPIN_NO", formatSearchField(searchRecord.getTpinno()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CUST_EXTN1", formatSearchField(searchRecord.getCustextn1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "NATIONALITY", formatSearchField(searchRecord.getNationality()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ALLOWED_PHONE_TYPE1", formatSearchField(searchRecord.getAllowedphonetype1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ADMIN_LAST_CMT", formatSearchField(searchRecord.getAdminlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ALLOWED_PHONE_ID3", formatSearchField(searchRecord.getAllowedphoneid3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "INITIAL_MPIN", formatSearchField(searchRecord.getInitialmpin()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MADE_BY", formatSearchField(searchRecord.getMadeby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "UG_ISSUED", formatSearchField(searchRecord.getUgissued()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKER_LAST_CMT", formatSearchField(searchRecord.getCheckerlastcmt()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from customer " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }
}
