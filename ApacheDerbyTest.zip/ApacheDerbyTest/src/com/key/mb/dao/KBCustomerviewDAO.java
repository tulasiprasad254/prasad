// Author Tulasi Vara Prasad
package com.key.mb.dao;

import com.key.mb.common.KBDAO;
import com.key.mb.to.KBCustomerviewRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class KBCustomerviewDAO extends KBDAO {
  public static LogUtils logger = new LogUtils(KBCustomerviewDAO.class.getName());

  public KBCustomerviewRecord[] loadKBCustomerviewRecords(String query, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      query = query + MAX_RECORD_LIMIT_APPENDER;
      query = updateQuery(query);
      logger.trace("loadKBCustomerviewRecords	" + closeConnection + "	" + query);
      ps = con.prepareStatement(query);
      rs = ps.executeQuery();
      ArrayList recordSet = new ArrayList();
      while(rs.next()) {
        KBCustomerviewRecord record = new KBCustomerviewRecord();
        record.setCheckedby(rs.getString("CHECKED_BY"));
        record.setTermssigned(rs.getString("TERMS_SIGNED"));
        record.setMakerlastcmt(rs.getString("MAKER_LAST_CMT"));
        record.setPreflang(rs.getString("PREF_LANG"));
        record.setInstitutionid(rs.getString("INSTITUTION_ID"));
        record.setIname(rs.getString("INAME"));
        record.setBlockedflag(rs.getString("BLOCKED_FLAG"));
        record.setPassport(rs.getString("PASSPORT"));
        record.setId(rs.getString("ID"));
        record.setModifiedat(rs.getString("MODIFIED_AT"));
        record.setAuthfailtpin(rs.getString("AUTH_FAIL_TPIN"));
        record.setValacc(rs.getString("VAL_ACC"));
        record.setMadeat(rs.getString("MADE_AT"));
        record.setCheckedat(rs.getString("CHECKED_AT"));
        record.setAllowedphoneid1(rs.getString("ALLOWED_PHONE_ID1"));
        record.setAllowedphoneid2(rs.getString("ALLOWED_PHONE_ID2"));
        record.setCreatedby(rs.getString("CREATED_BY"));
        record.setRstatus(rs.getString("RSTATUS"));
        record.setPinno(rs.getString("PIN_NO"));
        record.setNationality(rs.getString("NATIONALITY"));
        record.setAdminlastcmt(rs.getString("ADMIN_LAST_CMT"));
        record.setAllowedphoneid3(rs.getString("ALLOWED_PHONE_ID3"));
        record.setCheckerlastcmt(rs.getString("CHECKER_LAST_CMT"));
        record.setNationalid(rs.getString("NATIONAL_ID"));
        record.setCif(rs.getString("CIF"));
        record.setCname(rs.getString("CNAME"));
        record.setCreatedat(rs.getString("CREATED_AT"));
        record.setAuthfailpin(rs.getString("AUTH_FAIL_PIN"));
        record.setEmail(rs.getString("EMAIL"));
        record.setReportfreq(rs.getString("REPORT_FREQ"));
        record.setStatusname(rs.getString("STATUS_NAME"));
        record.setMobile(rs.getString("MOBILE"));
        record.setAllowedphonetype3(rs.getString("ALLOWED_PHONE_TYPE3"));
        record.setIdsubmitted(rs.getString("ID_SUBMITTED"));
        record.setAllowedphonetype2(rs.getString("ALLOWED_PHONE_TYPE2"));
        record.setIdverified(rs.getString("ID_VERIFIED"));
        record.setCustcat(rs.getString("CUST_CAT"));
        record.setCustextn4(rs.getString("CUST_EXTN4"));
        record.setCustextn3(rs.getString("CUST_EXTN3"));
        record.setCurrappstatus(rs.getString("CURR_APP_STATUS"));
        record.setCustextn2(rs.getString("CUST_EXTN2"));
        record.setCustextn1(rs.getString("CUST_EXTN1"));
        record.setTpinno(rs.getString("TPIN_NO"));
        record.setAllowedphonetype1(rs.getString("ALLOWED_PHONE_TYPE1"));
        record.setCurrappstatusname(rs.getString("CURR_APP_STATUS_NAME"));
        record.setModifiedby(rs.getString("MODIFIED_BY"));
        record.setMadeby(rs.getString("MADE_BY"));
        record.setCategory(rs.getString("CATEGORY"));
        record.setUgissued(rs.getString("UG_ISSUED"));
        recordSet.add(record);
      }
      logger.trace("loadKBCustomerviewRecords:Records Fetched:" + recordSet.size());
      KBCustomerviewRecord[] tempKBCustomerviewRecords = new KBCustomerviewRecord[recordSet.size()];
      for (int index = 0; index < recordSet.size(); index++) {
        tempKBCustomerviewRecords[index] = (KBCustomerviewRecord)(recordSet.get(index));
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return tempKBCustomerviewRecords;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBCustomerviewRecord[] loadKBCustomerviewRecords(String query) throws Exception {
    return loadKBCustomerviewRecords(query, null, true);
  }

  public KBCustomerviewRecord loadFirstKBCustomerviewRecord(String query) throws Exception {
    KBCustomerviewRecord[] results = loadKBCustomerviewRecords(query);
    if (results == null) {
      return null;
    }
    if(results.length < 1) {
      return null;
    }
    return results[0];
  }

  public KBCustomerviewRecord loadKBCustomerviewRecord(String id, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      String Query = "SELECT * FROM customer_view WHERE (ID = ?)";
      Query = updateQuery(Query);
      logger.trace("loadKBCustomerviewRecords	" + closeConnection + "	" + id);
      ps = con.prepareStatement(Query);
      ps.setString(1,id);
      rs = ps.executeQuery();
      if (!rs.next()) {
        ps.close();
        releaseDatabaseConnection(con, closeConnection);
        return null;
      }
      KBCustomerviewRecord record = new KBCustomerviewRecord();
      record.setCheckedby(rs.getString("CHECKED_BY"));
      record.setTermssigned(rs.getString("TERMS_SIGNED"));
      record.setMakerlastcmt(rs.getString("MAKER_LAST_CMT"));
      record.setPreflang(rs.getString("PREF_LANG"));
      record.setInstitutionid(rs.getString("INSTITUTION_ID"));
      record.setIname(rs.getString("INAME"));
      record.setBlockedflag(rs.getString("BLOCKED_FLAG"));
      record.setPassport(rs.getString("PASSPORT"));
      record.setId(rs.getString("ID"));
      record.setModifiedat(rs.getString("MODIFIED_AT"));
      record.setAuthfailtpin(rs.getString("AUTH_FAIL_TPIN"));
      record.setValacc(rs.getString("VAL_ACC"));
      record.setMadeat(rs.getString("MADE_AT"));
      record.setCheckedat(rs.getString("CHECKED_AT"));
      record.setAllowedphoneid1(rs.getString("ALLOWED_PHONE_ID1"));
      record.setAllowedphoneid2(rs.getString("ALLOWED_PHONE_ID2"));
      record.setCreatedby(rs.getString("CREATED_BY"));
      record.setRstatus(rs.getString("RSTATUS"));
      record.setPinno(rs.getString("PIN_NO"));
      record.setNationality(rs.getString("NATIONALITY"));
      record.setAdminlastcmt(rs.getString("ADMIN_LAST_CMT"));
      record.setAllowedphoneid3(rs.getString("ALLOWED_PHONE_ID3"));
      record.setCheckerlastcmt(rs.getString("CHECKER_LAST_CMT"));
      record.setNationalid(rs.getString("NATIONAL_ID"));
      record.setCif(rs.getString("CIF"));
      record.setCname(rs.getString("CNAME"));
      record.setCreatedat(rs.getString("CREATED_AT"));
      record.setAuthfailpin(rs.getString("AUTH_FAIL_PIN"));
      record.setEmail(rs.getString("EMAIL"));
      record.setReportfreq(rs.getString("REPORT_FREQ"));
      record.setStatusname(rs.getString("STATUS_NAME"));
      record.setMobile(rs.getString("MOBILE"));
      record.setAllowedphonetype3(rs.getString("ALLOWED_PHONE_TYPE3"));
      record.setIdsubmitted(rs.getString("ID_SUBMITTED"));
      record.setAllowedphonetype2(rs.getString("ALLOWED_PHONE_TYPE2"));
      record.setIdverified(rs.getString("ID_VERIFIED"));
      record.setCustcat(rs.getString("CUST_CAT"));
      record.setCustextn4(rs.getString("CUST_EXTN4"));
      record.setCustextn3(rs.getString("CUST_EXTN3"));
      record.setCurrappstatus(rs.getString("CURR_APP_STATUS"));
      record.setCustextn2(rs.getString("CUST_EXTN2"));
      record.setCustextn1(rs.getString("CUST_EXTN1"));
      record.setTpinno(rs.getString("TPIN_NO"));
      record.setAllowedphonetype1(rs.getString("ALLOWED_PHONE_TYPE1"));
      record.setCurrappstatusname(rs.getString("CURR_APP_STATUS_NAME"));
      record.setModifiedby(rs.getString("MODIFIED_BY"));
      record.setMadeby(rs.getString("MADE_BY"));
      record.setCategory(rs.getString("CATEGORY"));
      record.setUgissued(rs.getString("UG_ISSUED"));
      ps.close();
      logger.trace("loadKBCustomerviewRecord	" + record + "	");
      releaseDatabaseConnection(con, closeConnection);
      return record;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBCustomerviewRecord loadKBCustomerviewRecord(String id) throws Exception {
    return loadKBCustomerviewRecord(id, null, true);
  }

  public int insertKBCustomerviewRecord(KBCustomerviewRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query ="INSERT INTO customer_view ";
      Query +="(";
      Query +="CHECKED_BY,TERMS_SIGNED,MAKER_LAST_CMT,PREF_LANG,INSTITUTION_ID,INAME,BLOCKED_FLAG,PASSPORT,ID,MODIFIED_AT,AUTH_FAIL_TPIN,VAL_ACC,MADE_AT,CHECKED_AT,ALLOWED_PHONE_ID1,ALLOWED_PHONE_ID2,CREATED_BY,RSTATUS,PIN_NO,NATIONALITY,ADMIN_LAST_CMT,ALLOWED_PHONE_ID3,CHECKER_LAST_CMT,NATIONAL_ID,CIF,CNAME,CREATED_AT,AUTH_FAIL_PIN,EMAIL,REPORT_FREQ,STATUS_NAME,MOBILE,ALLOWED_PHONE_TYPE3,ID_SUBMITTED,ALLOWED_PHONE_TYPE2,ID_VERIFIED,CUST_CAT,CUST_EXTN4,CUST_EXTN3,CURR_APP_STATUS,CUST_EXTN2,CUST_EXTN1,TPIN_NO,ALLOWED_PHONE_TYPE1,CURR_APP_STATUS_NAME,MODIFIED_BY,MADE_BY,CATEGORY,UG_ISSUED";
      Query +=")";
      Query += " VALUES " ;
      Query +="(";
      Query +="?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?";
      Query +=")";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("insertKBCustomerviewRecords	" + closeConnection + "	" + Query);
      if (isOracleDatabase()) {
        ps = con.prepareStatement(Query,new String[]{"ID"});
      }
      else {
        ps = con.prepareStatement(Query,Statement.RETURN_GENERATED_KEYS);
      }
      setStringValue(ps, 1, record.getCheckedby());
      setStringValue(ps, 2, record.getTermssigned());
      setStringValue(ps, 3, record.getMakerlastcmt());
      setStringValue(ps, 4, record.getPreflang());
      setStringValue(ps, 5, record.getInstitutionid());
      setStringValue(ps, 6, record.getIname());
      setStringValue(ps, 7, record.getBlockedflag());
      setStringValue(ps, 8, record.getPassport());
      setStringValue(ps, 9, record.getId());
      setDateValue(ps, 10, fd.getSQLDateObject(record.getModifiedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 11, record.getAuthfailtpin());
      setStringValue(ps, 12, record.getValacc());
      setStringValue(ps, 13, record.getMadeat());
      setStringValue(ps, 14, record.getCheckedat());
      setStringValue(ps, 15, record.getAllowedphoneid1());
      setStringValue(ps, 16, record.getAllowedphoneid2());
      setStringValue(ps, 17, record.getCreatedby());
      setStringValue(ps, 18, record.getRstatus());
      setStringValue(ps, 19, record.getPinno());
      setStringValue(ps, 20, record.getNationality());
      setStringValue(ps, 21, record.getAdminlastcmt());
      setStringValue(ps, 22, record.getAllowedphoneid3());
      setStringValue(ps, 23, record.getCheckerlastcmt());
      setStringValue(ps, 24, record.getNationalid());
      setStringValue(ps, 25, record.getCif());
      setStringValue(ps, 26, record.getCname());
      setDateValue(ps, 27, fd.getSQLDateObject(record.getCreatedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 28, record.getAuthfailpin());
      setStringValue(ps, 29, record.getEmail());
      setStringValue(ps, 30, record.getReportfreq());
      setStringValue(ps, 31, record.getStatusname());
      setStringValue(ps, 32, record.getMobile());
      setStringValue(ps, 33, record.getAllowedphonetype3());
      setStringValue(ps, 34, record.getIdsubmitted());
      setStringValue(ps, 35, record.getAllowedphonetype2());
      setStringValue(ps, 36, record.getIdverified());
      setStringValue(ps, 37, record.getCustcat());
      setStringValue(ps, 38, record.getCustextn4());
      setStringValue(ps, 39, record.getCustextn3());
      setStringValue(ps, 40, record.getCurrappstatus());
      setStringValue(ps, 41, record.getCustextn2());
      setStringValue(ps, 42, record.getCustextn1());
      setStringValue(ps, 43, record.getTpinno());
      setStringValue(ps, 44, record.getAllowedphonetype1());
      setStringValue(ps, 45, record.getCurrappstatusname());
      setStringValue(ps, 46, record.getModifiedby());
      setStringValue(ps, 47, record.getMadeby());
      setStringValue(ps, 48, record.getCategory());
      setStringValue(ps, 49, record.getUgissued());
      boolean result = ps.execute();
      logger.trace("insertKBCustomerviewRecord	" + result + "	");
      int resultID = -1;
      rs = ps.getGeneratedKeys();
      if (rs.next()) {
        resultID = rs.getInt(1);
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return resultID;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public int insertKBCustomerviewRecord(KBCustomerviewRecord record) throws Exception {
    return insertKBCustomerviewRecord(record, null, true);
  }

  public boolean updateKBCustomerviewRecord(KBCustomerviewRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      KBCustomerviewRecord currentRecord = loadKBCustomerviewRecord(record.getId());
      String currentRecordContent = StringUtils.noNull(currentRecord);
      String Query = "UPDATE customer_view SET ";
      Query += "CHECKED_BY = ?,";
          Query += "TERMS_SIGNED = ?,";
          Query += "MAKER_LAST_CMT = ?,";
          Query += "PREF_LANG = ?,";
          Query += "INSTITUTION_ID = ?,";
          Query += "INAME = ?,";
          Query += "BLOCKED_FLAG = ?,";
          Query += "PASSPORT = ?,";
          Query += "MODIFIED_AT = ?,";
          Query += "AUTH_FAIL_TPIN = ?,";
          Query += "VAL_ACC = ?,";
          Query += "MADE_AT = ?,";
          Query += "CHECKED_AT = ?,";
          Query += "ALLOWED_PHONE_ID1 = ?,";
          Query += "ALLOWED_PHONE_ID2 = ?,";
          Query += "CREATED_BY = ?,";
          Query += "RSTATUS = ?,";
          Query += "PIN_NO = ?,";
          Query += "NATIONALITY = ?,";
          Query += "ADMIN_LAST_CMT = ?,";
          Query += "ALLOWED_PHONE_ID3 = ?,";
          Query += "CHECKER_LAST_CMT = ?,";
          Query += "NATIONAL_ID = ?,";
          Query += "CIF = ?,";
          Query += "CNAME = ?,";
          Query += "CREATED_AT = ?,";
          Query += "AUTH_FAIL_PIN = ?,";
          Query += "EMAIL = ?,";
          Query += "REPORT_FREQ = ?,";
          Query += "STATUS_NAME = ?,";
          Query += "MOBILE = ?,";
          Query += "ALLOWED_PHONE_TYPE3 = ?,";
          Query += "ID_SUBMITTED = ?,";
          Query += "ALLOWED_PHONE_TYPE2 = ?,";
          Query += "ID_VERIFIED = ?,";
          Query += "CUST_CAT = ?,";
          Query += "CUST_EXTN4 = ?,";
          Query += "CUST_EXTN3 = ?,";
          Query += "CURR_APP_STATUS = ?,";
          Query += "CUST_EXTN2 = ?,";
          Query += "CUST_EXTN1 = ?,";
          Query += "TPIN_NO = ?,";
          Query += "ALLOWED_PHONE_TYPE1 = ?,";
          Query += "CURR_APP_STATUS_NAME = ?,";
          Query += "MODIFIED_BY = ?,";
          Query += "MADE_BY = ?,";
          Query += "CATEGORY = ?,";
          Query += "UG_ISSUED = ?";
      Query += " WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("updateKBCustomerviewRecord	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      setStringValue(ps, 1, record.getCheckedby());
      setStringValue(ps, 2, record.getTermssigned());
      setStringValue(ps, 3, record.getMakerlastcmt());
      setStringValue(ps, 4, record.getPreflang());
      setStringValue(ps, 5, record.getInstitutionid());
      setStringValue(ps, 6, record.getIname());
      setStringValue(ps, 7, record.getBlockedflag());
      setStringValue(ps, 8, record.getPassport());
      setDateValue(ps, 9, fd.getSQLDateObject(record.getModifiedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 10, record.getAuthfailtpin());
      setStringValue(ps, 11, record.getValacc());
      setStringValue(ps, 12, record.getMadeat());
      setStringValue(ps, 13, record.getCheckedat());
      setStringValue(ps, 14, record.getAllowedphoneid1());
      setStringValue(ps, 15, record.getAllowedphoneid2());
      setStringValue(ps, 16, record.getCreatedby());
      setStringValue(ps, 17, record.getRstatus());
      setStringValue(ps, 18, record.getPinno());
      setStringValue(ps, 19, record.getNationality());
      setStringValue(ps, 20, record.getAdminlastcmt());
      setStringValue(ps, 21, record.getAllowedphoneid3());
      setStringValue(ps, 22, record.getCheckerlastcmt());
      setStringValue(ps, 23, record.getNationalid());
      setStringValue(ps, 24, record.getCif());
      setStringValue(ps, 25, record.getCname());
      setDateValue(ps, 26, fd.getSQLDateObject(record.getCreatedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 27, record.getAuthfailpin());
      setStringValue(ps, 28, record.getEmail());
      setStringValue(ps, 29, record.getReportfreq());
      setStringValue(ps, 30, record.getStatusname());
      setStringValue(ps, 31, record.getMobile());
      setStringValue(ps, 32, record.getAllowedphonetype3());
      setStringValue(ps, 33, record.getIdsubmitted());
      setStringValue(ps, 34, record.getAllowedphonetype2());
      setStringValue(ps, 35, record.getIdverified());
      setStringValue(ps, 36, record.getCustcat());
      setStringValue(ps, 37, record.getCustextn4());
      setStringValue(ps, 38, record.getCustextn3());
      setStringValue(ps, 39, record.getCurrappstatus());
      setStringValue(ps, 40, record.getCustextn2());
      setStringValue(ps, 41, record.getCustextn1());
      setStringValue(ps, 42, record.getTpinno());
      setStringValue(ps, 43, record.getAllowedphonetype1());
      setStringValue(ps, 44, record.getCurrappstatusname());
      setStringValue(ps, 45, record.getModifiedby());
      setStringValue(ps, 46, record.getMadeby());
      setStringValue(ps, 47, record.getCategory());
      setStringValue(ps, 48, record.getUgissued());
      ps.setString(49, StringUtils.noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("updateKBCustomerviewRecord	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean updateKBCustomerviewRecord(KBCustomerviewRecord record) throws Exception {
    return updateKBCustomerviewRecord(record, null, true);
  }

  public boolean deleteKBCustomerviewRecord(KBCustomerviewRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query = "DELETE FROM customer_view WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("deleteKBCustomerviewRecord	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      ps.setString(1, noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("deleteKBCustomerviewRecord	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean deleteKBCustomerviewRecord(KBCustomerviewRecord record) throws Exception {
    return deleteKBCustomerviewRecord(record, null, true);
  }

  public KBCustomerviewRecord[] searchKBCustomerviewRecords(KBCustomerviewRecord searchRecord)
      throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CHECKED_BY", formatSearchField(searchRecord.getCheckedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "TERMS_SIGNED", formatSearchField(searchRecord.getTermssigned()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MAKER_LAST_CMT", formatSearchField(searchRecord.getMakerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PREF_LANG", formatSearchField(searchRecord.getPreflang()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "INAME", formatSearchField(searchRecord.getIname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "BLOCKED_FLAG", formatSearchField(searchRecord.getBlockedflag()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PASSPORT", formatSearchField(searchRecord.getPassport()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "AUTH_FAIL_TPIN", formatSearchField(searchRecord.getAuthfailtpin()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "VAL_ACC", formatSearchField(searchRecord.getValacc()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MADE_AT", formatSearchField(searchRecord.getMadeat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHECKED_AT", formatSearchField(searchRecord.getCheckedat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ALLOWED_PHONE_ID1", formatSearchField(searchRecord.getAllowedphoneid1()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ALLOWED_PHONE_ID2", formatSearchField(searchRecord.getAllowedphoneid2()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "PIN_NO", formatSearchField(searchRecord.getPinno()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "NATIONALITY", formatSearchField(searchRecord.getNationality()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "ADMIN_LAST_CMT", formatSearchField(searchRecord.getAdminlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ALLOWED_PHONE_ID3", formatSearchField(searchRecord.getAllowedphoneid3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHECKER_LAST_CMT", formatSearchField(searchRecord.getCheckerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "NATIONAL_ID", formatSearchField(searchRecord.getNationalid()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CIF", formatSearchField(searchRecord.getCif()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CNAME", formatSearchField(searchRecord.getCname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "AUTH_FAIL_PIN", formatSearchField(searchRecord.getAuthfailpin()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EMAIL", formatSearchField(searchRecord.getEmail()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "REPORT_FREQ", formatSearchField(searchRecord.getReportfreq()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "STATUS_NAME", formatSearchField(searchRecord.getStatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MOBILE", formatSearchField(searchRecord.getMobile()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ALLOWED_PHONE_TYPE3", formatSearchField(searchRecord.getAllowedphonetype3()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID_SUBMITTED", formatSearchField(searchRecord.getIdsubmitted()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ALLOWED_PHONE_TYPE2", formatSearchField(searchRecord.getAllowedphonetype2()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID_VERIFIED", formatSearchField(searchRecord.getIdverified()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CUST_CAT", formatSearchField(searchRecord.getCustcat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CUST_EXTN4", formatSearchField(searchRecord.getCustextn4()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CUST_EXTN3", formatSearchField(searchRecord.getCustextn3()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CURR_APP_STATUS", formatSearchField(searchRecord.getCurrappstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CUST_EXTN2", formatSearchField(searchRecord.getCustextn2()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CUST_EXTN1", formatSearchField(searchRecord.getCustextn1()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "TPIN_NO", formatSearchField(searchRecord.getTpinno()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ALLOWED_PHONE_TYPE1", formatSearchField(searchRecord.getAllowedphonetype1()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CURR_APP_STATUS_NAME", formatSearchField(searchRecord.getCurrappstatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MADE_BY", formatSearchField(searchRecord.getMadeby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CATEGORY", formatSearchField(searchRecord.getCategory()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "UG_ISSUED", formatSearchField(searchRecord.getUgissued()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from customer_view " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM customer_view ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM customer_view $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBCustomerviewRecords(Query);
  }

  public KBCustomerviewRecord[] searchKBCustomerviewRecordsExactUpper(
      KBCustomerviewRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKED_BY", formatSearchField(searchRecord.getCheckedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "TERMS_SIGNED", formatSearchField(searchRecord.getTermssigned()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MAKER_LAST_CMT", formatSearchField(searchRecord.getMakerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PREF_LANG", formatSearchField(searchRecord.getPreflang()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "INAME", formatSearchField(searchRecord.getIname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "BLOCKED_FLAG", formatSearchField(searchRecord.getBlockedflag()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PASSPORT", formatSearchField(searchRecord.getPassport()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "AUTH_FAIL_TPIN", formatSearchField(searchRecord.getAuthfailtpin()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "VAL_ACC", formatSearchField(searchRecord.getValacc()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MADE_AT", formatSearchField(searchRecord.getMadeat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKED_AT", formatSearchField(searchRecord.getCheckedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ALLOWED_PHONE_ID1", formatSearchField(searchRecord.getAllowedphoneid1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ALLOWED_PHONE_ID2", formatSearchField(searchRecord.getAllowedphoneid2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PIN_NO", formatSearchField(searchRecord.getPinno()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "NATIONALITY", formatSearchField(searchRecord.getNationality()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ADMIN_LAST_CMT", formatSearchField(searchRecord.getAdminlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ALLOWED_PHONE_ID3", formatSearchField(searchRecord.getAllowedphoneid3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKER_LAST_CMT", formatSearchField(searchRecord.getCheckerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "NATIONAL_ID", formatSearchField(searchRecord.getNationalid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CIF", formatSearchField(searchRecord.getCif()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CNAME", formatSearchField(searchRecord.getCname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "AUTH_FAIL_PIN", formatSearchField(searchRecord.getAuthfailpin()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EMAIL", formatSearchField(searchRecord.getEmail()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "REPORT_FREQ", formatSearchField(searchRecord.getReportfreq()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "STATUS_NAME", formatSearchField(searchRecord.getStatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MOBILE", formatSearchField(searchRecord.getMobile()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ALLOWED_PHONE_TYPE3", formatSearchField(searchRecord.getAllowedphonetype3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID_SUBMITTED", formatSearchField(searchRecord.getIdsubmitted()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ALLOWED_PHONE_TYPE2", formatSearchField(searchRecord.getAllowedphonetype2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID_VERIFIED", formatSearchField(searchRecord.getIdverified()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CUST_CAT", formatSearchField(searchRecord.getCustcat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CUST_EXTN4", formatSearchField(searchRecord.getCustextn4()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CUST_EXTN3", formatSearchField(searchRecord.getCustextn3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CURR_APP_STATUS", formatSearchField(searchRecord.getCurrappstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CUST_EXTN2", formatSearchField(searchRecord.getCustextn2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CUST_EXTN1", formatSearchField(searchRecord.getCustextn1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "TPIN_NO", formatSearchField(searchRecord.getTpinno()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ALLOWED_PHONE_TYPE1", formatSearchField(searchRecord.getAllowedphonetype1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CURR_APP_STATUS_NAME", formatSearchField(searchRecord.getCurrappstatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MADE_BY", formatSearchField(searchRecord.getMadeby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CATEGORY", formatSearchField(searchRecord.getCategory()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "UG_ISSUED", formatSearchField(searchRecord.getUgissued()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from customer_view " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM customer_view ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM customer_view $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBCustomerviewRecords(Query);
  }

  public int loadKBCustomerviewRecordCount(KBCustomerviewRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CHECKED_BY", formatSearchField(searchRecord.getCheckedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "TERMS_SIGNED", formatSearchField(searchRecord.getTermssigned()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MAKER_LAST_CMT", formatSearchField(searchRecord.getMakerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PREF_LANG", formatSearchField(searchRecord.getPreflang()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "INAME", formatSearchField(searchRecord.getIname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "BLOCKED_FLAG", formatSearchField(searchRecord.getBlockedflag()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PASSPORT", formatSearchField(searchRecord.getPassport()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "AUTH_FAIL_TPIN", formatSearchField(searchRecord.getAuthfailtpin()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "VAL_ACC", formatSearchField(searchRecord.getValacc()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MADE_AT", formatSearchField(searchRecord.getMadeat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHECKED_AT", formatSearchField(searchRecord.getCheckedat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ALLOWED_PHONE_ID1", formatSearchField(searchRecord.getAllowedphoneid1()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ALLOWED_PHONE_ID2", formatSearchField(searchRecord.getAllowedphoneid2()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "PIN_NO", formatSearchField(searchRecord.getPinno()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "NATIONALITY", formatSearchField(searchRecord.getNationality()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "ADMIN_LAST_CMT", formatSearchField(searchRecord.getAdminlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ALLOWED_PHONE_ID3", formatSearchField(searchRecord.getAllowedphoneid3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHECKER_LAST_CMT", formatSearchField(searchRecord.getCheckerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "NATIONAL_ID", formatSearchField(searchRecord.getNationalid()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CIF", formatSearchField(searchRecord.getCif()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CNAME", formatSearchField(searchRecord.getCname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "AUTH_FAIL_PIN", formatSearchField(searchRecord.getAuthfailpin()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EMAIL", formatSearchField(searchRecord.getEmail()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "REPORT_FREQ", formatSearchField(searchRecord.getReportfreq()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "STATUS_NAME", formatSearchField(searchRecord.getStatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MOBILE", formatSearchField(searchRecord.getMobile()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ALLOWED_PHONE_TYPE3", formatSearchField(searchRecord.getAllowedphonetype3()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID_SUBMITTED", formatSearchField(searchRecord.getIdsubmitted()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ALLOWED_PHONE_TYPE2", formatSearchField(searchRecord.getAllowedphonetype2()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID_VERIFIED", formatSearchField(searchRecord.getIdverified()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CUST_CAT", formatSearchField(searchRecord.getCustcat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CUST_EXTN4", formatSearchField(searchRecord.getCustextn4()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CUST_EXTN3", formatSearchField(searchRecord.getCustextn3()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CURR_APP_STATUS", formatSearchField(searchRecord.getCurrappstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CUST_EXTN2", formatSearchField(searchRecord.getCustextn2()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CUST_EXTN1", formatSearchField(searchRecord.getCustextn1()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "TPIN_NO", formatSearchField(searchRecord.getTpinno()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ALLOWED_PHONE_TYPE1", formatSearchField(searchRecord.getAllowedphonetype1()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CURR_APP_STATUS_NAME", formatSearchField(searchRecord.getCurrappstatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MADE_BY", formatSearchField(searchRecord.getMadeby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CATEGORY", formatSearchField(searchRecord.getCategory()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "UG_ISSUED", formatSearchField(searchRecord.getUgissued()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from customer_view " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }

  public int loadKBCustomerviewRecordCountExact(KBCustomerviewRecord searchRecord) throws
      Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKED_BY", formatSearchField(searchRecord.getCheckedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "TERMS_SIGNED", formatSearchField(searchRecord.getTermssigned()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MAKER_LAST_CMT", formatSearchField(searchRecord.getMakerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PREF_LANG", formatSearchField(searchRecord.getPreflang()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "INAME", formatSearchField(searchRecord.getIname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "BLOCKED_FLAG", formatSearchField(searchRecord.getBlockedflag()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PASSPORT", formatSearchField(searchRecord.getPassport()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "AUTH_FAIL_TPIN", formatSearchField(searchRecord.getAuthfailtpin()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "VAL_ACC", formatSearchField(searchRecord.getValacc()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MADE_AT", formatSearchField(searchRecord.getMadeat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKED_AT", formatSearchField(searchRecord.getCheckedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ALLOWED_PHONE_ID1", formatSearchField(searchRecord.getAllowedphoneid1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ALLOWED_PHONE_ID2", formatSearchField(searchRecord.getAllowedphoneid2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PIN_NO", formatSearchField(searchRecord.getPinno()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "NATIONALITY", formatSearchField(searchRecord.getNationality()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ADMIN_LAST_CMT", formatSearchField(searchRecord.getAdminlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ALLOWED_PHONE_ID3", formatSearchField(searchRecord.getAllowedphoneid3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKER_LAST_CMT", formatSearchField(searchRecord.getCheckerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "NATIONAL_ID", formatSearchField(searchRecord.getNationalid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CIF", formatSearchField(searchRecord.getCif()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CNAME", formatSearchField(searchRecord.getCname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "AUTH_FAIL_PIN", formatSearchField(searchRecord.getAuthfailpin()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EMAIL", formatSearchField(searchRecord.getEmail()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "REPORT_FREQ", formatSearchField(searchRecord.getReportfreq()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "STATUS_NAME", formatSearchField(searchRecord.getStatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MOBILE", formatSearchField(searchRecord.getMobile()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ALLOWED_PHONE_TYPE3", formatSearchField(searchRecord.getAllowedphonetype3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID_SUBMITTED", formatSearchField(searchRecord.getIdsubmitted()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ALLOWED_PHONE_TYPE2", formatSearchField(searchRecord.getAllowedphonetype2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID_VERIFIED", formatSearchField(searchRecord.getIdverified()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CUST_CAT", formatSearchField(searchRecord.getCustcat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CUST_EXTN4", formatSearchField(searchRecord.getCustextn4()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CUST_EXTN3", formatSearchField(searchRecord.getCustextn3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CURR_APP_STATUS", formatSearchField(searchRecord.getCurrappstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CUST_EXTN2", formatSearchField(searchRecord.getCustextn2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CUST_EXTN1", formatSearchField(searchRecord.getCustextn1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "TPIN_NO", formatSearchField(searchRecord.getTpinno()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ALLOWED_PHONE_TYPE1", formatSearchField(searchRecord.getAllowedphonetype1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CURR_APP_STATUS_NAME", formatSearchField(searchRecord.getCurrappstatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MADE_BY", formatSearchField(searchRecord.getMadeby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CATEGORY", formatSearchField(searchRecord.getCategory()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "UG_ISSUED", formatSearchField(searchRecord.getUgissued()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from customer_view " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }
}
