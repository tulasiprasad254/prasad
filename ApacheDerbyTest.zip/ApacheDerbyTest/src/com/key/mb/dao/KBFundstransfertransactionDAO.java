// Author Tulasi Vara Prasad
package com.key.mb.dao;

import com.key.mb.common.KBDAO;
import com.key.mb.to.KBFundstransfertransactionRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class KBFundstransfertransactionDAO extends KBDAO {
  public static LogUtils logger = new LogUtils(KBFundstransfertransactionDAO.class.getName());

  public KBFundstransfertransactionRecord[] loadKBFundstransfertransactionRecords(String query,
      Connection con, boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      query = query + MAX_RECORD_LIMIT_APPENDER;
      query = updateQuery(query);
      logger.trace("loadKBFundstransfertransactionRecords	" + closeConnection + "	" + query);
      ps = con.prepareStatement(query);
      rs = ps.executeQuery();
      ArrayList recordSet = new ArrayList();
      while(rs.next()) {
        KBFundstransfertransactionRecord record = new KBFundstransfertransactionRecord();
        record.setFtresultcode(rs.getString("FTRESULTCODE"));
        record.setFtsessionid(rs.getString("FTSESSIONID"));
        record.setFtstepfailed(rs.getString("FTSTEPFAILED"));
        record.setCreatedat(rs.getString("CREATED_AT"));
        record.setBeneficiarymobile(rs.getString("BENEFICIARY_MOBILE"));
        record.setResp4(rs.getString("RESP4"));
        record.setResp2(rs.getString("RESP2"));
        record.setResp3(rs.getString("RESP3"));
        record.setResp1(rs.getString("RESP1"));
        record.setFttrantime(rs.getString("FTTRANTIME"));
        record.setFtfrom(rs.getString("FTFROM"));
        record.setId(rs.getString("ID"));
        record.setModifiedat(rs.getString("MODIFIED_AT"));
        record.setFtcif(rs.getString("FTCIF"));
        record.setFtsubcharge(rs.getString("FTSUBCHARGE"));
        record.setFtamount(rs.getString("FTAMOUNT"));
        record.setFtcharge(rs.getString("FTCHARGE"));
        record.setFtcomment(rs.getString("FTCOMMENT"));
        record.setFtrefno(rs.getString("FTREFNO"));
        record.setBeneficiarycurrency(rs.getString("BENEFICIARY_CURRENCY"));
        record.setErrmsg(rs.getString("ERRMSG"));
        record.setCreatedby(rs.getString("CREATED_BY"));
        record.setBeneficiarybranch(rs.getString("BENEFICIARY_BRANCH"));
        record.setFttype(rs.getString("FTTYPE"));
        record.setRstatus(rs.getString("RSTATUS"));
        record.setFtsource(rs.getString("FTSOURCE"));
        record.setFtresult(rs.getString("FTRESULT"));
        record.setFtphoneid(rs.getString("FTPHONEID"));
        record.setModifiedby(rs.getString("MODIFIED_BY"));
        record.setFtto(rs.getString("FTTO"));
        record.setBeneficiarybank(rs.getString("BENEFICIARY_BANK"));
        record.setFtcurrcode(rs.getString("FTCURRCODE"));
        recordSet.add(record);
      }
      logger.trace("loadKBFundstransfertransactionRecords:Records Fetched:" + recordSet.size());
      KBFundstransfertransactionRecord[] tempKBFundstransfertransactionRecords = new KBFundstransfertransactionRecord[recordSet.size()];
      for (int index = 0; index < recordSet.size(); index++) {
        tempKBFundstransfertransactionRecords[index] = (KBFundstransfertransactionRecord)(recordSet.get(index));
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return tempKBFundstransfertransactionRecords;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBFundstransfertransactionRecord[] loadKBFundstransfertransactionRecords(String query)
      throws Exception {
    return loadKBFundstransfertransactionRecords(query, null, true);
  }

  public KBFundstransfertransactionRecord loadFirstKBFundstransfertransactionRecord(String query)
      throws Exception {
    KBFundstransfertransactionRecord[] results = loadKBFundstransfertransactionRecords(query);
    if (results == null) {
      return null;
    }
    if(results.length < 1) {
      return null;
    }
    return results[0];
  }

  public KBFundstransfertransactionRecord loadKBFundstransfertransactionRecord(String id,
      Connection con, boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      String Query = "SELECT * FROM funds_transfer_transaction WHERE (ID = ?)";
      Query = updateQuery(Query);
      logger.trace("loadKBFundstransfertransactionRecords	" + closeConnection + "	" + id);
      ps = con.prepareStatement(Query);
      ps.setString(1,id);
      rs = ps.executeQuery();
      if (!rs.next()) {
        ps.close();
        releaseDatabaseConnection(con, closeConnection);
        return null;
      }
      KBFundstransfertransactionRecord record = new KBFundstransfertransactionRecord();
      record.setFtresultcode(rs.getString("FTRESULTCODE"));
      record.setFtsessionid(rs.getString("FTSESSIONID"));
      record.setFtstepfailed(rs.getString("FTSTEPFAILED"));
      record.setCreatedat(rs.getString("CREATED_AT"));
      record.setBeneficiarymobile(rs.getString("BENEFICIARY_MOBILE"));
      record.setResp4(rs.getString("RESP4"));
      record.setResp2(rs.getString("RESP2"));
      record.setResp3(rs.getString("RESP3"));
      record.setResp1(rs.getString("RESP1"));
      record.setFttrantime(rs.getString("FTTRANTIME"));
      record.setFtfrom(rs.getString("FTFROM"));
      record.setId(rs.getString("ID"));
      record.setModifiedat(rs.getString("MODIFIED_AT"));
      record.setFtcif(rs.getString("FTCIF"));
      record.setFtsubcharge(rs.getString("FTSUBCHARGE"));
      record.setFtamount(rs.getString("FTAMOUNT"));
      record.setFtcharge(rs.getString("FTCHARGE"));
      record.setFtcomment(rs.getString("FTCOMMENT"));
      record.setFtrefno(rs.getString("FTREFNO"));
      record.setBeneficiarycurrency(rs.getString("BENEFICIARY_CURRENCY"));
      record.setErrmsg(rs.getString("ERRMSG"));
      record.setCreatedby(rs.getString("CREATED_BY"));
      record.setBeneficiarybranch(rs.getString("BENEFICIARY_BRANCH"));
      record.setFttype(rs.getString("FTTYPE"));
      record.setRstatus(rs.getString("RSTATUS"));
      record.setFtsource(rs.getString("FTSOURCE"));
      record.setFtresult(rs.getString("FTRESULT"));
      record.setFtphoneid(rs.getString("FTPHONEID"));
      record.setModifiedby(rs.getString("MODIFIED_BY"));
      record.setFtto(rs.getString("FTTO"));
      record.setBeneficiarybank(rs.getString("BENEFICIARY_BANK"));
      record.setFtcurrcode(rs.getString("FTCURRCODE"));
      ps.close();
      logger.trace("loadKBFundstransfertransactionRecord	" + record + "	");
      releaseDatabaseConnection(con, closeConnection);
      return record;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBFundstransfertransactionRecord loadKBFundstransfertransactionRecord(String id) throws
      Exception {
    return loadKBFundstransfertransactionRecord(id, null, true);
  }

  public int insertKBFundstransfertransactionRecord(KBFundstransfertransactionRecord record,
      Connection con, boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query ="INSERT INTO funds_transfer_transaction ";
      Query +="(";
      Query +="FTRESULTCODE,FTSESSIONID,FTSTEPFAILED,CREATED_AT,BENEFICIARY_MOBILE,RESP4,RESP2,RESP3,RESP1,FTTRANTIME,FTFROM,ID,MODIFIED_AT,FTCIF,FTSUBCHARGE,FTAMOUNT,FTCHARGE,FTCOMMENT,FTREFNO,BENEFICIARY_CURRENCY,ERRMSG,CREATED_BY,BENEFICIARY_BRANCH,FTTYPE,RSTATUS,FTSOURCE,FTRESULT,FTPHONEID,MODIFIED_BY,FTTO,BENEFICIARY_BANK,FTCURRCODE";
      Query +=")";
      Query += " VALUES " ;
      Query +="(";
      Query +="?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?";
      Query +=")";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("insertKBFundstransfertransactionRecords	" + closeConnection + "	" + Query);
      if (isOracleDatabase()) {
        ps = con.prepareStatement(Query,new String[]{"ID"});
      }
      else {
        ps = con.prepareStatement(Query,Statement.RETURN_GENERATED_KEYS);
      }
      setStringValue(ps, 1, record.getFtresultcode());
      setStringValue(ps, 2, record.getFtsessionid());
      setStringValue(ps, 3, record.getFtstepfailed());
      setDateValue(ps, 4, fd.getSQLDateObject(record.getCreatedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 5, record.getBeneficiarymobile());
      setStringValue(ps, 6, record.getResp4());
      setStringValue(ps, 7, record.getResp2());
      setStringValue(ps, 8, record.getResp3());
      setStringValue(ps, 9, record.getResp1());
      setStringValue(ps, 10, record.getFttrantime());
      setStringValue(ps, 11, record.getFtfrom());
      setStringValue(ps, 12, record.getId());
      setDateValue(ps, 13, fd.getSQLDateObject(record.getModifiedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 14, record.getFtcif());
      setStringValue(ps, 15, record.getFtsubcharge());
      setStringValue(ps, 16, record.getFtamount());
      setStringValue(ps, 17, record.getFtcharge());
      setStringValue(ps, 18, record.getFtcomment());
      setStringValue(ps, 19, record.getFtrefno());
      setStringValue(ps, 20, record.getBeneficiarycurrency());
      setStringValue(ps, 21, record.getErrmsg());
      setStringValue(ps, 22, record.getCreatedby());
      setStringValue(ps, 23, record.getBeneficiarybranch());
      setStringValue(ps, 24, record.getFttype());
      setStringValue(ps, 25, record.getRstatus());
      setStringValue(ps, 26, record.getFtsource());
      setStringValue(ps, 27, record.getFtresult());
      setStringValue(ps, 28, record.getFtphoneid());
      setStringValue(ps, 29, record.getModifiedby());
      setStringValue(ps, 30, record.getFtto());
      setStringValue(ps, 31, record.getBeneficiarybank());
      setStringValue(ps, 32, record.getFtcurrcode());
      boolean result = ps.execute();
      logger.trace("insertKBFundstransfertransactionRecord	" + result + "	");
      int resultID = -1;
      rs = ps.getGeneratedKeys();
      if (rs.next()) {
        resultID = rs.getInt(1);
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return resultID;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public int insertKBFundstransfertransactionRecord(KBFundstransfertransactionRecord record) throws
      Exception {
    return insertKBFundstransfertransactionRecord(record, null, true);
  }

  public boolean updateKBFundstransfertransactionRecord(KBFundstransfertransactionRecord record,
      Connection con, boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      KBFundstransfertransactionRecord currentRecord = loadKBFundstransfertransactionRecord(record.getId());
      String currentRecordContent = StringUtils.noNull(currentRecord);
      String Query = "UPDATE funds_transfer_transaction SET ";
      Query += "FTRESULTCODE = ?,";
          Query += "FTSESSIONID = ?,";
          Query += "FTSTEPFAILED = ?,";
          Query += "CREATED_AT = ?,";
          Query += "BENEFICIARY_MOBILE = ?,";
          Query += "RESP4 = ?,";
          Query += "RESP2 = ?,";
          Query += "RESP3 = ?,";
          Query += "RESP1 = ?,";
          Query += "FTTRANTIME = ?,";
          Query += "FTFROM = ?,";
          Query += "MODIFIED_AT = ?,";
          Query += "FTCIF = ?,";
          Query += "FTSUBCHARGE = ?,";
          Query += "FTAMOUNT = ?,";
          Query += "FTCHARGE = ?,";
          Query += "FTCOMMENT = ?,";
          Query += "FTREFNO = ?,";
          Query += "BENEFICIARY_CURRENCY = ?,";
          Query += "ERRMSG = ?,";
          Query += "CREATED_BY = ?,";
          Query += "BENEFICIARY_BRANCH = ?,";
          Query += "FTTYPE = ?,";
          Query += "RSTATUS = ?,";
          Query += "FTSOURCE = ?,";
          Query += "FTRESULT = ?,";
          Query += "FTPHONEID = ?,";
          Query += "MODIFIED_BY = ?,";
          Query += "FTTO = ?,";
          Query += "BENEFICIARY_BANK = ?,";
          Query += "FTCURRCODE = ?";
      Query += " WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("updateKBFundstransfertransactionRecord	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      setStringValue(ps, 1, record.getFtresultcode());
      setStringValue(ps, 2, record.getFtsessionid());
      setStringValue(ps, 3, record.getFtstepfailed());
      setDateValue(ps, 4, fd.getSQLDateObject(record.getCreatedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 5, record.getBeneficiarymobile());
      setStringValue(ps, 6, record.getResp4());
      setStringValue(ps, 7, record.getResp2());
      setStringValue(ps, 8, record.getResp3());
      setStringValue(ps, 9, record.getResp1());
      setStringValue(ps, 10, record.getFttrantime());
      setStringValue(ps, 11, record.getFtfrom());
      setDateValue(ps, 12, fd.getSQLDateObject(record.getModifiedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 13, record.getFtcif());
      setStringValue(ps, 14, record.getFtsubcharge());
      setStringValue(ps, 15, record.getFtamount());
      setStringValue(ps, 16, record.getFtcharge());
      setStringValue(ps, 17, record.getFtcomment());
      setStringValue(ps, 18, record.getFtrefno());
      setStringValue(ps, 19, record.getBeneficiarycurrency());
      setStringValue(ps, 20, record.getErrmsg());
      setStringValue(ps, 21, record.getCreatedby());
      setStringValue(ps, 22, record.getBeneficiarybranch());
      setStringValue(ps, 23, record.getFttype());
      setStringValue(ps, 24, record.getRstatus());
      setStringValue(ps, 25, record.getFtsource());
      setStringValue(ps, 26, record.getFtresult());
      setStringValue(ps, 27, record.getFtphoneid());
      setStringValue(ps, 28, record.getModifiedby());
      setStringValue(ps, 29, record.getFtto());
      setStringValue(ps, 30, record.getBeneficiarybank());
      setStringValue(ps, 31, record.getFtcurrcode());
      ps.setString(32, StringUtils.noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("updateKBFundstransfertransactionRecord	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean updateKBFundstransfertransactionRecord(KBFundstransfertransactionRecord record)
      throws Exception {
    return updateKBFundstransfertransactionRecord(record, null, true);
  }

  public boolean deleteKBFundstransfertransactionRecord(KBFundstransfertransactionRecord record,
      Connection con, boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query = "DELETE FROM funds_transfer_transaction WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("deleteKBFundstransfertransactionRecord	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      ps.setString(1, noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("deleteKBFundstransfertransactionRecord	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean deleteKBFundstransfertransactionRecord(KBFundstransfertransactionRecord record)
      throws Exception {
    return deleteKBFundstransfertransactionRecord(record, null, true);
  }

  public KBFundstransfertransactionRecord[] searchKBFundstransfertransactionRecords(
      KBFundstransfertransactionRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FTRESULTCODE", formatSearchField(searchRecord.getFtresultcode()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FTSESSIONID", formatSearchField(searchRecord.getFtsessionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTSTEPFAILED", formatSearchField(searchRecord.getFtstepfailed()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "BENEFICIARY_MOBILE", formatSearchField(searchRecord.getBeneficiarymobile()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "RESP4", formatSearchField(searchRecord.getResp4()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "RESP2", formatSearchField(searchRecord.getResp2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "RESP3", formatSearchField(searchRecord.getResp3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "RESP1", formatSearchField(searchRecord.getResp1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTTRANTIME", formatSearchField(searchRecord.getFttrantime()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTFROM", formatSearchField(searchRecord.getFtfrom()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FTCIF", formatSearchField(searchRecord.getFtcif()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTSUBCHARGE", formatSearchField(searchRecord.getFtsubcharge()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTAMOUNT", formatSearchField(searchRecord.getFtamount()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTCHARGE", formatSearchField(searchRecord.getFtcharge()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTCOMMENT", formatSearchField(searchRecord.getFtcomment()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTREFNO", formatSearchField(searchRecord.getFtrefno()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "BENEFICIARY_CURRENCY", formatSearchField(searchRecord.getBeneficiarycurrency()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "ERRMSG", formatSearchField(searchRecord.getErrmsg()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "BENEFICIARY_BRANCH", formatSearchField(searchRecord.getBeneficiarybranch()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTTYPE", formatSearchField(searchRecord.getFttype()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTSOURCE", formatSearchField(searchRecord.getFtsource()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTRESULT", formatSearchField(searchRecord.getFtresult()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FTPHONEID", formatSearchField(searchRecord.getFtphoneid()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTTO", formatSearchField(searchRecord.getFtto()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "BENEFICIARY_BANK", formatSearchField(searchRecord.getBeneficiarybank()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FTCURRCODE", formatSearchField(searchRecord.getFtcurrcode()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from funds_transfer_transaction " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM funds_transfer_transaction ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM funds_transfer_transaction $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBFundstransfertransactionRecords(Query);
  }

  public KBFundstransfertransactionRecord[] searchKBFundstransfertransactionRecordsExactUpper(
      KBFundstransfertransactionRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTRESULTCODE", formatSearchField(searchRecord.getFtresultcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTSESSIONID", formatSearchField(searchRecord.getFtsessionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTSTEPFAILED", formatSearchField(searchRecord.getFtstepfailed()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "BENEFICIARY_MOBILE", formatSearchField(searchRecord.getBeneficiarymobile()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RESP4", formatSearchField(searchRecord.getResp4()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RESP2", formatSearchField(searchRecord.getResp2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RESP3", formatSearchField(searchRecord.getResp3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RESP1", formatSearchField(searchRecord.getResp1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTTRANTIME", formatSearchField(searchRecord.getFttrantime()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTFROM", formatSearchField(searchRecord.getFtfrom()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTCIF", formatSearchField(searchRecord.getFtcif()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTSUBCHARGE", formatSearchField(searchRecord.getFtsubcharge()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTAMOUNT", formatSearchField(searchRecord.getFtamount()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTCHARGE", formatSearchField(searchRecord.getFtcharge()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTCOMMENT", formatSearchField(searchRecord.getFtcomment()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTREFNO", formatSearchField(searchRecord.getFtrefno()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "BENEFICIARY_CURRENCY", formatSearchField(searchRecord.getBeneficiarycurrency()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ERRMSG", formatSearchField(searchRecord.getErrmsg()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "BENEFICIARY_BRANCH", formatSearchField(searchRecord.getBeneficiarybranch()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTTYPE", formatSearchField(searchRecord.getFttype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTSOURCE", formatSearchField(searchRecord.getFtsource()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTRESULT", formatSearchField(searchRecord.getFtresult()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTPHONEID", formatSearchField(searchRecord.getFtphoneid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTTO", formatSearchField(searchRecord.getFtto()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "BENEFICIARY_BANK", formatSearchField(searchRecord.getBeneficiarybank()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTCURRCODE", formatSearchField(searchRecord.getFtcurrcode()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from funds_transfer_transaction " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM funds_transfer_transaction ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM funds_transfer_transaction $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBFundstransfertransactionRecords(Query);
  }

  public int loadKBFundstransfertransactionRecordCount(
      KBFundstransfertransactionRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FTRESULTCODE", formatSearchField(searchRecord.getFtresultcode()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FTSESSIONID", formatSearchField(searchRecord.getFtsessionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTSTEPFAILED", formatSearchField(searchRecord.getFtstepfailed()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "BENEFICIARY_MOBILE", formatSearchField(searchRecord.getBeneficiarymobile()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "RESP4", formatSearchField(searchRecord.getResp4()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "RESP2", formatSearchField(searchRecord.getResp2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "RESP3", formatSearchField(searchRecord.getResp3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "RESP1", formatSearchField(searchRecord.getResp1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTTRANTIME", formatSearchField(searchRecord.getFttrantime()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTFROM", formatSearchField(searchRecord.getFtfrom()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FTCIF", formatSearchField(searchRecord.getFtcif()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTSUBCHARGE", formatSearchField(searchRecord.getFtsubcharge()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTAMOUNT", formatSearchField(searchRecord.getFtamount()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTCHARGE", formatSearchField(searchRecord.getFtcharge()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTCOMMENT", formatSearchField(searchRecord.getFtcomment()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTREFNO", formatSearchField(searchRecord.getFtrefno()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "BENEFICIARY_CURRENCY", formatSearchField(searchRecord.getBeneficiarycurrency()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "ERRMSG", formatSearchField(searchRecord.getErrmsg()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "BENEFICIARY_BRANCH", formatSearchField(searchRecord.getBeneficiarybranch()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTTYPE", formatSearchField(searchRecord.getFttype()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTSOURCE", formatSearchField(searchRecord.getFtsource()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTRESULT", formatSearchField(searchRecord.getFtresult()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FTPHONEID", formatSearchField(searchRecord.getFtphoneid()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTTO", formatSearchField(searchRecord.getFtto()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "BENEFICIARY_BANK", formatSearchField(searchRecord.getBeneficiarybank()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FTCURRCODE", formatSearchField(searchRecord.getFtcurrcode()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from funds_transfer_transaction " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }

  public int loadKBFundstransfertransactionRecordCountExact(
      KBFundstransfertransactionRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTRESULTCODE", formatSearchField(searchRecord.getFtresultcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTSESSIONID", formatSearchField(searchRecord.getFtsessionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTSTEPFAILED", formatSearchField(searchRecord.getFtstepfailed()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "BENEFICIARY_MOBILE", formatSearchField(searchRecord.getBeneficiarymobile()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RESP4", formatSearchField(searchRecord.getResp4()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RESP2", formatSearchField(searchRecord.getResp2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RESP3", formatSearchField(searchRecord.getResp3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RESP1", formatSearchField(searchRecord.getResp1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTTRANTIME", formatSearchField(searchRecord.getFttrantime()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTFROM", formatSearchField(searchRecord.getFtfrom()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTCIF", formatSearchField(searchRecord.getFtcif()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTSUBCHARGE", formatSearchField(searchRecord.getFtsubcharge()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTAMOUNT", formatSearchField(searchRecord.getFtamount()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTCHARGE", formatSearchField(searchRecord.getFtcharge()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTCOMMENT", formatSearchField(searchRecord.getFtcomment()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTREFNO", formatSearchField(searchRecord.getFtrefno()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "BENEFICIARY_CURRENCY", formatSearchField(searchRecord.getBeneficiarycurrency()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ERRMSG", formatSearchField(searchRecord.getErrmsg()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "BENEFICIARY_BRANCH", formatSearchField(searchRecord.getBeneficiarybranch()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTTYPE", formatSearchField(searchRecord.getFttype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTSOURCE", formatSearchField(searchRecord.getFtsource()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTRESULT", formatSearchField(searchRecord.getFtresult()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTPHONEID", formatSearchField(searchRecord.getFtphoneid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTTO", formatSearchField(searchRecord.getFtto()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "BENEFICIARY_BANK", formatSearchField(searchRecord.getBeneficiarybank()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTCURRCODE", formatSearchField(searchRecord.getFtcurrcode()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from funds_transfer_transaction " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }
}
