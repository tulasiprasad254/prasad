// Author Tulasi Vara Prasad
package com.key.mb.dao;

import com.key.mb.common.KBDAO;
import com.key.mb.to.KBFundstransfertransactionviewRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class KBFundstransfertransactionviewDAO extends KBDAO {
  public static LogUtils logger = new LogUtils(KBFundstransfertransactionviewDAO.class.getName());

  public KBFundstransfertransactionviewRecord[] loadKBFundstransfertransactionviewRecords(
      String query, Connection con, boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      query = query + MAX_RECORD_LIMIT_APPENDER;
      query = updateQuery(query);
      logger.trace("loadKBFundstransfertransactionviewRecords	" + closeConnection + "	" + query);
      ps = con.prepareStatement(query);
      rs = ps.executeQuery();
      ArrayList recordSet = new ArrayList();
      while(rs.next()) {
        KBFundstransfertransactionviewRecord record = new KBFundstransfertransactionviewRecord();
        record.setFtresultcode(rs.getString("FTRESULTCODE"));
        record.setFtsessionid(rs.getString("FTSESSIONID"));
        record.setFtstepfailed(rs.getString("FTSTEPFAILED"));
        record.setCreatedat(rs.getString("CREATED_AT"));
        record.setResp4(rs.getString("RESP4"));
        record.setResp2(rs.getString("RESP2"));
        record.setResp3(rs.getString("RESP3"));
        record.setResp1(rs.getString("RESP1"));
        record.setFttrantime(rs.getString("FTTRANTIME"));
        record.setFtfrom(rs.getString("FTFROM"));
        record.setId(rs.getString("ID"));
        record.setModifiedat(rs.getString("MODIFIED_AT"));
        record.setFtcif(rs.getString("FTCIF"));
        record.setFtsubcharge(rs.getString("FTSUBCHARGE"));
        record.setFtamount(rs.getString("FTAMOUNT"));
        record.setFtcharge(rs.getString("FTCHARGE"));
        record.setFtcomment(rs.getString("FTCOMMENT"));
        record.setFtrefno(rs.getString("FTREFNO"));
        record.setErrmsg(rs.getString("ERRMSG"));
        record.setCreatedby(rs.getString("CREATED_BY"));
        record.setFttype(rs.getString("FTTYPE"));
        record.setRstatus(rs.getString("RSTATUS"));
        record.setFtsource(rs.getString("FTSOURCE"));
        record.setFtresult(rs.getString("FTRESULT"));
        record.setFtphoneid(rs.getString("FTPHONEID"));
        record.setModifiedby(rs.getString("MODIFIED_BY"));
        record.setFtto(rs.getString("FTTO"));
        record.setResultcode(rs.getString("RESULTCODE"));
        record.setFtcurrcode(rs.getString("FTCURRCODE"));
        recordSet.add(record);
      }
      logger.trace("loadKBFundstransfertransactionviewRecords:Records Fetched:" + recordSet.size());
      KBFundstransfertransactionviewRecord[] tempKBFundstransfertransactionviewRecords = new KBFundstransfertransactionviewRecord[recordSet.size()];
      for (int index = 0; index < recordSet.size(); index++) {
        tempKBFundstransfertransactionviewRecords[index] = (KBFundstransfertransactionviewRecord)(recordSet.get(index));
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return tempKBFundstransfertransactionviewRecords;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBFundstransfertransactionviewRecord[] loadKBFundstransfertransactionviewRecords(
      String query) throws Exception {
    return loadKBFundstransfertransactionviewRecords(query, null, true);
  }

  public KBFundstransfertransactionviewRecord loadFirstKBFundstransfertransactionviewRecord(
      String query) throws Exception {
    KBFundstransfertransactionviewRecord[] results = loadKBFundstransfertransactionviewRecords(query);
    if (results == null) {
      return null;
    }
    if(results.length < 1) {
      return null;
    }
    return results[0];
  }

  public KBFundstransfertransactionviewRecord loadKBFundstransfertransactionviewRecord(String id,
      Connection con, boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      String Query = "SELECT * FROM funds_transfer_transaction_view WHERE (ID = ?)";
      Query = updateQuery(Query);
      logger.trace("loadKBFundstransfertransactionviewRecords	" + closeConnection + "	" + id);
      ps = con.prepareStatement(Query);
      ps.setString(1,id);
      rs = ps.executeQuery();
      if (!rs.next()) {
        ps.close();
        releaseDatabaseConnection(con, closeConnection);
        return null;
      }
      KBFundstransfertransactionviewRecord record = new KBFundstransfertransactionviewRecord();
      record.setFtresultcode(rs.getString("FTRESULTCODE"));
      record.setFtsessionid(rs.getString("FTSESSIONID"));
      record.setFtstepfailed(rs.getString("FTSTEPFAILED"));
      record.setCreatedat(rs.getString("CREATED_AT"));
      record.setResp4(rs.getString("RESP4"));
      record.setResp2(rs.getString("RESP2"));
      record.setResp3(rs.getString("RESP3"));
      record.setResp1(rs.getString("RESP1"));
      record.setFttrantime(rs.getString("FTTRANTIME"));
      record.setFtfrom(rs.getString("FTFROM"));
      record.setId(rs.getString("ID"));
      record.setModifiedat(rs.getString("MODIFIED_AT"));
      record.setFtcif(rs.getString("FTCIF"));
      record.setFtsubcharge(rs.getString("FTSUBCHARGE"));
      record.setFtamount(rs.getString("FTAMOUNT"));
      record.setFtcharge(rs.getString("FTCHARGE"));
      record.setFtcomment(rs.getString("FTCOMMENT"));
      record.setFtrefno(rs.getString("FTREFNO"));
      record.setErrmsg(rs.getString("ERRMSG"));
      record.setCreatedby(rs.getString("CREATED_BY"));
      record.setFttype(rs.getString("FTTYPE"));
      record.setRstatus(rs.getString("RSTATUS"));
      record.setFtsource(rs.getString("FTSOURCE"));
      record.setFtresult(rs.getString("FTRESULT"));
      record.setFtphoneid(rs.getString("FTPHONEID"));
      record.setModifiedby(rs.getString("MODIFIED_BY"));
      record.setFtto(rs.getString("FTTO"));
      record.setResultcode(rs.getString("RESULTCODE"));
      record.setFtcurrcode(rs.getString("FTCURRCODE"));
      ps.close();
      logger.trace("loadKBFundstransfertransactionviewRecord	" + record + "	");
      releaseDatabaseConnection(con, closeConnection);
      return record;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBFundstransfertransactionviewRecord loadKBFundstransfertransactionviewRecord(String id)
      throws Exception {
    return loadKBFundstransfertransactionviewRecord(id, null, true);
  }

  public int insertKBFundstransfertransactionviewRecord(KBFundstransfertransactionviewRecord record,
      Connection con, boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query ="INSERT INTO funds_transfer_transaction_view ";
      Query +="(";
      Query +="FTRESULTCODE,FTSESSIONID,FTSTEPFAILED,CREATED_AT,RESP4,RESP2,RESP3,RESP1,FTTRANTIME,FTFROM,ID,MODIFIED_AT,FTCIF,FTSUBCHARGE,FTAMOUNT,FTCHARGE,FTCOMMENT,FTREFNO,ERRMSG,CREATED_BY,FTTYPE,RSTATUS,FTSOURCE,FTRESULT,FTPHONEID,MODIFIED_BY,FTTO,RESULTCODE,FTCURRCODE";
      Query +=")";
      Query += " VALUES " ;
      Query +="(";
      Query +="?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?";
      Query +=")";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("insertKBFundstransfertransactionviewRecords	" + closeConnection + "	" + Query);
      if (isOracleDatabase()) {
        ps = con.prepareStatement(Query,new String[]{"ID"});
      }
      else {
        ps = con.prepareStatement(Query,Statement.RETURN_GENERATED_KEYS);
      }
      setStringValue(ps, 1, record.getFtresultcode());
      setStringValue(ps, 2, record.getFtsessionid());
      setStringValue(ps, 3, record.getFtstepfailed());
      setDateValue(ps, 4, fd.getSQLDateObject(record.getCreatedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 5, record.getResp4());
      setStringValue(ps, 6, record.getResp2());
      setStringValue(ps, 7, record.getResp3());
      setStringValue(ps, 8, record.getResp1());
      setStringValue(ps, 9, record.getFttrantime());
      setStringValue(ps, 10, record.getFtfrom());
      setStringValue(ps, 11, record.getId());
      setDateValue(ps, 12, fd.getSQLDateObject(record.getModifiedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 13, record.getFtcif());
      setStringValue(ps, 14, record.getFtsubcharge());
      setStringValue(ps, 15, record.getFtamount());
      setStringValue(ps, 16, record.getFtcharge());
      setStringValue(ps, 17, record.getFtcomment());
      setStringValue(ps, 18, record.getFtrefno());
      setStringValue(ps, 19, record.getErrmsg());
      setStringValue(ps, 20, record.getCreatedby());
      setStringValue(ps, 21, record.getFttype());
      setStringValue(ps, 22, record.getRstatus());
      setStringValue(ps, 23, record.getFtsource());
      setStringValue(ps, 24, record.getFtresult());
      setStringValue(ps, 25, record.getFtphoneid());
      setStringValue(ps, 26, record.getModifiedby());
      setStringValue(ps, 27, record.getFtto());
      setStringValue(ps, 28, record.getResultcode());
      setStringValue(ps, 29, record.getFtcurrcode());
      boolean result = ps.execute();
      logger.trace("insertKBFundstransfertransactionviewRecord	" + result + "	");
      int resultID = -1;
      rs = ps.getGeneratedKeys();
      if (rs.next()) {
        resultID = rs.getInt(1);
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return resultID;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public int insertKBFundstransfertransactionviewRecord(KBFundstransfertransactionviewRecord record)
      throws Exception {
    return insertKBFundstransfertransactionviewRecord(record, null, true);
  }

  public boolean updateKBFundstransfertransactionviewRecord(
      KBFundstransfertransactionviewRecord record, Connection con, boolean closeConnection) throws
      Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      KBFundstransfertransactionviewRecord currentRecord = loadKBFundstransfertransactionviewRecord(record.getId());
      String currentRecordContent = StringUtils.noNull(currentRecord);
      String Query = "UPDATE funds_transfer_transaction_view SET ";
      Query += "FTRESULTCODE = ?,";
          Query += "FTSESSIONID = ?,";
          Query += "FTSTEPFAILED = ?,";
          Query += "CREATED_AT = ?,";
          Query += "RESP4 = ?,";
          Query += "RESP2 = ?,";
          Query += "RESP3 = ?,";
          Query += "RESP1 = ?,";
          Query += "FTTRANTIME = ?,";
          Query += "FTFROM = ?,";
          Query += "MODIFIED_AT = ?,";
          Query += "FTCIF = ?,";
          Query += "FTSUBCHARGE = ?,";
          Query += "FTAMOUNT = ?,";
          Query += "FTCHARGE = ?,";
          Query += "FTCOMMENT = ?,";
          Query += "FTREFNO = ?,";
          Query += "ERRMSG = ?,";
          Query += "CREATED_BY = ?,";
          Query += "FTTYPE = ?,";
          Query += "RSTATUS = ?,";
          Query += "FTSOURCE = ?,";
          Query += "FTRESULT = ?,";
          Query += "FTPHONEID = ?,";
          Query += "MODIFIED_BY = ?,";
          Query += "FTTO = ?,";
          Query += "RESULTCODE = ?,";
          Query += "FTCURRCODE = ?";
      Query += " WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("updateKBFundstransfertransactionviewRecord	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      setStringValue(ps, 1, record.getFtresultcode());
      setStringValue(ps, 2, record.getFtsessionid());
      setStringValue(ps, 3, record.getFtstepfailed());
      setDateValue(ps, 4, fd.getSQLDateObject(record.getCreatedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 5, record.getResp4());
      setStringValue(ps, 6, record.getResp2());
      setStringValue(ps, 7, record.getResp3());
      setStringValue(ps, 8, record.getResp1());
      setStringValue(ps, 9, record.getFttrantime());
      setStringValue(ps, 10, record.getFtfrom());
      setDateValue(ps, 11, fd.getSQLDateObject(record.getModifiedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 12, record.getFtcif());
      setStringValue(ps, 13, record.getFtsubcharge());
      setStringValue(ps, 14, record.getFtamount());
      setStringValue(ps, 15, record.getFtcharge());
      setStringValue(ps, 16, record.getFtcomment());
      setStringValue(ps, 17, record.getFtrefno());
      setStringValue(ps, 18, record.getErrmsg());
      setStringValue(ps, 19, record.getCreatedby());
      setStringValue(ps, 20, record.getFttype());
      setStringValue(ps, 21, record.getRstatus());
      setStringValue(ps, 22, record.getFtsource());
      setStringValue(ps, 23, record.getFtresult());
      setStringValue(ps, 24, record.getFtphoneid());
      setStringValue(ps, 25, record.getModifiedby());
      setStringValue(ps, 26, record.getFtto());
      setStringValue(ps, 27, record.getResultcode());
      setStringValue(ps, 28, record.getFtcurrcode());
      ps.setString(29, StringUtils.noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("updateKBFundstransfertransactionviewRecord	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean updateKBFundstransfertransactionviewRecord(
      KBFundstransfertransactionviewRecord record) throws Exception {
    return updateKBFundstransfertransactionviewRecord(record, null, true);
  }

  public boolean deleteKBFundstransfertransactionviewRecord(
      KBFundstransfertransactionviewRecord record, Connection con, boolean closeConnection) throws
      Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query = "DELETE FROM funds_transfer_transaction_view WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("deleteKBFundstransfertransactionviewRecord	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      ps.setString(1, noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("deleteKBFundstransfertransactionviewRecord	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean deleteKBFundstransfertransactionviewRecord(
      KBFundstransfertransactionviewRecord record) throws Exception {
    return deleteKBFundstransfertransactionviewRecord(record, null, true);
  }

  public KBFundstransfertransactionviewRecord[] searchKBFundstransfertransactionviewRecords(
      KBFundstransfertransactionviewRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FTRESULTCODE", formatSearchField(searchRecord.getFtresultcode()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FTSESSIONID", formatSearchField(searchRecord.getFtsessionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTSTEPFAILED", formatSearchField(searchRecord.getFtstepfailed()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "RESP4", formatSearchField(searchRecord.getResp4()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "RESP2", formatSearchField(searchRecord.getResp2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "RESP3", formatSearchField(searchRecord.getResp3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "RESP1", formatSearchField(searchRecord.getResp1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTTRANTIME", formatSearchField(searchRecord.getFttrantime()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTFROM", formatSearchField(searchRecord.getFtfrom()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FTCIF", formatSearchField(searchRecord.getFtcif()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTSUBCHARGE", formatSearchField(searchRecord.getFtsubcharge()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTAMOUNT", formatSearchField(searchRecord.getFtamount()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTCHARGE", formatSearchField(searchRecord.getFtcharge()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTCOMMENT", formatSearchField(searchRecord.getFtcomment()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTREFNO", formatSearchField(searchRecord.getFtrefno()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "ERRMSG", formatSearchField(searchRecord.getErrmsg()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTTYPE", formatSearchField(searchRecord.getFttype()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTSOURCE", formatSearchField(searchRecord.getFtsource()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTRESULT", formatSearchField(searchRecord.getFtresult()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FTPHONEID", formatSearchField(searchRecord.getFtphoneid()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTTO", formatSearchField(searchRecord.getFtto()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "RESULTCODE", formatSearchField(searchRecord.getResultcode()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FTCURRCODE", formatSearchField(searchRecord.getFtcurrcode()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from funds_transfer_transaction_view " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM funds_transfer_transaction_view ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM funds_transfer_transaction_view $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBFundstransfertransactionviewRecords(Query);
  }

  public KBFundstransfertransactionviewRecord[] searchKBFundstransfertransactionviewRecordsExactUpper(
      KBFundstransfertransactionviewRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTRESULTCODE", formatSearchField(searchRecord.getFtresultcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTSESSIONID", formatSearchField(searchRecord.getFtsessionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTSTEPFAILED", formatSearchField(searchRecord.getFtstepfailed()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RESP4", formatSearchField(searchRecord.getResp4()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RESP2", formatSearchField(searchRecord.getResp2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RESP3", formatSearchField(searchRecord.getResp3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RESP1", formatSearchField(searchRecord.getResp1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTTRANTIME", formatSearchField(searchRecord.getFttrantime()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTFROM", formatSearchField(searchRecord.getFtfrom()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTCIF", formatSearchField(searchRecord.getFtcif()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTSUBCHARGE", formatSearchField(searchRecord.getFtsubcharge()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTAMOUNT", formatSearchField(searchRecord.getFtamount()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTCHARGE", formatSearchField(searchRecord.getFtcharge()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTCOMMENT", formatSearchField(searchRecord.getFtcomment()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTREFNO", formatSearchField(searchRecord.getFtrefno()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ERRMSG", formatSearchField(searchRecord.getErrmsg()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTTYPE", formatSearchField(searchRecord.getFttype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTSOURCE", formatSearchField(searchRecord.getFtsource()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTRESULT", formatSearchField(searchRecord.getFtresult()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTPHONEID", formatSearchField(searchRecord.getFtphoneid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTTO", formatSearchField(searchRecord.getFtto()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RESULTCODE", formatSearchField(searchRecord.getResultcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTCURRCODE", formatSearchField(searchRecord.getFtcurrcode()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from funds_transfer_transaction_view " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM funds_transfer_transaction_view ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM funds_transfer_transaction_view $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBFundstransfertransactionviewRecords(Query);
  }

  public int loadKBFundstransfertransactionviewRecordCount(
      KBFundstransfertransactionviewRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FTRESULTCODE", formatSearchField(searchRecord.getFtresultcode()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FTSESSIONID", formatSearchField(searchRecord.getFtsessionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTSTEPFAILED", formatSearchField(searchRecord.getFtstepfailed()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "RESP4", formatSearchField(searchRecord.getResp4()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "RESP2", formatSearchField(searchRecord.getResp2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "RESP3", formatSearchField(searchRecord.getResp3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "RESP1", formatSearchField(searchRecord.getResp1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTTRANTIME", formatSearchField(searchRecord.getFttrantime()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTFROM", formatSearchField(searchRecord.getFtfrom()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FTCIF", formatSearchField(searchRecord.getFtcif()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTSUBCHARGE", formatSearchField(searchRecord.getFtsubcharge()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTAMOUNT", formatSearchField(searchRecord.getFtamount()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTCHARGE", formatSearchField(searchRecord.getFtcharge()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTCOMMENT", formatSearchField(searchRecord.getFtcomment()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTREFNO", formatSearchField(searchRecord.getFtrefno()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "ERRMSG", formatSearchField(searchRecord.getErrmsg()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTTYPE", formatSearchField(searchRecord.getFttype()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTSOURCE", formatSearchField(searchRecord.getFtsource()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTRESULT", formatSearchField(searchRecord.getFtresult()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FTPHONEID", formatSearchField(searchRecord.getFtphoneid()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTTO", formatSearchField(searchRecord.getFtto()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "RESULTCODE", formatSearchField(searchRecord.getResultcode()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FTCURRCODE", formatSearchField(searchRecord.getFtcurrcode()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from funds_transfer_transaction_view " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }

  public int loadKBFundstransfertransactionviewRecordCountExact(
      KBFundstransfertransactionviewRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTRESULTCODE", formatSearchField(searchRecord.getFtresultcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTSESSIONID", formatSearchField(searchRecord.getFtsessionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTSTEPFAILED", formatSearchField(searchRecord.getFtstepfailed()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RESP4", formatSearchField(searchRecord.getResp4()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RESP2", formatSearchField(searchRecord.getResp2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RESP3", formatSearchField(searchRecord.getResp3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RESP1", formatSearchField(searchRecord.getResp1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTTRANTIME", formatSearchField(searchRecord.getFttrantime()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTFROM", formatSearchField(searchRecord.getFtfrom()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTCIF", formatSearchField(searchRecord.getFtcif()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTSUBCHARGE", formatSearchField(searchRecord.getFtsubcharge()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTAMOUNT", formatSearchField(searchRecord.getFtamount()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTCHARGE", formatSearchField(searchRecord.getFtcharge()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTCOMMENT", formatSearchField(searchRecord.getFtcomment()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTREFNO", formatSearchField(searchRecord.getFtrefno()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ERRMSG", formatSearchField(searchRecord.getErrmsg()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTTYPE", formatSearchField(searchRecord.getFttype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTSOURCE", formatSearchField(searchRecord.getFtsource()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTRESULT", formatSearchField(searchRecord.getFtresult()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTPHONEID", formatSearchField(searchRecord.getFtphoneid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTTO", formatSearchField(searchRecord.getFtto()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RESULTCODE", formatSearchField(searchRecord.getResultcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTCURRCODE", formatSearchField(searchRecord.getFtcurrcode()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from funds_transfer_transaction_view " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }
}
