// Author Tulasi Vara Prasad
package com.key.mb.dao;

import com.key.mb.common.KBDAO;
import com.key.mb.to.KBMobilemenumapviewRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class KBMobilemenumapviewDAO extends KBDAO {
  public static LogUtils logger = new LogUtils(KBMobilemenumapviewDAO.class.getName());

  public KBMobilemenumapviewRecord[] loadKBMobilemenumapviewRecords(String query, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      query = query + MAX_RECORD_LIMIT_APPENDER;
      query = updateQuery(query);
      logger.trace("loadKBMobilemenumapviewRecords	" + closeConnection + "	" + query);
      ps = con.prepareStatement(query);
      rs = ps.executeQuery();
      ArrayList recordSet = new ArrayList();
      while(rs.next()) {
        KBMobilemenumapviewRecord record = new KBMobilemenumapviewRecord();
        record.setFtext(rs.getString("FTEXT"));
        record.setFfldtype(rs.getString("FFLDTYPE"));
        record.setFseq(rs.getString("FSEQ"));
        record.setCreatedat(rs.getString("CREATED_AT"));
        record.setActiveflag(rs.getString("ACTIVE_FLAG"));
        record.setFsesscont(rs.getString("FSESSCONT"));
        record.setFfldcode(rs.getString("FFLDCODE"));
        record.setLangcode(rs.getString("LANGCODE"));
        record.setActionid(rs.getString("ACTION_ID"));
        record.setServiceid(rs.getString("SERVICE_ID"));
        record.setId(rs.getString("ID"));
        record.setNewsess(rs.getString("NEWSESS"));
        record.setModifiedat(rs.getString("MODIFIED_AT"));
        record.setContentlength(rs.getString("CONTENT_LENGTH"));
        record.setMenutype(rs.getString("MENU_TYPE"));
        record.setStatusname(rs.getString("STATUS_NAME"));
        record.setOverridecode(rs.getString("OVERRIDE_CODE"));
        record.setFconttype(rs.getString("FCONTTYPE"));
        record.setFwidth(rs.getString("FWIDTH"));
        record.setCreatedby(rs.getString("CREATED_BY"));
        record.setRstatus(rs.getString("RSTATUS"));
        record.setParentid(rs.getString("PARENT_ID"));
        record.setFfldlen(rs.getString("FFLDLEN"));
        record.setModifiedby(rs.getString("MODIFIED_BY"));
        record.setFheight(rs.getString("FHEIGHT"));
        record.setScreenid(rs.getString("SCREEN_ID"));
        recordSet.add(record);
      }
      logger.trace("loadKBMobilemenumapviewRecords:Records Fetched:" + recordSet.size());
      KBMobilemenumapviewRecord[] tempKBMobilemenumapviewRecords = new KBMobilemenumapviewRecord[recordSet.size()];
      for (int index = 0; index < recordSet.size(); index++) {
        tempKBMobilemenumapviewRecords[index] = (KBMobilemenumapviewRecord)(recordSet.get(index));
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return tempKBMobilemenumapviewRecords;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBMobilemenumapviewRecord[] loadKBMobilemenumapviewRecords(String query) throws Exception {
    return loadKBMobilemenumapviewRecords(query, null, true);
  }

  public KBMobilemenumapviewRecord loadFirstKBMobilemenumapviewRecord(String query) throws
      Exception {
    KBMobilemenumapviewRecord[] results = loadKBMobilemenumapviewRecords(query);
    if (results == null) {
      return null;
    }
    if(results.length < 1) {
      return null;
    }
    return results[0];
  }

  public KBMobilemenumapviewRecord loadKBMobilemenumapviewRecord(String id, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      String Query = "SELECT * FROM mobile_menu_map_view WHERE (ID = ?)";
      Query = updateQuery(Query);
      logger.trace("loadKBMobilemenumapviewRecords	" + closeConnection + "	" + id);
      ps = con.prepareStatement(Query);
      ps.setString(1,id);
      rs = ps.executeQuery();
      if (!rs.next()) {
        ps.close();
        releaseDatabaseConnection(con, closeConnection);
        return null;
      }
      KBMobilemenumapviewRecord record = new KBMobilemenumapviewRecord();
      record.setFtext(rs.getString("FTEXT"));
      record.setFfldtype(rs.getString("FFLDTYPE"));
      record.setFseq(rs.getString("FSEQ"));
      record.setCreatedat(rs.getString("CREATED_AT"));
      record.setActiveflag(rs.getString("ACTIVE_FLAG"));
      record.setFsesscont(rs.getString("FSESSCONT"));
      record.setFfldcode(rs.getString("FFLDCODE"));
      record.setLangcode(rs.getString("LANGCODE"));
      record.setActionid(rs.getString("ACTION_ID"));
      record.setServiceid(rs.getString("SERVICE_ID"));
      record.setId(rs.getString("ID"));
      record.setNewsess(rs.getString("NEWSESS"));
      record.setModifiedat(rs.getString("MODIFIED_AT"));
      record.setContentlength(rs.getString("CONTENT_LENGTH"));
      record.setMenutype(rs.getString("MENU_TYPE"));
      record.setStatusname(rs.getString("STATUS_NAME"));
      record.setOverridecode(rs.getString("OVERRIDE_CODE"));
      record.setFconttype(rs.getString("FCONTTYPE"));
      record.setFwidth(rs.getString("FWIDTH"));
      record.setCreatedby(rs.getString("CREATED_BY"));
      record.setRstatus(rs.getString("RSTATUS"));
      record.setParentid(rs.getString("PARENT_ID"));
      record.setFfldlen(rs.getString("FFLDLEN"));
      record.setModifiedby(rs.getString("MODIFIED_BY"));
      record.setFheight(rs.getString("FHEIGHT"));
      record.setScreenid(rs.getString("SCREEN_ID"));
      ps.close();
      logger.trace("loadKBMobilemenumapviewRecord	" + record + "	");
      releaseDatabaseConnection(con, closeConnection);
      return record;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBMobilemenumapviewRecord loadKBMobilemenumapviewRecord(String id) throws Exception {
    return loadKBMobilemenumapviewRecord(id, null, true);
  }

  public int insertKBMobilemenumapviewRecord(KBMobilemenumapviewRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query ="INSERT INTO mobile_menu_map_view ";
      Query +="(";
      Query +="FTEXT,FFLDTYPE,FSEQ,CREATED_AT,ACTIVE_FLAG,FSESSCONT,FFLDCODE,LANGCODE,ACTION_ID,SERVICE_ID,ID,NEWSESS,MODIFIED_AT,CONTENT_LENGTH,MENU_TYPE,STATUS_NAME,OVERRIDE_CODE,FCONTTYPE,FWIDTH,CREATED_BY,RSTATUS,PARENT_ID,FFLDLEN,MODIFIED_BY,FHEIGHT,SCREEN_ID";
      Query +=")";
      Query += " VALUES " ;
      Query +="(";
      Query +="?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?";
      Query +=")";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("insertKBMobilemenumapviewRecords	" + closeConnection + "	" + Query);
      if (isOracleDatabase()) {
        ps = con.prepareStatement(Query,new String[]{"ID"});
      }
      else {
        ps = con.prepareStatement(Query,Statement.RETURN_GENERATED_KEYS);
      }
      setStringValue(ps, 1, record.getFtext());
      setStringValue(ps, 2, record.getFfldtype());
      setStringValue(ps, 3, record.getFseq());
      setDateValue(ps, 4, fd.getSQLDateObject(record.getCreatedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 5, record.getActiveflag());
      setStringValue(ps, 6, record.getFsesscont());
      setStringValue(ps, 7, record.getFfldcode());
      setStringValue(ps, 8, record.getLangcode());
      setStringValue(ps, 9, record.getActionid());
      setStringValue(ps, 10, record.getServiceid());
      setStringValue(ps, 11, record.getId());
      setStringValue(ps, 12, record.getNewsess());
      setDateValue(ps, 13, fd.getSQLDateObject(record.getModifiedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 14, record.getContentlength());
      setStringValue(ps, 15, record.getMenutype());
      setStringValue(ps, 16, record.getStatusname());
      setStringValue(ps, 17, record.getOverridecode());
      setStringValue(ps, 18, record.getFconttype());
      setStringValue(ps, 19, record.getFwidth());
      setStringValue(ps, 20, record.getCreatedby());
      setStringValue(ps, 21, record.getRstatus());
      setStringValue(ps, 22, record.getParentid());
      setStringValue(ps, 23, record.getFfldlen());
      setStringValue(ps, 24, record.getModifiedby());
      setStringValue(ps, 25, record.getFheight());
      setStringValue(ps, 26, record.getScreenid());
      boolean result = ps.execute();
      logger.trace("insertKBMobilemenumapviewRecord	" + result + "	");
      int resultID = -1;
      rs = ps.getGeneratedKeys();
      if (rs.next()) {
        resultID = rs.getInt(1);
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return resultID;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public int insertKBMobilemenumapviewRecord(KBMobilemenumapviewRecord record) throws Exception {
    return insertKBMobilemenumapviewRecord(record, null, true);
  }

  public boolean updateKBMobilemenumapviewRecord(KBMobilemenumapviewRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      KBMobilemenumapviewRecord currentRecord = loadKBMobilemenumapviewRecord(record.getId());
      String currentRecordContent = StringUtils.noNull(currentRecord);
      String Query = "UPDATE mobile_menu_map_view SET ";
      Query += "FTEXT = ?,";
          Query += "FFLDTYPE = ?,";
          Query += "FSEQ = ?,";
          Query += "CREATED_AT = ?,";
          Query += "ACTIVE_FLAG = ?,";
          Query += "FSESSCONT = ?,";
          Query += "FFLDCODE = ?,";
          Query += "LANGCODE = ?,";
          Query += "ACTION_ID = ?,";
          Query += "SERVICE_ID = ?,";
          Query += "NEWSESS = ?,";
          Query += "MODIFIED_AT = ?,";
          Query += "CONTENT_LENGTH = ?,";
          Query += "MENU_TYPE = ?,";
          Query += "STATUS_NAME = ?,";
          Query += "OVERRIDE_CODE = ?,";
          Query += "FCONTTYPE = ?,";
          Query += "FWIDTH = ?,";
          Query += "CREATED_BY = ?,";
          Query += "RSTATUS = ?,";
          Query += "PARENT_ID = ?,";
          Query += "FFLDLEN = ?,";
          Query += "MODIFIED_BY = ?,";
          Query += "FHEIGHT = ?,";
          Query += "SCREEN_ID = ?";
      Query += " WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("updateKBMobilemenumapviewRecord	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      setStringValue(ps, 1, record.getFtext());
      setStringValue(ps, 2, record.getFfldtype());
      setStringValue(ps, 3, record.getFseq());
      setDateValue(ps, 4, fd.getSQLDateObject(record.getCreatedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 5, record.getActiveflag());
      setStringValue(ps, 6, record.getFsesscont());
      setStringValue(ps, 7, record.getFfldcode());
      setStringValue(ps, 8, record.getLangcode());
      setStringValue(ps, 9, record.getActionid());
      setStringValue(ps, 10, record.getServiceid());
      setStringValue(ps, 11, record.getNewsess());
      setDateValue(ps, 12, fd.getSQLDateObject(record.getModifiedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 13, record.getContentlength());
      setStringValue(ps, 14, record.getMenutype());
      setStringValue(ps, 15, record.getStatusname());
      setStringValue(ps, 16, record.getOverridecode());
      setStringValue(ps, 17, record.getFconttype());
      setStringValue(ps, 18, record.getFwidth());
      setStringValue(ps, 19, record.getCreatedby());
      setStringValue(ps, 20, record.getRstatus());
      setStringValue(ps, 21, record.getParentid());
      setStringValue(ps, 22, record.getFfldlen());
      setStringValue(ps, 23, record.getModifiedby());
      setStringValue(ps, 24, record.getFheight());
      setStringValue(ps, 25, record.getScreenid());
      ps.setString(26, StringUtils.noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("updateKBMobilemenumapviewRecord	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean updateKBMobilemenumapviewRecord(KBMobilemenumapviewRecord record) throws
      Exception {
    return updateKBMobilemenumapviewRecord(record, null, true);
  }

  public boolean deleteKBMobilemenumapviewRecord(KBMobilemenumapviewRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query = "DELETE FROM mobile_menu_map_view WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("deleteKBMobilemenumapviewRecord	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      ps.setString(1, noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("deleteKBMobilemenumapviewRecord	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean deleteKBMobilemenumapviewRecord(KBMobilemenumapviewRecord record) throws
      Exception {
    return deleteKBMobilemenumapviewRecord(record, null, true);
  }

  public KBMobilemenumapviewRecord[] searchKBMobilemenumapviewRecords(
      KBMobilemenumapviewRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTEXT", formatSearchField(searchRecord.getFtext()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FFLDTYPE", formatSearchField(searchRecord.getFfldtype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FSEQ", formatSearchField(searchRecord.getFseq()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "ACTIVE_FLAG", formatSearchField(searchRecord.getActiveflag()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FSESSCONT", formatSearchField(searchRecord.getFsesscont()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FFLDCODE", formatSearchField(searchRecord.getFfldcode()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "LANGCODE", formatSearchField(searchRecord.getLangcode()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ACTION_ID", formatSearchField(searchRecord.getActionid()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "SERVICE_ID", formatSearchField(searchRecord.getServiceid()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "NEWSESS", formatSearchField(searchRecord.getNewsess()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CONTENT_LENGTH", formatSearchField(searchRecord.getContentlength()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MENU_TYPE", formatSearchField(searchRecord.getMenutype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "STATUS_NAME", formatSearchField(searchRecord.getStatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "OVERRIDE_CODE", formatSearchField(searchRecord.getOverridecode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FCONTTYPE", formatSearchField(searchRecord.getFconttype()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FWIDTH", formatSearchField(searchRecord.getFwidth()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "PARENT_ID", formatSearchField(searchRecord.getParentid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FFLDLEN", formatSearchField(searchRecord.getFfldlen()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FHEIGHT", formatSearchField(searchRecord.getFheight()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "SCREEN_ID", formatSearchField(searchRecord.getScreenid()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from mobile_menu_map_view " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM mobile_menu_map_view ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM mobile_menu_map_view $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBMobilemenumapviewRecords(Query);
  }

  public KBMobilemenumapviewRecord[] searchKBMobilemenumapviewRecordsExactUpper(
      KBMobilemenumapviewRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTEXT", formatSearchField(searchRecord.getFtext()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FFLDTYPE", formatSearchField(searchRecord.getFfldtype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FSEQ", formatSearchField(searchRecord.getFseq()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ACTIVE_FLAG", formatSearchField(searchRecord.getActiveflag()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FSESSCONT", formatSearchField(searchRecord.getFsesscont()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FFLDCODE", formatSearchField(searchRecord.getFfldcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LANGCODE", formatSearchField(searchRecord.getLangcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ACTION_ID", formatSearchField(searchRecord.getActionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "SERVICE_ID", formatSearchField(searchRecord.getServiceid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "NEWSESS", formatSearchField(searchRecord.getNewsess()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CONTENT_LENGTH", formatSearchField(searchRecord.getContentlength()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MENU_TYPE", formatSearchField(searchRecord.getMenutype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "STATUS_NAME", formatSearchField(searchRecord.getStatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "OVERRIDE_CODE", formatSearchField(searchRecord.getOverridecode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FCONTTYPE", formatSearchField(searchRecord.getFconttype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FWIDTH", formatSearchField(searchRecord.getFwidth()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PARENT_ID", formatSearchField(searchRecord.getParentid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FFLDLEN", formatSearchField(searchRecord.getFfldlen()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FHEIGHT", formatSearchField(searchRecord.getFheight()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "SCREEN_ID", formatSearchField(searchRecord.getScreenid()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from mobile_menu_map_view " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM mobile_menu_map_view ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM mobile_menu_map_view $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBMobilemenumapviewRecords(Query);
  }

  public int loadKBMobilemenumapviewRecordCount(KBMobilemenumapviewRecord searchRecord) throws
      Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTEXT", formatSearchField(searchRecord.getFtext()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FFLDTYPE", formatSearchField(searchRecord.getFfldtype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FSEQ", formatSearchField(searchRecord.getFseq()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "ACTIVE_FLAG", formatSearchField(searchRecord.getActiveflag()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FSESSCONT", formatSearchField(searchRecord.getFsesscont()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FFLDCODE", formatSearchField(searchRecord.getFfldcode()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "LANGCODE", formatSearchField(searchRecord.getLangcode()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ACTION_ID", formatSearchField(searchRecord.getActionid()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "SERVICE_ID", formatSearchField(searchRecord.getServiceid()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "NEWSESS", formatSearchField(searchRecord.getNewsess()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CONTENT_LENGTH", formatSearchField(searchRecord.getContentlength()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MENU_TYPE", formatSearchField(searchRecord.getMenutype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "STATUS_NAME", formatSearchField(searchRecord.getStatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "OVERRIDE_CODE", formatSearchField(searchRecord.getOverridecode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FCONTTYPE", formatSearchField(searchRecord.getFconttype()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FWIDTH", formatSearchField(searchRecord.getFwidth()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "PARENT_ID", formatSearchField(searchRecord.getParentid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FFLDLEN", formatSearchField(searchRecord.getFfldlen()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FHEIGHT", formatSearchField(searchRecord.getFheight()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "SCREEN_ID", formatSearchField(searchRecord.getScreenid()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from mobile_menu_map_view " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }

  public int loadKBMobilemenumapviewRecordCountExact(KBMobilemenumapviewRecord searchRecord) throws
      Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTEXT", formatSearchField(searchRecord.getFtext()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FFLDTYPE", formatSearchField(searchRecord.getFfldtype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FSEQ", formatSearchField(searchRecord.getFseq()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ACTIVE_FLAG", formatSearchField(searchRecord.getActiveflag()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FSESSCONT", formatSearchField(searchRecord.getFsesscont()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FFLDCODE", formatSearchField(searchRecord.getFfldcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LANGCODE", formatSearchField(searchRecord.getLangcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ACTION_ID", formatSearchField(searchRecord.getActionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "SERVICE_ID", formatSearchField(searchRecord.getServiceid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "NEWSESS", formatSearchField(searchRecord.getNewsess()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CONTENT_LENGTH", formatSearchField(searchRecord.getContentlength()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MENU_TYPE", formatSearchField(searchRecord.getMenutype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "STATUS_NAME", formatSearchField(searchRecord.getStatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "OVERRIDE_CODE", formatSearchField(searchRecord.getOverridecode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FCONTTYPE", formatSearchField(searchRecord.getFconttype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FWIDTH", formatSearchField(searchRecord.getFwidth()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PARENT_ID", formatSearchField(searchRecord.getParentid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FFLDLEN", formatSearchField(searchRecord.getFfldlen()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FHEIGHT", formatSearchField(searchRecord.getFheight()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "SCREEN_ID", formatSearchField(searchRecord.getScreenid()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from mobile_menu_map_view " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }
}
