// Author Tulasi Vara Prasad
package com.key.mb.dao;

import com.key.mb.common.KBDAO;
import com.key.mb.to.KBMobilejsonresponseRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class KBMobilejsonresponseDAO extends KBDAO {
  public static LogUtils logger = new LogUtils(KBMobilejsonresponseDAO.class.getName());

  public KBMobilejsonresponseRecord[] loadKBMobilejsonresponseRecords(String query, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      query = query + MAX_RECORD_LIMIT_APPENDER;
      query = updateQuery(query);
      logger.trace("loadKBMobilejsonresponseRecords	" + closeConnection + "	" + query);
      ps = con.prepareStatement(query);
      rs = ps.executeQuery();
      ArrayList recordSet = new ArrayList();
      while(rs.next()) {
        KBMobilejsonresponseRecord record = new KBMobilejsonresponseRecord();
        record.setRstatus(rs.getString("RSTATUS"));
        record.setControllist(rs.getString("CONTROLLIST"));
        record.setModifiedby(rs.getString("MODIFIED_BY"));
        record.setCreatedat(rs.getString("CREATED_AT"));
        record.setId(rs.getString("ID"));
        record.setSessionid(rs.getString("SESSIONID"));
        record.setModifiedat(rs.getString("MODIFIED_AT"));
        record.setCreatedby(rs.getString("CREATED_BY"));
        record.setRequestid(rs.getString("REQUEST_ID"));
        record.setDirection(rs.getString("DIRECTION"));
        recordSet.add(record);
      }
      logger.trace("loadKBMobilejsonresponseRecords:Records Fetched:" + recordSet.size());
      KBMobilejsonresponseRecord[] tempKBMobilejsonresponseRecords = new KBMobilejsonresponseRecord[recordSet.size()];
      for (int index = 0; index < recordSet.size(); index++) {
        tempKBMobilejsonresponseRecords[index] = (KBMobilejsonresponseRecord)(recordSet.get(index));
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return tempKBMobilejsonresponseRecords;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBMobilejsonresponseRecord[] loadKBMobilejsonresponseRecords(String query) throws
      Exception {
    return loadKBMobilejsonresponseRecords(query, null, true);
  }

  public KBMobilejsonresponseRecord loadFirstKBMobilejsonresponseRecord(String query) throws
      Exception {
    KBMobilejsonresponseRecord[] results = loadKBMobilejsonresponseRecords(query);
    if (results == null) {
      return null;
    }
    if(results.length < 1) {
      return null;
    }
    return results[0];
  }

  public KBMobilejsonresponseRecord loadKBMobilejsonresponseRecord(String id, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      String Query = "SELECT * FROM mobilejsonresponse WHERE (ID = ?)";
      Query = updateQuery(Query);
      logger.trace("loadKBMobilejsonresponseRecords	" + closeConnection + "	" + id);
      ps = con.prepareStatement(Query);
      ps.setString(1,id);
      rs = ps.executeQuery();
      if (!rs.next()) {
        ps.close();
        releaseDatabaseConnection(con, closeConnection);
        return null;
      }
      KBMobilejsonresponseRecord record = new KBMobilejsonresponseRecord();
      record.setRstatus(rs.getString("RSTATUS"));
      record.setControllist(rs.getString("CONTROLLIST"));
      record.setModifiedby(rs.getString("MODIFIED_BY"));
      record.setCreatedat(rs.getString("CREATED_AT"));
      record.setId(rs.getString("ID"));
      record.setSessionid(rs.getString("SESSIONID"));
      record.setModifiedat(rs.getString("MODIFIED_AT"));
      record.setCreatedby(rs.getString("CREATED_BY"));
      record.setRequestid(rs.getString("REQUEST_ID"));
      record.setDirection(rs.getString("DIRECTION"));
      ps.close();
      logger.trace("loadKBMobilejsonresponseRecord	" + record + "	");
      releaseDatabaseConnection(con, closeConnection);
      return record;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBMobilejsonresponseRecord loadKBMobilejsonresponseRecord(String id) throws Exception {
    return loadKBMobilejsonresponseRecord(id, null, true);
  }

  public int insertKBMobilejsonresponseRecord(KBMobilejsonresponseRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query ="INSERT INTO mobilejsonresponse ";
      Query +="(";
      Query +="RSTATUS,CONTROLLIST,MODIFIED_BY,CREATED_AT,ID,SESSIONID,MODIFIED_AT,CREATED_BY,REQUEST_ID,DIRECTION";
      Query +=")";
      Query += " VALUES " ;
      Query +="(";
      Query +="?,?,?,?,?,?,?,?,?,?";
      Query +=")";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("insertKBMobilejsonresponseRecords	" + closeConnection + "	" + Query);
      if (isOracleDatabase()) {
        ps = con.prepareStatement(Query,new String[]{"ID"});
      }
      else {
        ps = con.prepareStatement(Query,Statement.RETURN_GENERATED_KEYS);
      }
      setStringValue(ps, 1, record.getRstatus());
      setStringValue(ps, 2, record.getControllist());
      setStringValue(ps, 3, record.getModifiedby());
      setDateValue(ps, 4, fd.getSQLDateObject(record.getCreatedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 5, record.getId());
      setStringValue(ps, 6, record.getSessionid());
      setDateValue(ps, 7, fd.getSQLDateObject(record.getModifiedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 8, record.getCreatedby());
      setStringValue(ps, 9, record.getRequestid());
      setStringValue(ps, 10, record.getDirection());
      boolean result = ps.execute();
      logger.trace("insertKBMobilejsonresponseRecord	" + result + "	");
      int resultID = -1;
      rs = ps.getGeneratedKeys();
      if (rs.next()) {
        resultID = rs.getInt(1);
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return resultID;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public int insertKBMobilejsonresponseRecord(KBMobilejsonresponseRecord record) throws Exception {
    return insertKBMobilejsonresponseRecord(record, null, true);
  }

  public boolean updateKBMobilejsonresponseRecord(KBMobilejsonresponseRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      KBMobilejsonresponseRecord currentRecord = loadKBMobilejsonresponseRecord(record.getId());
      String currentRecordContent = StringUtils.noNull(currentRecord);
      String Query = "UPDATE mobilejsonresponse SET ";
      Query += "RSTATUS = ?,";
          Query += "CONTROLLIST = ?,";
          Query += "MODIFIED_BY = ?,";
          Query += "CREATED_AT = ?,";
          Query += "SESSIONID = ?,";
          Query += "MODIFIED_AT = ?,";
          Query += "CREATED_BY = ?,";
          Query += "REQUEST_ID = ?,";
          Query += "DIRECTION = ?";
      Query += " WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("updateKBMobilejsonresponseRecord	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      setStringValue(ps, 1, record.getRstatus());
      setStringValue(ps, 2, record.getControllist());
      setStringValue(ps, 3, record.getModifiedby());
      setDateValue(ps, 4, fd.getSQLDateObject(record.getCreatedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 5, record.getSessionid());
      setDateValue(ps, 6, fd.getSQLDateObject(record.getModifiedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 7, record.getCreatedby());
      setStringValue(ps, 8, record.getRequestid());
      setStringValue(ps, 9, record.getDirection());
      ps.setString(10, StringUtils.noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("updateKBMobilejsonresponseRecord	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean updateKBMobilejsonresponseRecord(KBMobilejsonresponseRecord record) throws
      Exception {
    return updateKBMobilejsonresponseRecord(record, null, true);
  }

  public boolean deleteKBMobilejsonresponseRecord(KBMobilejsonresponseRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query = "DELETE FROM mobilejsonresponse WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("deleteKBMobilejsonresponseRecord	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      ps.setString(1, noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("deleteKBMobilejsonresponseRecord	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean deleteKBMobilejsonresponseRecord(KBMobilejsonresponseRecord record) throws
      Exception {
    return deleteKBMobilejsonresponseRecord(record, null, true);
  }

  public KBMobilejsonresponseRecord[] searchKBMobilejsonresponseRecords(
      KBMobilejsonresponseRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CONTROLLIST", formatSearchField(searchRecord.getControllist()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "SESSIONID", formatSearchField(searchRecord.getSessionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "REQUEST_ID", formatSearchField(searchRecord.getRequestid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "DIRECTION", formatSearchField(searchRecord.getDirection()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from mobilejsonresponse " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM mobilejsonresponse ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM mobilejsonresponse $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBMobilejsonresponseRecords(Query);
  }

  public KBMobilejsonresponseRecord[] searchKBMobilejsonresponseRecordsExactUpper(
      KBMobilejsonresponseRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CONTROLLIST", formatSearchField(searchRecord.getControllist()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "SESSIONID", formatSearchField(searchRecord.getSessionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "REQUEST_ID", formatSearchField(searchRecord.getRequestid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "DIRECTION", formatSearchField(searchRecord.getDirection()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from mobilejsonresponse " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM mobilejsonresponse ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM mobilejsonresponse $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBMobilejsonresponseRecords(Query);
  }

  public int loadKBMobilejsonresponseRecordCount(KBMobilejsonresponseRecord searchRecord) throws
      Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CONTROLLIST", formatSearchField(searchRecord.getControllist()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "SESSIONID", formatSearchField(searchRecord.getSessionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "REQUEST_ID", formatSearchField(searchRecord.getRequestid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "DIRECTION", formatSearchField(searchRecord.getDirection()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from mobilejsonresponse " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }

  public int loadKBMobilejsonresponseRecordCountExact(KBMobilejsonresponseRecord searchRecord)
      throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CONTROLLIST", formatSearchField(searchRecord.getControllist()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "SESSIONID", formatSearchField(searchRecord.getSessionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "REQUEST_ID", formatSearchField(searchRecord.getRequestid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "DIRECTION", formatSearchField(searchRecord.getDirection()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from mobilejsonresponse " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }
}
