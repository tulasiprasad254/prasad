// Author Tulasi Vara Prasad
package com.key.mb.dao;

import com.key.mb.common.KBDAO;
import com.key.mb.to.KBControllermapRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class KBControllermapDAO extends KBDAO {
  public static LogUtils logger = new LogUtils(KBControllermapDAO.class.getName());

  public KBControllermapRecord[] loadKBControllermapRecords(String query, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      query = query + MAX_RECORD_LIMIT_APPENDER;
      query = updateQuery(query);
      logger.trace("loadKBControllermapRecords	" + closeConnection + "	" + query);
      ps = con.prepareStatement(query);
      rs = ps.executeQuery();
      ArrayList recordSet = new ArrayList();
      while(rs.next()) {
        KBControllermapRecord record = new KBControllermapRecord();
        record.setCode(rs.getString("CODE"));
        record.setClassname(rs.getString("CLASSNAME"));
        record.setId(rs.getString("ID"));
        record.setAuthflag(rs.getString("AUTH_FLAG"));
        recordSet.add(record);
      }
      logger.trace("loadKBControllermapRecords:Records Fetched:" + recordSet.size());
      KBControllermapRecord[] tempKBControllermapRecords = new KBControllermapRecord[recordSet.size()];
      for (int index = 0; index < recordSet.size(); index++) {
        tempKBControllermapRecords[index] = (KBControllermapRecord)(recordSet.get(index));
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return tempKBControllermapRecords;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBControllermapRecord[] loadKBControllermapRecords(String query) throws Exception {
    return loadKBControllermapRecords(query, null, true);
  }

  public KBControllermapRecord loadFirstKBControllermapRecord(String query) throws Exception {
    KBControllermapRecord[] results = loadKBControllermapRecords(query);
    if (results == null) {
      return null;
    }
    if(results.length < 1) {
      return null;
    }
    return results[0];
  }

  public KBControllermapRecord loadKBControllermapRecord(String id, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      String Query = "SELECT * FROM controller_map WHERE (ID = ?)";
      Query = updateQuery(Query);
      logger.trace("loadKBControllermapRecords	" + closeConnection + "	" + id);
      ps = con.prepareStatement(Query);
      ps.setString(1,id);
      rs = ps.executeQuery();
      if (!rs.next()) {
        ps.close();
        releaseDatabaseConnection(con, closeConnection);
        return null;
      }
      KBControllermapRecord record = new KBControllermapRecord();
      record.setCode(rs.getString("CODE"));
      record.setClassname(rs.getString("CLASSNAME"));
      record.setId(rs.getString("ID"));
      record.setAuthflag(rs.getString("AUTH_FLAG"));
      ps.close();
      logger.trace("loadKBControllermapRecord	" + record + "	");
      releaseDatabaseConnection(con, closeConnection);
      return record;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBControllermapRecord loadKBControllermapRecord(String id) throws Exception {
    return loadKBControllermapRecord(id, null, true);
  }

  public int insertKBControllermapRecord(KBControllermapRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query ="INSERT INTO controller_map ";
      Query +="(";
      Query +="CODE,CLASSNAME,ID,AUTH_FLAG";
      Query +=")";
      Query += " VALUES " ;
      Query +="(";
      Query +="?,?,?,?";
      Query +=")";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("insertKBControllermapRecords	" + closeConnection + "	" + Query);
      if (isOracleDatabase()) {
        ps = con.prepareStatement(Query,new String[]{"ID"});
      }
      else {
        ps = con.prepareStatement(Query,Statement.RETURN_GENERATED_KEYS);
      }
      setStringValue(ps, 1, record.getCode());
      setStringValue(ps, 2, record.getClassname());
      setStringValue(ps, 3, record.getId());
      setStringValue(ps, 4, record.getAuthflag());
      boolean result = ps.execute();
      logger.trace("insertKBControllermapRecord	" + result + "	");
      int resultID = -1;
      rs = ps.getGeneratedKeys();
      if (rs.next()) {
        resultID = rs.getInt(1);
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return resultID;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public int insertKBControllermapRecord(KBControllermapRecord record) throws Exception {
    return insertKBControllermapRecord(record, null, true);
  }

  public boolean updateKBControllermapRecord(KBControllermapRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      KBControllermapRecord currentRecord = loadKBControllermapRecord(record.getId());
      String currentRecordContent = StringUtils.noNull(currentRecord);
      String Query = "UPDATE controller_map SET ";
      Query += "CODE = ?,";
          Query += "CLASSNAME = ?,";
          Query += "AUTH_FLAG = ?";
      Query += " WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("updateKBControllermapRecord	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      setStringValue(ps, 1, record.getCode());
      setStringValue(ps, 2, record.getClassname());
      setStringValue(ps, 3, record.getAuthflag());
      ps.setString(4, StringUtils.noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("updateKBControllermapRecord	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean updateKBControllermapRecord(KBControllermapRecord record) throws Exception {
    return updateKBControllermapRecord(record, null, true);
  }

  public boolean deleteKBControllermapRecord(KBControllermapRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query = "DELETE FROM controller_map WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("deleteKBControllermapRecord	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      ps.setString(1, noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("deleteKBControllermapRecord	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean deleteKBControllermapRecord(KBControllermapRecord record) throws Exception {
    return deleteKBControllermapRecord(record, null, true);
  }

  public KBControllermapRecord[] searchKBControllermapRecords(KBControllermapRecord searchRecord)
      throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CODE", formatSearchField(searchRecord.getCode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CLASSNAME", formatSearchField(searchRecord.getClassname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "AUTH_FLAG", formatSearchField(searchRecord.getAuthflag()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from controller_map " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM controller_map ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM controller_map $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBControllermapRecords(Query);
  }

  public KBControllermapRecord[] searchKBControllermapRecordsExactUpper(
      KBControllermapRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CODE", formatSearchField(searchRecord.getCode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CLASSNAME", formatSearchField(searchRecord.getClassname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "AUTH_FLAG", formatSearchField(searchRecord.getAuthflag()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from controller_map " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM controller_map ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM controller_map $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBControllermapRecords(Query);
  }

  public int loadKBControllermapRecordCount(KBControllermapRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CODE", formatSearchField(searchRecord.getCode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CLASSNAME", formatSearchField(searchRecord.getClassname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "AUTH_FLAG", formatSearchField(searchRecord.getAuthflag()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from controller_map " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }

  public int loadKBControllermapRecordCountExact(KBControllermapRecord searchRecord) throws
      Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CODE", formatSearchField(searchRecord.getCode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CLASSNAME", formatSearchField(searchRecord.getClassname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "AUTH_FLAG", formatSearchField(searchRecord.getAuthflag()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from controller_map " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }
}
