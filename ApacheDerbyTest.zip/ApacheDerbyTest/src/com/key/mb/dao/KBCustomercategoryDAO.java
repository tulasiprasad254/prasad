// Author Tulasi Vara Prasad
package com.key.mb.dao;

import com.key.mb.common.KBDAO;
import com.key.mb.to.KBCustomercategoryRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class KBCustomercategoryDAO extends KBDAO {
  public static LogUtils logger = new LogUtils(KBCustomercategoryDAO.class.getName());

  public KBCustomercategoryRecord[] loadKBCustomercategoryRecords(String query, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      query = query + MAX_RECORD_LIMIT_APPENDER;
      query = updateQuery(query);
      logger.trace("loadKBCustomercategoryRecords	" + closeConnection + "	" + query);
      ps = con.prepareStatement(query);
      rs = ps.executeQuery();
      ArrayList recordSet = new ArrayList();
      while(rs.next()) {
        KBCustomercategoryRecord record = new KBCustomercategoryRecord();
        record.setMadeat(rs.getString("MADE_AT"));
        record.setChargetype(rs.getString("CHARGE_TYPE"));
        record.setCheckedat(rs.getString("CHECKED_AT"));
        record.setChargevalue(rs.getString("CHARGE_VALUE"));
        record.setCheckedby(rs.getString("CHECKED_BY"));
        record.setCreatedat(rs.getString("CREATED_AT"));
        record.setMintranlimit(rs.getString("MIN_TRAN_LIMIT"));
        record.setMakerlastcmt(rs.getString("MAKER_LAST_CMT"));
        record.setCreatedby(rs.getString("CREATED_BY"));
        record.setInstitutionid(rs.getString("INSTITUTION_ID"));
        record.setRstatus(rs.getString("RSTATUS"));
        record.setCurrappstatus(rs.getString("CURR_APP_STATUS"));
        record.setAdminlastcmt(rs.getString("ADMIN_LAST_CMT"));
        record.setPerdaylimit(rs.getString("PER_DAY_LIMIT"));
        record.setServiceid(rs.getString("SERVICE_ID"));
        record.setModifiedby(rs.getString("MODIFIED_BY"));
        record.setPertranlimit(rs.getString("PER_TRAN_LIMIT"));
        record.setId(rs.getString("ID"));
        record.setCategory(rs.getString("CATEGORY"));
        record.setMadeby(rs.getString("MADE_BY"));
        record.setModifiedat(rs.getString("MODIFIED_AT"));
        record.setCheckerlastcmt(rs.getString("CHECKER_LAST_CMT"));
        recordSet.add(record);
      }
      logger.trace("loadKBCustomercategoryRecords:Records Fetched:" + recordSet.size());
      KBCustomercategoryRecord[] tempKBCustomercategoryRecords = new KBCustomercategoryRecord[recordSet.size()];
      for (int index = 0; index < recordSet.size(); index++) {
        tempKBCustomercategoryRecords[index] = (KBCustomercategoryRecord)(recordSet.get(index));
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return tempKBCustomercategoryRecords;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBCustomercategoryRecord[] loadKBCustomercategoryRecords(String query) throws Exception {
    return loadKBCustomercategoryRecords(query, null, true);
  }

  public KBCustomercategoryRecord loadFirstKBCustomercategoryRecord(String query) throws Exception {
    KBCustomercategoryRecord[] results = loadKBCustomercategoryRecords(query);
    if (results == null) {
      return null;
    }
    if(results.length < 1) {
      return null;
    }
    return results[0];
  }

  public KBCustomercategoryRecord loadKBCustomercategoryRecord(String id, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      String Query = "SELECT * FROM customer_category WHERE (ID = ?)";
      Query = updateQuery(Query);
      logger.trace("loadKBCustomercategoryRecords	" + closeConnection + "	" + id);
      ps = con.prepareStatement(Query);
      ps.setString(1,id);
      rs = ps.executeQuery();
      if (!rs.next()) {
        ps.close();
        releaseDatabaseConnection(con, closeConnection);
        return null;
      }
      KBCustomercategoryRecord record = new KBCustomercategoryRecord();
      record.setMadeat(rs.getString("MADE_AT"));
      record.setChargetype(rs.getString("CHARGE_TYPE"));
      record.setCheckedat(rs.getString("CHECKED_AT"));
      record.setChargevalue(rs.getString("CHARGE_VALUE"));
      record.setCheckedby(rs.getString("CHECKED_BY"));
      record.setCreatedat(rs.getString("CREATED_AT"));
      record.setMintranlimit(rs.getString("MIN_TRAN_LIMIT"));
      record.setMakerlastcmt(rs.getString("MAKER_LAST_CMT"));
      record.setCreatedby(rs.getString("CREATED_BY"));
      record.setInstitutionid(rs.getString("INSTITUTION_ID"));
      record.setRstatus(rs.getString("RSTATUS"));
      record.setCurrappstatus(rs.getString("CURR_APP_STATUS"));
      record.setAdminlastcmt(rs.getString("ADMIN_LAST_CMT"));
      record.setPerdaylimit(rs.getString("PER_DAY_LIMIT"));
      record.setServiceid(rs.getString("SERVICE_ID"));
      record.setModifiedby(rs.getString("MODIFIED_BY"));
      record.setPertranlimit(rs.getString("PER_TRAN_LIMIT"));
      record.setId(rs.getString("ID"));
      record.setCategory(rs.getString("CATEGORY"));
      record.setMadeby(rs.getString("MADE_BY"));
      record.setModifiedat(rs.getString("MODIFIED_AT"));
      record.setCheckerlastcmt(rs.getString("CHECKER_LAST_CMT"));
      ps.close();
      logger.trace("loadKBCustomercategoryRecord	" + record + "	");
      releaseDatabaseConnection(con, closeConnection);
      return record;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBCustomercategoryRecord loadKBCustomercategoryRecord(String id) throws Exception {
    return loadKBCustomercategoryRecord(id, null, true);
  }

  public int insertKBCustomercategoryRecord(KBCustomercategoryRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query ="INSERT INTO customer_category ";
      Query +="(";
      Query +="MADE_AT,CHARGE_TYPE,CHECKED_AT,CHARGE_VALUE,CHECKED_BY,CREATED_AT,MIN_TRAN_LIMIT,MAKER_LAST_CMT,CREATED_BY,INSTITUTION_ID,RSTATUS,CURR_APP_STATUS,ADMIN_LAST_CMT,PER_DAY_LIMIT,SERVICE_ID,MODIFIED_BY,PER_TRAN_LIMIT,ID,CATEGORY,MADE_BY,MODIFIED_AT,CHECKER_LAST_CMT";
      Query +=")";
      Query += " VALUES " ;
      Query +="(";
      Query +="?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?";
      Query +=")";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("insertKBCustomercategoryRecords	" + closeConnection + "	" + Query);
      if (isOracleDatabase()) {
        ps = con.prepareStatement(Query,new String[]{"ID"});
      }
      else {
        ps = con.prepareStatement(Query,Statement.RETURN_GENERATED_KEYS);
      }
      setStringValue(ps, 1, record.getMadeat());
      setStringValue(ps, 2, record.getChargetype());
      setStringValue(ps, 3, record.getCheckedat());
      setStringValue(ps, 4, record.getChargevalue());
      setStringValue(ps, 5, record.getCheckedby());
      setDateValue(ps, 6, fd.getSQLDateObject(record.getCreatedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 7, record.getMintranlimit());
      setStringValue(ps, 8, record.getMakerlastcmt());
      setStringValue(ps, 9, record.getCreatedby());
      setStringValue(ps, 10, record.getInstitutionid());
      setStringValue(ps, 11, record.getRstatus());
      setStringValue(ps, 12, record.getCurrappstatus());
      setStringValue(ps, 13, record.getAdminlastcmt());
      setStringValue(ps, 14, record.getPerdaylimit());
      setStringValue(ps, 15, record.getServiceid());
      setStringValue(ps, 16, record.getModifiedby());
      setStringValue(ps, 17, record.getPertranlimit());
      setStringValue(ps, 18, record.getId());
      setStringValue(ps, 19, record.getCategory());
      setStringValue(ps, 20, record.getMadeby());
      setDateValue(ps, 21, fd.getSQLDateObject(record.getModifiedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 22, record.getCheckerlastcmt());
      boolean result = ps.execute();
      logger.trace("insertKBCustomercategoryRecord	" + result + "	");
      int resultID = -1;
      rs = ps.getGeneratedKeys();
      if (rs.next()) {
        resultID = rs.getInt(1);
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return resultID;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public int insertKBCustomercategoryRecord(KBCustomercategoryRecord record) throws Exception {
    return insertKBCustomercategoryRecord(record, null, true);
  }

  public boolean updateKBCustomercategoryRecord(KBCustomercategoryRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      KBCustomercategoryRecord currentRecord = loadKBCustomercategoryRecord(record.getId());
      String currentRecordContent = StringUtils.noNull(currentRecord);
      String Query = "UPDATE customer_category SET ";
      Query += "MADE_AT = ?,";
          Query += "CHARGE_TYPE = ?,";
          Query += "CHECKED_AT = ?,";
          Query += "CHARGE_VALUE = ?,";
          Query += "CHECKED_BY = ?,";
          Query += "CREATED_AT = ?,";
          Query += "MIN_TRAN_LIMIT = ?,";
          Query += "MAKER_LAST_CMT = ?,";
          Query += "CREATED_BY = ?,";
          Query += "INSTITUTION_ID = ?,";
          Query += "RSTATUS = ?,";
          Query += "CURR_APP_STATUS = ?,";
          Query += "ADMIN_LAST_CMT = ?,";
          Query += "PER_DAY_LIMIT = ?,";
          Query += "SERVICE_ID = ?,";
          Query += "MODIFIED_BY = ?,";
          Query += "PER_TRAN_LIMIT = ?,";
          Query += "CATEGORY = ?,";
          Query += "MADE_BY = ?,";
          Query += "MODIFIED_AT = ?,";
          Query += "CHECKER_LAST_CMT = ?";
      Query += " WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("updateKBCustomercategoryRecord	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      setStringValue(ps, 1, record.getMadeat());
      setStringValue(ps, 2, record.getChargetype());
      setStringValue(ps, 3, record.getCheckedat());
      setStringValue(ps, 4, record.getChargevalue());
      setStringValue(ps, 5, record.getCheckedby());
      setDateValue(ps, 6, fd.getSQLDateObject(record.getCreatedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 7, record.getMintranlimit());
      setStringValue(ps, 8, record.getMakerlastcmt());
      setStringValue(ps, 9, record.getCreatedby());
      setStringValue(ps, 10, record.getInstitutionid());
      setStringValue(ps, 11, record.getRstatus());
      setStringValue(ps, 12, record.getCurrappstatus());
      setStringValue(ps, 13, record.getAdminlastcmt());
      setStringValue(ps, 14, record.getPerdaylimit());
      setStringValue(ps, 15, record.getServiceid());
      setStringValue(ps, 16, record.getModifiedby());
      setStringValue(ps, 17, record.getPertranlimit());
      setStringValue(ps, 18, record.getCategory());
      setStringValue(ps, 19, record.getMadeby());
      setDateValue(ps, 20, fd.getSQLDateObject(record.getModifiedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 21, record.getCheckerlastcmt());
      ps.setString(22, StringUtils.noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("updateKBCustomercategoryRecord	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean updateKBCustomercategoryRecord(KBCustomercategoryRecord record) throws Exception {
    return updateKBCustomercategoryRecord(record, null, true);
  }

  public boolean deleteKBCustomercategoryRecord(KBCustomercategoryRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query = "DELETE FROM customer_category WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("deleteKBCustomercategoryRecord	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      ps.setString(1, noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("deleteKBCustomercategoryRecord	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean deleteKBCustomercategoryRecord(KBCustomercategoryRecord record) throws Exception {
    return deleteKBCustomercategoryRecord(record, null, true);
  }

  public KBCustomercategoryRecord[] searchKBCustomercategoryRecords(
      KBCustomercategoryRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MADE_AT", formatSearchField(searchRecord.getMadeat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHARGE_TYPE", formatSearchField(searchRecord.getChargetype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHECKED_AT", formatSearchField(searchRecord.getCheckedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHARGE_VALUE", formatSearchField(searchRecord.getChargevalue()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CHECKED_BY", formatSearchField(searchRecord.getCheckedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MIN_TRAN_LIMIT", formatSearchField(searchRecord.getMintranlimit()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MAKER_LAST_CMT", formatSearchField(searchRecord.getMakerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CURR_APP_STATUS", formatSearchField(searchRecord.getCurrappstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "ADMIN_LAST_CMT", formatSearchField(searchRecord.getAdminlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PER_DAY_LIMIT", formatSearchField(searchRecord.getPerdaylimit()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "SERVICE_ID", formatSearchField(searchRecord.getServiceid()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PER_TRAN_LIMIT", formatSearchField(searchRecord.getPertranlimit()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CATEGORY", formatSearchField(searchRecord.getCategory()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MADE_BY", formatSearchField(searchRecord.getMadeby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHECKER_LAST_CMT", formatSearchField(searchRecord.getCheckerlastcmt()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from customer_category " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM customer_category ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM customer_category $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBCustomercategoryRecords(Query);
  }

  public KBCustomercategoryRecord[] searchKBCustomercategoryRecordsExactUpper(
      KBCustomercategoryRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MADE_AT", formatSearchField(searchRecord.getMadeat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHARGE_TYPE", formatSearchField(searchRecord.getChargetype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKED_AT", formatSearchField(searchRecord.getCheckedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHARGE_VALUE", formatSearchField(searchRecord.getChargevalue()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKED_BY", formatSearchField(searchRecord.getCheckedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MIN_TRAN_LIMIT", formatSearchField(searchRecord.getMintranlimit()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MAKER_LAST_CMT", formatSearchField(searchRecord.getMakerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CURR_APP_STATUS", formatSearchField(searchRecord.getCurrappstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ADMIN_LAST_CMT", formatSearchField(searchRecord.getAdminlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PER_DAY_LIMIT", formatSearchField(searchRecord.getPerdaylimit()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "SERVICE_ID", formatSearchField(searchRecord.getServiceid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PER_TRAN_LIMIT", formatSearchField(searchRecord.getPertranlimit()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CATEGORY", formatSearchField(searchRecord.getCategory()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MADE_BY", formatSearchField(searchRecord.getMadeby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKER_LAST_CMT", formatSearchField(searchRecord.getCheckerlastcmt()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from customer_category " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM customer_category ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM customer_category $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBCustomercategoryRecords(Query);
  }

  public int loadKBCustomercategoryRecordCount(KBCustomercategoryRecord searchRecord) throws
      Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MADE_AT", formatSearchField(searchRecord.getMadeat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHARGE_TYPE", formatSearchField(searchRecord.getChargetype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHECKED_AT", formatSearchField(searchRecord.getCheckedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHARGE_VALUE", formatSearchField(searchRecord.getChargevalue()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CHECKED_BY", formatSearchField(searchRecord.getCheckedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MIN_TRAN_LIMIT", formatSearchField(searchRecord.getMintranlimit()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MAKER_LAST_CMT", formatSearchField(searchRecord.getMakerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CURR_APP_STATUS", formatSearchField(searchRecord.getCurrappstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "ADMIN_LAST_CMT", formatSearchField(searchRecord.getAdminlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PER_DAY_LIMIT", formatSearchField(searchRecord.getPerdaylimit()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "SERVICE_ID", formatSearchField(searchRecord.getServiceid()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PER_TRAN_LIMIT", formatSearchField(searchRecord.getPertranlimit()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CATEGORY", formatSearchField(searchRecord.getCategory()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MADE_BY", formatSearchField(searchRecord.getMadeby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHECKER_LAST_CMT", formatSearchField(searchRecord.getCheckerlastcmt()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from customer_category " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }

  public int loadKBCustomercategoryRecordCountExact(KBCustomercategoryRecord searchRecord) throws
      Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MADE_AT", formatSearchField(searchRecord.getMadeat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHARGE_TYPE", formatSearchField(searchRecord.getChargetype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKED_AT", formatSearchField(searchRecord.getCheckedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHARGE_VALUE", formatSearchField(searchRecord.getChargevalue()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKED_BY", formatSearchField(searchRecord.getCheckedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MIN_TRAN_LIMIT", formatSearchField(searchRecord.getMintranlimit()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MAKER_LAST_CMT", formatSearchField(searchRecord.getMakerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CURR_APP_STATUS", formatSearchField(searchRecord.getCurrappstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ADMIN_LAST_CMT", formatSearchField(searchRecord.getAdminlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PER_DAY_LIMIT", formatSearchField(searchRecord.getPerdaylimit()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "SERVICE_ID", formatSearchField(searchRecord.getServiceid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PER_TRAN_LIMIT", formatSearchField(searchRecord.getPertranlimit()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CATEGORY", formatSearchField(searchRecord.getCategory()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MADE_BY", formatSearchField(searchRecord.getMadeby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKER_LAST_CMT", formatSearchField(searchRecord.getCheckerlastcmt()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from customer_category " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }
}
