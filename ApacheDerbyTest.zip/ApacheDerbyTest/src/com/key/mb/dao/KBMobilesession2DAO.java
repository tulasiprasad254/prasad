// Author Tulasi Vara Prasad
package com.key.mb.dao;

import com.key.mb.common.KBDAO;
import com.key.mb.to.KBMobilesession2Record;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class KBMobilesession2DAO extends KBDAO {
  public static LogUtils logger = new LogUtils(KBMobilesession2DAO.class.getName());

  public KBMobilesession2Record[] loadKBMobilesession2Records(String query, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      query = query + MAX_RECORD_LIMIT_APPENDER;
      query = updateQuery(query);
      logger.trace("loadKBMobilesession2Records	" + closeConnection + "	" + query);
      ps = con.prepareStatement(query);
      rs = ps.executeQuery();
      ArrayList recordSet = new ArrayList();
      while(rs.next()) {
        KBMobilesession2Record record = new KBMobilesession2Record();
        record.setLastftamt(rs.getString("LAST_FT_AMT"));
        record.setCifno(rs.getString("CIFNO"));
        record.setLastphoneid(rs.getString("LAST_PHONE_ID"));
        record.setAgentacc(rs.getString("AGENT_ACC"));
        record.setLastphonetype(rs.getString("LAST_PHONE_TYPE"));
        record.setExtnval4(rs.getString("EXTN_VAL_4"));
        record.setCreatedat(rs.getString("CREATED_AT"));
        record.setAgentchargesacc(rs.getString("AGENT_CHARGES_ACC"));
        record.setSessionid(rs.getString("SESSIONID"));
        record.setCreatedby(rs.getString("CREATED_BY"));
        record.setExtnval1(rs.getString("EXTN_VAL_1"));
        record.setExtnval2(rs.getString("EXTN_VAL_2"));
        record.setExtnval3(rs.getString("EXTN_VAL_3"));
        record.setLastftto(rs.getString("LAST_FT_TO"));
        record.setLastftfrom(rs.getString("LAST_FT_FROM"));
        record.setLangcode(rs.getString("LANG_CODE"));
        record.setNavcont(rs.getString("NAVCONT"));
        record.setModifiedby(rs.getString("MODIFIED_BY"));
        record.setLastacc(rs.getString("LASTACC"));
        record.setId(rs.getString("ID"));
        record.setAgentflag(rs.getString("AGENT_FLAG"));
        record.setModifiedat(rs.getString("MODIFIED_AT"));
        record.setLastftremarks(rs.getString("LAST_FT_REMARKS"));
        record.setStatus(rs.getString("STATUS"));
        recordSet.add(record);
      }
      logger.trace("loadKBMobilesession2Records:Records Fetched:" + recordSet.size());
      KBMobilesession2Record[] tempKBMobilesession2Records = new KBMobilesession2Record[recordSet.size()];
      for (int index = 0; index < recordSet.size(); index++) {
        tempKBMobilesession2Records[index] = (KBMobilesession2Record)(recordSet.get(index));
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return tempKBMobilesession2Records;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBMobilesession2Record[] loadKBMobilesession2Records(String query) throws Exception {
    return loadKBMobilesession2Records(query, null, true);
  }

  public KBMobilesession2Record loadFirstKBMobilesession2Record(String query) throws Exception {
    KBMobilesession2Record[] results = loadKBMobilesession2Records(query);
    if (results == null) {
      return null;
    }
    if(results.length < 1) {
      return null;
    }
    return results[0];
  }

  public KBMobilesession2Record loadKBMobilesession2Record(String id, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      String Query = "SELECT * FROM mobile_session2 WHERE (ID = ?)";
      Query = updateQuery(Query);
      logger.trace("loadKBMobilesession2Records	" + closeConnection + "	" + id);
      ps = con.prepareStatement(Query);
      ps.setString(1,id);
      rs = ps.executeQuery();
      if (!rs.next()) {
        ps.close();
        releaseDatabaseConnection(con, closeConnection);
        return null;
      }
      KBMobilesession2Record record = new KBMobilesession2Record();
      record.setLastftamt(rs.getString("LAST_FT_AMT"));
      record.setCifno(rs.getString("CIFNO"));
      record.setLastphoneid(rs.getString("LAST_PHONE_ID"));
      record.setAgentacc(rs.getString("AGENT_ACC"));
      record.setLastphonetype(rs.getString("LAST_PHONE_TYPE"));
      record.setExtnval4(rs.getString("EXTN_VAL_4"));
      record.setCreatedat(rs.getString("CREATED_AT"));
      record.setAgentchargesacc(rs.getString("AGENT_CHARGES_ACC"));
      record.setSessionid(rs.getString("SESSIONID"));
      record.setCreatedby(rs.getString("CREATED_BY"));
      record.setExtnval1(rs.getString("EXTN_VAL_1"));
      record.setExtnval2(rs.getString("EXTN_VAL_2"));
      record.setExtnval3(rs.getString("EXTN_VAL_3"));
      record.setLastftto(rs.getString("LAST_FT_TO"));
      record.setLastftfrom(rs.getString("LAST_FT_FROM"));
      record.setLangcode(rs.getString("LANG_CODE"));
      record.setNavcont(rs.getString("NAVCONT"));
      record.setModifiedby(rs.getString("MODIFIED_BY"));
      record.setLastacc(rs.getString("LASTACC"));
      record.setId(rs.getString("ID"));
      record.setAgentflag(rs.getString("AGENT_FLAG"));
      record.setModifiedat(rs.getString("MODIFIED_AT"));
      record.setLastftremarks(rs.getString("LAST_FT_REMARKS"));
      record.setStatus(rs.getString("STATUS"));
      ps.close();
      logger.trace("loadKBMobilesession2Record	" + record + "	");
      releaseDatabaseConnection(con, closeConnection);
      return record;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBMobilesession2Record loadKBMobilesession2Record(String id) throws Exception {
    return loadKBMobilesession2Record(id, null, true);
  }

  public int insertKBMobilesession2Record(KBMobilesession2Record record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query ="INSERT INTO mobile_session2 ";
      Query +="(";
      Query +="LAST_FT_AMT,CIFNO,LAST_PHONE_ID,AGENT_ACC,LAST_PHONE_TYPE,EXTN_VAL_4,CREATED_AT,AGENT_CHARGES_ACC,SESSIONID,CREATED_BY,EXTN_VAL_1,EXTN_VAL_2,EXTN_VAL_3,LAST_FT_TO,LAST_FT_FROM,LANG_CODE,NAVCONT,MODIFIED_BY,LASTACC,ID,AGENT_FLAG,MODIFIED_AT,LAST_FT_REMARKS,STATUS";
      Query +=")";
      Query += " VALUES " ;
      Query +="(";
      Query +="?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?";
      Query +=")";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("insertKBMobilesession2Records	" + closeConnection + "	" + Query);
      if (isOracleDatabase()) {
        ps = con.prepareStatement(Query,new String[]{"ID"});
      }
      else {
        ps = con.prepareStatement(Query,Statement.RETURN_GENERATED_KEYS);
      }
      setStringValue(ps, 1, record.getLastftamt());
      setStringValue(ps, 2, record.getCifno());
      setStringValue(ps, 3, record.getLastphoneid());
      setStringValue(ps, 4, record.getAgentacc());
      setStringValue(ps, 5, record.getLastphonetype());
      setStringValue(ps, 6, record.getExtnval4());
      setDateValue(ps, 7, fd.getSQLDateObject(record.getCreatedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 8, record.getAgentchargesacc());
      setStringValue(ps, 9, record.getSessionid());
      setStringValue(ps, 10, record.getCreatedby());
      setStringValue(ps, 11, record.getExtnval1());
      setStringValue(ps, 12, record.getExtnval2());
      setStringValue(ps, 13, record.getExtnval3());
      setStringValue(ps, 14, record.getLastftto());
      setStringValue(ps, 15, record.getLastftfrom());
      setStringValue(ps, 16, record.getLangcode());
      setStringValue(ps, 17, record.getNavcont());
      setStringValue(ps, 18, record.getModifiedby());
      setStringValue(ps, 19, record.getLastacc());
      setStringValue(ps, 20, record.getId());
      setStringValue(ps, 21, record.getAgentflag());
      setDateValue(ps, 22, fd.getSQLDateObject(record.getModifiedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 23, record.getLastftremarks());
      setStringValue(ps, 24, record.getStatus());
      boolean result = ps.execute();
      logger.trace("insertKBMobilesession2Record	" + result + "	");
      int resultID = -1;
      rs = ps.getGeneratedKeys();
      if (rs.next()) {
        resultID = rs.getInt(1);
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return resultID;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public int insertKBMobilesession2Record(KBMobilesession2Record record) throws Exception {
    return insertKBMobilesession2Record(record, null, true);
  }

  public boolean updateKBMobilesession2Record(KBMobilesession2Record record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      KBMobilesession2Record currentRecord = loadKBMobilesession2Record(record.getId());
      String currentRecordContent = StringUtils.noNull(currentRecord);
      String Query = "UPDATE mobile_session2 SET ";
      Query += "LAST_FT_AMT = ?,";
          Query += "CIFNO = ?,";
          Query += "LAST_PHONE_ID = ?,";
          Query += "AGENT_ACC = ?,";
          Query += "LAST_PHONE_TYPE = ?,";
          Query += "EXTN_VAL_4 = ?,";
          Query += "CREATED_AT = ?,";
          Query += "AGENT_CHARGES_ACC = ?,";
          Query += "SESSIONID = ?,";
          Query += "CREATED_BY = ?,";
          Query += "EXTN_VAL_1 = ?,";
          Query += "EXTN_VAL_2 = ?,";
          Query += "EXTN_VAL_3 = ?,";
          Query += "LAST_FT_TO = ?,";
          Query += "LAST_FT_FROM = ?,";
          Query += "LANG_CODE = ?,";
          Query += "NAVCONT = ?,";
          Query += "MODIFIED_BY = ?,";
          Query += "LASTACC = ?,";
          Query += "AGENT_FLAG = ?,";
          Query += "MODIFIED_AT = ?,";
          Query += "LAST_FT_REMARKS = ?,";
          Query += "STATUS = ?";
      Query += " WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("updateKBMobilesession2Record	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      setStringValue(ps, 1, record.getLastftamt());
      setStringValue(ps, 2, record.getCifno());
      setStringValue(ps, 3, record.getLastphoneid());
      setStringValue(ps, 4, record.getAgentacc());
      setStringValue(ps, 5, record.getLastphonetype());
      setStringValue(ps, 6, record.getExtnval4());
      setDateValue(ps, 7, fd.getSQLDateObject(record.getCreatedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 8, record.getAgentchargesacc());
      setStringValue(ps, 9, record.getSessionid());
      setStringValue(ps, 10, record.getCreatedby());
      setStringValue(ps, 11, record.getExtnval1());
      setStringValue(ps, 12, record.getExtnval2());
      setStringValue(ps, 13, record.getExtnval3());
      setStringValue(ps, 14, record.getLastftto());
      setStringValue(ps, 15, record.getLastftfrom());
      setStringValue(ps, 16, record.getLangcode());
      setStringValue(ps, 17, record.getNavcont());
      setStringValue(ps, 18, record.getModifiedby());
      setStringValue(ps, 19, record.getLastacc());
      setStringValue(ps, 20, record.getAgentflag());
      setDateValue(ps, 21, fd.getSQLDateObject(record.getModifiedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 22, record.getLastftremarks());
      setStringValue(ps, 23, record.getStatus());
      ps.setString(24, StringUtils.noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("updateKBMobilesession2Record	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean updateKBMobilesession2Record(KBMobilesession2Record record) throws Exception {
    return updateKBMobilesession2Record(record, null, true);
  }

  public boolean deleteKBMobilesession2Record(KBMobilesession2Record record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query = "DELETE FROM mobile_session2 WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("deleteKBMobilesession2Record	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      ps.setString(1, noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("deleteKBMobilesession2Record	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean deleteKBMobilesession2Record(KBMobilesession2Record record) throws Exception {
    return deleteKBMobilesession2Record(record, null, true);
  }

  public KBMobilesession2Record[] searchKBMobilesession2Records(KBMobilesession2Record searchRecord)
      throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "LAST_FT_AMT", formatSearchField(searchRecord.getLastftamt()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CIFNO", formatSearchField(searchRecord.getCifno()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "LAST_PHONE_ID", formatSearchField(searchRecord.getLastphoneid()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "AGENT_ACC", formatSearchField(searchRecord.getAgentacc()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "LAST_PHONE_TYPE", formatSearchField(searchRecord.getLastphonetype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EXTN_VAL_4", formatSearchField(searchRecord.getExtnval4()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "AGENT_CHARGES_ACC", formatSearchField(searchRecord.getAgentchargesacc()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "SESSIONID", formatSearchField(searchRecord.getSessionid()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EXTN_VAL_1", formatSearchField(searchRecord.getExtnval1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EXTN_VAL_2", formatSearchField(searchRecord.getExtnval2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EXTN_VAL_3", formatSearchField(searchRecord.getExtnval3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "LAST_FT_TO", formatSearchField(searchRecord.getLastftto()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "LAST_FT_FROM", formatSearchField(searchRecord.getLastftfrom()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "LANG_CODE", formatSearchField(searchRecord.getLangcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "NAVCONT", formatSearchField(searchRecord.getNavcont()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "LASTACC", formatSearchField(searchRecord.getLastacc()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "AGENT_FLAG", formatSearchField(searchRecord.getAgentflag()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "LAST_FT_REMARKS", formatSearchField(searchRecord.getLastftremarks()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "STATUS", formatSearchField(searchRecord.getStatus()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from mobile_session2 " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM mobile_session2 ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM mobile_session2 $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBMobilesession2Records(Query);
  }

  public KBMobilesession2Record[] searchKBMobilesession2RecordsExactUpper(
      KBMobilesession2Record searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LAST_FT_AMT", formatSearchField(searchRecord.getLastftamt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CIFNO", formatSearchField(searchRecord.getCifno()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LAST_PHONE_ID", formatSearchField(searchRecord.getLastphoneid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "AGENT_ACC", formatSearchField(searchRecord.getAgentacc()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LAST_PHONE_TYPE", formatSearchField(searchRecord.getLastphonetype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EXTN_VAL_4", formatSearchField(searchRecord.getExtnval4()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "AGENT_CHARGES_ACC", formatSearchField(searchRecord.getAgentchargesacc()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "SESSIONID", formatSearchField(searchRecord.getSessionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EXTN_VAL_1", formatSearchField(searchRecord.getExtnval1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EXTN_VAL_2", formatSearchField(searchRecord.getExtnval2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EXTN_VAL_3", formatSearchField(searchRecord.getExtnval3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LAST_FT_TO", formatSearchField(searchRecord.getLastftto()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LAST_FT_FROM", formatSearchField(searchRecord.getLastftfrom()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LANG_CODE", formatSearchField(searchRecord.getLangcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "NAVCONT", formatSearchField(searchRecord.getNavcont()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LASTACC", formatSearchField(searchRecord.getLastacc()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "AGENT_FLAG", formatSearchField(searchRecord.getAgentflag()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LAST_FT_REMARKS", formatSearchField(searchRecord.getLastftremarks()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "STATUS", formatSearchField(searchRecord.getStatus()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from mobile_session2 " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM mobile_session2 ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM mobile_session2 $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBMobilesession2Records(Query);
  }

  public int loadKBMobilesession2RecordCount(KBMobilesession2Record searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "LAST_FT_AMT", formatSearchField(searchRecord.getLastftamt()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CIFNO", formatSearchField(searchRecord.getCifno()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "LAST_PHONE_ID", formatSearchField(searchRecord.getLastphoneid()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "AGENT_ACC", formatSearchField(searchRecord.getAgentacc()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "LAST_PHONE_TYPE", formatSearchField(searchRecord.getLastphonetype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EXTN_VAL_4", formatSearchField(searchRecord.getExtnval4()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "AGENT_CHARGES_ACC", formatSearchField(searchRecord.getAgentchargesacc()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "SESSIONID", formatSearchField(searchRecord.getSessionid()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EXTN_VAL_1", formatSearchField(searchRecord.getExtnval1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EXTN_VAL_2", formatSearchField(searchRecord.getExtnval2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EXTN_VAL_3", formatSearchField(searchRecord.getExtnval3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "LAST_FT_TO", formatSearchField(searchRecord.getLastftto()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "LAST_FT_FROM", formatSearchField(searchRecord.getLastftfrom()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "LANG_CODE", formatSearchField(searchRecord.getLangcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "NAVCONT", formatSearchField(searchRecord.getNavcont()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "LASTACC", formatSearchField(searchRecord.getLastacc()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "AGENT_FLAG", formatSearchField(searchRecord.getAgentflag()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "LAST_FT_REMARKS", formatSearchField(searchRecord.getLastftremarks()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "STATUS", formatSearchField(searchRecord.getStatus()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from mobile_session2 " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }

  public int loadKBMobilesession2RecordCountExact(KBMobilesession2Record searchRecord) throws
      Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LAST_FT_AMT", formatSearchField(searchRecord.getLastftamt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CIFNO", formatSearchField(searchRecord.getCifno()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LAST_PHONE_ID", formatSearchField(searchRecord.getLastphoneid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "AGENT_ACC", formatSearchField(searchRecord.getAgentacc()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LAST_PHONE_TYPE", formatSearchField(searchRecord.getLastphonetype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EXTN_VAL_4", formatSearchField(searchRecord.getExtnval4()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "AGENT_CHARGES_ACC", formatSearchField(searchRecord.getAgentchargesacc()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "SESSIONID", formatSearchField(searchRecord.getSessionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EXTN_VAL_1", formatSearchField(searchRecord.getExtnval1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EXTN_VAL_2", formatSearchField(searchRecord.getExtnval2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EXTN_VAL_3", formatSearchField(searchRecord.getExtnval3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LAST_FT_TO", formatSearchField(searchRecord.getLastftto()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LAST_FT_FROM", formatSearchField(searchRecord.getLastftfrom()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LANG_CODE", formatSearchField(searchRecord.getLangcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "NAVCONT", formatSearchField(searchRecord.getNavcont()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LASTACC", formatSearchField(searchRecord.getLastacc()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "AGENT_FLAG", formatSearchField(searchRecord.getAgentflag()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LAST_FT_REMARKS", formatSearchField(searchRecord.getLastftremarks()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "STATUS", formatSearchField(searchRecord.getStatus()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from mobile_session2 " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }
}
