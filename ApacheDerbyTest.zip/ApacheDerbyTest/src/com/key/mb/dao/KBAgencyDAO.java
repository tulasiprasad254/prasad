// Author Tulasi Vara Prasad
package com.key.mb.dao;

import com.key.mb.common.KBDAO;
import com.key.mb.to.KBAgencyRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class KBAgencyDAO extends KBDAO {
  public static LogUtils logger = new LogUtils(KBAgencyDAO.class.getName());

  public KBAgencyRecord[] loadKBAgencyRecords(String query, Connection con, boolean closeConnection)
      throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      query = query + MAX_RECORD_LIMIT_APPENDER;
      query = updateQuery(query);
      logger.trace("loadKBAgencyRecords	" + closeConnection + "	" + query);
      ps = con.prepareStatement(query);
      rs = ps.executeQuery();
      ArrayList recordSet = new ArrayList();
      while(rs.next()) {
        KBAgencyRecord record = new KBAgencyRecord();
        record.setBusstat(rs.getString("BUSSTAT"));
        record.setAgtype(rs.getString("AG_TYPE"));
        record.setPstaddr(rs.getString("PSTADDR"));
        record.setProfprov(rs.getString("PROFPROV"));
        record.setCheckedby(rs.getString("CHECKED_BY"));
        record.setCreatedat(rs.getString("CREATED_AT"));
        record.setMakerlastcmt(rs.getString("MAKER_LAST_CMT"));
        record.setBrnchcode(rs.getString("BRNCHCODE"));
        record.setInstitutionid(rs.getString("INSTITUTION_ID"));
        record.setDomibrnch(rs.getString("DOMIBRNCH"));
        record.setServpk(rs.getString("SERVPK"));
        record.setMastagcode(rs.getString("MAST_AGCODE"));
        record.setPstzip(rs.getString("PSTZIP"));
        record.setBusname(rs.getString("BUSNAME"));
        record.setId(rs.getString("ID"));
        record.setModifiedat(rs.getString("MODIFIED_AT"));
        record.setMadeat(rs.getString("MADE_AT"));
        record.setExtn4(rs.getString("EXTN4"));
        record.setBusloc(rs.getString("BUSLOC"));
        record.setExtn3(rs.getString("EXTN3"));
        record.setExtn2(rs.getString("EXTN2"));
        record.setBusnationality(rs.getString("BUSNATIONALITY"));
        record.setCheckedat(rs.getString("CHECKED_AT"));
        record.setExtn1(rs.getString("EXTN1"));
        record.setDlylimit(rs.getString("DLY_LIMIT"));
        record.setLrnum(rs.getString("LRNUM"));
        record.setBusdesig(rs.getString("BUSDESIG"));
        record.setCreatedby(rs.getString("CREATED_BY"));
        record.setMnthlimit(rs.getString("MNTH_LIMIT"));
        record.setNationalty(rs.getString("NATIONALTY"));
        record.setExtn5(rs.getString("EXTN5"));
        record.setRstatus(rs.getString("RSTATUS"));
        record.setCurrappstatus(rs.getString("CURR_APP_STATUS"));
        record.setPstcity(rs.getString("PSTCITY"));
        record.setProfagcode(rs.getString("PROFAGCODE"));
        record.setAdminlastcmt(rs.getString("ADMIN_LAST_CMT"));
        record.setProfcont2(rs.getString("PROFCONT2"));
        record.setModifiedby(rs.getString("MODIFIED_BY"));
        record.setProfcont1(rs.getString("PROFCONT1"));
        record.setPhyaddr(rs.getString("PHYADDR"));
        record.setMadeby(rs.getString("MADE_BY"));
        record.setAccnum3(rs.getString("ACCNUM3"));
        record.setTrdname(rs.getString("TRDNAME"));
        record.setAccnum2(rs.getString("ACCNUM2"));
        record.setCheckerlastcmt(rs.getString("CHECKER_LAST_CMT"));
        record.setAccnum1(rs.getString("ACCNUM1"));
        recordSet.add(record);
      }
      logger.trace("loadKBAgencyRecords:Records Fetched:" + recordSet.size());
      KBAgencyRecord[] tempKBAgencyRecords = new KBAgencyRecord[recordSet.size()];
      for (int index = 0; index < recordSet.size(); index++) {
        tempKBAgencyRecords[index] = (KBAgencyRecord)(recordSet.get(index));
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return tempKBAgencyRecords;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBAgencyRecord[] loadKBAgencyRecords(String query) throws Exception {
    return loadKBAgencyRecords(query, null, true);
  }

  public KBAgencyRecord loadFirstKBAgencyRecord(String query) throws Exception {
    KBAgencyRecord[] results = loadKBAgencyRecords(query);
    if (results == null) {
      return null;
    }
    if(results.length < 1) {
      return null;
    }
    return results[0];
  }

  public KBAgencyRecord loadKBAgencyRecord(String id, Connection con, boolean closeConnection)
      throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      String Query = "SELECT * FROM agency WHERE (ID = ?)";
      Query = updateQuery(Query);
      logger.trace("loadKBAgencyRecords	" + closeConnection + "	" + id);
      ps = con.prepareStatement(Query);
      ps.setString(1,id);
      rs = ps.executeQuery();
      if (!rs.next()) {
        ps.close();
        releaseDatabaseConnection(con, closeConnection);
        return null;
      }
      KBAgencyRecord record = new KBAgencyRecord();
      record.setBusstat(rs.getString("BUSSTAT"));
      record.setAgtype(rs.getString("AG_TYPE"));
      record.setPstaddr(rs.getString("PSTADDR"));
      record.setProfprov(rs.getString("PROFPROV"));
      record.setCheckedby(rs.getString("CHECKED_BY"));
      record.setCreatedat(rs.getString("CREATED_AT"));
      record.setMakerlastcmt(rs.getString("MAKER_LAST_CMT"));
      record.setBrnchcode(rs.getString("BRNCHCODE"));
      record.setInstitutionid(rs.getString("INSTITUTION_ID"));
      record.setDomibrnch(rs.getString("DOMIBRNCH"));
      record.setServpk(rs.getString("SERVPK"));
      record.setMastagcode(rs.getString("MAST_AGCODE"));
      record.setPstzip(rs.getString("PSTZIP"));
      record.setBusname(rs.getString("BUSNAME"));
      record.setId(rs.getString("ID"));
      record.setModifiedat(rs.getString("MODIFIED_AT"));
      record.setMadeat(rs.getString("MADE_AT"));
      record.setExtn4(rs.getString("EXTN4"));
      record.setBusloc(rs.getString("BUSLOC"));
      record.setExtn3(rs.getString("EXTN3"));
      record.setExtn2(rs.getString("EXTN2"));
      record.setBusnationality(rs.getString("BUSNATIONALITY"));
      record.setCheckedat(rs.getString("CHECKED_AT"));
      record.setExtn1(rs.getString("EXTN1"));
      record.setDlylimit(rs.getString("DLY_LIMIT"));
      record.setLrnum(rs.getString("LRNUM"));
      record.setBusdesig(rs.getString("BUSDESIG"));
      record.setCreatedby(rs.getString("CREATED_BY"));
      record.setMnthlimit(rs.getString("MNTH_LIMIT"));
      record.setNationalty(rs.getString("NATIONALTY"));
      record.setExtn5(rs.getString("EXTN5"));
      record.setRstatus(rs.getString("RSTATUS"));
      record.setCurrappstatus(rs.getString("CURR_APP_STATUS"));
      record.setPstcity(rs.getString("PSTCITY"));
      record.setProfagcode(rs.getString("PROFAGCODE"));
      record.setAdminlastcmt(rs.getString("ADMIN_LAST_CMT"));
      record.setProfcont2(rs.getString("PROFCONT2"));
      record.setModifiedby(rs.getString("MODIFIED_BY"));
      record.setProfcont1(rs.getString("PROFCONT1"));
      record.setPhyaddr(rs.getString("PHYADDR"));
      record.setMadeby(rs.getString("MADE_BY"));
      record.setAccnum3(rs.getString("ACCNUM3"));
      record.setTrdname(rs.getString("TRDNAME"));
      record.setAccnum2(rs.getString("ACCNUM2"));
      record.setCheckerlastcmt(rs.getString("CHECKER_LAST_CMT"));
      record.setAccnum1(rs.getString("ACCNUM1"));
      ps.close();
      logger.trace("loadKBAgencyRecord	" + record + "	");
      releaseDatabaseConnection(con, closeConnection);
      return record;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBAgencyRecord loadKBAgencyRecord(String id) throws Exception {
    return loadKBAgencyRecord(id, null, true);
  }

  public int insertKBAgencyRecord(KBAgencyRecord record, Connection con, boolean closeConnection)
      throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query ="INSERT INTO agency ";
      Query +="(";
      Query +="BUSSTAT,AG_TYPE,PSTADDR,PROFPROV,CHECKED_BY,CREATED_AT,MAKER_LAST_CMT,BRNCHCODE,INSTITUTION_ID,DOMIBRNCH,SERVPK,MAST_AGCODE,PSTZIP,BUSNAME,ID,MODIFIED_AT,MADE_AT,EXTN4,BUSLOC,EXTN3,EXTN2,BUSNATIONALITY,CHECKED_AT,EXTN1,DLY_LIMIT,LRNUM,BUSDESIG,CREATED_BY,MNTH_LIMIT,NATIONALTY,EXTN5,RSTATUS,CURR_APP_STATUS,PSTCITY,PROFAGCODE,ADMIN_LAST_CMT,PROFCONT2,MODIFIED_BY,PROFCONT1,PHYADDR,MADE_BY,ACCNUM3,TRDNAME,ACCNUM2,CHECKER_LAST_CMT,ACCNUM1";
      Query +=")";
      Query += " VALUES " ;
      Query +="(";
      Query +="?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?";
      Query +=")";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("insertKBAgencyRecords	" + closeConnection + "	" + Query);
      if (isOracleDatabase()) {
        ps = con.prepareStatement(Query,new String[]{"ID"});
      }
      else {
        ps = con.prepareStatement(Query,Statement.RETURN_GENERATED_KEYS);
      }
      setStringValue(ps, 1, record.getBusstat());
      setStringValue(ps, 2, record.getAgtype());
      setStringValue(ps, 3, record.getPstaddr());
      setStringValue(ps, 4, record.getProfprov());
      setStringValue(ps, 5, record.getCheckedby());
      setDateValue(ps, 6, fd.getSQLDateObject(record.getCreatedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 7, record.getMakerlastcmt());
      setStringValue(ps, 8, record.getBrnchcode());
      setStringValue(ps, 9, record.getInstitutionid());
      setStringValue(ps, 10, record.getDomibrnch());
      setStringValue(ps, 11, record.getServpk());
      setStringValue(ps, 12, record.getMastagcode());
      setStringValue(ps, 13, record.getPstzip());
      setStringValue(ps, 14, record.getBusname());
      setStringValue(ps, 15, record.getId());
      setDateValue(ps, 16, fd.getSQLDateObject(record.getModifiedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 17, record.getMadeat());
      setStringValue(ps, 18, record.getExtn4());
      setStringValue(ps, 19, record.getBusloc());
      setStringValue(ps, 20, record.getExtn3());
      setStringValue(ps, 21, record.getExtn2());
      setStringValue(ps, 22, record.getBusnationality());
      setStringValue(ps, 23, record.getCheckedat());
      setStringValue(ps, 24, record.getExtn1());
      setStringValue(ps, 25, record.getDlylimit());
      setStringValue(ps, 26, record.getLrnum());
      setStringValue(ps, 27, record.getBusdesig());
      setStringValue(ps, 28, record.getCreatedby());
      setStringValue(ps, 29, record.getMnthlimit());
      setStringValue(ps, 30, record.getNationalty());
      setStringValue(ps, 31, record.getExtn5());
      setStringValue(ps, 32, record.getRstatus());
      setStringValue(ps, 33, record.getCurrappstatus());
      setStringValue(ps, 34, record.getPstcity());
      setStringValue(ps, 35, record.getProfagcode());
      setStringValue(ps, 36, record.getAdminlastcmt());
      setStringValue(ps, 37, record.getProfcont2());
      setStringValue(ps, 38, record.getModifiedby());
      setStringValue(ps, 39, record.getProfcont1());
      setStringValue(ps, 40, record.getPhyaddr());
      setStringValue(ps, 41, record.getMadeby());
      setStringValue(ps, 42, record.getAccnum3());
      setStringValue(ps, 43, record.getTrdname());
      setStringValue(ps, 44, record.getAccnum2());
      setStringValue(ps, 45, record.getCheckerlastcmt());
      setStringValue(ps, 46, record.getAccnum1());
      boolean result = ps.execute();
      logger.trace("insertKBAgencyRecord	" + result + "	");
      int resultID = -1;
      rs = ps.getGeneratedKeys();
      if (rs.next()) {
        resultID = rs.getInt(1);
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return resultID;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public int insertKBAgencyRecord(KBAgencyRecord record) throws Exception {
    return insertKBAgencyRecord(record, null, true);
  }

  public boolean updateKBAgencyRecord(KBAgencyRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      KBAgencyRecord currentRecord = loadKBAgencyRecord(record.getId());
      String currentRecordContent = StringUtils.noNull(currentRecord);
      String Query = "UPDATE agency SET ";
      Query += "BUSSTAT = ?,";
          Query += "AG_TYPE = ?,";
          Query += "PSTADDR = ?,";
          Query += "PROFPROV = ?,";
          Query += "CHECKED_BY = ?,";
          Query += "CREATED_AT = ?,";
          Query += "MAKER_LAST_CMT = ?,";
          Query += "BRNCHCODE = ?,";
          Query += "INSTITUTION_ID = ?,";
          Query += "DOMIBRNCH = ?,";
          Query += "SERVPK = ?,";
          Query += "MAST_AGCODE = ?,";
          Query += "PSTZIP = ?,";
          Query += "BUSNAME = ?,";
          Query += "MODIFIED_AT = ?,";
          Query += "MADE_AT = ?,";
          Query += "EXTN4 = ?,";
          Query += "BUSLOC = ?,";
          Query += "EXTN3 = ?,";
          Query += "EXTN2 = ?,";
          Query += "BUSNATIONALITY = ?,";
          Query += "CHECKED_AT = ?,";
          Query += "EXTN1 = ?,";
          Query += "DLY_LIMIT = ?,";
          Query += "LRNUM = ?,";
          Query += "BUSDESIG = ?,";
          Query += "CREATED_BY = ?,";
          Query += "MNTH_LIMIT = ?,";
          Query += "NATIONALTY = ?,";
          Query += "EXTN5 = ?,";
          Query += "RSTATUS = ?,";
          Query += "CURR_APP_STATUS = ?,";
          Query += "PSTCITY = ?,";
          Query += "PROFAGCODE = ?,";
          Query += "ADMIN_LAST_CMT = ?,";
          Query += "PROFCONT2 = ?,";
          Query += "MODIFIED_BY = ?,";
          Query += "PROFCONT1 = ?,";
          Query += "PHYADDR = ?,";
          Query += "MADE_BY = ?,";
          Query += "ACCNUM3 = ?,";
          Query += "TRDNAME = ?,";
          Query += "ACCNUM2 = ?,";
          Query += "CHECKER_LAST_CMT = ?,";
          Query += "ACCNUM1 = ?";
      Query += " WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("updateKBAgencyRecord	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      setStringValue(ps, 1, record.getBusstat());
      setStringValue(ps, 2, record.getAgtype());
      setStringValue(ps, 3, record.getPstaddr());
      setStringValue(ps, 4, record.getProfprov());
      setStringValue(ps, 5, record.getCheckedby());
      setDateValue(ps, 6, fd.getSQLDateObject(record.getCreatedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 7, record.getMakerlastcmt());
      setStringValue(ps, 8, record.getBrnchcode());
      setStringValue(ps, 9, record.getInstitutionid());
      setStringValue(ps, 10, record.getDomibrnch());
      setStringValue(ps, 11, record.getServpk());
      setStringValue(ps, 12, record.getMastagcode());
      setStringValue(ps, 13, record.getPstzip());
      setStringValue(ps, 14, record.getBusname());
      setDateValue(ps, 15, fd.getSQLDateObject(record.getModifiedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 16, record.getMadeat());
      setStringValue(ps, 17, record.getExtn4());
      setStringValue(ps, 18, record.getBusloc());
      setStringValue(ps, 19, record.getExtn3());
      setStringValue(ps, 20, record.getExtn2());
      setStringValue(ps, 21, record.getBusnationality());
      setStringValue(ps, 22, record.getCheckedat());
      setStringValue(ps, 23, record.getExtn1());
      setStringValue(ps, 24, record.getDlylimit());
      setStringValue(ps, 25, record.getLrnum());
      setStringValue(ps, 26, record.getBusdesig());
      setStringValue(ps, 27, record.getCreatedby());
      setStringValue(ps, 28, record.getMnthlimit());
      setStringValue(ps, 29, record.getNationalty());
      setStringValue(ps, 30, record.getExtn5());
      setStringValue(ps, 31, record.getRstatus());
      setStringValue(ps, 32, record.getCurrappstatus());
      setStringValue(ps, 33, record.getPstcity());
      setStringValue(ps, 34, record.getProfagcode());
      setStringValue(ps, 35, record.getAdminlastcmt());
      setStringValue(ps, 36, record.getProfcont2());
      setStringValue(ps, 37, record.getModifiedby());
      setStringValue(ps, 38, record.getProfcont1());
      setStringValue(ps, 39, record.getPhyaddr());
      setStringValue(ps, 40, record.getMadeby());
      setStringValue(ps, 41, record.getAccnum3());
      setStringValue(ps, 42, record.getTrdname());
      setStringValue(ps, 43, record.getAccnum2());
      setStringValue(ps, 44, record.getCheckerlastcmt());
      setStringValue(ps, 45, record.getAccnum1());
      ps.setString(46, StringUtils.noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("updateKBAgencyRecord	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean updateKBAgencyRecord(KBAgencyRecord record) throws Exception {
    return updateKBAgencyRecord(record, null, true);
  }

  public boolean deleteKBAgencyRecord(KBAgencyRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query = "DELETE FROM agency WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("deleteKBAgencyRecord	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      ps.setString(1, noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("deleteKBAgencyRecord	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean deleteKBAgencyRecord(KBAgencyRecord record) throws Exception {
    return deleteKBAgencyRecord(record, null, true);
  }

  public KBAgencyRecord[] searchKBAgencyRecords(KBAgencyRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "BUSSTAT", formatSearchField(searchRecord.getBusstat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "AG_TYPE", formatSearchField(searchRecord.getAgtype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PSTADDR", formatSearchField(searchRecord.getPstaddr()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PROFPROV", formatSearchField(searchRecord.getProfprov()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CHECKED_BY", formatSearchField(searchRecord.getCheckedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MAKER_LAST_CMT", formatSearchField(searchRecord.getMakerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "BRNCHCODE", formatSearchField(searchRecord.getBrnchcode()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "DOMIBRNCH", formatSearchField(searchRecord.getDomibrnch()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "SERVPK", formatSearchField(searchRecord.getServpk()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MAST_AGCODE", formatSearchField(searchRecord.getMastagcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PSTZIP", formatSearchField(searchRecord.getPstzip()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "BUSNAME", formatSearchField(searchRecord.getBusname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MADE_AT", formatSearchField(searchRecord.getMadeat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EXTN4", formatSearchField(searchRecord.getExtn4()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "BUSLOC", formatSearchField(searchRecord.getBusloc()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EXTN3", formatSearchField(searchRecord.getExtn3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EXTN2", formatSearchField(searchRecord.getExtn2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "BUSNATIONALITY", formatSearchField(searchRecord.getBusnationality()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHECKED_AT", formatSearchField(searchRecord.getCheckedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EXTN1", formatSearchField(searchRecord.getExtn1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "DLY_LIMIT", formatSearchField(searchRecord.getDlylimit()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "LRNUM", formatSearchField(searchRecord.getLrnum()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "BUSDESIG", formatSearchField(searchRecord.getBusdesig()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MNTH_LIMIT", formatSearchField(searchRecord.getMnthlimit()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "NATIONALTY", formatSearchField(searchRecord.getNationalty()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EXTN5", formatSearchField(searchRecord.getExtn5()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CURR_APP_STATUS", formatSearchField(searchRecord.getCurrappstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PSTCITY", formatSearchField(searchRecord.getPstcity()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "PROFAGCODE", formatSearchField(searchRecord.getProfagcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "ADMIN_LAST_CMT", formatSearchField(searchRecord.getAdminlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PROFCONT2", formatSearchField(searchRecord.getProfcont2()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PROFCONT1", formatSearchField(searchRecord.getProfcont1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PHYADDR", formatSearchField(searchRecord.getPhyaddr()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MADE_BY", formatSearchField(searchRecord.getMadeby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ACCNUM3", formatSearchField(searchRecord.getAccnum3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "TRDNAME", formatSearchField(searchRecord.getTrdname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ACCNUM2", formatSearchField(searchRecord.getAccnum2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHECKER_LAST_CMT", formatSearchField(searchRecord.getCheckerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ACCNUM1", formatSearchField(searchRecord.getAccnum1()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from agency " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM agency ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM agency $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBAgencyRecords(Query);
  }

  public KBAgencyRecord[] searchKBAgencyRecordsExactUpper(KBAgencyRecord searchRecord) throws
      Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "BUSSTAT", formatSearchField(searchRecord.getBusstat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "AG_TYPE", formatSearchField(searchRecord.getAgtype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PSTADDR", formatSearchField(searchRecord.getPstaddr()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PROFPROV", formatSearchField(searchRecord.getProfprov()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKED_BY", formatSearchField(searchRecord.getCheckedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MAKER_LAST_CMT", formatSearchField(searchRecord.getMakerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "BRNCHCODE", formatSearchField(searchRecord.getBrnchcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "DOMIBRNCH", formatSearchField(searchRecord.getDomibrnch()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "SERVPK", formatSearchField(searchRecord.getServpk()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MAST_AGCODE", formatSearchField(searchRecord.getMastagcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PSTZIP", formatSearchField(searchRecord.getPstzip()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "BUSNAME", formatSearchField(searchRecord.getBusname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MADE_AT", formatSearchField(searchRecord.getMadeat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EXTN4", formatSearchField(searchRecord.getExtn4()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "BUSLOC", formatSearchField(searchRecord.getBusloc()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EXTN3", formatSearchField(searchRecord.getExtn3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EXTN2", formatSearchField(searchRecord.getExtn2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "BUSNATIONALITY", formatSearchField(searchRecord.getBusnationality()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKED_AT", formatSearchField(searchRecord.getCheckedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EXTN1", formatSearchField(searchRecord.getExtn1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "DLY_LIMIT", formatSearchField(searchRecord.getDlylimit()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LRNUM", formatSearchField(searchRecord.getLrnum()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "BUSDESIG", formatSearchField(searchRecord.getBusdesig()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MNTH_LIMIT", formatSearchField(searchRecord.getMnthlimit()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "NATIONALTY", formatSearchField(searchRecord.getNationalty()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EXTN5", formatSearchField(searchRecord.getExtn5()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CURR_APP_STATUS", formatSearchField(searchRecord.getCurrappstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PSTCITY", formatSearchField(searchRecord.getPstcity()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PROFAGCODE", formatSearchField(searchRecord.getProfagcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ADMIN_LAST_CMT", formatSearchField(searchRecord.getAdminlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PROFCONT2", formatSearchField(searchRecord.getProfcont2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PROFCONT1", formatSearchField(searchRecord.getProfcont1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PHYADDR", formatSearchField(searchRecord.getPhyaddr()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MADE_BY", formatSearchField(searchRecord.getMadeby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ACCNUM3", formatSearchField(searchRecord.getAccnum3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "TRDNAME", formatSearchField(searchRecord.getTrdname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ACCNUM2", formatSearchField(searchRecord.getAccnum2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKER_LAST_CMT", formatSearchField(searchRecord.getCheckerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ACCNUM1", formatSearchField(searchRecord.getAccnum1()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from agency " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM agency ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM agency $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBAgencyRecords(Query);
  }

  public int loadKBAgencyRecordCount(KBAgencyRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "BUSSTAT", formatSearchField(searchRecord.getBusstat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "AG_TYPE", formatSearchField(searchRecord.getAgtype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PSTADDR", formatSearchField(searchRecord.getPstaddr()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PROFPROV", formatSearchField(searchRecord.getProfprov()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CHECKED_BY", formatSearchField(searchRecord.getCheckedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MAKER_LAST_CMT", formatSearchField(searchRecord.getMakerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "BRNCHCODE", formatSearchField(searchRecord.getBrnchcode()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "DOMIBRNCH", formatSearchField(searchRecord.getDomibrnch()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "SERVPK", formatSearchField(searchRecord.getServpk()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MAST_AGCODE", formatSearchField(searchRecord.getMastagcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PSTZIP", formatSearchField(searchRecord.getPstzip()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "BUSNAME", formatSearchField(searchRecord.getBusname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MADE_AT", formatSearchField(searchRecord.getMadeat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EXTN4", formatSearchField(searchRecord.getExtn4()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "BUSLOC", formatSearchField(searchRecord.getBusloc()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EXTN3", formatSearchField(searchRecord.getExtn3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EXTN2", formatSearchField(searchRecord.getExtn2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "BUSNATIONALITY", formatSearchField(searchRecord.getBusnationality()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHECKED_AT", formatSearchField(searchRecord.getCheckedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EXTN1", formatSearchField(searchRecord.getExtn1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "DLY_LIMIT", formatSearchField(searchRecord.getDlylimit()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "LRNUM", formatSearchField(searchRecord.getLrnum()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "BUSDESIG", formatSearchField(searchRecord.getBusdesig()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MNTH_LIMIT", formatSearchField(searchRecord.getMnthlimit()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "NATIONALTY", formatSearchField(searchRecord.getNationalty()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EXTN5", formatSearchField(searchRecord.getExtn5()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CURR_APP_STATUS", formatSearchField(searchRecord.getCurrappstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PSTCITY", formatSearchField(searchRecord.getPstcity()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "PROFAGCODE", formatSearchField(searchRecord.getProfagcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "ADMIN_LAST_CMT", formatSearchField(searchRecord.getAdminlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PROFCONT2", formatSearchField(searchRecord.getProfcont2()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PROFCONT1", formatSearchField(searchRecord.getProfcont1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PHYADDR", formatSearchField(searchRecord.getPhyaddr()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MADE_BY", formatSearchField(searchRecord.getMadeby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ACCNUM3", formatSearchField(searchRecord.getAccnum3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "TRDNAME", formatSearchField(searchRecord.getTrdname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ACCNUM2", formatSearchField(searchRecord.getAccnum2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHECKER_LAST_CMT", formatSearchField(searchRecord.getCheckerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ACCNUM1", formatSearchField(searchRecord.getAccnum1()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from agency " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }

  public int loadKBAgencyRecordCountExact(KBAgencyRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "BUSSTAT", formatSearchField(searchRecord.getBusstat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "AG_TYPE", formatSearchField(searchRecord.getAgtype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PSTADDR", formatSearchField(searchRecord.getPstaddr()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PROFPROV", formatSearchField(searchRecord.getProfprov()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKED_BY", formatSearchField(searchRecord.getCheckedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MAKER_LAST_CMT", formatSearchField(searchRecord.getMakerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "BRNCHCODE", formatSearchField(searchRecord.getBrnchcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "DOMIBRNCH", formatSearchField(searchRecord.getDomibrnch()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "SERVPK", formatSearchField(searchRecord.getServpk()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MAST_AGCODE", formatSearchField(searchRecord.getMastagcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PSTZIP", formatSearchField(searchRecord.getPstzip()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "BUSNAME", formatSearchField(searchRecord.getBusname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MADE_AT", formatSearchField(searchRecord.getMadeat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EXTN4", formatSearchField(searchRecord.getExtn4()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "BUSLOC", formatSearchField(searchRecord.getBusloc()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EXTN3", formatSearchField(searchRecord.getExtn3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EXTN2", formatSearchField(searchRecord.getExtn2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "BUSNATIONALITY", formatSearchField(searchRecord.getBusnationality()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKED_AT", formatSearchField(searchRecord.getCheckedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EXTN1", formatSearchField(searchRecord.getExtn1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "DLY_LIMIT", formatSearchField(searchRecord.getDlylimit()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LRNUM", formatSearchField(searchRecord.getLrnum()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "BUSDESIG", formatSearchField(searchRecord.getBusdesig()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MNTH_LIMIT", formatSearchField(searchRecord.getMnthlimit()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "NATIONALTY", formatSearchField(searchRecord.getNationalty()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EXTN5", formatSearchField(searchRecord.getExtn5()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CURR_APP_STATUS", formatSearchField(searchRecord.getCurrappstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PSTCITY", formatSearchField(searchRecord.getPstcity()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PROFAGCODE", formatSearchField(searchRecord.getProfagcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ADMIN_LAST_CMT", formatSearchField(searchRecord.getAdminlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PROFCONT2", formatSearchField(searchRecord.getProfcont2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PROFCONT1", formatSearchField(searchRecord.getProfcont1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PHYADDR", formatSearchField(searchRecord.getPhyaddr()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MADE_BY", formatSearchField(searchRecord.getMadeby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ACCNUM3", formatSearchField(searchRecord.getAccnum3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "TRDNAME", formatSearchField(searchRecord.getTrdname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ACCNUM2", formatSearchField(searchRecord.getAccnum2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKER_LAST_CMT", formatSearchField(searchRecord.getCheckerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ACCNUM1", formatSearchField(searchRecord.getAccnum1()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from agency " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }
}
