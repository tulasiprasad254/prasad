// Author Tulasi Vara Prasad
package com.key.mb.dao;

import com.key.mb.common.KBDAO;
import com.key.mb.to.KBMobilemenumapRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class KBMobilemenumapDAO extends KBDAO {
  public static LogUtils logger = new LogUtils(KBMobilemenumapDAO.class.getName());

  public KBMobilemenumapRecord[] loadKBMobilemenumapRecords(String query, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      query = query + MAX_RECORD_LIMIT_APPENDER;
      query = updateQuery(query);
      logger.trace("loadKBMobilemenumapRecords	" + closeConnection + "	" + query);
      ps = con.prepareStatement(query);
      rs = ps.executeQuery();
      ArrayList recordSet = new ArrayList();
      while(rs.next()) {
        KBMobilemenumapRecord record = new KBMobilemenumapRecord();
        record.setFtext(rs.getString("FTEXT"));
        record.setFfldtype(rs.getString("FFLDTYPE"));
        record.setAccesscode(rs.getString("ACCESS_CODE"));
        record.setLang2msg(rs.getString("LANG2_MSG"));
        record.setFseq(rs.getString("FSEQ"));
        record.setCreatedat(rs.getString("CREATED_AT"));
        record.setActiveflag(rs.getString("ACTIVE_FLAG"));
        record.setFsesscont(rs.getString("FSESSCONT"));
        record.setFfldcode(rs.getString("FFLDCODE"));
        record.setLangcode(rs.getString("LANGCODE"));
        record.setActionid(rs.getString("ACTION_ID"));
        record.setServiceid(rs.getString("SERVICE_ID"));
        record.setUssd(rs.getString("USSD"));
        record.setId(rs.getString("ID"));
        record.setNewsess(rs.getString("NEWSESS"));
        record.setLang3msg(rs.getString("LANG3_MSG"));
        record.setModifiedat(rs.getString("MODIFIED_AT"));
        record.setContentlength(rs.getString("CONTENT_LENGTH"));
        record.setExtn4(rs.getString("EXTN4"));
        record.setExtn3(rs.getString("EXTN3"));
        record.setExtn2(rs.getString("EXTN2"));
        record.setLang4msg(rs.getString("LANG4_MSG"));
        record.setExtn1(rs.getString("EXTN1"));
        record.setMenutype(rs.getString("MENU_TYPE"));
        record.setOverridecode(rs.getString("OVERRIDE_CODE"));
        record.setWap(rs.getString("WAP"));
        record.setFconttype(rs.getString("FCONTTYPE"));
        record.setFwidth(rs.getString("FWIDTH"));
        record.setCreatedby(rs.getString("CREATED_BY"));
        record.setRstatus(rs.getString("RSTATUS"));
        record.setParentid(rs.getString("PARENT_ID"));
        record.setFfldlen(rs.getString("FFLDLEN"));
        record.setModifiedby(rs.getString("MODIFIED_BY"));
        record.setFheight(rs.getString("FHEIGHT"));
        record.setScreenid(rs.getString("SCREEN_ID"));
        recordSet.add(record);
      }
      logger.trace("loadKBMobilemenumapRecords:Records Fetched:" + recordSet.size());
      KBMobilemenumapRecord[] tempKBMobilemenumapRecords = new KBMobilemenumapRecord[recordSet.size()];
      for (int index = 0; index < recordSet.size(); index++) {
        tempKBMobilemenumapRecords[index] = (KBMobilemenumapRecord)(recordSet.get(index));
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return tempKBMobilemenumapRecords;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBMobilemenumapRecord[] loadKBMobilemenumapRecords(String query) throws Exception {
    return loadKBMobilemenumapRecords(query, null, true);
  }

  public KBMobilemenumapRecord loadFirstKBMobilemenumapRecord(String query) throws Exception {
    KBMobilemenumapRecord[] results = loadKBMobilemenumapRecords(query);
    if (results == null) {
      return null;
    }
    if(results.length < 1) {
      return null;
    }
    return results[0];
  }

  public KBMobilemenumapRecord loadKBMobilemenumapRecord(String id, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      String Query = "SELECT * FROM mobile_menu_map WHERE (ID = ?)";
      Query = updateQuery(Query);
      logger.trace("loadKBMobilemenumapRecords	" + closeConnection + "	" + id);
      ps = con.prepareStatement(Query);
      ps.setString(1,id);
      rs = ps.executeQuery();
      if (!rs.next()) {
        ps.close();
        releaseDatabaseConnection(con, closeConnection);
        return null;
      }
      KBMobilemenumapRecord record = new KBMobilemenumapRecord();
      record.setFtext(rs.getString("FTEXT"));
      record.setFfldtype(rs.getString("FFLDTYPE"));
      record.setAccesscode(rs.getString("ACCESS_CODE"));
      record.setLang2msg(rs.getString("LANG2_MSG"));
      record.setFseq(rs.getString("FSEQ"));
      record.setCreatedat(rs.getString("CREATED_AT"));
      record.setActiveflag(rs.getString("ACTIVE_FLAG"));
      record.setFsesscont(rs.getString("FSESSCONT"));
      record.setFfldcode(rs.getString("FFLDCODE"));
      record.setLangcode(rs.getString("LANGCODE"));
      record.setActionid(rs.getString("ACTION_ID"));
      record.setServiceid(rs.getString("SERVICE_ID"));
      record.setUssd(rs.getString("USSD"));
      record.setId(rs.getString("ID"));
      record.setNewsess(rs.getString("NEWSESS"));
      record.setLang3msg(rs.getString("LANG3_MSG"));
      record.setModifiedat(rs.getString("MODIFIED_AT"));
      record.setContentlength(rs.getString("CONTENT_LENGTH"));
      record.setExtn4(rs.getString("EXTN4"));
      record.setExtn3(rs.getString("EXTN3"));
      record.setExtn2(rs.getString("EXTN2"));
      record.setLang4msg(rs.getString("LANG4_MSG"));
      record.setExtn1(rs.getString("EXTN1"));
      record.setMenutype(rs.getString("MENU_TYPE"));
      record.setOverridecode(rs.getString("OVERRIDE_CODE"));
      record.setWap(rs.getString("WAP"));
      record.setFconttype(rs.getString("FCONTTYPE"));
      record.setFwidth(rs.getString("FWIDTH"));
      record.setCreatedby(rs.getString("CREATED_BY"));
      record.setRstatus(rs.getString("RSTATUS"));
      record.setParentid(rs.getString("PARENT_ID"));
      record.setFfldlen(rs.getString("FFLDLEN"));
      record.setModifiedby(rs.getString("MODIFIED_BY"));
      record.setFheight(rs.getString("FHEIGHT"));
      record.setScreenid(rs.getString("SCREEN_ID"));
      ps.close();
      logger.trace("loadKBMobilemenumapRecord	" + record + "	");
      releaseDatabaseConnection(con, closeConnection);
      return record;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBMobilemenumapRecord loadKBMobilemenumapRecord(String id) throws Exception {
    return loadKBMobilemenumapRecord(id, null, true);
  }

  public int insertKBMobilemenumapRecord(KBMobilemenumapRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query ="INSERT INTO mobile_menu_map ";
      Query +="(";
      Query +="FTEXT,FFLDTYPE,ACCESS_CODE,LANG2_MSG,FSEQ,CREATED_AT,ACTIVE_FLAG,FSESSCONT,FFLDCODE,LANGCODE,ACTION_ID,SERVICE_ID,USSD,ID,NEWSESS,LANG3_MSG,MODIFIED_AT,CONTENT_LENGTH,EXTN4,EXTN3,EXTN2,LANG4_MSG,EXTN1,MENU_TYPE,OVERRIDE_CODE,WAP,FCONTTYPE,FWIDTH,CREATED_BY,RSTATUS,PARENT_ID,FFLDLEN,MODIFIED_BY,FHEIGHT,SCREEN_ID";
      Query +=")";
      Query += " VALUES " ;
      Query +="(";
      Query +="?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?";
      Query +=")";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("insertKBMobilemenumapRecords	" + closeConnection + "	" + Query);
      if (isOracleDatabase()) {
        ps = con.prepareStatement(Query,new String[]{"ID"});
      }
      else {
        ps = con.prepareStatement(Query,Statement.RETURN_GENERATED_KEYS);
      }
      setStringValue(ps, 1, record.getFtext());
      setStringValue(ps, 2, record.getFfldtype());
      setStringValue(ps, 3, record.getAccesscode());
      setStringValue(ps, 4, record.getLang2msg());
      setStringValue(ps, 5, record.getFseq());
      setDateValue(ps, 6, fd.getSQLDateObject(record.getCreatedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 7, record.getActiveflag());
      setStringValue(ps, 8, record.getFsesscont());
      setStringValue(ps, 9, record.getFfldcode());
      setStringValue(ps, 10, record.getLangcode());
      setStringValue(ps, 11, record.getActionid());
      setStringValue(ps, 12, record.getServiceid());
      setStringValue(ps, 13, record.getUssd());
      setStringValue(ps, 14, record.getId());
      setStringValue(ps, 15, record.getNewsess());
      setStringValue(ps, 16, record.getLang3msg());
      setDateValue(ps, 17, fd.getSQLDateObject(record.getModifiedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 18, record.getContentlength());
      setStringValue(ps, 19, record.getExtn4());
      setStringValue(ps, 20, record.getExtn3());
      setStringValue(ps, 21, record.getExtn2());
      setStringValue(ps, 22, record.getLang4msg());
      setStringValue(ps, 23, record.getExtn1());
      setStringValue(ps, 24, record.getMenutype());
      setStringValue(ps, 25, record.getOverridecode());
      setStringValue(ps, 26, record.getWap());
      setStringValue(ps, 27, record.getFconttype());
      setStringValue(ps, 28, record.getFwidth());
      setStringValue(ps, 29, record.getCreatedby());
      setStringValue(ps, 30, record.getRstatus());
      setStringValue(ps, 31, record.getParentid());
      setStringValue(ps, 32, record.getFfldlen());
      setStringValue(ps, 33, record.getModifiedby());
      setStringValue(ps, 34, record.getFheight());
      setStringValue(ps, 35, record.getScreenid());
      boolean result = ps.execute();
      logger.trace("insertKBMobilemenumapRecord	" + result + "	");
      int resultID = -1;
      rs = ps.getGeneratedKeys();
      if (rs.next()) {
        resultID = rs.getInt(1);
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return resultID;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public int insertKBMobilemenumapRecord(KBMobilemenumapRecord record) throws Exception {
    return insertKBMobilemenumapRecord(record, null, true);
  }

  public boolean updateKBMobilemenumapRecord(KBMobilemenumapRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      KBMobilemenumapRecord currentRecord = loadKBMobilemenumapRecord(record.getId());
      String currentRecordContent = StringUtils.noNull(currentRecord);
      String Query = "UPDATE mobile_menu_map SET ";
      Query += "FTEXT = ?,";
          Query += "FFLDTYPE = ?,";
          Query += "ACCESS_CODE = ?,";
          Query += "LANG2_MSG = ?,";
          Query += "FSEQ = ?,";
          Query += "CREATED_AT = ?,";
          Query += "ACTIVE_FLAG = ?,";
          Query += "FSESSCONT = ?,";
          Query += "FFLDCODE = ?,";
          Query += "LANGCODE = ?,";
          Query += "ACTION_ID = ?,";
          Query += "SERVICE_ID = ?,";
          Query += "USSD = ?,";
          Query += "NEWSESS = ?,";
          Query += "LANG3_MSG = ?,";
          Query += "MODIFIED_AT = ?,";
          Query += "CONTENT_LENGTH = ?,";
          Query += "EXTN4 = ?,";
          Query += "EXTN3 = ?,";
          Query += "EXTN2 = ?,";
          Query += "LANG4_MSG = ?,";
          Query += "EXTN1 = ?,";
          Query += "MENU_TYPE = ?,";
          Query += "OVERRIDE_CODE = ?,";
          Query += "WAP = ?,";
          Query += "FCONTTYPE = ?,";
          Query += "FWIDTH = ?,";
          Query += "CREATED_BY = ?,";
          Query += "RSTATUS = ?,";
          Query += "PARENT_ID = ?,";
          Query += "FFLDLEN = ?,";
          Query += "MODIFIED_BY = ?,";
          Query += "FHEIGHT = ?,";
          Query += "SCREEN_ID = ?";
      Query += " WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("updateKBMobilemenumapRecord	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      setStringValue(ps, 1, record.getFtext());
      setStringValue(ps, 2, record.getFfldtype());
      setStringValue(ps, 3, record.getAccesscode());
      setStringValue(ps, 4, record.getLang2msg());
      setStringValue(ps, 5, record.getFseq());
      setDateValue(ps, 6, fd.getSQLDateObject(record.getCreatedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 7, record.getActiveflag());
      setStringValue(ps, 8, record.getFsesscont());
      setStringValue(ps, 9, record.getFfldcode());
      setStringValue(ps, 10, record.getLangcode());
      setStringValue(ps, 11, record.getActionid());
      setStringValue(ps, 12, record.getServiceid());
      setStringValue(ps, 13, record.getUssd());
      setStringValue(ps, 14, record.getNewsess());
      setStringValue(ps, 15, record.getLang3msg());
      setDateValue(ps, 16, fd.getSQLDateObject(record.getModifiedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 17, record.getContentlength());
      setStringValue(ps, 18, record.getExtn4());
      setStringValue(ps, 19, record.getExtn3());
      setStringValue(ps, 20, record.getExtn2());
      setStringValue(ps, 21, record.getLang4msg());
      setStringValue(ps, 22, record.getExtn1());
      setStringValue(ps, 23, record.getMenutype());
      setStringValue(ps, 24, record.getOverridecode());
      setStringValue(ps, 25, record.getWap());
      setStringValue(ps, 26, record.getFconttype());
      setStringValue(ps, 27, record.getFwidth());
      setStringValue(ps, 28, record.getCreatedby());
      setStringValue(ps, 29, record.getRstatus());
      setStringValue(ps, 30, record.getParentid());
      setStringValue(ps, 31, record.getFfldlen());
      setStringValue(ps, 32, record.getModifiedby());
      setStringValue(ps, 33, record.getFheight());
      setStringValue(ps, 34, record.getScreenid());
      ps.setString(35, StringUtils.noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("updateKBMobilemenumapRecord	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean updateKBMobilemenumapRecord(KBMobilemenumapRecord record) throws Exception {
    return updateKBMobilemenumapRecord(record, null, true);
  }

  public boolean deleteKBMobilemenumapRecord(KBMobilemenumapRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query = "DELETE FROM mobile_menu_map WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("deleteKBMobilemenumapRecord	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      ps.setString(1, noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("deleteKBMobilemenumapRecord	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean deleteKBMobilemenumapRecord(KBMobilemenumapRecord record) throws Exception {
    return deleteKBMobilemenumapRecord(record, null, true);
  }

  public KBMobilemenumapRecord[] searchKBMobilemenumapRecords(KBMobilemenumapRecord searchRecord)
      throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTEXT", formatSearchField(searchRecord.getFtext()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FFLDTYPE", formatSearchField(searchRecord.getFfldtype()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ACCESS_CODE", formatSearchField(searchRecord.getAccesscode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "LANG2_MSG", formatSearchField(searchRecord.getLang2msg()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FSEQ", formatSearchField(searchRecord.getFseq()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "ACTIVE_FLAG", formatSearchField(searchRecord.getActiveflag()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FSESSCONT", formatSearchField(searchRecord.getFsesscont()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FFLDCODE", formatSearchField(searchRecord.getFfldcode()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "LANGCODE", formatSearchField(searchRecord.getLangcode()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ACTION_ID", formatSearchField(searchRecord.getActionid()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "SERVICE_ID", formatSearchField(searchRecord.getServiceid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "USSD", formatSearchField(searchRecord.getUssd()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "NEWSESS", formatSearchField(searchRecord.getNewsess()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "LANG3_MSG", formatSearchField(searchRecord.getLang3msg()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CONTENT_LENGTH", formatSearchField(searchRecord.getContentlength()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EXTN4", formatSearchField(searchRecord.getExtn4()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EXTN3", formatSearchField(searchRecord.getExtn3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EXTN2", formatSearchField(searchRecord.getExtn2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "LANG4_MSG", formatSearchField(searchRecord.getLang4msg()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EXTN1", formatSearchField(searchRecord.getExtn1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MENU_TYPE", formatSearchField(searchRecord.getMenutype()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "OVERRIDE_CODE", formatSearchField(searchRecord.getOverridecode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "WAP", formatSearchField(searchRecord.getWap()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FCONTTYPE", formatSearchField(searchRecord.getFconttype()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FWIDTH", formatSearchField(searchRecord.getFwidth()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "PARENT_ID", formatSearchField(searchRecord.getParentid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FFLDLEN", formatSearchField(searchRecord.getFfldlen()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FHEIGHT", formatSearchField(searchRecord.getFheight()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "SCREEN_ID", formatSearchField(searchRecord.getScreenid()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from mobile_menu_map " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM mobile_menu_map ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM mobile_menu_map $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBMobilemenumapRecords(Query);
  }

  public KBMobilemenumapRecord[] searchKBMobilemenumapRecordsExactUpper(
      KBMobilemenumapRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTEXT", formatSearchField(searchRecord.getFtext()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FFLDTYPE", formatSearchField(searchRecord.getFfldtype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ACCESS_CODE", formatSearchField(searchRecord.getAccesscode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LANG2_MSG", formatSearchField(searchRecord.getLang2msg()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FSEQ", formatSearchField(searchRecord.getFseq()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ACTIVE_FLAG", formatSearchField(searchRecord.getActiveflag()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FSESSCONT", formatSearchField(searchRecord.getFsesscont()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FFLDCODE", formatSearchField(searchRecord.getFfldcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LANGCODE", formatSearchField(searchRecord.getLangcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ACTION_ID", formatSearchField(searchRecord.getActionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "SERVICE_ID", formatSearchField(searchRecord.getServiceid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "USSD", formatSearchField(searchRecord.getUssd()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "NEWSESS", formatSearchField(searchRecord.getNewsess()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LANG3_MSG", formatSearchField(searchRecord.getLang3msg()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CONTENT_LENGTH", formatSearchField(searchRecord.getContentlength()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EXTN4", formatSearchField(searchRecord.getExtn4()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EXTN3", formatSearchField(searchRecord.getExtn3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EXTN2", formatSearchField(searchRecord.getExtn2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LANG4_MSG", formatSearchField(searchRecord.getLang4msg()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EXTN1", formatSearchField(searchRecord.getExtn1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MENU_TYPE", formatSearchField(searchRecord.getMenutype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "OVERRIDE_CODE", formatSearchField(searchRecord.getOverridecode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "WAP", formatSearchField(searchRecord.getWap()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FCONTTYPE", formatSearchField(searchRecord.getFconttype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FWIDTH", formatSearchField(searchRecord.getFwidth()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PARENT_ID", formatSearchField(searchRecord.getParentid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FFLDLEN", formatSearchField(searchRecord.getFfldlen()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FHEIGHT", formatSearchField(searchRecord.getFheight()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "SCREEN_ID", formatSearchField(searchRecord.getScreenid()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from mobile_menu_map " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM mobile_menu_map ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM mobile_menu_map $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBMobilemenumapRecords(Query);
  }

  public int loadKBMobilemenumapRecordCount(KBMobilemenumapRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FTEXT", formatSearchField(searchRecord.getFtext()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FFLDTYPE", formatSearchField(searchRecord.getFfldtype()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ACCESS_CODE", formatSearchField(searchRecord.getAccesscode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "LANG2_MSG", formatSearchField(searchRecord.getLang2msg()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FSEQ", formatSearchField(searchRecord.getFseq()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "ACTIVE_FLAG", formatSearchField(searchRecord.getActiveflag()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FSESSCONT", formatSearchField(searchRecord.getFsesscont()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FFLDCODE", formatSearchField(searchRecord.getFfldcode()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "LANGCODE", formatSearchField(searchRecord.getLangcode()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ACTION_ID", formatSearchField(searchRecord.getActionid()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "SERVICE_ID", formatSearchField(searchRecord.getServiceid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "USSD", formatSearchField(searchRecord.getUssd()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "NEWSESS", formatSearchField(searchRecord.getNewsess()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "LANG3_MSG", formatSearchField(searchRecord.getLang3msg()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CONTENT_LENGTH", formatSearchField(searchRecord.getContentlength()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EXTN4", formatSearchField(searchRecord.getExtn4()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EXTN3", formatSearchField(searchRecord.getExtn3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EXTN2", formatSearchField(searchRecord.getExtn2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "LANG4_MSG", formatSearchField(searchRecord.getLang4msg()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "EXTN1", formatSearchField(searchRecord.getExtn1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MENU_TYPE", formatSearchField(searchRecord.getMenutype()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "OVERRIDE_CODE", formatSearchField(searchRecord.getOverridecode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "WAP", formatSearchField(searchRecord.getWap()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FCONTTYPE", formatSearchField(searchRecord.getFconttype()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "FWIDTH", formatSearchField(searchRecord.getFwidth()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "PARENT_ID", formatSearchField(searchRecord.getParentid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FFLDLEN", formatSearchField(searchRecord.getFfldlen()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "FHEIGHT", formatSearchField(searchRecord.getFheight()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "SCREEN_ID", formatSearchField(searchRecord.getScreenid()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from mobile_menu_map " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }

  public int loadKBMobilemenumapRecordCountExact(KBMobilemenumapRecord searchRecord) throws
      Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FTEXT", formatSearchField(searchRecord.getFtext()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FFLDTYPE", formatSearchField(searchRecord.getFfldtype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ACCESS_CODE", formatSearchField(searchRecord.getAccesscode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LANG2_MSG", formatSearchField(searchRecord.getLang2msg()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FSEQ", formatSearchField(searchRecord.getFseq()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ACTIVE_FLAG", formatSearchField(searchRecord.getActiveflag()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FSESSCONT", formatSearchField(searchRecord.getFsesscont()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FFLDCODE", formatSearchField(searchRecord.getFfldcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LANGCODE", formatSearchField(searchRecord.getLangcode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ACTION_ID", formatSearchField(searchRecord.getActionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "SERVICE_ID", formatSearchField(searchRecord.getServiceid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "USSD", formatSearchField(searchRecord.getUssd()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "NEWSESS", formatSearchField(searchRecord.getNewsess()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LANG3_MSG", formatSearchField(searchRecord.getLang3msg()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CONTENT_LENGTH", formatSearchField(searchRecord.getContentlength()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EXTN4", formatSearchField(searchRecord.getExtn4()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EXTN3", formatSearchField(searchRecord.getExtn3()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EXTN2", formatSearchField(searchRecord.getExtn2()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "LANG4_MSG", formatSearchField(searchRecord.getLang4msg()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "EXTN1", formatSearchField(searchRecord.getExtn1()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MENU_TYPE", formatSearchField(searchRecord.getMenutype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "OVERRIDE_CODE", formatSearchField(searchRecord.getOverridecode()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "WAP", formatSearchField(searchRecord.getWap()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FCONTTYPE", formatSearchField(searchRecord.getFconttype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FWIDTH", formatSearchField(searchRecord.getFwidth()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PARENT_ID", formatSearchField(searchRecord.getParentid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FFLDLEN", formatSearchField(searchRecord.getFfldlen()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "FHEIGHT", formatSearchField(searchRecord.getFheight()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "SCREEN_ID", formatSearchField(searchRecord.getScreenid()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from mobile_menu_map " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }
}
