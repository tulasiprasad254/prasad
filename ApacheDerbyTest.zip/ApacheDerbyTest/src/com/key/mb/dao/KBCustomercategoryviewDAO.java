// Author Tulasi Vara Prasad
package com.key.mb.dao;

import com.key.mb.common.KBDAO;
import com.key.mb.to.KBCustomercategoryviewRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class KBCustomercategoryviewDAO extends KBDAO {
  public static LogUtils logger = new LogUtils(KBCustomercategoryviewDAO.class.getName());

  public KBCustomercategoryviewRecord[] loadKBCustomercategoryviewRecords(String query,
      Connection con, boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      query = query + MAX_RECORD_LIMIT_APPENDER;
      query = updateQuery(query);
      logger.trace("loadKBCustomercategoryviewRecords	" + closeConnection + "	" + query);
      ps = con.prepareStatement(query);
      rs = ps.executeQuery();
      ArrayList recordSet = new ArrayList();
      while(rs.next()) {
        KBCustomercategoryviewRecord record = new KBCustomercategoryviewRecord();
        record.setMadeat(rs.getString("MADE_AT"));
        record.setChargetype(rs.getString("CHARGE_TYPE"));
        record.setCheckedat(rs.getString("CHECKED_AT"));
        record.setChargevalue(rs.getString("CHARGE_VALUE"));
        record.setStatusname(rs.getString("STATUS_NAME"));
        record.setCheckedby(rs.getString("CHECKED_BY"));
        record.setCreatedat(rs.getString("CREATED_AT"));
        record.setMintranlimit(rs.getString("MIN_TRAN_LIMIT"));
        record.setMakerlastcmt(rs.getString("MAKER_LAST_CMT"));
        record.setCreatedby(rs.getString("CREATED_BY"));
        record.setInstitutionid(rs.getString("INSTITUTION_ID"));
        record.setIname(rs.getString("INAME"));
        record.setRstatus(rs.getString("RSTATUS"));
        record.setCurrappstatus(rs.getString("CURR_APP_STATUS"));
        record.setAdminlastcmt(rs.getString("ADMIN_LAST_CMT"));
        record.setPerdaylimit(rs.getString("PER_DAY_LIMIT"));
        record.setCurrappstatusname(rs.getString("CURR_APP_STATUS_NAME"));
        record.setModifiedby(rs.getString("MODIFIED_BY"));
        record.setPertranlimit(rs.getString("PER_TRAN_LIMIT"));
        record.setId(rs.getString("ID"));
        record.setCategory(rs.getString("CATEGORY"));
        record.setMadeby(rs.getString("MADE_BY"));
        record.setModifiedat(rs.getString("MODIFIED_AT"));
        record.setCheckerlastcmt(rs.getString("CHECKER_LAST_CMT"));
        recordSet.add(record);
      }
      logger.trace("loadKBCustomercategoryviewRecords:Records Fetched:" + recordSet.size());
      KBCustomercategoryviewRecord[] tempKBCustomercategoryviewRecords = new KBCustomercategoryviewRecord[recordSet.size()];
      for (int index = 0; index < recordSet.size(); index++) {
        tempKBCustomercategoryviewRecords[index] = (KBCustomercategoryviewRecord)(recordSet.get(index));
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return tempKBCustomercategoryviewRecords;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBCustomercategoryviewRecord[] loadKBCustomercategoryviewRecords(String query) throws
      Exception {
    return loadKBCustomercategoryviewRecords(query, null, true);
  }

  public KBCustomercategoryviewRecord loadFirstKBCustomercategoryviewRecord(String query) throws
      Exception {
    KBCustomercategoryviewRecord[] results = loadKBCustomercategoryviewRecords(query);
    if (results == null) {
      return null;
    }
    if(results.length < 1) {
      return null;
    }
    return results[0];
  }

  public KBCustomercategoryviewRecord loadKBCustomercategoryviewRecord(String id, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      String Query = "SELECT * FROM customer_category_view WHERE (ID = ?)";
      Query = updateQuery(Query);
      logger.trace("loadKBCustomercategoryviewRecords	" + closeConnection + "	" + id);
      ps = con.prepareStatement(Query);
      ps.setString(1,id);
      rs = ps.executeQuery();
      if (!rs.next()) {
        ps.close();
        releaseDatabaseConnection(con, closeConnection);
        return null;
      }
      KBCustomercategoryviewRecord record = new KBCustomercategoryviewRecord();
      record.setMadeat(rs.getString("MADE_AT"));
      record.setChargetype(rs.getString("CHARGE_TYPE"));
      record.setCheckedat(rs.getString("CHECKED_AT"));
      record.setChargevalue(rs.getString("CHARGE_VALUE"));
      record.setStatusname(rs.getString("STATUS_NAME"));
      record.setCheckedby(rs.getString("CHECKED_BY"));
      record.setCreatedat(rs.getString("CREATED_AT"));
      record.setMintranlimit(rs.getString("MIN_TRAN_LIMIT"));
      record.setMakerlastcmt(rs.getString("MAKER_LAST_CMT"));
      record.setCreatedby(rs.getString("CREATED_BY"));
      record.setInstitutionid(rs.getString("INSTITUTION_ID"));
      record.setIname(rs.getString("INAME"));
      record.setRstatus(rs.getString("RSTATUS"));
      record.setCurrappstatus(rs.getString("CURR_APP_STATUS"));
      record.setAdminlastcmt(rs.getString("ADMIN_LAST_CMT"));
      record.setPerdaylimit(rs.getString("PER_DAY_LIMIT"));
      record.setCurrappstatusname(rs.getString("CURR_APP_STATUS_NAME"));
      record.setModifiedby(rs.getString("MODIFIED_BY"));
      record.setPertranlimit(rs.getString("PER_TRAN_LIMIT"));
      record.setId(rs.getString("ID"));
      record.setCategory(rs.getString("CATEGORY"));
      record.setMadeby(rs.getString("MADE_BY"));
      record.setModifiedat(rs.getString("MODIFIED_AT"));
      record.setCheckerlastcmt(rs.getString("CHECKER_LAST_CMT"));
      ps.close();
      logger.trace("loadKBCustomercategoryviewRecord	" + record + "	");
      releaseDatabaseConnection(con, closeConnection);
      return record;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBCustomercategoryviewRecord loadKBCustomercategoryviewRecord(String id) throws Exception {
    return loadKBCustomercategoryviewRecord(id, null, true);
  }

  public int insertKBCustomercategoryviewRecord(KBCustomercategoryviewRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query ="INSERT INTO customer_category_view ";
      Query +="(";
      Query +="MADE_AT,CHARGE_TYPE,CHECKED_AT,CHARGE_VALUE,STATUS_NAME,CHECKED_BY,CREATED_AT,MIN_TRAN_LIMIT,MAKER_LAST_CMT,CREATED_BY,INSTITUTION_ID,INAME,RSTATUS,CURR_APP_STATUS,ADMIN_LAST_CMT,PER_DAY_LIMIT,CURR_APP_STATUS_NAME,MODIFIED_BY,PER_TRAN_LIMIT,ID,CATEGORY,MADE_BY,MODIFIED_AT,CHECKER_LAST_CMT";
      Query +=")";
      Query += " VALUES " ;
      Query +="(";
      Query +="?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?";
      Query +=")";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("insertKBCustomercategoryviewRecords	" + closeConnection + "	" + Query);
      if (isOracleDatabase()) {
        ps = con.prepareStatement(Query,new String[]{"ID"});
      }
      else {
        ps = con.prepareStatement(Query,Statement.RETURN_GENERATED_KEYS);
      }
      setStringValue(ps, 1, record.getMadeat());
      setStringValue(ps, 2, record.getChargetype());
      setStringValue(ps, 3, record.getCheckedat());
      setStringValue(ps, 4, record.getChargevalue());
      setStringValue(ps, 5, record.getStatusname());
      setStringValue(ps, 6, record.getCheckedby());
      setDateValue(ps, 7, fd.getSQLDateObject(record.getCreatedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 8, record.getMintranlimit());
      setStringValue(ps, 9, record.getMakerlastcmt());
      setStringValue(ps, 10, record.getCreatedby());
      setStringValue(ps, 11, record.getInstitutionid());
      setStringValue(ps, 12, record.getIname());
      setStringValue(ps, 13, record.getRstatus());
      setStringValue(ps, 14, record.getCurrappstatus());
      setStringValue(ps, 15, record.getAdminlastcmt());
      setStringValue(ps, 16, record.getPerdaylimit());
      setStringValue(ps, 17, record.getCurrappstatusname());
      setStringValue(ps, 18, record.getModifiedby());
      setStringValue(ps, 19, record.getPertranlimit());
      setStringValue(ps, 20, record.getId());
      setStringValue(ps, 21, record.getCategory());
      setStringValue(ps, 22, record.getMadeby());
      setDateValue(ps, 23, fd.getSQLDateObject(record.getModifiedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 24, record.getCheckerlastcmt());
      boolean result = ps.execute();
      logger.trace("insertKBCustomercategoryviewRecord	" + result + "	");
      int resultID = -1;
      rs = ps.getGeneratedKeys();
      if (rs.next()) {
        resultID = rs.getInt(1);
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return resultID;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public int insertKBCustomercategoryviewRecord(KBCustomercategoryviewRecord record) throws
      Exception {
    return insertKBCustomercategoryviewRecord(record, null, true);
  }

  public boolean updateKBCustomercategoryviewRecord(KBCustomercategoryviewRecord record,
      Connection con, boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      KBCustomercategoryviewRecord currentRecord = loadKBCustomercategoryviewRecord(record.getId());
      String currentRecordContent = StringUtils.noNull(currentRecord);
      String Query = "UPDATE customer_category_view SET ";
      Query += "MADE_AT = ?,";
          Query += "CHARGE_TYPE = ?,";
          Query += "CHECKED_AT = ?,";
          Query += "CHARGE_VALUE = ?,";
          Query += "STATUS_NAME = ?,";
          Query += "CHECKED_BY = ?,";
          Query += "CREATED_AT = ?,";
          Query += "MIN_TRAN_LIMIT = ?,";
          Query += "MAKER_LAST_CMT = ?,";
          Query += "CREATED_BY = ?,";
          Query += "INSTITUTION_ID = ?,";
          Query += "INAME = ?,";
          Query += "RSTATUS = ?,";
          Query += "CURR_APP_STATUS = ?,";
          Query += "ADMIN_LAST_CMT = ?,";
          Query += "PER_DAY_LIMIT = ?,";
          Query += "CURR_APP_STATUS_NAME = ?,";
          Query += "MODIFIED_BY = ?,";
          Query += "PER_TRAN_LIMIT = ?,";
          Query += "CATEGORY = ?,";
          Query += "MADE_BY = ?,";
          Query += "MODIFIED_AT = ?,";
          Query += "CHECKER_LAST_CMT = ?";
      Query += " WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("updateKBCustomercategoryviewRecord	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      setStringValue(ps, 1, record.getMadeat());
      setStringValue(ps, 2, record.getChargetype());
      setStringValue(ps, 3, record.getCheckedat());
      setStringValue(ps, 4, record.getChargevalue());
      setStringValue(ps, 5, record.getStatusname());
      setStringValue(ps, 6, record.getCheckedby());
      setDateValue(ps, 7, fd.getSQLDateObject(record.getCreatedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 8, record.getMintranlimit());
      setStringValue(ps, 9, record.getMakerlastcmt());
      setStringValue(ps, 10, record.getCreatedby());
      setStringValue(ps, 11, record.getInstitutionid());
      setStringValue(ps, 12, record.getIname());
      setStringValue(ps, 13, record.getRstatus());
      setStringValue(ps, 14, record.getCurrappstatus());
      setStringValue(ps, 15, record.getAdminlastcmt());
      setStringValue(ps, 16, record.getPerdaylimit());
      setStringValue(ps, 17, record.getCurrappstatusname());
      setStringValue(ps, 18, record.getModifiedby());
      setStringValue(ps, 19, record.getPertranlimit());
      setStringValue(ps, 20, record.getCategory());
      setStringValue(ps, 21, record.getMadeby());
      setDateValue(ps, 22, fd.getSQLDateObject(record.getModifiedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 23, record.getCheckerlastcmt());
      ps.setString(24, StringUtils.noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("updateKBCustomercategoryviewRecord	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean updateKBCustomercategoryviewRecord(KBCustomercategoryviewRecord record) throws
      Exception {
    return updateKBCustomercategoryviewRecord(record, null, true);
  }

  public boolean deleteKBCustomercategoryviewRecord(KBCustomercategoryviewRecord record,
      Connection con, boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query = "DELETE FROM customer_category_view WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("deleteKBCustomercategoryviewRecord	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      ps.setString(1, noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("deleteKBCustomercategoryviewRecord	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean deleteKBCustomercategoryviewRecord(KBCustomercategoryviewRecord record) throws
      Exception {
    return deleteKBCustomercategoryviewRecord(record, null, true);
  }

  public KBCustomercategoryviewRecord[] searchKBCustomercategoryviewRecords(
      KBCustomercategoryviewRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MADE_AT", formatSearchField(searchRecord.getMadeat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHARGE_TYPE", formatSearchField(searchRecord.getChargetype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHECKED_AT", formatSearchField(searchRecord.getCheckedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHARGE_VALUE", formatSearchField(searchRecord.getChargevalue()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "STATUS_NAME", formatSearchField(searchRecord.getStatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CHECKED_BY", formatSearchField(searchRecord.getCheckedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MIN_TRAN_LIMIT", formatSearchField(searchRecord.getMintranlimit()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MAKER_LAST_CMT", formatSearchField(searchRecord.getMakerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "INAME", formatSearchField(searchRecord.getIname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CURR_APP_STATUS", formatSearchField(searchRecord.getCurrappstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "ADMIN_LAST_CMT", formatSearchField(searchRecord.getAdminlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PER_DAY_LIMIT", formatSearchField(searchRecord.getPerdaylimit()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CURR_APP_STATUS_NAME", formatSearchField(searchRecord.getCurrappstatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PER_TRAN_LIMIT", formatSearchField(searchRecord.getPertranlimit()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CATEGORY", formatSearchField(searchRecord.getCategory()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MADE_BY", formatSearchField(searchRecord.getMadeby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHECKER_LAST_CMT", formatSearchField(searchRecord.getCheckerlastcmt()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from customer_category_view " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM customer_category_view ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM customer_category_view $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBCustomercategoryviewRecords(Query);
  }

  public KBCustomercategoryviewRecord[] searchKBCustomercategoryviewRecordsExactUpper(
      KBCustomercategoryviewRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MADE_AT", formatSearchField(searchRecord.getMadeat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHARGE_TYPE", formatSearchField(searchRecord.getChargetype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKED_AT", formatSearchField(searchRecord.getCheckedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHARGE_VALUE", formatSearchField(searchRecord.getChargevalue()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "STATUS_NAME", formatSearchField(searchRecord.getStatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKED_BY", formatSearchField(searchRecord.getCheckedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MIN_TRAN_LIMIT", formatSearchField(searchRecord.getMintranlimit()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MAKER_LAST_CMT", formatSearchField(searchRecord.getMakerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "INAME", formatSearchField(searchRecord.getIname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CURR_APP_STATUS", formatSearchField(searchRecord.getCurrappstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ADMIN_LAST_CMT", formatSearchField(searchRecord.getAdminlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PER_DAY_LIMIT", formatSearchField(searchRecord.getPerdaylimit()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CURR_APP_STATUS_NAME", formatSearchField(searchRecord.getCurrappstatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PER_TRAN_LIMIT", formatSearchField(searchRecord.getPertranlimit()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CATEGORY", formatSearchField(searchRecord.getCategory()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MADE_BY", formatSearchField(searchRecord.getMadeby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKER_LAST_CMT", formatSearchField(searchRecord.getCheckerlastcmt()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from customer_category_view " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM customer_category_view ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM customer_category_view $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBCustomercategoryviewRecords(Query);
  }

  public int loadKBCustomercategoryviewRecordCount(KBCustomercategoryviewRecord searchRecord) throws
      Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MADE_AT", formatSearchField(searchRecord.getMadeat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHARGE_TYPE", formatSearchField(searchRecord.getChargetype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHECKED_AT", formatSearchField(searchRecord.getCheckedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHARGE_VALUE", formatSearchField(searchRecord.getChargevalue()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "STATUS_NAME", formatSearchField(searchRecord.getStatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CHECKED_BY", formatSearchField(searchRecord.getCheckedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MIN_TRAN_LIMIT", formatSearchField(searchRecord.getMintranlimit()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MAKER_LAST_CMT", formatSearchField(searchRecord.getMakerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "INAME", formatSearchField(searchRecord.getIname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CURR_APP_STATUS", formatSearchField(searchRecord.getCurrappstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "ADMIN_LAST_CMT", formatSearchField(searchRecord.getAdminlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PER_DAY_LIMIT", formatSearchField(searchRecord.getPerdaylimit()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CURR_APP_STATUS_NAME", formatSearchField(searchRecord.getCurrappstatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "PER_TRAN_LIMIT", formatSearchField(searchRecord.getPertranlimit()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CATEGORY", formatSearchField(searchRecord.getCategory()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MADE_BY", formatSearchField(searchRecord.getMadeby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHECKER_LAST_CMT", formatSearchField(searchRecord.getCheckerlastcmt()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from customer_category_view " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }

  public int loadKBCustomercategoryviewRecordCountExact(KBCustomercategoryviewRecord searchRecord)
      throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MADE_AT", formatSearchField(searchRecord.getMadeat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHARGE_TYPE", formatSearchField(searchRecord.getChargetype()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKED_AT", formatSearchField(searchRecord.getCheckedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHARGE_VALUE", formatSearchField(searchRecord.getChargevalue()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "STATUS_NAME", formatSearchField(searchRecord.getStatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKED_BY", formatSearchField(searchRecord.getCheckedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MIN_TRAN_LIMIT", formatSearchField(searchRecord.getMintranlimit()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MAKER_LAST_CMT", formatSearchField(searchRecord.getMakerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "INAME", formatSearchField(searchRecord.getIname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CURR_APP_STATUS", formatSearchField(searchRecord.getCurrappstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ADMIN_LAST_CMT", formatSearchField(searchRecord.getAdminlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PER_DAY_LIMIT", formatSearchField(searchRecord.getPerdaylimit()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CURR_APP_STATUS_NAME", formatSearchField(searchRecord.getCurrappstatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "PER_TRAN_LIMIT", formatSearchField(searchRecord.getPertranlimit()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CATEGORY", formatSearchField(searchRecord.getCategory()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MADE_BY", formatSearchField(searchRecord.getMadeby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKER_LAST_CMT", formatSearchField(searchRecord.getCheckerlastcmt()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from customer_category_view " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }
}
