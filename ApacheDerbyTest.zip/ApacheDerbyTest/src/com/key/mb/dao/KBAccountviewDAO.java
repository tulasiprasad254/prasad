// Author Tulasi Vara Prasad
package com.key.mb.dao;

import com.key.mb.common.KBDAO;
import com.key.mb.to.KBAccountviewRecord;
import com.key.utils.LogUtils;
import com.key.utils.StringUtils;
import java.lang.Exception;
import java.lang.String;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class KBAccountviewDAO extends KBDAO {
  public static LogUtils logger = new LogUtils(KBAccountviewDAO.class.getName());

  public KBAccountviewRecord[] loadKBAccountviewRecords(String query, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      query = query + MAX_RECORD_LIMIT_APPENDER;
      query = updateQuery(query);
      logger.trace("loadKBAccountviewRecords	" + closeConnection + "	" + query);
      ps = con.prepareStatement(query);
      rs = ps.executeQuery();
      ArrayList recordSet = new ArrayList();
      while(rs.next()) {
        KBAccountviewRecord record = new KBAccountviewRecord();
        record.setMadeat(rs.getString("MADE_AT"));
        record.setCheckedat(rs.getString("CHECKED_AT"));
        record.setAccnum(rs.getString("ACC_NUM"));
        record.setStatusname(rs.getString("STATUS_NAME"));
        record.setCheckedby(rs.getString("CHECKED_BY"));
        record.setCname(rs.getString("CNAME"));
        record.setCreatedat(rs.getString("CREATED_AT"));
        record.setMakerlastcmt(rs.getString("MAKER_LAST_CMT"));
        record.setCreatedby(rs.getString("CREATED_BY"));
        record.setInstitutionid(rs.getString("INSTITUTION_ID"));
        record.setIname(rs.getString("INAME"));
        record.setRstatus(rs.getString("RSTATUS"));
        record.setBlockedflag(rs.getString("BLOCKED_FLAG"));
        record.setCurrappstatus(rs.getString("CURR_APP_STATUS"));
        record.setAdminlastcmt(rs.getString("ADMIN_LAST_CMT"));
        record.setCurrappstatusname(rs.getString("CURR_APP_STATUS_NAME"));
        record.setModifiedby(rs.getString("MODIFIED_BY"));
        record.setAlias(rs.getString("ALIAS"));
        record.setCurrency(rs.getString("CURRENCY"));
        record.setId(rs.getString("ID"));
        record.setMadeby(rs.getString("MADE_BY"));
        record.setModifiedat(rs.getString("MODIFIED_AT"));
        record.setCustid(rs.getString("CUST_ID"));
        record.setCheckerlastcmt(rs.getString("CHECKER_LAST_CMT"));
        recordSet.add(record);
      }
      logger.trace("loadKBAccountviewRecords:Records Fetched:" + recordSet.size());
      KBAccountviewRecord[] tempKBAccountviewRecords = new KBAccountviewRecord[recordSet.size()];
      for (int index = 0; index < recordSet.size(); index++) {
        tempKBAccountviewRecords[index] = (KBAccountviewRecord)(recordSet.get(index));
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return tempKBAccountviewRecords;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBAccountviewRecord[] loadKBAccountviewRecords(String query) throws Exception {
    return loadKBAccountviewRecords(query, null, true);
  }

  public KBAccountviewRecord loadFirstKBAccountviewRecord(String query) throws Exception {
    KBAccountviewRecord[] results = loadKBAccountviewRecords(query);
    if (results == null) {
      return null;
    }
    if(results.length < 1) {
      return null;
    }
    return results[0];
  }

  public KBAccountviewRecord loadKBAccountviewRecord(String id, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      if(con == null) {
        con = getCPDatabaseConnection();
      }
      String Query = "SELECT * FROM account_view WHERE (ID = ?)";
      Query = updateQuery(Query);
      logger.trace("loadKBAccountviewRecords	" + closeConnection + "	" + id);
      ps = con.prepareStatement(Query);
      ps.setString(1,id);
      rs = ps.executeQuery();
      if (!rs.next()) {
        ps.close();
        releaseDatabaseConnection(con, closeConnection);
        return null;
      }
      KBAccountviewRecord record = new KBAccountviewRecord();
      record.setMadeat(rs.getString("MADE_AT"));
      record.setCheckedat(rs.getString("CHECKED_AT"));
      record.setAccnum(rs.getString("ACC_NUM"));
      record.setStatusname(rs.getString("STATUS_NAME"));
      record.setCheckedby(rs.getString("CHECKED_BY"));
      record.setCname(rs.getString("CNAME"));
      record.setCreatedat(rs.getString("CREATED_AT"));
      record.setMakerlastcmt(rs.getString("MAKER_LAST_CMT"));
      record.setCreatedby(rs.getString("CREATED_BY"));
      record.setInstitutionid(rs.getString("INSTITUTION_ID"));
      record.setIname(rs.getString("INAME"));
      record.setRstatus(rs.getString("RSTATUS"));
      record.setBlockedflag(rs.getString("BLOCKED_FLAG"));
      record.setCurrappstatus(rs.getString("CURR_APP_STATUS"));
      record.setAdminlastcmt(rs.getString("ADMIN_LAST_CMT"));
      record.setCurrappstatusname(rs.getString("CURR_APP_STATUS_NAME"));
      record.setModifiedby(rs.getString("MODIFIED_BY"));
      record.setAlias(rs.getString("ALIAS"));
      record.setCurrency(rs.getString("CURRENCY"));
      record.setId(rs.getString("ID"));
      record.setMadeby(rs.getString("MADE_BY"));
      record.setModifiedat(rs.getString("MODIFIED_AT"));
      record.setCustid(rs.getString("CUST_ID"));
      record.setCheckerlastcmt(rs.getString("CHECKER_LAST_CMT"));
      ps.close();
      logger.trace("loadKBAccountviewRecord	" + record + "	");
      releaseDatabaseConnection(con, closeConnection);
      return record;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public KBAccountviewRecord loadKBAccountviewRecord(String id) throws Exception {
    return loadKBAccountviewRecord(id, null, true);
  }

  public int insertKBAccountviewRecord(KBAccountviewRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query ="INSERT INTO account_view ";
      Query +="(";
      Query +="MADE_AT,CHECKED_AT,ACC_NUM,STATUS_NAME,CHECKED_BY,CNAME,CREATED_AT,MAKER_LAST_CMT,CREATED_BY,INSTITUTION_ID,INAME,RSTATUS,BLOCKED_FLAG,CURR_APP_STATUS,ADMIN_LAST_CMT,CURR_APP_STATUS_NAME,MODIFIED_BY,ALIAS,CURRENCY,ID,MADE_BY,MODIFIED_AT,CUST_ID,CHECKER_LAST_CMT";
      Query +=")";
      Query += " VALUES " ;
      Query +="(";
      Query +="?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?";
      Query +=")";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("insertKBAccountviewRecords	" + closeConnection + "	" + Query);
      if (isOracleDatabase()) {
        ps = con.prepareStatement(Query,new String[]{"ID"});
      }
      else {
        ps = con.prepareStatement(Query,Statement.RETURN_GENERATED_KEYS);
      }
      setStringValue(ps, 1, record.getMadeat());
      setStringValue(ps, 2, record.getCheckedat());
      setStringValue(ps, 3, record.getAccnum());
      setStringValue(ps, 4, record.getStatusname());
      setStringValue(ps, 5, record.getCheckedby());
      setStringValue(ps, 6, record.getCname());
      setDateValue(ps, 7, fd.getSQLDateObject(record.getCreatedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 8, record.getMakerlastcmt());
      setStringValue(ps, 9, record.getCreatedby());
      setStringValue(ps, 10, record.getInstitutionid());
      setStringValue(ps, 11, record.getIname());
      setStringValue(ps, 12, record.getRstatus());
      setStringValue(ps, 13, record.getBlockedflag());
      setStringValue(ps, 14, record.getCurrappstatus());
      setStringValue(ps, 15, record.getAdminlastcmt());
      setStringValue(ps, 16, record.getCurrappstatusname());
      setStringValue(ps, 17, record.getModifiedby());
      setStringValue(ps, 18, record.getAlias());
      setStringValue(ps, 19, record.getCurrency());
      setStringValue(ps, 20, record.getId());
      setStringValue(ps, 21, record.getMadeby());
      setDateValue(ps, 22, fd.getSQLDateObject(record.getModifiedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 23, record.getCustid());
      setStringValue(ps, 24, record.getCheckerlastcmt());
      boolean result = ps.execute();
      logger.trace("insertKBAccountviewRecord	" + result + "	");
      int resultID = -1;
      rs = ps.getGeneratedKeys();
      if (rs.next()) {
        resultID = rs.getInt(1);
      }
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return resultID;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public int insertKBAccountviewRecord(KBAccountviewRecord record) throws Exception {
    return insertKBAccountviewRecord(record, null, true);
  }

  public boolean updateKBAccountviewRecord(KBAccountviewRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      KBAccountviewRecord currentRecord = loadKBAccountviewRecord(record.getId());
      String currentRecordContent = StringUtils.noNull(currentRecord);
      String Query = "UPDATE account_view SET ";
      Query += "MADE_AT = ?,";
          Query += "CHECKED_AT = ?,";
          Query += "ACC_NUM = ?,";
          Query += "STATUS_NAME = ?,";
          Query += "CHECKED_BY = ?,";
          Query += "CNAME = ?,";
          Query += "CREATED_AT = ?,";
          Query += "MAKER_LAST_CMT = ?,";
          Query += "CREATED_BY = ?,";
          Query += "INSTITUTION_ID = ?,";
          Query += "INAME = ?,";
          Query += "RSTATUS = ?,";
          Query += "BLOCKED_FLAG = ?,";
          Query += "CURR_APP_STATUS = ?,";
          Query += "ADMIN_LAST_CMT = ?,";
          Query += "CURR_APP_STATUS_NAME = ?,";
          Query += "MODIFIED_BY = ?,";
          Query += "ALIAS = ?,";
          Query += "CURRENCY = ?,";
          Query += "MADE_BY = ?,";
          Query += "MODIFIED_AT = ?,";
          Query += "CUST_ID = ?,";
          Query += "CHECKER_LAST_CMT = ?";
      Query += " WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("updateKBAccountviewRecord	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      setStringValue(ps, 1, record.getMadeat());
      setStringValue(ps, 2, record.getCheckedat());
      setStringValue(ps, 3, record.getAccnum());
      setStringValue(ps, 4, record.getStatusname());
      setStringValue(ps, 5, record.getCheckedby());
      setStringValue(ps, 6, record.getCname());
      setDateValue(ps, 7, fd.getSQLDateObject(record.getCreatedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 8, record.getMakerlastcmt());
      setStringValue(ps, 9, record.getCreatedby());
      setStringValue(ps, 10, record.getInstitutionid());
      setStringValue(ps, 11, record.getIname());
      setStringValue(ps, 12, record.getRstatus());
      setStringValue(ps, 13, record.getBlockedflag());
      setStringValue(ps, 14, record.getCurrappstatus());
      setStringValue(ps, 15, record.getAdminlastcmt());
      setStringValue(ps, 16, record.getCurrappstatusname());
      setStringValue(ps, 17, record.getModifiedby());
      setStringValue(ps, 18, record.getAlias());
      setStringValue(ps, 19, record.getCurrency());
      setStringValue(ps, 20, record.getMadeby());
      setDateValue(ps, 21, fd.getSQLDateObject(record.getModifiedat(), "yyyyMMddHHmmss"));
      setStringValue(ps, 22, record.getCustid());
      setStringValue(ps, 23, record.getCheckerlastcmt());
      ps.setString(24, StringUtils.noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("updateKBAccountviewRecord	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean updateKBAccountviewRecord(KBAccountviewRecord record) throws Exception {
    return updateKBAccountviewRecord(record, null, true);
  }

  public boolean deleteKBAccountviewRecord(KBAccountviewRecord record, Connection con,
      boolean closeConnection) throws Exception {
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      String Query = "DELETE FROM account_view WHERE (ID = ?)";
      if (con == null) {
        con = getCPDatabaseConnection();
      }
      Query = updateQuery(Query);
      logger.trace("deleteKBAccountviewRecord	" + closeConnection + "	" + record + "	" + Query + "	");
      ps = con.prepareStatement(Query);
      ps.setString(1, noNull(record.getId()));
      boolean result = ps.execute();
      logger.trace("deleteKBAccountviewRecord	" + result + "	");
      ps.close();
      releaseDatabaseConnection(con, closeConnection);
      return result;
    }
    finally {
      releaseDatabaseConnection(rs, ps, con, closeConnection);
    }
  }

  public boolean deleteKBAccountviewRecord(KBAccountviewRecord record) throws Exception {
    return deleteKBAccountviewRecord(record, null, true);
  }

  public KBAccountviewRecord[] searchKBAccountviewRecords(KBAccountviewRecord searchRecord) throws
      Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MADE_AT", formatSearchField(searchRecord.getMadeat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHECKED_AT", formatSearchField(searchRecord.getCheckedat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ACC_NUM", formatSearchField(searchRecord.getAccnum()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "STATUS_NAME", formatSearchField(searchRecord.getStatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CHECKED_BY", formatSearchField(searchRecord.getCheckedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CNAME", formatSearchField(searchRecord.getCname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MAKER_LAST_CMT", formatSearchField(searchRecord.getMakerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "INAME", formatSearchField(searchRecord.getIname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "BLOCKED_FLAG", formatSearchField(searchRecord.getBlockedflag()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CURR_APP_STATUS", formatSearchField(searchRecord.getCurrappstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "ADMIN_LAST_CMT", formatSearchField(searchRecord.getAdminlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CURR_APP_STATUS_NAME", formatSearchField(searchRecord.getCurrappstatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "ALIAS", formatSearchField(searchRecord.getAlias()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CURRENCY", formatSearchField(searchRecord.getCurrency()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MADE_BY", formatSearchField(searchRecord.getMadeby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CUST_ID", formatSearchField(searchRecord.getCustid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHECKER_LAST_CMT", formatSearchField(searchRecord.getCheckerlastcmt()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from account_view " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM account_view ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM account_view $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBAccountviewRecords(Query);
  }

  public KBAccountviewRecord[] searchKBAccountviewRecordsExactUpper(
      KBAccountviewRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MADE_AT", formatSearchField(searchRecord.getMadeat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKED_AT", formatSearchField(searchRecord.getCheckedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ACC_NUM", formatSearchField(searchRecord.getAccnum()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "STATUS_NAME", formatSearchField(searchRecord.getStatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKED_BY", formatSearchField(searchRecord.getCheckedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CNAME", formatSearchField(searchRecord.getCname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MAKER_LAST_CMT", formatSearchField(searchRecord.getMakerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "INAME", formatSearchField(searchRecord.getIname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "BLOCKED_FLAG", formatSearchField(searchRecord.getBlockedflag()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CURR_APP_STATUS", formatSearchField(searchRecord.getCurrappstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ADMIN_LAST_CMT", formatSearchField(searchRecord.getAdminlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CURR_APP_STATUS_NAME", formatSearchField(searchRecord.getCurrappstatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ALIAS", formatSearchField(searchRecord.getAlias()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CURRENCY", formatSearchField(searchRecord.getCurrency()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MADE_BY", formatSearchField(searchRecord.getMadeby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CUST_ID", formatSearchField(searchRecord.getCustid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKER_LAST_CMT", formatSearchField(searchRecord.getCheckerlastcmt()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select * from account_view " + WhereCondition + " order by " + ORDERBYSTRING;
    if (isMSSQL8()) {
      Query = "select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) as rownum FROM account_view ) acvmfs " + WhereCondition;
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadMSSQL8OrderByID(ORDERBYSTRING),true);
    }
    if (isOracleDatabase()) {
      Query = "select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $ORDERBYSTRING$) R FROM (SELECT * FROM account_view $WHERECONDITION$) C ) WHERE (1=1) $OUTERLIMITCONDITION$";
      Query = StringUtils.replaceString(Query, "$WHERECONDITION$", WhereCondition,true);
      Query = StringUtils.replaceString(Query, "$OUTERLIMITCONDITION$", getOuterLimitCondition(),true);
      Query = StringUtils.replaceString(Query, "$ORDERBYSTRING$", loadOracleOrderByID(ORDERBYSTRING),true);
    }
    Query = updateQuery(Query);
    logger.trace("Search Query	" + Query + "	");
    return loadKBAccountviewRecords(Query);
  }

  public int loadKBAccountviewRecordCount(KBAccountviewRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MADE_AT", formatSearchField(searchRecord.getMadeat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHECKED_AT", formatSearchField(searchRecord.getCheckedat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ACC_NUM", formatSearchField(searchRecord.getAccnum()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "STATUS_NAME", formatSearchField(searchRecord.getStatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CHECKED_BY", formatSearchField(searchRecord.getCheckedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CNAME", formatSearchField(searchRecord.getCname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MAKER_LAST_CMT", formatSearchField(searchRecord.getMakerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "INAME", formatSearchField(searchRecord.getIname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "BLOCKED_FLAG", formatSearchField(searchRecord.getBlockedflag()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CURR_APP_STATUS", formatSearchField(searchRecord.getCurrappstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "ADMIN_LAST_CMT", formatSearchField(searchRecord.getAdminlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CURR_APP_STATUS_NAME", formatSearchField(searchRecord.getCurrappstatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "ALIAS", formatSearchField(searchRecord.getAlias()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CURRENCY", formatSearchField(searchRecord.getCurrency()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "MADE_BY", formatSearchField(searchRecord.getMadeby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "($COLNAME$ = '$COLVAL$')", "", "CUST_ID", formatSearchField(searchRecord.getCustid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) LIKE UPPER('%$COLVAL$%'))", "", "CHECKER_LAST_CMT", formatSearchField(searchRecord.getCheckerlastcmt()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from account_view " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }

  public int loadKBAccountviewRecordCountExact(KBAccountviewRecord searchRecord) throws Exception {
    String WhereCondition =  " ";
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MADE_AT", formatSearchField(searchRecord.getMadeat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKED_AT", formatSearchField(searchRecord.getCheckedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ACC_NUM", formatSearchField(searchRecord.getAccnum()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "STATUS_NAME", formatSearchField(searchRecord.getStatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKED_BY", formatSearchField(searchRecord.getCheckedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CNAME", formatSearchField(searchRecord.getCname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_AT", formatSearchField(searchRecord.getCreatedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MAKER_LAST_CMT", formatSearchField(searchRecord.getMakerlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CREATED_BY", formatSearchField(searchRecord.getCreatedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "INSTITUTION_ID", formatSearchField(searchRecord.getInstitutionid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "INAME", formatSearchField(searchRecord.getIname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "RSTATUS", formatSearchField(searchRecord.getRstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "BLOCKED_FLAG", formatSearchField(searchRecord.getBlockedflag()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CURR_APP_STATUS", formatSearchField(searchRecord.getCurrappstatus()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ADMIN_LAST_CMT", formatSearchField(searchRecord.getAdminlastcmt()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CURR_APP_STATUS_NAME", formatSearchField(searchRecord.getCurrappstatusname()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_BY", formatSearchField(searchRecord.getModifiedby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ALIAS", formatSearchField(searchRecord.getAlias()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CURRENCY", formatSearchField(searchRecord.getCurrency()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "ID", formatSearchField(searchRecord.getId()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MADE_BY", formatSearchField(searchRecord.getMadeby()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "MODIFIED_AT", formatSearchField(searchRecord.getModifiedat()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CUST_ID", formatSearchField(searchRecord.getCustid()));
    WhereCondition = addSearchCondition(WhereCondition, "(UPPER($COLNAME$) = UPPER('%$COLVAL$%'))", "", "CHECKER_LAST_CMT", formatSearchField(searchRecord.getCheckerlastcmt()));
    if (isNull(WhereCondition)) {
      WhereCondition += "(1=1)";
    }
    if (!isNull(WhereCondition)) {
      WhereCondition = "WHERE " + WhereCondition;
    }
    if (hasCustomCondition()) {
      WhereCondition += getCustomCondition();
    }
    String Query = "select count(*) from account_view " + WhereCondition;
    Query = updateQuery(Query);
    logger.trace("Search Count Query	" + Query + "	");
    return loadCount(Query);
  }
}
