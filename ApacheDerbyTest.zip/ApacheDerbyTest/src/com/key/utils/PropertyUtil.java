/* PropertyUtil.java
 * 
 * Project Name             : KEY BANK CARDLESS WITHDRAWAL
 * Module                   : Cradles Withdrawal
 * Author                   : Chennamsetti T V Prasad (Cognizant Private Limited)
 * Date                     : August 01, 2023
 * Change Revision
 * ----------------------------------------------------------------
 * Date            Author         Version#    Remarks/Description
 *-----------------------------------------------------------------
 *
 */
package com.key.utils;
//Java imports
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.StringTokenizer;
import java.util.Collections;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.Vector;

import org.json.simple.JSONObject;

import com.key.utils.LogUtils;
import com.key.utils.PropertyUtil;
import com.key.utils.StringUtils;


public class PropertyUtil
{
	private static String dbdriver = null;
	private static String dburl = null;
	private static String dbuid = null;
	private static String dbpwd = null;
	private static String enckey =null;
	private static HashMap propertyMap = new HashMap();

	public static String getEnckey() {
		return enckey;
	}

	public static void setEnckey(String enckey) {
		PropertyUtil.enckey = enckey;
	}

	static
	{
		loadProperties();	
	}
	
	public static void loadProperties()
	{
    	if (dbdriver == null)
    	{
			ResourceBundle rb = ResourceBundle.getBundle("mfmbs", Locale.getDefault());
			dbdriver = rb.getString("dbdriver");
			dburl=rb.getString("dburl");
			dbuid=rb.getString("dbuid");
			dbpwd=rb.getString("dbpwd");
			enckey=rb.getString("enckey");

			Iterator iterator = rb.keySet().iterator();
			while(iterator.hasNext())
			{
				String key = iterator.next().toString();
				String value = rb.getString(key);
				propertyMap.put(key,value);
			}
    	}
	}
	
	public static boolean isPropertyEquals(String propertyName, String val, boolean ignoreCase)
	{
		String propertyVal = StringUtils.noNull(getProperty(propertyName));
		if (ignoreCase)
		{
			return propertyVal.equalsIgnoreCase(val);
		}
		else
		{
			return propertyVal.equals(val);
		}
	}
	
	public static boolean isPropertyEquals(String propertyName, String val)
	{
		val = StringUtils.noNull(val);
		String propertyVal = StringUtils.noNull(getProperty(propertyName));
		return propertyVal.equals(val);
	}
	
	public static boolean isPropertyEqualsIC(String propertyName, String val)
	{
		val = StringUtils.noNull(val);
		String propertyVal = StringUtils.noNull(getProperty(propertyName));
		return propertyVal.equalsIgnoreCase(val);
	}		
	
	public static String getPropertyNoNull(String key)
	{
		return StringUtils.noNull(getProperty(key));
	}
	
	public static double getPropertyAsDouble(String key)
	throws Exception
	{
		return Double.parseDouble(StringUtils.noNull(getProperty(key)));
	}
	
	public static int getPropertyAsInt(String key)
	throws Exception
	{
		return Integer.parseInt(StringUtils.noNull(getProperty(key)));
	}
	
	public static String getProperty(String key)
	{
		if (!propertyMap.containsKey(key))
		{
			return "";
		}
		else return  propertyMap.get(key).toString();
	}
	
	
	
	public static String getPropertyFileContent(String key)
	{
		try
		{
			String fileName = getProperty(key);
			return StringUtils.loadFileAsString(fileName);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return "";
		}
	}
	
	public PropertyUtil()
	{
		loadProperties();
	}

	public static String getDbdriver() {
		return dbdriver;
	}

	public static void setDbdriver(String dbdriver) {
		PropertyUtil.dbdriver = dbdriver;
	}

	public static String getDburl() {
		return dburl;
	}

	public static void setDburl(String dburl) {
		PropertyUtil.dburl = dburl;
	}

	public static String getDbuid() {
		return dbuid;
	}

	public static void setDbuid(String dbuid) {
		PropertyUtil.dbuid = dbuid;
	}

	public static String getDbpwd() {
		return dbpwd;
	}

	public static void setDbpwd(String dbpwd) {
		PropertyUtil.dbpwd = dbpwd;
	}
	
	public static void main(String[] args)
			throws Exception
			{
				//PropertyUtil.migrateProperties();

				LogUtils.println(propertyMap.size());
				LogUtils.println(propertyMap);
				
			}

}
