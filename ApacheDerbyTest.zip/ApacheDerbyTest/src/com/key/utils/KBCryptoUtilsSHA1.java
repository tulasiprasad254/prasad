/* KBCryptoUtilsSHA1.java
 * 
 * Project Name             : KEY BANK CARDLESS WITHDRAWAL
 * Module                   : Cradles Withdrawal
 * Author                   : Chennamsetti T V Prasad (Cognizant Private Limited)
 * Date                     : August 01, 2023
 * Change Revision
 * ----------------------------------------------------------------
 * Date            Author         Version#    Remarks/Description
 *-----------------------------------------------------------------
 *
 */


package com.key.utils;

import java.security.MessageDigest;
import java.util.HashMap;

import org.apache.logging.log4j.core.Logger;
import org.json.simple.JSONArray;

import com.key.utils.PropertyUtil;
import com.key.utils.StringUtils;
import com.key.mb.common.KBService;
import com.key.utils.LogUtils;


public class KBCryptoUtilsSHA1 {

	private static LogUtils logger =
			new LogUtils(KBCryptoUtilsSHA1.class.getName());
	public static byte[] computeHash(String x) throws Exception {
		MessageDigest digest = MessageDigest.getInstance("SHA-1");
		digest.reset();
		digest.update(x.getBytes());
		return digest.digest();
	}

	public static String encryptPassword(String password) 
	{
		try 
		{
			byte[] pinData = KBCryptoUtilsSHA1.computeHash(password);
			return KBCryptoUtilsSHA1.byteArrayToHexString(pinData);
		}
		catch(Exception ex) 
		{
			logger.error(ex);
			//log.warn("Error while encrypting Password :"+ex);
			return "";
		}
	}
	
	public static String encryptPassword(String cif, String password) 
	{
		try 
		{
			if (PropertyUtil.isPropertyEquals("PrependCIFTOPIN", "Y"))
			{
				password = StringUtils.noNull(cif) + StringUtils.noNull(password);
			}
			
			byte[] pinData = KBCryptoUtilsSHA1.computeHash(password);
			return KBCryptoUtilsSHA1.byteArrayToHexString(pinData);
		}
		catch(Exception ex) 
		{
			logger.error(ex);
			//log.warn("Error while encrypting Password :"+ex);
			return "";
		}
	}

	public static String byteArrayToHexString(byte[] b) {
		StringBuffer sb = new StringBuffer(b.length * 2);
		for (int i = 0; i < b.length; i++) {
			int v = b[i] & 0xff;
			if (v < 16) {
				sb.append('0');
			}
			sb.append(Integer.toHexString(v));
		}
		return sb.toString().toUpperCase();
	}

}