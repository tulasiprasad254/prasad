package com.key.utils;

/* KBHickaryDAO.java
 * 
 * Project Name             : KEY BANK CARDLESS WITHDRAWAL
 * Module                   : Cradles Withdrawal
 * Author                   : Chennamsetti T V Prasad (Cognizant Private Limited)
 * Date                     : August 01, 2023
 * Change Revision
 * ----------------------------------------------------------------
 * Date            Author         Version#    Remarks/Description
 *-----------------------------------------------------------------
 *
 */
import java.awt.*;
import java.text.*;
import java.util.*;
import java.io.*;
import java.security.spec.KeySpec;
import java.sql.*;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;


import com.zaxxer.hikari.*;

public class KBHickaryDAO 
{
 static LogUtils logger = new LogUtils(KBHickaryDAO.class.getName());
 private static HikariDataSource connectionPool = null;
 
 static
 {
  
  configureConnPoolConnectionManager();

 }
 
 public static void configureConnPoolConnectionManager() 
    {  
  if (PropertyUtil.isPropertyEquals("HickaryCPDisabled", "Y")) return;
  LogUtils.println("Loading DB Connections");   

  try
  {
     HikariConfig config = new HikariConfig();
     config.setMaxLifetime(30000);
     //config.setMinimumIdle(1);
     
     int maxPoolSize=PropertyUtil.getPropertyAsInt("hcpMaxPoolSize");
     if (maxPoolSize < 10) maxPoolSize = 15;
     LogUtils.println("Utilizing Pool. Max Size:" + maxPoolSize);
     config.setMaximumPoolSize(maxPoolSize);
     
     if (PropertyUtil.isPropertyEquals("hcpInitFailFast","Y"))
     {
      //config.setInitializationFailFast(true);
     }
   
     config.setConnectionTestQuery(PropertyUtil.getProperty("hcpConTestQry"));
     config.setJdbcUrl(PropertyUtil.getDburl());
     config.setUsername(PropertyUtil.getDbuid());
     config.setPassword((new KBSecurityUtil()).decryptRegular(PropertyUtil.getDbpwd()));
     config.setDriverClassName (PropertyUtil.getDbdriver());
     
     config.addDataSourceProperty("cachePrepStmts", "true");
     config.addDataSourceProperty("prepStmtCacheSize", "250");
     config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");

     connectionPool = new HikariDataSource (config);  
  }
  catch(Exception e)
  {
	  System.out.println(e.getMessage());
	  e.getStackTrace();
	  //logger.error(e);
  }
   } 

 public static void shutdownConnPool() 
 {
  try 
  {
   HikariDataSource connectionPool = KBHickaryDAO.getConnectionPool();
   if (connectionPool != null) 
   {
    connectionPool.close(); 
    LogUtils.println("Connection Pooling shut downed!");
   }
  } 
  catch (Exception e) 
  {
   LogUtils.println("Error in ConnectionManager >> " + e);
  }
 }

 public static Connection getConnection() 
 {
  Connection conn = null;
  try 
  {
   conn = getConnectionPool().getConnection();
  } 
  catch (Exception e) 
  {
   LogUtils.println("Error in ConnectionManager >> " + e);
  }
  return conn;
 }
 
 public static void releaseConnection(Connection conn) 
 {
  try 
  {
   if (conn != null)
    conn.close(); 
  } 
  catch (SQLException e) 
  {
   LogUtils.println("Error in ConnectionManager >> " + e);
  }
 }

 public static HikariDataSource getConnectionPool() 
 {
  return connectionPool;
 }

 public static void setConnectionPool(HikariDataSource connectionPool) 
 {
  KBHickaryDAO.connectionPool = connectionPool;
 }
 
 public static void main(String args[])
 {
  Connection con=null;
  try
  {
   LogUtils.println("Reached main method ");   
   
   con=KBHickaryDAO.getConnection();
   LogUtils.println("Connection is established "+con);
   if(con!=null)
   {
    LogUtils.println("Reached If condition");
    String query1 = "select * from user_details where user_id='100'";
       PreparedStatement ps = con.prepareStatement(query1);
    ResultSet rs = ps.executeQuery();
    String value = null;
    if (rs.next())
    {
        System.out.println("Success>>>>>");
    } 
   }
   LogUtils.println("Successfully executed");
  }
  catch(Exception e)
  {
	  System.out.println(e.getMessage());
	  e.getStackTrace();
  }
  finally
  {
   KBHickaryDAO.releaseConnection(con);
  }
 }
}