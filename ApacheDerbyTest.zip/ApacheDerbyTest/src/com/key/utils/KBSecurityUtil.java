/* 8KBSecurityUtil.java
 * 
 * Project Name             : KEY BANK CARDLESS WITHDRAWAL
 * Module                   : Cradles Withdrawal
 * Author                   : Chennamsetti T V Prasad (Cognizant Private Limited)
 * Date                     : August 01, 2023
 * Change Revision
 * ----------------------------------------------------------------
 * Date            Author         Version#    Remarks/Description
 *-----------------------------------------------------------------
 *
 */

package com.key.utils;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.security.MessageDigest;
import java.security.spec.KeySpec;
import java.util.Arrays;
import java.util.Random;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.RandomStringUtils;

import com.key.utils.LogUtils;

import com.key.utils.KBSecurityUtil;
import com.key.utils.PropertyUtil;
import com.key.utils.StringUtils;

public class KBSecurityUtil 
{
	private static LogUtils logger =
			new LogUtils(KBSecurityUtil.class.getName());
	
    private static final String UNICODE_FORMAT = "UTF8";
    public static final String DESEDE_ENCRYPTION_SCHEME = "DESede";
    private KeySpec ks;
    private SecretKeyFactory skf;
    private Cipher cipher;
    byte[] arrayBytes;
    private String myEncryptionKey;
    private String myEncryptionScheme;
    SecretKey key;

    public KBSecurityUtil() throws Exception 
    {
        myEncryptionKey = PropertyUtil.getEnckey();
        myEncryptionScheme = DESEDE_ENCRYPTION_SCHEME;
        arrayBytes = myEncryptionKey.getBytes(UNICODE_FORMAT);
        ks = new DESedeKeySpec(arrayBytes);
        skf = SecretKeyFactory.getInstance(myEncryptionScheme);
        cipher = Cipher.getInstance(myEncryptionScheme);
        key = skf.generateSecret(ks);
    }

    public String generateRandomPassword()
    {
    	if (PropertyUtil.isPropertyEquals("GenerateNumericOnlyPassword", "Y"))
    	{
        	RandomStringUtils rs = new RandomStringUtils();
        	return rs.randomNumeric(8);
    	}
    	else
    	{
	    	RandomStringUtils rs = new RandomStringUtils();
	    	return rs.randomAlphanumeric(10);
    	}
    }

    public String generateRandomPin()
    {
    	int pinLength = 6;
    	try
    	{
    		pinLength = Integer.parseInt(PropertyUtil.getProperty("SecurityPinLength"));
    		if (pinLength < 4) pinLength = 6;
    	}
    	catch(Exception exception)
    	{
    		pinLength = 6;
    	}
    	
    	RandomStringUtils rs = new RandomStringUtils();
    	return rs.randomNumeric(pinLength);
    }
    
    public String generateOTP()
    {
    	RandomStringUtils rs = new RandomStringUtils();
    	return rs.randomNumeric(6);
    }
    
    public String generateOTPByLen(int len)
    {
    	RandomStringUtils rs = new RandomStringUtils();
    	return rs.randomNumeric(len);
    }
    
    public String generateOTPExternal()
    {
    	RandomStringUtils rs = new RandomStringUtils();
    	return rs.randomNumeric(10);
    }

    public String encrypt(String unencryptedString) 
    {

    	if (PropertyUtil.isPropertyEquals("CustomSecurityEncryptionAlgorithm", "SHA1"))
    	{
    		KBCryptoUtilsSHA1 sha1 = new KBCryptoUtilsSHA1();
    		return sha1.encryptPassword(unencryptedString);
    	}
    	else
    	{
    		return encryptRegular(unencryptedString);
    	}
    }
    
    public String encrypt(String cif, String unencryptedString) 
    {
    	LogUtils.println("ECODE231:CIF1:" + cif);
    	LogUtils.println("ECODE232:CIF2:" + unencryptedString);
    	LogUtils.println("ECODE231:CIF3:" + PropertyUtil.getProperty("CustomSecurityEncryptionAlgorithm"));
    	LogUtils.println("ECODE232:CIF4:" + PropertyUtil.getProperty("PrependCIFTOPIN"));

    	if (PropertyUtil.isPropertyEquals("CustomSecurityEncryptionAlgorithm", "SHA1"))
    	{
    		KBCryptoUtilsSHA1 sha1 = new KBCryptoUtilsSHA1();
    		return sha1.encryptPassword(cif,unencryptedString);
    	}
    	else
    	{
    		return encryptRegular(unencryptedString);
    	}
    }
    
    public String convertRegularEncryptedToSha1(String value)
    {
    	if (StringUtils.isNullOrEmpty(value)) return "";
    	try
    	{
    		String decrypted = decryptRegular(value);
    		KBCryptoUtilsSHA1 sha1 = new KBCryptoUtilsSHA1();
    		String shaEncrypted = sha1.encryptPassword(decrypted);
    		return shaEncrypted;
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    		return value;
    	}
    }

    public String encryptRegular(String unencryptedString) 
    {
        String encryptedString = null;
        try {
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] plainText = unencryptedString.getBytes(UNICODE_FORMAT);
            byte[] encryptedText = cipher.doFinal(plainText);
            encryptedString = new String(Base64.encodeBase64(encryptedText));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return encryptedString;
    }
    
    public boolean validatePassword(String inputPassword, String dbPassword)
    {
    	if (inputPassword == null) return false;
    	if (dbPassword == null) return false;

    	String encryptedVal = encrypt(inputPassword);
    	if (inputPassword.equals(dbPassword)) return true;
    	return false;
    }

    public String decrypt(String encryptedString) 
    {
    	return decryptRegular(encryptedString);
    }

    public String decryptRegular(String encryptedString) {
        String decryptedText=null;
        try {
            cipher.init(Cipher.DECRYPT_MODE, key);
            byte[] encryptedText = Base64.decodeBase64(encryptedString);
            byte[] plainText = cipher.doFinal(encryptedText);
            decryptedText= new String(plainText);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return decryptedText;
    }
    
    public static void main(String args []) throws Exception
    {
        KBSecurityUtil td= new KBSecurityUtil();
        //td.encryptRegular("root");
        System.out.println("Encrypted Database Password **** "+td.encryptRegular("root"));
        System.out.println("Encrypted Database CLOUD Password **** "+td.encryptRegular("password"));
        System.out.println("Decrypted Password **************** "+td.decrypt("DGnXOW9J2DLXNiWjM8CKgw=="));

   }
    
    public String generateRandomPinWitLen(int length)
    {
    		RandomStringUtils rs = new RandomStringUtils();
    	return rs.randomNumeric(length);
    }
}
