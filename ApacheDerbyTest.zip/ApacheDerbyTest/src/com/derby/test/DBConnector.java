package com.derby.test;

import java.sql.Connection;
import java.sql.DriverManager;

import com.derby.common.MBDAO;


public class DBConnector {
	//jdbc:mysql://mb.cehnnnhwe8sx.eu-north-1.rds.amazonaws.com:3306/oldmfmbs?useSSL=false
	private static String dbURL = "jdbc:mysql://mb.cehnnnhwe8sx.eu-north-1.rds.amazonaws.com:3306/mlmdb?useSSL=false";//"jdbc:derby://localhost:1527/kbmb";
	private static String UserName = "root";
	private static String Password = "Master123";
	
	
	
	public Connection getDatabaseConnection()
    {
        try
        {        	
		   // Class.forName("org.apache.derby.jdbc.ClientDriver");
		   // Connection con = DriverManager.getConnection(dbURL, UserName, Password);
        	 MBDAO dao =new MBDAO();
        	 
		    return dao.getDatabaseConnection();
		}
		catch(Exception e)
		{
		    e.printStackTrace();
		    return null;
		}
    }
	
	public void releaseDatabaseConnection(Connection con)
	{
		releaseConnection(con);
	}
	
	public void releaseDatabaseConnection(Connection con, boolean releaseConnection)
	{
		if (releaseConnection)
		{
			releaseConnection(con);
		}
	}	
	
	public void releaseConnection(Connection con)
    {
        try
        {
            con.close();
        }
        catch(Exception e)
        {
        	e.printStackTrace();
        }
    }
    

}
