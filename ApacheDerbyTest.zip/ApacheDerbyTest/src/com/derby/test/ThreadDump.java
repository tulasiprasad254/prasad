package com.derby.test;

import java.lang.management.ManagementFactory;
import java.lang.management.ThreadInfo;
import java.lang.management.ThreadMXBean;

public class ThreadDump {
  public static void main(String[] args) {
    /*ThreadMXBean threadMXBean = ManagementFactory.getThreadMXBean();
    long[] threadIds = threadMXBean.getAllThreadIds();
    ThreadInfo[] threadInfos = threadMXBean.getThreadInfo(threadIds);
    for (ThreadInfo threadInfo : threadInfos) {
      System.out.println("Thread name: " + threadInfo.getThreadName());
      System.out.println("Thread state: " + threadInfo.getThreadState());
      System.out.println("Thread Id: " +threadInfo.getThreadId());
      System.out.println("Thread stack trace: ");
      for (StackTraceElement stackTraceElement : threadInfo.getStackTrace()) {
        System.out.println("  " + stackTraceElement);
      }
    }*/
	  
	  String tablestogenerate = "system_user,content_map,controller_map,mobile_menu_map,customer,customer_category,user_roles,web_session,system_user_view";
		String rs = "controller_map";
			if(tablestogenerate.toLowerCase().contains(rs))
			{
				System.out.println("found "+rs);
			}
			}
  }
