package com.derby.test;

import com.mb.service.MBSmsmesgService;
import com.mb.to.MBSmsmesgRecord;

public class TestInserRecords {
	public static void main(String[] args) throws Exception
	{
		MBSmsmesgRecord record = new MBSmsmesgRecord();
		record.setId("5");
		record.setMfromaddr("9966778891");
		record.setMmessage("Testing the Insert");
		record.setMtoaddr("9966778822");
		record.setRstatus("1");
		MBSmsmesgService service = new MBSmsmesgService();
		int value = service.insertMBSmsmesgRecord(record);
		System.out.println("Records Inserted :"+value);
	}

}
