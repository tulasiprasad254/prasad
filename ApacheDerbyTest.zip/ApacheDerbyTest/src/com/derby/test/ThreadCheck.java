package com.derby.test;
import java.lang.reflect.Field;
import java.util.HashMap;

public class ThreadCheck {
	
	private static final ThreadLocal attributes = new 	ThreadLocal() {
		@Override
		protected Object initialValue() {
			return new HashMap();
		}
	};
	private static final Field[] fields = ThreadCheck.class.getFields();
	
	public static void main(String[] args)
	{
		
	}

}
