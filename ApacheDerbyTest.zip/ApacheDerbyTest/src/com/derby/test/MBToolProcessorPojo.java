package com.derby.test;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import javax.lang.model.element.Modifier;

import com.derby.utils.StringUtils;
import com.squareup.javapoet.ClassName;
import com.squareup.javapoet.FieldSpec;
import com.squareup.javapoet.JavaFile;
import com.squareup.javapoet.MethodSpec;
import com.squareup.javapoet.TypeName;
import com.squareup.javapoet.TypeSpec;
import com.squareup.javapoet.MethodSpec.Builder;

public class MBToolProcessorPojo {
	/*static TypeName globalstringUtils = ClassName.get("com.mtreetech.sawc.utils", "StringUtils");
	private final String recordClass = "MBRecord";
	private final String packagePath = "com.derby.common";
	private final String daoClass = "MBDAO";
	private final String utilsPackagePath = "com.derby.utils";
	private final String logUtilsClass = "LogUtils";
	private final String stringUtilsClass = "StringUtils";
	private final String jsonPackagePath = "org.json.simple";
	private final String jSONObjectClass = "JSONObject";
	private final String javaUtilsPackagePath = "java.util";
	private final String hashMapClass = "HashMap";
	private final String arrayListClass = "ArrayList";
	private final String pojoPackagetoGeneratejavafiles="com.mb.to";*/
	static TypeName globalstringUtils = ClassName.get("com.key.utils", "StringUtils");
	private final String recordClass = "KBRecord";
	private final String packagePath = "com.key.mb.common";
	private final String daoClass = "KBDAO";
	private final String utilsPackagePath = "com.key.utils";
	private final String logUtilsClass = "LogUtils";
	private final String stringUtilsClass = "StringUtils";
	private final String jsonPackagePath = "org.json.simple";
	private final String jSONObjectClass = "JSONObject";
	private final String javaUtilsPackagePath = "java.util";
	private final String hashMapClass = "HashMap";
	private final String arrayListClass = "ArrayList";
	private final String pojoPackagetoGeneratejavafiles="com.key.mb.to";
	private final String calssNameStartsKey="KB";
	
	public void pojoGenerator() throws SQLException, Exception
	{
		HashMap<String,String> columnList = new HashMap<String, String>();
		ClassName superClassRecord = ClassName.get(packagePath, recordClass);	
		ClassName superClassDAO = ClassName.get(packagePath, daoClass);
		ArrayList<String> tablesData = Metadata.getTablesMetadata();		
		int countTables = tablesData.size();
		String className = null;

		for (String string : tablesData) {
			
			columnList = Metadata.getColumnsMetadataWitHFAN(string) ;
			className = StringUtils.replaceString(string, "_", "", true);
			className = calssNameStartsKey + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
			processGeneratePojo(pojoPackagetoGeneratejavafiles,className,columnList,superClassRecord);
		}
		System.out.println("***********************POJO Class Completed*********************");
		
	}
	private void processGeneratePojo(String packageName,String className,HashMap columns,ClassName superClass) throws IOException
	{
		File sourcePath = new File("src");
		TypeName LogUtils = ClassName.get(utilsPackagePath, logUtilsClass);
		TypeName  JSONObject= ClassName.get(jsonPackagePath, jSONObjectClass);
		TypeName  hashMap= ClassName.get(javaUtilsPackagePath, hashMapClass);
		TypeName  arrayList= ClassName.get(javaUtilsPackagePath, arrayListClass);
		TypeName classNamelog = ClassName.get(packageName, StringUtils.convertFirstCharacterToUpperCase(className));
		TypeSpec.Builder classObject = TypeSpec.classBuilder(StringUtils.convertFirstCharacterToUpperCase(className))
			    .addModifiers(Modifier.PUBLIC)
			    .superclass(superClass);
		 FieldSpec fieldSpec = FieldSpec.builder(LogUtils, "logger")
		            .addModifiers(Modifier.PUBLIC, Modifier.STATIC)
		            .initializer("new $T($T.class.getName())",LogUtils,classNamelog)
		            .build();
		 //FieldSpec fieldSpec2 = FieldSpec.builder(JSONObject, "")
		           // .build();
		classObject.addField(fieldSpec);
		//classObject.addField(fieldSpec2);
		Iterator keyIterator = columns.keySet().iterator();
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			String value = columns.get(key).toString();
			
			ClassName stringUtils = ClassName.get(utilsPackagePath, stringUtilsClass);
			key = key.replaceAll("\\s","");
			ClassName id = ClassName.get("", key);
			classObject.addField(String.class, key, Modifier.PUBLIC);
			
			
			
			classObject.addMethod(getterMethodspec("get"+StringUtils.convertFirstCharacterToUpperCase(key),stringUtils,key));
			
		}
		
		Iterator keyIterator2 = columns.keySet().iterator();
		
		while(keyIterator2.hasNext())
		{
			String key = keyIterator2.next().toString();
			String value = columns.get(key).toString();
			key = key.replaceAll("\\s","");
			classObject.addMethod(setterMethodspec("set"+StringUtils.convertFirstCharacterToUpperCase(key),key));
		}
		classObject.addMethod(loadContentMethodspec("loadContent",classNamelog,columns));
		classObject.addMethod(loadNonNullContentMethodspec("loadNonNullContent",classNamelog,columns));
		classObject.addMethod(getJSONObjectMethodspec("getJSONObject",JSONObject,columns));
		classObject.addMethod(loadJSONObjectMethodspec("loadJSONObject",JSONObject,columns));
		classObject.addMethod(getJSONObjectUIMethodspec("getJSONObjectUI",JSONObject,columns));
		classObject.addMethod(getTableMapMethodspec("getTableMap",hashMap,columns,arrayList));
		classObject.addMethod(toStringMethodspec("toString",columns));
		
		//
		
		JavaFile javaFile = JavaFile.builder(packageName, classObject.build())
				.build();
		javaFile.writeTo(sourcePath);	
	}
	
	private static MethodSpec getTableMapMethodspec(String methodName,TypeName hashMap,HashMap columns,TypeName arrayList)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		mehtod.addStatement("$T resultMap = new $T()", hashMap, hashMap);
		mehtod.addStatement("$T columnList = new $T()", arrayList, arrayList);
		mehtod.addStatement("resultMap.put(\"table\", \"call_back\")");
		Iterator keyIterator = columns.keySet().iterator();
		
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			key = key.replaceAll("\\s","");
			String keycaps  = StringUtils.convertFirstCharacterToUpperCase(key);
			
			mehtod.addStatement("columnList.add($S)", key);
			
		}
		mehtod.addStatement("resultMap.put(\"ColumnList\", columnList)");
		mehtod.addStatement("return resultMap");
		mehtod.returns(hashMap);
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private static MethodSpec logMethodspec(String methodName)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		mehtod.addStatement("logger.trace(this.toString())");
		
		return mehtod.build();
	}
	
	private static MethodSpec getJSONObjectUIMethodspec(String methodName,TypeName JSONObject,HashMap columns)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		Iterator keyIterator = columns.keySet().iterator();
		mehtod.addStatement("$T obj = new $T()", JSONObject, JSONObject);
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			key = key.replaceAll("\\s","");
			String keycaps  = StringUtils.convertFirstCharacterToUpperCase(key);
			
			mehtod.addStatement("obj.put($S,StringUtils.noNull($N))", key,key);
			
		}
		//mehtod.addParameter(JSONObject, "obj");
		mehtod.returns(JSONObject);
		mehtod.addModifiers(Modifier.PUBLIC);
		mehtod.addStatement("return obj");
		return mehtod.build(); 
	}
	
	
	private static MethodSpec loadJSONObjectMethodspec(String methodName,TypeName JSONObject,HashMap columns)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		TypeName exception = ClassName.get("java.lang", "Exception");
		Iterator keyIterator = columns.keySet().iterator();
		
		mehtod.beginControlFlow("if (obj == null)")
		.addStatement("return")
		.endControlFlow();
		
		//mehtod.addStatement("JSONObject obj = new JSONObject()", "");
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			key = key.replaceAll("\\s","");
			String keycaps  = StringUtils.convertFirstCharacterToUpperCase(key);
			
			mehtod.addStatement("$N = StringUtils.getValueFromJSONObject(obj, $S)", key,key);
			
		}
		mehtod.addParameter(JSONObject, "obj");
		mehtod.addException(exception);
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	private static MethodSpec getJSONObjectMethodspec(String methodName,TypeName JSONObject,HashMap columns)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		Iterator keyIterator = columns.keySet().iterator();
		
		mehtod.addStatement("$T obj = new $T()", JSONObject, JSONObject);
		//mehtod.addStatement("JSONObject obj = new JSONObject()", "");
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			key = key.replaceAll("\\s","");
			String keycaps  = StringUtils.convertFirstCharacterToUpperCase(key);
			
			mehtod.addStatement("obj.put(\"$N\",StringUtils.noNull($N))", key,key);
			
		}
		
		mehtod.addStatement("return obj");
		mehtod.returns(JSONObject);
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private static MethodSpec loadNonNullContentMethodspec(String methodName,TypeName classNamelog,HashMap columns)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		Iterator keyIterator = columns.keySet().iterator();
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			key = key.replaceAll("\\s","");
			key  = StringUtils.convertFirstCharacterToUpperCase(key);
			//String valued = columns.get(key).toString();
			mehtod.beginControlFlow("if (StringUtils.hasChanged(get$L(), inputRecord.get$L()))", key,key)
			.addStatement("set$N(StringUtils.noNull(inputRecord.get$N()))", key,key)
			.endControlFlow();
			
		}
	 
		
		mehtod.addParameter(classNamelog, "inputRecord");
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	private static MethodSpec loadContentMethodspec(String methodName,TypeName classNamelog,HashMap columns)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		Iterator keyIterator = columns.keySet().iterator();
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			key = key.replaceAll("\\s","");
			//String valued = columns.get(key).toString();
			mehtod.addStatement("set$N(inputRecord.get$N())", StringUtils.convertFirstCharacterToUpperCase(key),StringUtils.convertFirstCharacterToUpperCase(key));
		}
	 
		
		mehtod.addParameter(classNamelog, "inputRecord");
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build();
	}
	
	private static MethodSpec setterMethodspec(String methodName,String value)
	{
		return MethodSpec.methodBuilder(methodName)
				.addParameter(String.class, "value")
			    .addStatement("$N = value", value)
			    .addModifiers(Modifier.PUBLIC).build();
	}
	
	private static MethodSpec getterMethodspec(String name,ClassName stringUtils,String key)
	{
		return MethodSpec.methodBuilder(name)
	    .returns(String.class)
	    .beginControlFlow("if(isNoNullForHTMLEnabled())")
	    .addStatement("return $T.noNullForHTML($N)",stringUtils,key)
	    .endControlFlow()
	    .beginControlFlow("else if(isNoNullEnabled())")
	    .addStatement("return $T.noNull($N)",stringUtils,key)
	    .endControlFlow()
	    .beginControlFlow("else")
	    .addStatement("return $N",key)
	    .endControlFlow()
	    .addModifiers(Modifier.PUBLIC) //method will be abstract and protected
	    .build();
	}
	
	private static MethodSpec toStringMethodspec(String methodName,HashMap columns)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		mehtod.returns(String.class);
		Iterator keyIterator = columns.keySet().iterator();
		String returnStat = "return ";
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			key = key.replaceAll("\\s","");
			returnStat = returnStat +"\"$N:\" + $N +";
			returnStat = StringUtils.replaceString(returnStat, "$N", key, true);
			//
		} 
		returnStat = returnStat +"\"\"" ;
		mehtod.addStatement(returnStat);
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build();
	}
	

	
}
