/*
 * Metadata.java.java
 *
 * Copyright (c) ModeFinserver Private Limited
 *
 *
 * This software is the confidential and proprietary information of 
 * ModeFinserver Private Limited ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with ModeFinserver Private Limited
 *
 * Project Name             : MODE Mobile Banking
 * Module                   : Mobile Banking V4
 * Author                   : ModeFinserver Private Limited
 * Date                     : Mar 23, 2013
 * Change Revision
 * ----------------------------------------------------------------
 * Date            Author         Version#    Remarks/Description
 *-----------------------------------------------------------------
 *
 */

package com.derby.test;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import com.derby.utils.StringUtils;



public class Metadata {
	


	static Connection connection = null;
	static DatabaseMetaData metadata = null;

	// Static block for initialization
	static {
		connection = new DBConnector().getDatabaseConnection();

		try {
			metadata = connection.getMetaData();
		} catch (SQLException e) {
			System.err.println("There was an error getting the metadata: "
					+ e.getMessage());
		}
	}

	/**
	 * Prints in the console the general metadata.
	 * 
	 * @throws SQLException
	 */
	public static void printGeneralMetadata() throws SQLException {
		System.out.println("Database Product Name: "
				+ metadata.getDatabaseProductName());
		System.out.println("Database Product Version: "
				+ metadata.getDatabaseProductVersion());
		System.out.println("Logged User: " + metadata.getUserName());
		System.out.println("JDBC Driver: " + metadata.getDriverName());
		System.out.println("Driver Version: " + metadata.getDriverVersion());
		System.out.println("\n");
	}

	/**
	 * 
	 * @return Arraylist with the table's name
	 * @throws SQLException
	 */
	public static ArrayList getTablesMetadata() throws SQLException {
		String table[] = { "TABLE","VIEW" };
		ResultSet rs = null;
		ArrayList tables = null;
		// receive the Type of the object in a String array.
		rs = metadata.getTables(null, null, null, table);
		tables = new ArrayList();
		//String tablestogenerate = "system_user,content_map,controller_map,mobile_menu_map,customer,customer_category,user_roles,web_session,system_user_view,service_map,mobile_session,mobile_session2"
			//	+ "system_user_view,content_map_view,controller_map_view,mobile_menu_map_view,customer_view,customer_category_view,user_roles_view,web_session_view,service_map_view,mobile_session_view,mobile_session2_view";
		//String tablestogenerate = "account,content_map,mobile_menu_map,customer,customer_category,service_map,mobile_session,mobile_session2,mobilejsonrequest,mobilejsonresponse,funds_transfer_transaction"
		//		+ "account_view,content_map_view,controller_map_view,mobile_menu_map_view,customer_view,customer_category_view,service_map_view,mobile_session_view,mobile_session2_view,funds_transfer_transaction_view";
		String tablestogenerate = "agency";
		while (rs.next()) {
			if(tablestogenerate.toLowerCase().contains(rs.getString("TABLE_NAME").toLowerCase()))
			{
				tables.add(rs.getString("TABLE_NAME").toLowerCase());
				System.out.println(rs.getString("TABLE_NAME").toLowerCase());
				
			}
		}
		return tables;
	}

	/**
	 * Prints in the console the columns metadata, based in the Arraylist of
	 * tables passed as parameter.
	 * 
	 * @param tables
	 * @throws SQLException
	 */
/*	public static HashMap getColumnsMetadata(ArrayList<String> tables)
			throws SQLException {
		HashMap<String,String> columnList = new HashMap<String, String>();
		ResultSet rs = null;
		// Print the columns properties of the actual table
		for (String actualTable : tables) {
			rs = metadata.getColumns(null, null, actualTable, null);
			System.out.println(actualTable.toUpperCase());
			while (rs.next()) {
				
				System.out.println(rs.getString("COLUMN_NAME") + " "
						+ rs.getString("TYPE_NAME") + " "
						+ rs.getString("COLUMN_SIZE"));
				 columnList.put(""+StringUtils.replaceString(rs.getString("COLUMN_NAME").toLowerCase(), "_", "", true).toLowerCase(), ""+rs.getString("TYPE_NAME"));
			}
			System.out.println("\n");
		}
      return columnList;
	}*/
	
	
	public static HashMap getColumnsMetadata(String tables)
			throws SQLException {
		HashMap<String,String> columnList = new HashMap<String, String>();
		ResultSet rs = null;
		// Print the columns properties of the actual table
		//for (String actualTable : tables) {
			rs = metadata.getColumns(null, null, tables.toUpperCase(), null);
			System.out.println(tables.toUpperCase());
			while (rs.next()) {
				
				System.out.println(rs.getString("COLUMN_NAME") + " "
						+ rs.getString("TYPE_NAME") + " "
						+ rs.getString("COLUMN_SIZE"));
				 //columnList.put(""+StringUtils.replaceString(rs.getString("COLUMN_NAME").toLowerCase(), "_", "", true).toLowerCase(), ""+rs.getString("TYPE_NAME"));
				 columnList.put(""+rs.getString("COLUMN_NAME").toLowerCase(), ""+rs.getString("TYPE_NAME"));
			}
			System.out.println("\n");
		//}
      return columnList;
	}
	
	public static HashMap getColumnsMetadataWitHFAN(String tables)
			throws SQLException {
		HashMap<String,String> columnList = new HashMap<String, String>();
		ResultSet rs = null;
		// Print the columns properties of the actual table
		//for (String actualTable : tables) {
			rs = metadata.getColumns(null, null,tables.toUpperCase(), null);//getColumns(null, null, tables, null);
			System.out.println("Table:"+tables.toUpperCase());
			while (rs.next()) {
				
				System.out.println(rs.getString("COLUMN_NAME") + " "
						+ rs.getString("TYPE_NAME") + " "
						+ rs.getString("COLUMN_SIZE"));
				 columnList.put(""+StringUtils.replaceString(rs.getString("COLUMN_NAME").toLowerCase(), "_", "", true).toLowerCase(), ""+rs.getString("TYPE_NAME"));
				// columnList.put(""+rs.getString("COLUMN_NAME"), ""+rs.getString("TYPE_NAME"));
			}
			System.out.println("\n");
		//}
      return columnList;
	}

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			printGeneralMetadata();
			// Print all the tables of the database scheme, with their names and
			// structure
			//getColumnsMetadata(getTablesMetadata());
			ArrayList<String> tablesData = Metadata.getTablesMetadata();		
			int countTables = tablesData.size();
			System.out.println("Tables Count:"+countTables);
		} catch (SQLException e) {
			System.err
					.println("There was an error retrieving the metadata properties: "
							+ e.getMessage());
		}
	}

}
