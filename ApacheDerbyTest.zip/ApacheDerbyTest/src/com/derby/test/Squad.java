package com.derby.test;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Type;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import javax.lang.model.element.Modifier;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.derby.utils.StringUtils;
import com.squareup.javapoet.ArrayTypeName;
import com.squareup.javapoet.ClassName;
import com.squareup.javapoet.FieldSpec;
import com.squareup.javapoet.JavaFile;
import com.squareup.javapoet.MethodSpec;
import com.squareup.javapoet.MethodSpec.Builder;
import com.squareup.javapoet.ParameterSpec;
import com.squareup.javapoet.ParameterizedTypeName;
import com.squareup.javapoet.TypeName;
import com.squareup.javapoet.TypeSpec;


public class Squad {
	
	static TypeName globalstringUtils = ClassName.get("com.mtreetech.sawc.utils", "StringUtils");
	
	public static void main(String[] args) throws Exception
	{
		Squad sq = new Squad();
		
		try {
			
			//MFSecurityUtil util = new MFSecurityUtil();
			//System.out.println("Password ::: "+util.encrypt("password"));
			//
			sq.test("");
			//sq.service("");
			/*String query = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
			query +="<msg><sessionid>7168187341</sessionid><response>Welcome to LPB";
			query +="\\n1.Login";
			query +="\\n2.Self Registration";
			query +="</response></msg>";
			System.out.println(query);
			System.out.println(query.replaceAll("\\\\n", ""));*/
			//MFSecurityUtil util = new MFSecurityUtil();
			//System.out.println(util.encrypt("root"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void all0and1sides(int inputArray[],int size)
	{
		int left=0, right=size-1;
		while(left < right)
		{
			while(inputArray[left] == 0 && left < right)
				left++;
			while(inputArray[right] == 0 && left < right)
				right++;
			
			if(left < right)
			{
				inputArray[left]=0;
				inputArray[right]=1;
				left++;
				right--;
			}
			
		}
	}
	
	
	
	private static MethodSpec toStringMethodspec(String methodName,HashMap columns)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		mehtod.returns(String.class);
		Iterator keyIterator = columns.keySet().iterator();
		String returnStat = "return ";
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			key = key.replaceAll("\\s","");
			returnStat = returnStat +"\"$N:\" + $N +";
			returnStat = StringUtils.replaceString(returnStat, "$N", key, true);
			//
		} 
		returnStat = returnStat +"\"\"" ;
		mehtod.addStatement(returnStat);
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build();
	}
	
	private static MethodSpec getTableMapMethodspec(String methodName,TypeName hashMap,HashMap columns,TypeName arrayList)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		mehtod.addStatement("$T resultMap = new $T()", hashMap, hashMap);
		mehtod.addStatement("$T columnList = new $T()", arrayList, arrayList);
		mehtod.addStatement("resultMap.put(\"table\", \"call_back\")");
		Iterator keyIterator = columns.keySet().iterator();
		
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			key = key.replaceAll("\\s","");
			String keycaps  = StringUtils.convertFirstCharacterToUpperCase(key);
			
			mehtod.addStatement("columnList.add($S)", key);
			
		}
		mehtod.addStatement("resultMap.put(\"ColumnList\", columnList)");
		mehtod.addStatement("return resultMap");
		mehtod.returns(hashMap);
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private static MethodSpec logMethodspec(String methodName)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		mehtod.addStatement("logger.trace(this.toString())");
		
		return mehtod.build();
	}
	
	private static MethodSpec getJSONObjectUIMethodspec(String methodName,TypeName JSONObject,HashMap columns)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		Iterator keyIterator = columns.keySet().iterator();
		mehtod.addStatement("$T obj = new $T()", JSONObject, JSONObject);
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			key = key.replaceAll("\\s","");
			String keycaps  = StringUtils.convertFirstCharacterToUpperCase(key);
			
			mehtod.addStatement("obj.put($S,StringUtils.noNull($N))", key,key);
			
		}
		//mehtod.addParameter(JSONObject, "obj");
		mehtod.returns(JSONObject);
		mehtod.addModifiers(Modifier.PUBLIC);
		mehtod.addStatement("return obj");
		return mehtod.build(); 
	}
	
	
	private static MethodSpec loadJSONObjectMethodspec(String methodName,TypeName JSONObject,HashMap columns)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		TypeName exception = ClassName.get("java.lang", "Exception");
		Iterator keyIterator = columns.keySet().iterator();
		
		mehtod.beginControlFlow("if (obj == null)")
		.addStatement("return")
		.endControlFlow();
		
		//mehtod.addStatement("JSONObject obj = new JSONObject()", "");
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			key = key.replaceAll("\\s","");
			String keycaps  = StringUtils.convertFirstCharacterToUpperCase(key);
			
			mehtod.addStatement("$N = StringUtils.getValueFromJSONObject(obj, $S)", key,key);
			
		}
		mehtod.addParameter(JSONObject, "obj");
		mehtod.addException(exception);
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	private static MethodSpec getJSONObjectMethodspec(String methodName,TypeName JSONObject,HashMap columns)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		Iterator keyIterator = columns.keySet().iterator();
		
		mehtod.addStatement("$T obj = new $T()", JSONObject, JSONObject);
		//mehtod.addStatement("JSONObject obj = new JSONObject()", "");
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			key = key.replaceAll("\\s","");
			String keycaps  = StringUtils.convertFirstCharacterToUpperCase(key);
			
			mehtod.addStatement("obj.put(\"$N\",StringUtils.noNull($N))", key,key);
			
		}
		
		mehtod.addStatement("return obj");
		mehtod.returns(JSONObject);
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private static MethodSpec loadNonNullContentMethodspec(String methodName,TypeName classNamelog,HashMap columns)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		Iterator keyIterator = columns.keySet().iterator();
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			key = key.replaceAll("\\s","");
			key  = StringUtils.convertFirstCharacterToUpperCase(key);
			//String valued = columns.get(key).toString();
			mehtod.beginControlFlow("if (StringUtils.hasChanged(get$L(), inputRecord.get$L()))", key,key)
			.addStatement("set$N(StringUtils.noNull(inputRecord.get$N()))", key,key)
			.endControlFlow();
			
		}
	 
		
		mehtod.addParameter(classNamelog, "inputRecord");
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	private static MethodSpec loadContentMethodspec(String methodName,TypeName classNamelog,HashMap columns)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		Iterator keyIterator = columns.keySet().iterator();
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			key = key.replaceAll("\\s","");
			//String valued = columns.get(key).toString();
			mehtod.addStatement("set$N(inputRecord.get$N())", StringUtils.convertFirstCharacterToUpperCase(key),StringUtils.convertFirstCharacterToUpperCase(key));
		}
	 
		
		mehtod.addParameter(classNamelog, "inputRecord");
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build();
	}
	
	private static MethodSpec setterMethodspec(String methodName,String value)
	{
		return MethodSpec.methodBuilder(methodName)
				.addParameter(String.class, "value")
			    .addStatement("$N = value", value)
			    .addModifiers(Modifier.PUBLIC).build();
	}
	
	private static MethodSpec getterMethodspec(String name,ClassName stringUtils,String key)
	{
		return MethodSpec.methodBuilder(name)
	    .returns(String.class)
	    .beginControlFlow("if(isNoNullForHTMLEnabled())")
	    .addStatement("return $T.noNullForHTML($N)",stringUtils,key)
	    .endControlFlow()
	    .beginControlFlow("else if(isNoNullEnabled())")
	    .addStatement("return $T.noNull($N)",stringUtils,key)
	    .endControlFlow()
	    .beginControlFlow("else")
	    .addStatement("return $N",key)
	    .endControlFlow()
	    .addModifiers(Modifier.PUBLIC) //method will be abstract and protected
	    .build();
	}
	
	private void processGeneratePojo(String packageName,String className,HashMap columns,ClassName superClass) throws IOException
	{
		File sourcePath = new File("src");
		TypeName LogUtils = ClassName.get("com.mtreetech.sawc.utils", "LogUtils");
		TypeName  JSONObject= ClassName.get("org.json.simple", "JSONObject");
		TypeName  hashMap= ClassName.get("java.util", "HashMap");
		TypeName  arrayList= ClassName.get("java.util", "ArrayList");
		TypeName classNamelog = ClassName.get(packageName, StringUtils.convertFirstCharacterToUpperCase(className));
		TypeSpec.Builder classObject = TypeSpec.classBuilder(StringUtils.convertFirstCharacterToUpperCase(className))
			    .addModifiers(Modifier.PUBLIC)
			    .superclass(superClass);
		 FieldSpec fieldSpec = FieldSpec.builder(LogUtils, "logger")
		            .addModifiers(Modifier.PUBLIC, Modifier.STATIC)
		            .initializer("new $T($T.class.getName())",LogUtils,classNamelog)
		            .build();
		 //FieldSpec fieldSpec2 = FieldSpec.builder(JSONObject, "")
		           // .build();
		classObject.addField(fieldSpec);
		//classObject.addField(fieldSpec2);
		Iterator keyIterator = columns.keySet().iterator();
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			String value = columns.get(key).toString();
			
			ClassName stringUtils = ClassName.get("com.mtreetech.sawc.utils", "StringUtils");
			key = key.replaceAll("\\s","");
			ClassName id = ClassName.get("", key);
			classObject.addField(String.class, key, Modifier.PUBLIC);
			
			
			
			classObject.addMethod(getterMethodspec("get"+StringUtils.convertFirstCharacterToUpperCase(key),stringUtils,key));
			
		}
		
		Iterator keyIterator2 = columns.keySet().iterator();
		
		while(keyIterator2.hasNext())
		{
			String key = keyIterator2.next().toString();
			String value = columns.get(key).toString();
			key = key.replaceAll("\\s","");
			classObject.addMethod(setterMethodspec("set"+StringUtils.convertFirstCharacterToUpperCase(key),key));
		}
		classObject.addMethod(loadContentMethodspec("loadContent",classNamelog,columns));
		classObject.addMethod(loadNonNullContentMethodspec("loadNonNullContent",classNamelog,columns));
		classObject.addMethod(getJSONObjectMethodspec("getJSONObject",JSONObject,columns));
		classObject.addMethod(loadJSONObjectMethodspec("loadJSONObject",JSONObject,columns));
		classObject.addMethod(getJSONObjectUIMethodspec("getJSONObjectUI",JSONObject,columns));
		classObject.addMethod(getTableMapMethodspec("getTableMap",hashMap,columns,arrayList));
		classObject.addMethod(toStringMethodspec("toString",columns));
		
		//
		
		JavaFile javaFile = JavaFile.builder(packageName, classObject.build())
				.build();
		javaFile.writeTo(sourcePath);
		
			
		
	
	}
	
	private HashMap getConnection(String Query) throws SQLException, Exception
	{
		HashMap<String,String> columnList = new HashMap<String, String>();
		ClassName superClassRecord = ClassName.get("com.mtreetech.sawc.common", "MFRecord");	
		ClassName superClassDAO = ClassName.get("com.mtreetech.sawc.common", "MFDAO");
		ArrayList<String> tablesData = Metadata.getTablesMetadata();		
		int countTables = tablesData.size();
		String className = null;

		for (String string : tablesData) {
			
			columnList = Metadata.getColumnsMetadataWitHFAN(string) ;
			className = StringUtils.replaceString(string, "_", "", true);
			className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
			processGeneratePojo("com.mtreetech.sawc.to",className,columnList,superClassRecord);
		}
		System.out.println("***********************POJO Class Completed*********************");
		return null;
	}
	
	private HashMap test(String Query) throws SQLException, Exception
	{
		
		getConnection("");
		HashMap<String,String> columnList = new HashMap<String, String>();
		//ClassName superClassRecord = ClassName.get("com.mtreetech.sawc.common", "MFRecord");	
		ClassName superClassDAO = ClassName.get("com.mtreetech.sawc.common", "MFDAO");
		ArrayList<String> tablesData = Metadata.getTablesMetadata();		
		int countTables = tablesData.size();
		String className = null,classNameRecord= null,temp = null,originaltableName= null;

		for (String string : tablesData) {
			
			columnList = Metadata.getColumnsMetadata(string) ;
			originaltableName = string.toLowerCase();
			className = StringUtils.replaceString(string, "_", "", true);
			temp = className;
			if("tmpesapendingtransactions".equalsIgnoreCase(className) || "statuscode".equalsIgnoreCase(className) || "sequencedata".equalsIgnoreCase(className)) continue;
			className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "DAO";
			classNameRecord = "MT" + StringUtils.convertFirstCharacterToUpperCase(temp) + "Record";
			generateDAOLayer("com.mtreetech.sawc.dao",className,columnList,superClassDAO,classNameRecord,originaltableName);
			
		}
		System.out.println("***********************DAO Class Completed*********************");
		service("");
		controller("");
		return null;
	}
	
	private HashMap service(String Query) throws SQLException, Exception
	{
		HashMap<String,String> columnList = new HashMap<String, String>();
		//ClassName superClassRecord = ClassName.get("com.mtreetech.sawc.common", "MFRecord");	
		ClassName superClassService = ClassName.get("com.mtreetech.sawc.common", "MFService");
		ArrayList<String> tablesData = Metadata.getTablesMetadata();		
		int countTables = tablesData.size();
		String className = null,classNameRecord= null,temp = null,originaltableName= null,classNameDAO= null ;

		for (String string : tablesData) {
			
			columnList = Metadata.getColumnsMetadata(string) ;
			originaltableName = string.toLowerCase();
			className = StringUtils.replaceString(string, "_", "", true);
			temp = className;
			if("tmpesapendingtransactions".equalsIgnoreCase(className) || "statuscode".equalsIgnoreCase(className) || "sequencedata".equalsIgnoreCase(className) 
					|| "reportwalletaccountsummary".equalsIgnoreCase(className) || "reportwalletcustomersummary".equalsIgnoreCase(className)
					|| "reportsystemuserlist".equalsIgnoreCase(className) || "reportcustomeribactivelist".equalsIgnoreCase(className) 
					|| "reportcustomeribinactivelist".equalsIgnoreCase(className) || "reportcustomerlist".equalsIgnoreCase(className)) continue;
			classNameDAO = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "DAO";
			classNameRecord = "MT" + StringUtils.convertFirstCharacterToUpperCase(temp) + "Record";
			className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Service";
			generateServiceLayer("com.mtreetech.sawc.service",className,columnList,superClassService,classNameRecord,originaltableName,classNameDAO);
			//break;
		}
		System.out.println("***********************Service Class Completed*********************");
		return null;
	}
	
	private HashMap controller(String Query) throws SQLException, Exception
	{
		HashMap<String,String> columnList = new HashMap<String, String>();
		//ClassName superClassRecord = ClassName.get("com.mtreetech.sawc.common", "MFRecord");	
		ClassName superClassService = ClassName.get("com.mtreetech.sawc.common", "MFController");
		ArrayList<String> tablesData = Metadata.getTablesMetadata();		
		int countTables = tablesData.size();
		String className = null,classNameRecord= null,temp = null,originaltableName= null,classNameDAO= null,classNameService = null,classNameController = null;

		for (String string : tablesData) {
			
			columnList = Metadata.getColumnsMetadata(string) ;
			originaltableName = string.toLowerCase();
			className = StringUtils.replaceString(string, "_", "", true);
			temp = className;
			if("tmpesapendingtransactions".equalsIgnoreCase(className) || "statuscode".equalsIgnoreCase(className) || "sequencedata".equalsIgnoreCase(className)) continue;
			classNameDAO = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "DAO";
			classNameRecord = "MT" + StringUtils.convertFirstCharacterToUpperCase(temp) + "Record";
			className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Controller";
			classNameService = "MT" + StringUtils.convertFirstCharacterToUpperCase(temp) + "Service";
			generateControllerLayer("com.mtreetech.sawc.controller",className,columnList,superClassService,classNameRecord,originaltableName,classNameDAO,classNameService);
			//break;
		}
		System.out.println("***********************Controllers Class Completed*********************");
		return null;
	}
	
	private void generateControllerLayer(String packageName,String className,HashMap tableColumns,ClassName extendedClass,String classNameRecord,String originaltableName,String classNameDAO,String classNameService) throws Exception
	{
		File sourcePath = new File("src");
		TypeName LogUtils = ClassName.get("com.mtreetech.sawc.utils", "LogUtils");
		TypeName stringUtils = ClassName.get("com.mtreetech.sawc.utils", "StringUtils");
		TypeName  JSONObject= ClassName.get("org.json.simple", "JSONObject");
		TypeName  hashMap= ClassName.get("java.util", "HashMap");
		TypeName  arrayList= ClassName.get("java.util", "ArrayList");
		
		TypeName classNamelog = ClassName.get(packageName, StringUtils.convertFirstCharacterToUpperCase(className));
		TypeSpec.Builder classObject = TypeSpec.classBuilder(StringUtils.convertFirstCharacterToUpperCase(className))
			    .addModifiers(Modifier.PUBLIC)
			    .superclass(extendedClass);
		 FieldSpec fieldSpec = FieldSpec.builder(LogUtils, "logger")
		            .addModifiers(Modifier.PUBLIC, Modifier.STATIC)
		            .initializer("new $T($T.class.getName())",LogUtils,classNamelog)
		            .build();
		classObject.addField(fieldSpec);
		
		Iterator keyIterator = tableColumns.keySet().iterator();
		String firstCaps = null;
		String allCaps = null;
		boolean checkContainstoaddMethods = false;
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();	
		    if(firstCaps.equalsIgnoreCase("Createdby"))
		    	{
		    	//getCreatedby
		    	checkContainstoaddMethods = true;
		    		break;
		    	}
		
			
		}
		
		boolean idKey = false;
		Iterator keyIterator2 = tableColumns.keySet().iterator();
		
		while(keyIterator2.hasNext())
		{
			String key = keyIterator2.next().toString();
			if(key.equalsIgnoreCase("id")) 
			{
				idKey = true;
				break;
			}
			
		}
				
		classObject.addMethod(loadFormControllerRecordsMethodspec("loadForm"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO));
		classObject.addMethod(loadJSONFormFormControllerRecordsMethodspec("loadJSONForm"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO));
		classObject.addMethod(loadJSONFormFormEncodeControllerRecordsMethodspec("loadJSONForm"+classNameRecord+"Encode",classNamelog,tableColumns,classNameRecord,classNameDAO));
		classObject.addMethod(loadMapControllerRecordsMethodspec("loadMap"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO));
		if(idKey)
		{
		classObject.addMethod(processInsertControllerRecordsMethodspec("processInsert"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,classNameService,className,checkContainstoaddMethods));
		
		classObject.addMethod(processUpdateControllerRecordsMethodspec("processUpdate"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,classNameService,className,checkContainstoaddMethods));
		classObject.addMethod(processDeleteControllerRecordsMethodspec("processDelete"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,classNameService,className,checkContainstoaddMethods));
		classObject.addMethod(processWebControllerRecordsMethodspec("processWebRequest",classNamelog,tableColumns,classNameRecord,classNameDAO,classNameService,className));
		}
		
		
		JavaFile javaFile = JavaFile.builder(packageName, classObject.build())
				.build();
		javaFile.writeTo(sourcePath);
		/*classObject.addMethod(insertServiceRecordMethodspec("insert"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,className,checkContainstoaddMethods));
		classObject.addMethod(updateServiceRecordMethodspec("update"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,className,checkContainstoaddMethods));
		classObject.addMethod(updateServiceRecordNoNullMethodspec("update"+classNameRecord+"NoNull",classNamelog,tableColumns,classNameRecord,classNameDAO,className,checkContainstoaddMethods));
		classObject.addMethod(deleteServiceRecordNoNullMethodspec("delete"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,className,checkContainstoaddMethods));
		*/
	}

	private void generateServiceLayer(String packageName,String className,HashMap tableColumns,ClassName extendedClass,String classNameRecord,String originaltableName,String classNameDAO) throws Exception
	{
		File sourcePath = new File("src");
		TypeName LogUtils = ClassName.get("com.mtreetech.sawc.utils", "LogUtils");
		TypeName stringUtils = ClassName.get("com.mtreetech.sawc.utils", "StringUtils");
		TypeName  JSONObject= ClassName.get("org.json.simple", "JSONObject");
		TypeName  hashMap= ClassName.get("java.util", "HashMap");
		TypeName  arrayList= ClassName.get("java.util", "ArrayList");
		
		TypeName classNamelog = ClassName.get(packageName, StringUtils.convertFirstCharacterToUpperCase(className));
		TypeSpec.Builder classObject = TypeSpec.classBuilder(StringUtils.convertFirstCharacterToUpperCase(className))
			    .addModifiers(Modifier.PUBLIC)
			    .superclass(extendedClass);
		 FieldSpec fieldSpec = FieldSpec.builder(LogUtils, "logger")
		            .addModifiers(Modifier.PUBLIC, Modifier.STATIC)
		            .initializer("new $T($T.class.getName())",LogUtils,classNamelog)
		            .build();
		classObject.addField(fieldSpec);
		
		Iterator keyIterator = tableColumns.keySet().iterator();
		String firstCaps = null;
		String allCaps = null;
		boolean checkContainstoaddMethods = false;
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();	
		    if(firstCaps.equalsIgnoreCase("Madeby"))
		    	{
		    	//getCreatedby
		    	checkContainstoaddMethods = true;
		    		break;
		    	}
		
			
		}
		
		boolean idKey = false;
		Iterator keyIterator2 = tableColumns.keySet().iterator();
		
		while(keyIterator2.hasNext())
		{
			String key = keyIterator2.next().toString();
			if(key.equalsIgnoreCase("id")) 
			{
				idKey = true;
				break;
			}
			
		}
				
		classObject.addMethod(loadServiceRecordsMethodspec("load"+classNameRecord+"s",classNamelog,tableColumns,classNameRecord,classNameDAO));
		classObject.addMethod(loadServiceFirstRecordsMethodspec("loadFirst"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO));
		classObject.addMethod(searchServiceFirstRecordsMethodspec("searchFirst"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO));
		classObject.addMethod(searchServiceExactUpperRecordsMethodspec("search"+classNameRecord+"ExactUpper",classNamelog,tableColumns,classNameRecord,classNameDAO));
		classObject.addMethod(searchServiceArrayRecordsMethodspec("search"+classNameRecord+"s",classNamelog,tableColumns,classNameRecord,classNameDAO));
		classObject.addMethod(loadServiceRecordCountMethodspec("load"+classNameRecord+"Count",classNamelog,tableColumns,classNameRecord,classNameDAO));
		classObject.addMethod(loadServiceRecordCountTwoParametersMethodspec("load"+classNameRecord+"Count",classNamelog,tableColumns,classNameRecord,classNameDAO));
		classObject.addMethod(loadServiceRecordkeyParameterMethodspec("load"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO));
		classObject.addMethod(getJSONSearchResultByPageMethodspec("getJSON"+classNameRecord+"SearchResultByPage",classNamelog,tableColumns,classNameRecord,classNameDAO));
		classObject.addMethod(getJSONSearchResultByPageFirstMethodspec("getJSON"+classNameRecord+"SearchResultByPage",classNamelog,tableColumns,classNameRecord,classNameDAO));
		if(idKey)
		{
		classObject.addMethod(insertServiceRecordMethodspec("insert"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,className,checkContainstoaddMethods));
		classObject.addMethod(updateServiceRecordMethodspec("update"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,className,checkContainstoaddMethods));
		classObject.addMethod(updateServiceRecordNoNullMethodspec("update"+classNameRecord+"NonNull",classNamelog,tableColumns,classNameRecord,classNameDAO,className,checkContainstoaddMethods));
		classObject.addMethod(deleteServiceRecordNoNullMethodspec("delete"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,className,checkContainstoaddMethods));
		}
		if(checkContainstoaddMethods)
		{
		classObject.addMethod(approveServiceRecordNoNullMethodspec("approve"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,className));
		classObject.addMethod(submitServiceRecordNoNullMethodspec("submit"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,className));
		classObject.addMethod(denyServiceRecordNoNullMethodspec("deny"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,className));
		classObject.addMethod(denyPermanentServiceRecordNoNullMethodspec("denyPermanant"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,className));
		classObject.addMethod(remindServiceRecordNoNullMethodspec("remindApproval"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,className));
		classObject.addMethod(resetServiceRecordNoNullMethodspec("resetApproval"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,className));
		}
		
		
		
		
		JavaFile javaFile = JavaFile.builder(packageName, classObject.build())
				.build();
		javaFile.writeTo(sourcePath);
		
		
		
		
	}
	
	
	
	
	private void generateDAOLayer(String packageName,String className,HashMap tableColumns,ClassName extendedClass,String classNameRecord,String originaltableName) throws Exception
	{

		File sourcePath = new File("src");
		TypeName LogUtils = ClassName.get("com.mtreetech.sawc.utils", "LogUtils");
		TypeName stringUtils = ClassName.get("com.mtreetech.sawc.utils", "StringUtils");
		TypeName  JSONObject= ClassName.get("org.json.simple", "JSONObject");
		TypeName  hashMap= ClassName.get("java.util", "HashMap");
		TypeName  arrayList= ClassName.get("java.util", "ArrayList");
		
		TypeName classNamelog = ClassName.get(packageName, StringUtils.convertFirstCharacterToUpperCase(className));
		TypeSpec.Builder classObject = TypeSpec.classBuilder(StringUtils.convertFirstCharacterToUpperCase(className))
			    .addModifiers(Modifier.PUBLIC)
			    .superclass(extendedClass);
		 FieldSpec fieldSpec = FieldSpec.builder(LogUtils, "logger")
		            .addModifiers(Modifier.PUBLIC, Modifier.STATIC)
		            .initializer("new $T($T.class.getName())",LogUtils,classNamelog)
		            .build();
		 
		classObject.addField(fieldSpec);
		//classObject.addField(stringUtils);
		//classObject.addField(fieldSpec2);
		/*Iterator keyIterator = tableColumns.keySet().iterator();
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			String value = tableColumns.get(key).toString();
			
			ClassName stringUtils = ClassName.get("com.mtreetech.sawc.utils", "StringUtils");
			ClassName id = ClassName.get("", key);
			classObject.addField(String.class, key, Modifier.PUBLIC);
			

			
			classObject.addMethod(getterMethodspec("get"+StringUtils.convertFirstCharacterToUpperCase(key),stringUtils,id));
			
		}
		
		Iterator keyIterator2 = tableColumns.keySet().iterator();
		
		while(keyIterator2.hasNext())
		{
			String key = keyIterator2.next().toString();
			String value = tableColumns.get(key).toString();
			classObject.addMethod(setterMethodspec("set"+StringUtils.convertFirstCharacterToUpperCase(key),key));
		}*/
		boolean idKey = false;
		Iterator keyIterator2 = tableColumns.keySet().iterator();
		
		while(keyIterator2.hasNext())
		{
			String key = keyIterator2.next().toString();
			if(key.equalsIgnoreCase("id")) 
			{
				idKey = true;
				break;
			}
			
		}
		
		classObject.addMethod(loadArrayRecordsMethodspec("load"+classNameRecord+"s",classNamelog,tableColumns,classNameRecord));
		classObject.addMethod(loadArrayRecordsFirstMethodspec("load"+classNameRecord+"s",classNamelog,tableColumns,classNameRecord));
		classObject.addMethod(loadFirstRecordMethodspec("loadFirst"+classNameRecord,classNamelog,tableColumns,classNameRecord));
		
		//$PK$
		if(idKey)
		{
			classObject.addMethod(loadRecordsMethodspec("load"+classNameRecord,classNamelog,tableColumns,classNameRecord,originaltableName));
		}
		else
		{
			classObject.addMethod(loadRecordsPKMethodspec("load"+classNameRecord,classNamelog,tableColumns,classNameRecord,originaltableName));
		}
		
		classObject.addMethod(loadRecordFirstMethodspec("load"+classNameRecord,classNamelog,tableColumns,classNameRecord));
		if(idKey)
		{
			classObject.addMethod(insertRecordsMethodspec("insert"+classNameRecord,classNamelog,tableColumns,classNameRecord,originaltableName));
			classObject.addMethod(insertRecordFirstMethodspec("insert"+classNameRecord,classNamelog,tableColumns,classNameRecord));
			classObject.addMethod(updateRecordsMethodspec("update"+classNameRecord,classNamelog,tableColumns,classNameRecord,originaltableName,stringUtils));
			classObject.addMethod(updateRecordFirstMethodspec("update"+classNameRecord,classNamelog,tableColumns,classNameRecord));
			classObject.addMethod(deleteRecordsMethodspec("delete"+classNameRecord,classNamelog,tableColumns,classNameRecord,originaltableName,stringUtils));
			classObject.addMethod(deleteRecordFirstMethodspec("delete"+classNameRecord,classNamelog,tableColumns,classNameRecord));
		}
		classObject.addMethod(searchRecordsMethodspec("search"+classNameRecord+"s",classNamelog,tableColumns,classNameRecord,originaltableName,stringUtils));
		classObject.addMethod(searchRecordsExactUpperMethodspec("search"+classNameRecord+"s",classNamelog,tableColumns,classNameRecord,originaltableName,stringUtils));
		classObject.addMethod(loadRecordsCountMethodspec("load"+classNameRecord,classNamelog,tableColumns,classNameRecord,originaltableName,stringUtils));
		
		
		classObject.addMethod(loadRecordsCountExactUpperMethodspec("load"+classNameRecord,classNamelog,tableColumns,classNameRecord,originaltableName,stringUtils));
		/*classObject.addMethod(loadContentMethodspec("loadContent",classNamelog,tableColumns));
		classObject.addMethod(loadNonNullContentMethodspec("loadNonNullContent",classNamelog,tableColumns));
		classObject.addMethod(getJSONObjectMethodspec("getJSONObject",JSONObject,tableColumns));
		classObject.addMethod(loadJSONObjectMethodspec("loadJSONObject",JSONObject,tableColumns));
		classObject.addMethod(getJSONObjectUIMethodspec("getJSONObjectUI",JSONObject,tableColumns));
		classObject.addMethod(getTableMapMethodspec("getTableMap",hashMap,tableColumns,arrayList));
		classObject.addMethod(toStringMethodspec("toString",tableColumns));	*/
		JavaFile javaFile = JavaFile.builder(packageName, classObject.build()).addFileComment("Author Tulasi Vara Prasad")
				.build();
		javaFile.writeTo(sourcePath);
		
	
	}
	/*
	 * DAO Layer
	 */
	
	private static MethodSpec loadArrayRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);		
		TypeName exception = ClassName.get("java.lang", "Exception");
		TypeName arrayList = ClassName.get("java.util", "ArrayList");
		TypeName preparedStatement = ClassName.get("java.sql", "PreparedStatement");
		TypeName resultSet = ClassName.get("java.sql", "ResultSet");
		

		
		mehtod.addParameter(String.class, "query");
		mehtod.addParameter(Connection.class, "con");
		mehtod.addParameter(boolean.class, "closeConnection");
		mehtod.returns(ArrayTypeName.of(toClassRecord));
		mehtod.addException(exception);
		mehtod.addStatement("$T ps = null",preparedStatement);
		mehtod.addStatement("$T rs = null",resultSet);
		
		mehtod.beginControlFlow("try");
		mehtod.beginControlFlow("if(con == null)");
		mehtod.addStatement("con = getCPDatabaseConnection()");
		mehtod.endControlFlow();
		mehtod.addStatement("query = query + MAX_RECORD_LIMIT_APPENDER");
		mehtod.addStatement("query = updateQuery(query)");
		mehtod.addStatement("logger.trace(\"load$Ns\t\" + closeConnection + \"\t\" + query)",classRecord);
		mehtod.addStatement("ps = con.prepareStatement(query)");
		mehtod.addStatement("rs = ps.executeQuery()");
		mehtod.addStatement("$T recordSet = new $T()",arrayList,arrayList);
		mehtod.beginControlFlow("while(rs.next())");
		mehtod.addStatement("$T record = new $T()",toClassRecord,toClassRecord);
		Iterator keyIterator = columns.keySet().iterator();
		String firstCaps = null;
		String allCaps = null;
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			key = key.replaceAll("\\s","");
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();			
			mehtod.addStatement("record.set$N(rs.getString($S))",firstCaps,allCaps);
			
		}
		mehtod.addStatement("recordSet.add(record)");
		mehtod.endControlFlow();
		mehtod.addStatement("logger.trace(\"load$Ns:Records Fetched:\" + recordSet.size())",classRecord);
		mehtod.addStatement("$N[] temp$Ns = new $N[recordSet.size()]",classRecord,classRecord,classRecord);
		mehtod.beginControlFlow("for (int index = 0; index < recordSet.size(); index++)");
		mehtod.addStatement("temp$Ns[index] = ($N)(recordSet.get(index))",classRecord,classRecord);
		mehtod.endControlFlow();
		mehtod.addStatement("ps.close()");
		mehtod.addStatement("releaseDatabaseConnection(con, closeConnection)");
		mehtod.addStatement("return temp$Ns",classRecord);	
		mehtod.endControlFlow();
		mehtod.beginControlFlow("finally");
		mehtod.addStatement("releaseDatabaseConnection(rs, ps, con, closeConnection)");	
		mehtod.endControlFlow();
	
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	} 
	private static MethodSpec loadArrayRecordsFirstMethodspec(String methodName,TypeName className,HashMap columns,String classRecord)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);		
		TypeName exception = ClassName.get("java.lang", "Exception");
		
		
		mehtod.addParameter(String.class, "query");
		mehtod.returns(ArrayTypeName.of(toClassRecord));
		mehtod.addException(exception);
		mehtod.addStatement("return load$Ns(query, null, true)",classRecord);
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private static MethodSpec loadFirstRecordMethodspec(String methodName,TypeName className,HashMap columns,String classRecord)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);		
		TypeName exception = ClassName.get("java.lang", "Exception");
		
		
		mehtod.addParameter(String.class, "query");
		mehtod.returns(toClassRecord);
		mehtod.addException(exception);
		mehtod.addStatement("$T[] results = load$Ts(query)",toClassRecord,toClassRecord);
		mehtod.beginControlFlow("if (results == null)");
		mehtod.addStatement("return null");	
		mehtod.endControlFlow();
		mehtod.beginControlFlow("if(results.length < 1)");
		mehtod.addStatement("return null");	
		mehtod.endControlFlow();
		mehtod.addStatement("return results[0]");	
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	private static MethodSpec loadRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String originaltableName)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);		
		TypeName exception = ClassName.get("java.lang", "Exception");
		TypeName arrayList = ClassName.get("java.util", "ArrayList");
		TypeName preparedStatement = ClassName.get("java.sql", "PreparedStatement");
		TypeName resultSet = ClassName.get("java.sql", "ResultSet");
		

		
		mehtod.addParameter(String.class, "id");
		mehtod.addParameter(Connection.class, "con");
		mehtod.addParameter(boolean.class, "closeConnection");
		mehtod.returns(toClassRecord);
		mehtod.addException(exception);
		mehtod.addStatement("$T ps = null",preparedStatement);
		mehtod.addStatement("$T rs = null",resultSet);
		

		mehtod.beginControlFlow("try");
		mehtod.beginControlFlow("if(con == null)");
		mehtod.addStatement("con = getCPDatabaseConnection()");
		mehtod.endControlFlow();
		mehtod.addStatement("String Query = \"SELECT * FROM $N WHERE (ID = ?)\"",originaltableName);
		mehtod.addStatement("Query = updateQuery(Query)");
		mehtod.addStatement("logger.trace(\"load$Ns\t\" + closeConnection + \"\t\" + id)",classRecord);
		mehtod.addStatement("ps = con.prepareStatement(Query)");
		mehtod.addStatement("ps.setString(1,id)");
		mehtod.addStatement("rs = ps.executeQuery()");
		
		mehtod.beginControlFlow("if (!rs.next())");
		mehtod.addStatement("ps.close()");
		mehtod.addStatement("releaseDatabaseConnection(con, closeConnection)");
		mehtod.addStatement("return null");
		mehtod.endControlFlow();
		
		mehtod.addStatement("$T record = new $T()",toClassRecord,toClassRecord);
		Iterator keyIterator = columns.keySet().iterator();
		String firstCaps = null;
		String allCaps = null;
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			key = key.replaceAll("\\s","");
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();
			/*firstCaps  = StringUtils.convertFirstCharacterToUpperCase(key);
			allCaps = key.toUpperCase();*/
			mehtod.addStatement("record.set$N(rs.getString($S))",firstCaps,allCaps);
			
		}
		
		mehtod.addStatement("ps.close()");
		mehtod.addStatement("logger.trace(\"load$N\t\" + record + \"\t\")",classRecord);
		mehtod.addStatement("releaseDatabaseConnection(con, closeConnection)");
		mehtod.addStatement("return record");	
		mehtod.endControlFlow();
		mehtod.beginControlFlow("finally");
		mehtod.addStatement("releaseDatabaseConnection(rs, ps, con, closeConnection)");	
		mehtod.endControlFlow();
	
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	} 
	
	private static MethodSpec loadRecordsPKMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String originaltableName)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);		
		TypeName exception = ClassName.get("java.lang", "Exception");
		TypeName arrayList = ClassName.get("java.util", "ArrayList");
		TypeName preparedStatement = ClassName.get("java.sql", "PreparedStatement");
		TypeName resultSet = ClassName.get("java.sql", "ResultSet");
		

		
		mehtod.addParameter(String.class, "$pk$");
		mehtod.addParameter(Connection.class, "con");
		mehtod.addParameter(boolean.class, "closeConnection");
		mehtod.returns(toClassRecord);
		mehtod.addException(exception);
		mehtod.addStatement("$T ps = null",preparedStatement);
		mehtod.addStatement("$T rs = null",resultSet);
		

		mehtod.beginControlFlow("try");
		mehtod.beginControlFlow("if(con == null)");
		mehtod.addStatement("con = getCPDatabaseConnection()");
		mehtod.endControlFlow();
		mehtod.addStatement("String Query = \"SELECT * FROM $N WHERE ($N = ?)\"",originaltableName,"$PK$");
		mehtod.addStatement("Query = updateQuery(Query)");
		mehtod.addStatement("logger.trace(\"load$Ns\t\" + closeConnection + \"\t\" + $S)",classRecord,"$PK$");
		mehtod.addStatement("ps = con.prepareStatement(Query)");
		mehtod.addStatement("ps.setString(1,$N)","$pk$");
		mehtod.addStatement("rs = ps.executeQuery()");
		
		mehtod.beginControlFlow("if (!rs.next())");
		mehtod.addStatement("ps.close()");
		mehtod.addStatement("releaseDatabaseConnection(con, closeConnection)");
		mehtod.addStatement("return null");
		mehtod.endControlFlow();
		
		mehtod.addStatement("$T record = new $T()",toClassRecord,toClassRecord);
		Iterator keyIterator = columns.keySet().iterator();
		String firstCaps = null;
		String allCaps = null;
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			key = key.replaceAll("\\s","");
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();
			/*firstCaps  = StringUtils.convertFirstCharacterToUpperCase(key);
			allCaps = key.toUpperCase();*/
			mehtod.addStatement("record.set$N(rs.getString($S))",firstCaps,allCaps);
			
		}
		
		mehtod.addStatement("ps.close()");
		mehtod.addStatement("logger.trace(\"load$N\t\" + record + \"\t\")",classRecord);
		mehtod.addStatement("releaseDatabaseConnection(con, closeConnection)");
		mehtod.addStatement("return record");	
		mehtod.endControlFlow();
		mehtod.beginControlFlow("finally");
		mehtod.addStatement("releaseDatabaseConnection(rs, ps, con, closeConnection)");	
		mehtod.endControlFlow();
	
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	} 
	
	
	private static MethodSpec loadRecordFirstMethodspec(String methodName,TypeName className,HashMap columns,String classRecord)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);		
		TypeName exception = ClassName.get("java.lang", "Exception");
		
		
		mehtod.addParameter(String.class, "id");
		mehtod.returns(toClassRecord);
		mehtod.addException(exception);
		mehtod.addStatement("return load$N(id, null, true)",classRecord);
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private static MethodSpec insertRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String originaltableName)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);		
		TypeName exception = ClassName.get("java.lang", "Exception");
		TypeName arrayList = ClassName.get("java.util", "ArrayList");
		TypeName preparedStatement = ClassName.get("java.sql", "PreparedStatement");
		TypeName resultSet = ClassName.get("java.sql", "ResultSet");
		TypeName Statement = ClassName.get("java.sql", "Statement");
		

		
		mehtod.addParameter(toClassRecord, "record");
		mehtod.addParameter(Connection.class, "con");
		mehtod.addParameter(boolean.class, "closeConnection");
		mehtod.returns(int.class);
		mehtod.addException(exception);
		mehtod.addStatement("$T ps = null",preparedStatement);
		mehtod.addStatement("$T rs = null",resultSet);
		
		mehtod.beginControlFlow("try");
		
		Iterator keyIterator = columns.keySet().iterator();
		String firstCaps = null;
		String allCaps = "";
		String addingColumns  = "";
		String valuesInsertScript = "";
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			key = key.replaceAll("\\s","");
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();
			/*firstCaps  = StringUtils.convertFirstCharacterToUpperCase(key);
			allCaps = key.toUpperCase();*/
			if(addingColumns.length() < 1)
			{
				addingColumns  = allCaps;
				valuesInsertScript = "?";
			}
			else
			{
			    addingColumns  = addingColumns + "," + allCaps;
			    valuesInsertScript  = valuesInsertScript + "," + "?";
			}
			//mehtod.addStatement("record.set$N(rs.getString($S))",firstCaps,allCaps);
			
		}
		System.out.println("Query ::: "+addingColumns);
		System.out.println("Query2 ::: "+valuesInsertScript);
		
		
		mehtod.addStatement("String Query =\"INSERT INTO $N \"",originaltableName);
		mehtod.addStatement("Query +=$S","(");
		mehtod.addStatement("Query +=$S",addingColumns);
		mehtod.addStatement("Query +=$S",")");
		mehtod.addStatement("Query += $S "," VALUES ");
		mehtod.addStatement("Query +=$S","(");
		mehtod.addStatement("Query +=$S",valuesInsertScript);
		mehtod.addStatement("Query +=$S",")");
		
			mehtod.beginControlFlow("if (con == null)");
				mehtod.addStatement("con = getCPDatabaseConnection()");		
			mehtod.endControlFlow();
			
		mehtod.addStatement("Query = updateQuery(Query)");	
		mehtod.addStatement("logger.trace(\"insert$Ns\t\" + closeConnection + \"\t\" + Query)",classRecord);
		
			mehtod.beginControlFlow("if (isOracleDatabase())");
				mehtod.addStatement("ps = con.prepareStatement(Query,new String[]{\"ID\"})");		
			mehtod.endControlFlow();
			
			mehtod.beginControlFlow("else");
				mehtod.addStatement("ps = con.prepareStatement(Query,$T.RETURN_GENERATED_KEYS)",Statement);		
		    mehtod.endControlFlow();
		
	   Iterator keyIterator2 = columns.keySet().iterator();
	   int number = 1;
	   while(keyIterator2.hasNext())
	   {
		   String key = keyIterator2.next().toString();
		   key = key.replaceAll("\\s","");
		   String old  = StringUtils.replaceString(key, "_", "", true);
		   firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
		   
		  // firstCaps  = StringUtils.convertFirstCharacterToUpperCase(key);
		   if(firstCaps.equalsIgnoreCase("Createdat") || firstCaps.equalsIgnoreCase("Modifiedat"))  
			   mehtod.addStatement("setDateValue(ps, $N, fd.getSQLDateObject(record.get$N(), \"yyyyMMddHHmmss\"))",""+number,firstCaps);
		   else
		       mehtod.addStatement("setStringValue(ps, $N, record.get$N())",""+number,firstCaps);
		   number++;

	   }
	   mehtod.addStatement("boolean result = ps.execute()");
	   mehtod.addStatement("logger.trace(\"insert$N\t\" + result + \"\t\")",classRecord);
	   
	   mehtod.addStatement("int resultID = -1");
	   mehtod.addStatement("rs = ps.getGeneratedKeys()");
	   mehtod.beginControlFlow("if (rs.next())");
	   mehtod.addStatement("resultID = rs.getInt(1)");
	   mehtod.endControlFlow();
	   mehtod.addStatement("ps.close()");
	   mehtod.addStatement("releaseDatabaseConnection(con, closeConnection)");
	   mehtod.addStatement("return resultID");
	   
	   
				
		mehtod.endControlFlow();
		
		 mehtod.beginControlFlow("finally");
		   mehtod.addStatement("releaseDatabaseConnection(rs, ps, con, closeConnection)");
		 mehtod.endControlFlow();
		 
		
		mehtod.addModifiers(Modifier.PUBLIC);
		
		return mehtod.build(); 
		
	}
	
	
	private static MethodSpec insertRecordFirstMethodspec(String methodName,TypeName className,HashMap columns,String classRecord)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);		
		TypeName exception = ClassName.get("java.lang", "Exception");
		
		
		mehtod.addParameter(toClassRecord, "record");
		mehtod.returns(int.class);
		mehtod.addException(exception);
		mehtod.addStatement("return insert$N(record, null, true)",classRecord);
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	
	private static MethodSpec updateRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String originaltableName,TypeName stringUtils)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);		
		TypeName exception = ClassName.get("java.lang", "Exception");
		TypeName arrayList = ClassName.get("java.util", "ArrayList");
		TypeName preparedStatement = ClassName.get("java.sql", "PreparedStatement");
		TypeName resultSet = ClassName.get("java.sql", "ResultSet");
		TypeName Statement = ClassName.get("java.sql", "Statement");
		

		
		mehtod.addParameter(toClassRecord, "record");
		mehtod.addParameter(Connection.class, "con");
		mehtod.addParameter(boolean.class, "closeConnection");
		mehtod.returns(boolean.class);
		mehtod.addException(exception);
		mehtod.addStatement("$T ps = null",preparedStatement);
		mehtod.addStatement("$T rs = null",resultSet);
		
		mehtod.beginControlFlow("try");
			mehtod.addStatement("$T currentRecord = load$T(record.getId())",toClassRecord,toClassRecord);
			mehtod.addStatement("String currentRecordContent = $T.noNull(currentRecord)",stringUtils);
			mehtod.addStatement("String Query = \"UPDATE $N SET \"",originaltableName);
			Iterator keyIterator = columns.keySet().iterator();
			String firstCaps = null;
			String allCaps = "";
			String valueofQuery  = "";
			String valuesInsertScript = "";
			
			while(keyIterator.hasNext())
			{
				String key = keyIterator.next().toString();
				key = key.replaceAll("\\s","");
				String old  = StringUtils.replaceString(key, "_", "", true);
				//firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
				allCaps = key.toUpperCase();
				
				allCaps = key.toUpperCase();
				if(allCaps.equals("ID")) continue;
				valueofQuery = valueofQuery + "Query += \""+allCaps+" = ?,\";\n";
				
				//mehtod.addStatement("Query += \"$N = ?, \"",allCaps);
				
			}
			valueofQuery = valueofQuery.substring(0, valueofQuery.length() - 5);
			valueofQuery = valueofQuery+"?\""; 
			//StringBuilder finalQuery = new StringBuilder(valueofQuery);
			//finalQuery.setCharAt(finalQuery.length()-11, ' ');
			
			//String partQuerytoreplace 
			//valueofQuery = StringUtils.trimLeadingSize(valueofQuery, valueofQuery.length()-1);
			mehtod.addStatement("$N",valueofQuery);
			mehtod.addStatement("Query += \" WHERE (ID = ?)\"");
			mehtod.beginControlFlow("if (con == null)");
				mehtod.addStatement("con = getCPDatabaseConnection()");
			mehtod.endControlFlow();
			mehtod.addStatement("Query = updateQuery(Query)");
			mehtod.addStatement("logger.trace(\"update$N\t\" + closeConnection + \"\t\" + record + \"\t\" + Query + \"\t\")",classRecord);
			mehtod.addStatement("ps = con.prepareStatement(Query)");
			
			Iterator keyIterator2 = columns.keySet().iterator();
			   int number = 1;
			   while(keyIterator2.hasNext())
			   {
				   String key = keyIterator2.next().toString();
				   key = key.replaceAll("\\s","");
				   String old  = StringUtils.replaceString(key, "_", "", true);
					firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
					allCaps = key.toUpperCase();
					if(allCaps.equals("ID")) continue;
				   //firstCaps  = StringUtils.convertFirstCharacterToUpperCase(key);
				   if(firstCaps.equalsIgnoreCase("Createdat") || firstCaps.equalsIgnoreCase("Modifiedat"))  
					   mehtod.addStatement("setDateValue(ps, $N, fd.getSQLDateObject(record.get$N(), \"yyyyMMddHHmmss\"))",""+number,firstCaps);
				   else 
				       mehtod.addStatement("setStringValue(ps, $N, record.get$N())",""+number,firstCaps);
				   number++;

			   }
			mehtod.addStatement("ps.setString($N, $T.noNull(record.getId()))",""+number,stringUtils);
			mehtod.addStatement("boolean result = ps.execute()");
			mehtod.addStatement("logger.trace(\"update$N\t\" + result + \"\t\")",classRecord);
			mehtod.addStatement("ps.close()");
			mehtod.addStatement("releaseDatabaseConnection(con, closeConnection)");
			mehtod.addStatement("return result");
				
		
		mehtod.endControlFlow();
		
		 mehtod.beginControlFlow("finally");
		   mehtod.addStatement("releaseDatabaseConnection(rs, ps, con, closeConnection)");
		 mehtod.endControlFlow();
		 
		
		mehtod.addModifiers(Modifier.PUBLIC);
		
		return mehtod.build(); 
		
	}
	
	
	private static MethodSpec updateRecordFirstMethodspec(String methodName,TypeName className,HashMap columns,String classRecord)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);		
		TypeName exception = ClassName.get("java.lang", "Exception");
		
		
		mehtod.addParameter(toClassRecord, "record");
		mehtod.returns(boolean.class);
		mehtod.addException(exception);
		mehtod.addStatement("return update$N(record, null, true)",classRecord);
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	private static MethodSpec deleteRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String originaltableName,TypeName stringUtils)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);		
		TypeName exception = ClassName.get("java.lang", "Exception");
		TypeName arrayList = ClassName.get("java.util", "ArrayList");
		TypeName preparedStatement = ClassName.get("java.sql", "PreparedStatement");
		TypeName resultSet = ClassName.get("java.sql", "ResultSet");
		TypeName Statement = ClassName.get("java.sql", "Statement");
		

		
		mehtod.addParameter(toClassRecord, "record");
		mehtod.addParameter(Connection.class, "con");
		mehtod.addParameter(boolean.class, "closeConnection");
		mehtod.returns(boolean.class);
		mehtod.addException(exception);
		mehtod.addStatement("$T ps = null",preparedStatement);
		mehtod.addStatement("$T rs = null",resultSet);
		
		mehtod.beginControlFlow("try");
		mehtod.addStatement("String Query = \"DELETE FROM $N WHERE (ID = ?)\"", originaltableName);
		
			mehtod.beginControlFlow("if (con == null)");
			mehtod.addStatement("con = getCPDatabaseConnection()");
			mehtod.endControlFlow();
		mehtod.addStatement("Query = updateQuery(Query)");
		mehtod.addStatement("logger.trace(\"delete$N\t\" + closeConnection + \"\t\" + record + \"\t\" + Query + \"\t\")",classRecord);
		mehtod.addStatement("ps = con.prepareStatement(Query)");
		mehtod.addStatement("ps.setString(1, noNull(record.getId()))");
		mehtod.addStatement("boolean result = ps.execute()");
		mehtod.addStatement("logger.trace(\"delete$N\t\" + result + \"\t\")",classRecord);
		mehtod.addStatement("ps.close()");
		mehtod.addStatement("releaseDatabaseConnection(con, closeConnection)");
		mehtod.addStatement("return result");
		mehtod.endControlFlow();
		mehtod.beginControlFlow("finally");
		mehtod.addStatement("releaseDatabaseConnection(rs, ps, con, closeConnection)");
		mehtod.endControlFlow();
		
		mehtod.addModifiers(Modifier.PUBLIC);
		
		return mehtod.build(); 
	}
	
	
	private static MethodSpec deleteRecordFirstMethodspec(String methodName,TypeName className,HashMap columns,String classRecord)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);		
		TypeName exception = ClassName.get("java.lang", "Exception");
		
		
		mehtod.addParameter(toClassRecord, "record");
		mehtod.returns(boolean.class);
		mehtod.addException(exception);
		mehtod.addStatement("return delete$N(record, null, true)",classRecord);
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private static MethodSpec searchRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String originaltableName,TypeName stringUtils)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);		
		TypeName exception = ClassName.get("java.lang", "Exception");
		
		mehtod.addParameter(toClassRecord, "searchRecord");
		mehtod.addException(exception);
		mehtod.addStatement("String WhereCondition =  \" \"");
		
		
		Iterator keyIterator = columns.keySet().iterator();
		String firstCaps = null;
		String allCaps = "";
		String valueofQuery  = "";
		String valuesInsertScript = "";
		
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			
			String value = columns.get(key).toString();
			key = key.replaceAll("\\s","");
			
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();
			
			//firstCaps  = StringUtils.convertFirstCharacterToUpperCase(key);
			//allCaps  = key.toUpperCase();
			
			
			if(value.contains("INT")  || value.contains("VARCHAR 1") )
				mehtod.addStatement("WhereCondition = addSearchCondition(WhereCondition, \"($N)\", \"\", \"$N\", formatSearchField(searchRecord.get$N()))","$COLNAME$ = '$COLVAL$'",allCaps,firstCaps);
			else if(key.toUpperCase().contains("ID") || key.toUpperCase().contains("NUM")  || key.toUpperCase().contains("MOBILE") || key.toUpperCase().contains("MADE_BY") || key.toUpperCase().contains("CHECKED_BY")
					|| key.toUpperCase().contains("CURR_APP_STATUS") || key.toUpperCase().contains("RSTATUS") || key.toUpperCase().contains("CREATED_BY") || key.toUpperCase().contains("MODIFIED_BY")
					|| key.toUpperCase().contains("BLOCKED_FLAG")|| key.toUpperCase().contains("CUST_CAT")|| key.toUpperCase().contains("PIN") || key.toUpperCase().contains("PHONE")
					|| key.toUpperCase().contains("ACC") || key.toUpperCase().contains("CIF") || key.toUpperCase().contains("OTP") || key.toUpperCase().contains("CODE")
					|| key.toUpperCase().contains("REFBY") || key.toUpperCase().contains("NUM") || key.toUpperCase().contains("CUST") )
				mehtod.addStatement("WhereCondition = addSearchCondition(WhereCondition, \"($N)\", \"\", \"$N\", formatSearchField(searchRecord.get$N()))","$COLNAME$ = '$COLVAL$'",allCaps,firstCaps);
			else 
			    mehtod.addStatement("WhereCondition = addSearchCondition(WhereCondition, \"(UPPER($N) LIKE UPPER('$N'))\", \"\", \"$N\", formatSearchField(searchRecord.get$N()))","$COLNAME$","%$COLVAL$%",allCaps,firstCaps);
		}
		
		mehtod.beginControlFlow("if (isNull(WhereCondition))");
			mehtod.addStatement("WhereCondition += \"(1=1)\"");
		mehtod.endControlFlow();
		
		
		mehtod.beginControlFlow("if (!isNull(WhereCondition))");
			mehtod.addStatement("WhereCondition = \"WHERE \" + WhereCondition");
		mehtod.endControlFlow();
		
		mehtod.beginControlFlow("if (hasCustomCondition())");
			mehtod.addStatement("WhereCondition += getCustomCondition()");
		mehtod.endControlFlow();
		
		mehtod.addStatement("String Query = \"select * from $N \" + WhereCondition + \" order by \" + ORDERBYSTRING",originaltableName);
		
		mehtod.beginControlFlow("if (isMSSQL8())");
			mehtod.addStatement("Query = \"select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $N) as rownum FROM $N ) acvmfs \" + WhereCondition","$ORDERBYSTRING$",originaltableName);
			mehtod.addStatement("Query = $T.replaceString(Query, \"$N\", loadMSSQL8OrderByID(ORDERBYSTRING),true)",globalstringUtils,"$ORDERBYSTRING$");
		mehtod.endControlFlow();
		
		mehtod.beginControlFlow("if (isOracleDatabase())");
			mehtod.addStatement("Query = \"select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $N) R FROM (SELECT * FROM $N $N) C ) WHERE (1=1) $N\"","$ORDERBYSTRING$",originaltableName,"$WHERECONDITION$","$OUTERLIMITCONDITION$");
			mehtod.addStatement("Query = $T.replaceString(Query, \"$N\", WhereCondition,true)",globalstringUtils,"$WHERECONDITION$");
			mehtod.addStatement("Query = $T.replaceString(Query, \"$N\", getOuterLimitCondition(),true)",globalstringUtils,"$OUTERLIMITCONDITION$");
			mehtod.addStatement("Query = $T.replaceString(Query, \"$N\", loadOracleOrderByID(ORDERBYSTRING),true)",globalstringUtils,"$ORDERBYSTRING$");
		mehtod.endControlFlow();
		
		mehtod.addStatement("Query = updateQuery(Query)");
		mehtod.addStatement("logger.trace(\"Search Query	\" + Query + \"\t\")");
		mehtod.addStatement("return load$Ts(Query)",toClassRecord);
		mehtod.returns(ArrayTypeName.of(toClassRecord));
		mehtod.addModifiers(Modifier.PUBLIC);
		
		return mehtod.build(); 
		
	}
	
	
	private static MethodSpec searchRecordsExactUpperMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String originaltableName,TypeName stringUtils)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName+"ExactUpper");
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);		
		TypeName exception = ClassName.get("java.lang", "Exception");
		
		mehtod.addParameter(toClassRecord, "searchRecord");
		mehtod.addException(exception);
		mehtod.addStatement("String WhereCondition =  \" \"");
		
		
		Iterator keyIterator = columns.keySet().iterator();
		String firstCaps = null;
		String allCaps = "";
		String valueofQuery  = "";
		String valuesInsertScript = "";
		
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			
			String value = columns.get(key).toString();
			key = key.replaceAll("\\s","");
			
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();
			
			//firstCaps  = StringUtils.convertFirstCharacterToUpperCase(key);
			//allCaps  = key.toUpperCase();
			
			
			
			    mehtod.addStatement("WhereCondition = addSearchCondition(WhereCondition, \"(UPPER($N) = UPPER('$N'))\", \"\", \"$N\", formatSearchField(searchRecord.get$N()))","$COLNAME$","%$COLVAL$%",allCaps,firstCaps);
		}
		
		mehtod.beginControlFlow("if (isNull(WhereCondition))");
			mehtod.addStatement("WhereCondition += \"(1=1)\"");
		mehtod.endControlFlow();
		
		
		mehtod.beginControlFlow("if (!isNull(WhereCondition))");
			mehtod.addStatement("WhereCondition = \"WHERE \" + WhereCondition");
		mehtod.endControlFlow();
		
		mehtod.beginControlFlow("if (hasCustomCondition())");
			mehtod.addStatement("WhereCondition += getCustomCondition()");
		mehtod.endControlFlow();
		
		mehtod.addStatement("String Query = \"select * from $N \" + WhereCondition + \" order by \" + ORDERBYSTRING",originaltableName);
		
		mehtod.beginControlFlow("if (isMSSQL8())");
			mehtod.addStatement("Query = \"select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $N) as rownum FROM $N ) acvmfs \" + WhereCondition","$ORDERBYSTRING$",originaltableName);
			mehtod.addStatement("Query = $T.replaceString(Query, \"$N\", loadMSSQL8OrderByID(ORDERBYSTRING),true)",globalstringUtils,"$ORDERBYSTRING$");
		mehtod.endControlFlow();
		
		mehtod.beginControlFlow("if (isOracleDatabase())");
			mehtod.addStatement("Query = \"select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $N) R FROM (SELECT * FROM $N $N) C ) WHERE (1=1) $N\"","$ORDERBYSTRING$",originaltableName,"$WHERECONDITION$","$OUTERLIMITCONDITION$");
			mehtod.addStatement("Query = $T.replaceString(Query, \"$N\", WhereCondition,true)",globalstringUtils,"$WHERECONDITION$");
			mehtod.addStatement("Query = $T.replaceString(Query, \"$N\", getOuterLimitCondition(),true)",globalstringUtils,"$OUTERLIMITCONDITION$");
			mehtod.addStatement("Query = $T.replaceString(Query, \"$N\", loadOracleOrderByID(ORDERBYSTRING),true)",globalstringUtils,"$ORDERBYSTRING$");
		mehtod.endControlFlow();
		
		mehtod.addStatement("Query = updateQuery(Query)");
		mehtod.addStatement("logger.trace(\"Search Query	\" + Query + \"\t\")");
		mehtod.addStatement("return load$Ts(Query)",toClassRecord);
		mehtod.returns(ArrayTypeName.of(toClassRecord));
		mehtod.addModifiers(Modifier.PUBLIC);
		
		return mehtod.build(); 
		
	}
	
	private static MethodSpec loadRecordsCountMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String originaltableName,TypeName stringUtils)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName+"Count");
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);		
		TypeName exception = ClassName.get("java.lang", "Exception");
		
		mehtod.addParameter(toClassRecord, "searchRecord");
		mehtod.addException(exception);
		mehtod.addStatement("String WhereCondition =  \" \"");
		
		
		Iterator keyIterator = columns.keySet().iterator();
		String firstCaps = null;
		String allCaps = "";
		String valueofQuery  = "";
		String valuesInsertScript = "";
		
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			
			String value = columns.get(key).toString();
			key = key.replaceAll("\\s","");
			
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();
			
			//firstCaps  = StringUtils.convertFirstCharacterToUpperCase(key);
			//allCaps  = key.toUpperCase();
			
			
			if(value.contains("INT")  || value.contains("VARCHAR 1") )
				mehtod.addStatement("WhereCondition = addSearchCondition(WhereCondition, \"($N)\", \"\", \"$N\", formatSearchField(searchRecord.get$N()))","$COLNAME$ = '$COLVAL$'",allCaps,firstCaps);
			else if(key.toUpperCase().contains("ID") || key.toUpperCase().contains("NUM")  || key.toUpperCase().contains("MOBILE") || key.toUpperCase().contains("MADE_BY") || key.toUpperCase().contains("CHECKED_BY")
					|| key.toUpperCase().contains("CURR_APP_STATUS") || key.toUpperCase().contains("RSTATUS") || key.toUpperCase().contains("CREATED_BY") || key.toUpperCase().contains("MODIFIED_BY")
					|| key.toUpperCase().contains("BLOCKED_FLAG")|| key.toUpperCase().contains("CUST_CAT")|| key.toUpperCase().contains("PIN") || key.toUpperCase().contains("PHONE")
					|| key.toUpperCase().contains("ACC") || key.toUpperCase().contains("CIF") || key.toUpperCase().contains("OTP") || key.toUpperCase().contains("CODE")
					|| key.toUpperCase().contains("REFBY") || key.toUpperCase().contains("NUM") || key.toUpperCase().contains("CUST") )
				mehtod.addStatement("WhereCondition = addSearchCondition(WhereCondition, \"($N)\", \"\", \"$N\", formatSearchField(searchRecord.get$N()))","$COLNAME$ = '$COLVAL$'",allCaps,firstCaps);
			else 
			    mehtod.addStatement("WhereCondition = addSearchCondition(WhereCondition, \"(UPPER($N) LIKE UPPER('$N'))\", \"\", \"$N\", formatSearchField(searchRecord.get$N()))","$COLNAME$","%$COLVAL$%",allCaps,firstCaps);
		}
		
		mehtod.beginControlFlow("if (isNull(WhereCondition))");
			mehtod.addStatement("WhereCondition += \"(1=1)\"");
		mehtod.endControlFlow();
		
		
		mehtod.beginControlFlow("if (!isNull(WhereCondition))");
			mehtod.addStatement("WhereCondition = \"WHERE \" + WhereCondition");
		mehtod.endControlFlow();
		
		mehtod.beginControlFlow("if (hasCustomCondition())");
			mehtod.addStatement("WhereCondition += getCustomCondition()");
		mehtod.endControlFlow();
		
		
		mehtod.addStatement("String Query = \"select count(*) from $N \" + WhereCondition",originaltableName);
		
		/*mehtod.beginControlFlow("if (isMSSQL8())");
			mehtod.addStatement("Query = \"select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $N) as rownum FROM $N ) acvmfs \" + WhereCondition","$ORDERBYSTRING$",originaltableName);
			mehtod.addStatement("Query = StringUtils.replaceString(Query, \"\", loadMSSQL8OrderByID(ORDERBYSTRING),true)","$ORDERBYSTRING$");
		mehtod.endControlFlow();
		
		mehtod.beginControlFlow("if (isOracleDatabase())");
			mehtod.addStatement("Query = \"select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $N) R FROM (SELECT * FROM $N $N) C ) WHERE (1=1) $N\"","$ORDERBYSTRING$",originaltableName,"$WHERECONDITION$","$OUTERLIMITCONDITION$");
			mehtod.addStatement("Query = StringUtils.replaceString(Query, \"$N\", WhereCondition,true)","$WHERECONDITION$");
			mehtod.addStatement("Query = StringUtils.replaceString(Query, \"\", getOuterLimitCondition(),true)","$OUTERLIMITCONDITION$");
			mehtod.addStatement("Query = StringUtils.replaceString(Query, \"\", loadOracleOrderByID(ORDERBYSTRING),true)","$ORDERBYSTRING$");
		mehtod.endControlFlow();*/
		
		mehtod.addStatement("Query = updateQuery(Query)");
		mehtod.addStatement("logger.trace(\"Search Count Query	\" + Query + \"\t\")");
		mehtod.addStatement("return loadCount(Query)",toClassRecord);
		mehtod.returns(int.class);
		mehtod.addModifiers(Modifier.PUBLIC);
		
		return mehtod.build(); 
		
	}
	
	
	private static MethodSpec loadRecordsCountExactUpperMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String originaltableName,TypeName stringUtils)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName+"CountExact");
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);		
		TypeName exception = ClassName.get("java.lang", "Exception");
		
		mehtod.addParameter(toClassRecord, "searchRecord");
		mehtod.addException(exception);
		mehtod.addStatement("String WhereCondition =  \" \"");
		
		
		Iterator keyIterator = columns.keySet().iterator();
		String firstCaps = null;
		String allCaps = "";
		String valueofQuery  = "";
		String valuesInsertScript = "";
		
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			
			String value = columns.get(key).toString();
			key = key.replaceAll("\\s","");
			
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();
			
			//firstCaps  = StringUtils.convertFirstCharacterToUpperCase(key);
			//allCaps  = key.toUpperCase();
			
			
			
			    mehtod.addStatement("WhereCondition = addSearchCondition(WhereCondition, \"(UPPER($N) = UPPER('$N'))\", \"\", \"$N\", formatSearchField(searchRecord.get$N()))","$COLNAME$","%$COLVAL$%",allCaps,firstCaps);
		}
		
		mehtod.beginControlFlow("if (isNull(WhereCondition))");
			mehtod.addStatement("WhereCondition += \"(1=1)\"");
		mehtod.endControlFlow();
		
		
		mehtod.beginControlFlow("if (!isNull(WhereCondition))");
			mehtod.addStatement("WhereCondition = \"WHERE \" + WhereCondition");
		mehtod.endControlFlow();
		
		mehtod.beginControlFlow("if (hasCustomCondition())");
			mehtod.addStatement("WhereCondition += getCustomCondition()");
		mehtod.endControlFlow();
		
		
		mehtod.addStatement("String Query = \"select count(*) from $N \" + WhereCondition",originaltableName);
		
		/*mehtod.beginControlFlow("if (isMSSQL8())");
			mehtod.addStatement("Query = \"select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $N) as rownum FROM $N ) acvmfs \" + WhereCondition","$ORDERBYSTRING$",originaltableName);
			mehtod.addStatement("Query = StringUtils.replaceString(Query, \"\", loadMSSQL8OrderByID(ORDERBYSTRING),true)","$ORDERBYSTRING$");
		mehtod.endControlFlow();
		
		mehtod.beginControlFlow("if (isOracleDatabase())");
			mehtod.addStatement("Query = \"select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $N) R FROM (SELECT * FROM $N $N) C ) WHERE (1=1) $N\"","$ORDERBYSTRING$",originaltableName,"$WHERECONDITION$","$OUTERLIMITCONDITION$");
			mehtod.addStatement("Query = StringUtils.replaceString(Query, \"$N\", WhereCondition,true)","$WHERECONDITION$");
			mehtod.addStatement("Query = StringUtils.replaceString(Query, \"\", getOuterLimitCondition(),true)","$OUTERLIMITCONDITION$");
			mehtod.addStatement("Query = StringUtils.replaceString(Query, \"\", loadOracleOrderByID(ORDERBYSTRING),true)","$ORDERBYSTRING$");
		mehtod.endControlFlow();*/
		
		mehtod.addStatement("Query = updateQuery(Query)");
		mehtod.addStatement("logger.trace(\"Search Count Query	\" + Query + \"\t\")");
		mehtod.addStatement("return loadCount(Query)",toClassRecord);
		mehtod.returns(int.class);
		mehtod.addModifiers(Modifier.PUBLIC);
		
		return mehtod.build(); 
		
	}
	
	/***
	 * 
	 * Service Layer Method Implementations
	 * 
	 */
	
	private static MethodSpec loadServiceRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);	
		TypeName exception = ClassName.get("java.lang", "Exception");
		TypeName arrayList = ClassName.get("java.util", "ArrayList");
		TypeName preparedStatement = ClassName.get("java.sql", "PreparedStatement");
		TypeName resultSet = ClassName.get("java.sql", "ResultSet");
		mehtod.addParameter(String.class, "query");
		mehtod.returns(ArrayTypeName.of(toClassRecord));
		mehtod.addException(exception);
		
		mehtod.beginControlFlow("try");
			mehtod.addStatement("logger.trace(\"load$Ns:\" + query)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"load$Ns\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("$T[] results = dao.load$Ns(query)",toClassRecord,classRecord);
			mehtod.addStatement("int resultRecordCount = 0");
				mehtod.beginControlFlow("if (results != null)");
					mehtod.addStatement("resultRecordCount = results.length");
				mehtod.endControlFlow();
			mehtod.addStatement("logger.trace(\"load$Ns:Fetched\" + resultRecordCount)",classRecord);
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)",classRecord);
			mehtod.addStatement("return results");
	    mehtod.endControlFlow();
	    mehtod.beginControlFlow("catch(Exception exception)");
	    	mehtod.addStatement("logger.error(\"load$Ns\" + getStackTrace(exception))",classRecord);
	    	mehtod.addStatement("throw new Exception(\"MFException:\" + getErrorMessage(exception))",classRecord);
	    mehtod.endControlFlow();
	
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private static MethodSpec loadServiceFirstRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);	
		TypeName exception = ClassName.get("java.lang", "Exception");
		TypeName arrayList = ClassName.get("java.util", "ArrayList");
		TypeName preparedStatement = ClassName.get("java.sql", "PreparedStatement");
		TypeName resultSet = ClassName.get("java.sql", "ResultSet");
		mehtod.addParameter(String.class, "query");
		mehtod.returns(toClassRecord);
		mehtod.addException(exception);
		
		mehtod.beginControlFlow("try");
			mehtod.addStatement("logger.trace(\"load$Ns:\" + query)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"load$Ns\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("$T result = dao.loadFirst$N(query)",toClassRecord,classRecord);
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)",classRecord);
			mehtod.addStatement("return result");
	    mehtod.endControlFlow();
	    mehtod.beginControlFlow("catch(Exception exception)");
	    	mehtod.addStatement("logger.error(\"loadFirst$N\" + getStackTrace(exception))",classRecord);
	    	mehtod.addStatement("throw new Exception(\"MFException:\" + getErrorMessage(exception))",classRecord);
	    mehtod.endControlFlow();
	
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private static MethodSpec searchServiceFirstRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);	
		TypeName exception = ClassName.get("java.lang", "Exception");
		TypeName arrayList = ClassName.get("java.util", "ArrayList");
		TypeName preparedStatement = ClassName.get("java.sql", "PreparedStatement");
		TypeName resultSet = ClassName.get("java.sql", "ResultSet");
		mehtod.addParameter(toClassRecord, "record");
		mehtod.returns(toClassRecord);
		mehtod.addException(exception);
		
		mehtod.beginControlFlow("try");
			mehtod.addStatement("logger.trace(\"searchFirst$Ns:\" + record)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"searchFirst$Ns\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("$T[] records = dao.search$Ns(record)",toClassRecord,classRecord);
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)",classRecord);
			mehtod.beginControlFlow("if(records == null)");
			mehtod.addStatement("return null");
			mehtod.endControlFlow();
			mehtod.beginControlFlow("if(records.length < 1)");
			mehtod.addStatement("return null");
			mehtod.endControlFlow();
			mehtod.addStatement("return records[0]");
	    mehtod.endControlFlow();
	    mehtod.beginControlFlow("catch(Exception exception)");
	    	mehtod.addStatement("logger.error(\"searchFirst$Ns\" + getStackTrace(exception))",classRecord);
	    	mehtod.addStatement("throw new Exception(\"MFException:\" + getErrorMessage(exception))",classRecord);
	    mehtod.endControlFlow();
	
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private static MethodSpec searchServiceExactUpperRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);	
		TypeName exception = ClassName.get("java.lang", "Exception");
		TypeName arrayList = ClassName.get("java.util", "ArrayList");
		TypeName preparedStatement = ClassName.get("java.sql", "PreparedStatement");
		TypeName resultSet = ClassName.get("java.sql", "ResultSet");
		mehtod.addParameter(toClassRecord, "record");
		mehtod.returns(toClassRecord);
		mehtod.addException(exception);
		
		mehtod.beginControlFlow("try");
			mehtod.addStatement("logger.trace(\"searchFirst$NsExactUpper:\" + record)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"searchFirst$NsExactUpper\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("$T[] records = dao.search$NsExactUpper(record)",toClassRecord,classRecord);
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)",classRecord);
			mehtod.beginControlFlow("if(records == null)");
			mehtod.addStatement("return null");
			mehtod.endControlFlow();
			mehtod.beginControlFlow("if(records.length < 1)");
			mehtod.addStatement("return null");
			mehtod.endControlFlow();
			mehtod.addStatement("return records[0]");
	    mehtod.endControlFlow();
	    mehtod.beginControlFlow("catch(Exception exception)");
	    	mehtod.addStatement("logger.error(\"searchFirst$Ns\" + getStackTrace(exception))",classRecord);
	    	mehtod.addStatement("throw new Exception(\"MFException:\" + getErrorMessage(exception))",classRecord);
	    mehtod.endControlFlow();
	
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	private static MethodSpec searchServiceArrayRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);	
		TypeName exception = ClassName.get("java.lang", "Exception");
		TypeName arrayList = ClassName.get("java.util", "ArrayList");
		TypeName preparedStatement = ClassName.get("java.sql", "PreparedStatement");
		TypeName resultSet = ClassName.get("java.sql", "ResultSet");
		mehtod.addParameter(toClassRecord, "record");
		mehtod.returns(ArrayTypeName.of(toClassRecord));
		mehtod.addException(exception);
		
		mehtod.beginControlFlow("try");
			mehtod.addStatement("logger.trace(\"search$Ns:\" + record)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"load$Ns\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("$T[] records = dao.search$Ns(record)",toClassRecord,classRecord);
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)",classRecord);	
			mehtod.addStatement("return records");
	    mehtod.endControlFlow();
	    mehtod.beginControlFlow("catch(Exception exception)");
	    	mehtod.addStatement("logger.error(\"search$Ns\" + getStackTrace(exception))",classRecord);
	    	mehtod.addStatement("throw new Exception(\"MFException:\" + getErrorMessage(exception))",classRecord);
	    mehtod.endControlFlow();
	
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private static MethodSpec loadServiceRecordCountMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);	
		TypeName exception = ClassName.get("java.lang", "Exception");
		mehtod.addParameter(toClassRecord, "record");
		mehtod.returns(int.class);
		mehtod.addException(exception);
		
		mehtod.addStatement("return load$NCount(record, null)",classRecord);
		
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	private static MethodSpec loadServiceRecordCountTwoParametersMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);	
		TypeName exception = ClassName.get("java.lang", "Exception");
		mehtod.addParameter(toClassRecord, "record");
		mehtod.addParameter(String.class, "customCondition");
		mehtod.returns(int.class);
		mehtod.addException(exception);
		mehtod.beginControlFlow("try");
			mehtod.addStatement("logger.trace(\"load$N:\" + record)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"load$NCount\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("dao.setCustomCondition(customCondition)");
			mehtod.addStatement("int resultcount = dao.load$NCount(record)",classRecord);
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)",classRecord);	
			mehtod.addStatement("return resultcount");
		mehtod.endControlFlow();
		mehtod.beginControlFlow("catch(Exception exception)");
    	mehtod.addStatement("logger.error(\"load$NCount\" + getStackTrace(exception))",classRecord);
    	mehtod.addStatement("throw new Exception(\"MFException:\" + getErrorMessage(exception))",classRecord);
    	mehtod.endControlFlow();

	  mehtod.addModifiers(Modifier.PUBLIC);
	  return mehtod.build(); 
	}
	
	private static MethodSpec loadServiceRecordkeyParameterMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);	
		TypeName exception = ClassName.get("java.lang", "Exception");
		mehtod.addParameter(String.class, "key");	
		mehtod.returns(toClassRecord);
		mehtod.addException(exception);
		mehtod.beginControlFlow("try");
			mehtod.addStatement("logger.trace(\"load$N:\" + key)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"load$NCount\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("$T result = dao.load$N(key)",toClassRecord,classRecord);
			mehtod.addStatement("logger.trace(\"load$N:\" + result)",classRecord);	
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)",classRecord);	
			mehtod.addStatement("return result");
		mehtod.endControlFlow();
		mehtod.beginControlFlow("catch(Exception exception)");
    	mehtod.addStatement("logger.error(\"load$N\" + getStackTrace(exception))",classRecord);
    	mehtod.addStatement("throw new Exception(\"MFException:\" + getErrorMessage(exception))",classRecord);
    	mehtod.endControlFlow();

	  mehtod.addModifiers(Modifier.PUBLIC);
	  return mehtod.build(); 
	}
	
	private static MethodSpec getJSONSearchResultByPageMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);	
		TypeName exception = ClassName.get("java.lang", "Exception");
		TypeName jsonObject = ClassName.get("org.json.simple", "JSONObject");
		mehtod.addParameter(toClassRecord, "record");
		mehtod.addParameter(String.class, "offset");
		mehtod.addParameter(String.class, "maxrows");
		mehtod.addParameter(String.class, "orderBy");
		mehtod.returns(jsonObject);
		mehtod.addException(exception);
		
		mehtod.addStatement("return getJSON$NSearchResultByPage(record, offset, maxrows, orderBy, null)",classRecord);
		
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	private static MethodSpec getJSONSearchResultByPageFirstMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);	
		TypeName exception = ClassName.get("java.lang", "Exception");
		TypeName jsonObject = ClassName.get("org.json.simple", "JSONObject");
		TypeName jsonArray = ClassName.get("org.json.simple", "JSONArray");
		
		mehtod.addParameter(toClassRecord, "record");
		mehtod.addParameter(String.class, "offset");
		mehtod.addParameter(String.class, "maxrows");
		mehtod.addParameter(String.class, "orderBy");
		mehtod.addParameter(String.class, "customCondition");
		
		mehtod.returns(jsonObject);
		mehtod.addException(exception);
		mehtod.beginControlFlow("try");
			mehtod.addStatement("logger.trace(\"getJSON$NSearchResultByPage:\" + record + \" Offset:\" + offset + \" Maxrows:\" + maxrows)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"getJSON$NSearchResult\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()", daoClassRecord,daoClassRecord);
			mehtod.addStatement("int totalCount = dao.load$NCount(record)", classRecord);
			mehtod.addStatement("dao.setLimits(offset, maxrows)");
			mehtod.addStatement("$N[] records = null", classRecord);
			mehtod.beginControlFlow("if (totalCount > 0)");
				mehtod.addStatement("dao.setOrderBy(orderBy)");
				mehtod.addStatement("records = dao.search$Ns(record)",classRecord);
			mehtod.endControlFlow();
			mehtod.addStatement("$T resultObject = new $T()",jsonObject,jsonObject);
			mehtod.addStatement("resultObject.put(\"total\",totalCount + \"\")");
			mehtod.addStatement("$T dataArray = new $T()",jsonArray,jsonArray);
			mehtod.addStatement("int recordCount = 0");
			mehtod.beginControlFlow("if (totalCount > 0)");
				mehtod.addStatement("recordCount = records.length");
			mehtod.endControlFlow(); 
			mehtod.beginControlFlow("for (int index = 0; index < recordCount; index++)");
				mehtod.addStatement("dataArray.add(records[index].getJSONObjectUI())");
			mehtod.endControlFlow(); 
			mehtod.addStatement("resultObject.put(\"rows\",dataArray)");
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
			mehtod.addStatement("return resultObject");
		mehtod.endControlFlow();
		mehtod.beginControlFlow("catch(Exception exception)");
    	mehtod.addStatement("logger.error(\"getJSON$NSearchResult\" + getStackTrace(exception))",classRecord);
    	mehtod.addStatement("throw new Exception(\"MFException:\" + getErrorMessage(exception))",classRecord);
    	mehtod.endControlFlow();
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private static MethodSpec insertServiceRecordMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String nameClass,boolean checkContainstoaddMethods)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);
		TypeName exception = ClassName.get("java.lang", "Exception");
		mehtod.addParameter(toClassRecord, "record");
		mehtod.returns(int.class);
		mehtod.addException(exception);
		mehtod.beginControlFlow("try");
			mehtod.addStatement("logger.trace(\"insert$N:\" + record)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"insert$N\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("int result = dao.insert$N(record)",classRecord);
			mehtod.addStatement("logger.trace(\"insert$N:Result:\" + result)",classRecord);
			if(checkContainstoaddMethods)
			{
			     mehtod.addStatement("createMakerCheckerAuditEntry(\"$N\", record.getId() + \"\", \"Create\", record.getCreatedby(), \"Created\")",nameClass);
			}
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
			mehtod.addStatement("return result");
			mehtod.endControlFlow();
		mehtod.beginControlFlow("catch(Exception exception)");
	    mehtod.addStatement("logger.error(\"insert$N\" + getStackTrace(exception))",classRecord);
	    mehtod.addStatement("throw exception");
	    mehtod.endControlFlow();
		
		
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private static MethodSpec updateServiceRecordMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String nameClass,boolean checkContainstoaddMethods)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);
		TypeName exception = ClassName.get("java.lang", "Exception");
		mehtod.addParameter(toClassRecord, "record");
		mehtod.returns(boolean.class);
		mehtod.addException(exception);
		mehtod.beginControlFlow("try");
			mehtod.addStatement("logger.trace(\"update$N:\" + record)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"update$N\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("boolean result = dao.update$N(record)",classRecord);
			mehtod.addStatement("logger.trace(\"update$N:Result:\" + result)",classRecord);
			if(checkContainstoaddMethods)
			{
				mehtod.addStatement("createMakerCheckerAuditEntry(\"$N\", record.getId() + \"\", \"Update\", record.getModifiedby(), \"Update\")",nameClass);
			}
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
			mehtod.addStatement("return result");
			mehtod.endControlFlow();
		mehtod.beginControlFlow("catch(Exception exception)");
	    mehtod.addStatement("logger.error(\"update$N\" + getStackTrace(exception))",classRecord);
	    mehtod.addStatement("throw exception");
	    mehtod.endControlFlow();
		
		
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	private static MethodSpec updateServiceRecordNoNullMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String nameClass,boolean checkContainstoaddMethods)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);
		TypeName exception = ClassName.get("java.lang", "Exception");
		mehtod.addParameter(toClassRecord, "inputRecord");
		mehtod.returns(boolean.class);
		mehtod.addException(exception);
		mehtod.beginControlFlow("try");
			mehtod.addStatement("logger.trace(\"update$N:\" + inputRecord)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"update$NNoNull\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("$T dbRecord = dao.load$N(inputRecord.getId())",toClassRecord,classRecord);
			mehtod.beginControlFlow("if (dbRecord == null)"); ;
				mehtod.addStatement("throw new Exception(\"Record not found\")");		       
			mehtod.endControlFlow();
			mehtod.addStatement("dbRecord.loadNonNullContent(inputRecord)");
			mehtod.addStatement("dbRecord.setActionSource(inputRecord.getActionSource())");
			mehtod.addStatement("boolean result = dao.update$N(inputRecord)",classRecord);
			if(checkContainstoaddMethods)
			{
				mehtod.addStatement("createMakerCheckerAuditEntry(\"$N\", inputRecord.getId() + \"\", \"Update\", inputRecord.getModifiedby(), \"UpdateNoNull\")",nameClass);
			}
			mehtod.addStatement("logger.trace(\"update$NNoNull:Result:\" + result)",classRecord);
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
			mehtod.addStatement("return result");
			mehtod.endControlFlow();
		mehtod.beginControlFlow("catch(Exception exception)");
	    mehtod.addStatement("logger.error(\"update$NNoNull\" + getStackTrace(exception))",classRecord);
	    mehtod.addStatement("throw exception");
	    mehtod.endControlFlow();
		
		
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private static MethodSpec deleteServiceRecordNoNullMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String nameClass,boolean checkContainstoaddMethods)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);
		TypeName exception = ClassName.get("java.lang", "Exception");
		mehtod.addParameter(toClassRecord, "record");
		mehtod.returns(boolean.class);
		mehtod.addException(exception);
		mehtod.beginControlFlow("try");
			mehtod.addStatement("logger.trace(\"delete$N:\" + record)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"delete$N\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("boolean result = dao.delete$N(record)",classRecord);
			mehtod.addStatement("logger.trace(\"delete$N:Result:\" + result)",classRecord);
			if(checkContainstoaddMethods)
			{
				mehtod.addStatement("createMakerCheckerAuditEntry(\"$N\", record.getId(), \"Delete\", null, \"Deleted\")",nameClass);
			}
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
			mehtod.addStatement("return result");
			mehtod.endControlFlow();
		mehtod.beginControlFlow("catch(Exception exception)");
	    mehtod.addStatement("logger.error(\"delete$N\" + getStackTrace(exception))",classRecord);
	    mehtod.addStatement("throw exception");
	    mehtod.endControlFlow();
		
		
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	private static MethodSpec approveServiceRecordNoNullMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String nameClass)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);
		TypeName exception = ClassName.get("java.lang", "Exception");
		TypeName hashMap = ClassName.get("java.util", "HashMap");
		TypeName dateUtils = ClassName.get("com.mtreetech.sawc.utils", "DateUtils");
		TypeName stringUtils = ClassName.get("com.mtreetech.sawc.utils", "StringUtils");
		
		mehtod.addParameter(toClassRecord, "inputRecord");
		mehtod.addParameter(String.class, "updateId");
		mehtod.addParameter(String.class, "comment");
		mehtod.returns(boolean.class);
		mehtod.addException(exception);
		mehtod.beginControlFlow("try");
		
			mehtod.addStatement("logger.trace(\"approve$N:\" + inputRecord)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"approve$N\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("$T updateRecord = dao.load$N(inputRecord.getId())",toClassRecord,classRecord);
			mehtod.beginControlFlow("if (updateRecord == null)");
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-RNFA104:Record not found\")");
			mehtod.endControlFlow();
			mehtod.beginControlFlow("if (!isValidStatusForApproval(updateRecord.getCurrappstatus()))");
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-IS101:Cannot approve - Invalid Status for Approval\")");
			mehtod.endControlFlow();
			mehtod.beginControlFlow("if ($T.isSame(updateRecord.getMadeby(), updateId))",stringUtils);
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-MCS102:Cannot Approve. Maker Checker cannot be same\")");
			mehtod.endControlFlow();
		      
			mehtod.addStatement("updateRecord.setRstatus(\"1\")");
			mehtod.addStatement("updateRecord.setCheckerlastcmt(comment)");
			mehtod.addStatement("updateRecord.setCurrappstatus(\"1\")");
			mehtod.addStatement("updateRecord.setModifiedat($T.getCurrentDateTime())",dateUtils);
			mehtod.addStatement("updateRecord.setModifiedby(updateId)"); 
			mehtod.addStatement("updateRecord.setCheckedat($T.getCurrentDateTime())",dateUtils); 
			mehtod.addStatement("updateRecord.setCheckedby(updateId)"); 
			mehtod.addStatement("boolean result = dao.update$N(updateRecord)",classRecord);
			mehtod.addStatement("logger.trace(\"approve$N:Result:\" + result)",classRecord);
			
			mehtod.addStatement("createMakerCheckerAuditEntry(\"$N\", updateRecord.getId(), \"Approve\", updateId, comment)",nameClass);
			mehtod.addStatement("$T approveEventMap = callActionEvent(\"Event_OnApprovalOf_$N\", updateRecord.getId())",hashMap,classRecord);
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
			mehtod.addStatement("return result");
			
		mehtod.endControlFlow();
		mehtod.beginControlFlow("catch(Exception exception)");
	    mehtod.addStatement("logger.error(\"approve$N\" + getStackTrace(exception))",classRecord);
	    mehtod.addStatement("throw exception");
	    mehtod.endControlFlow();

	    mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private static MethodSpec submitServiceRecordNoNullMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String nameClass)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);
		TypeName exception = ClassName.get("java.lang", "Exception");
		TypeName hashMap = ClassName.get("java.util", "HashMap");
		TypeName dateUtils = ClassName.get("com.mtreetech.sawc.utils", "DateUtils");
		TypeName stringUtils = ClassName.get("com.mtreetech.sawc.utils", "StringUtils");
		
		mehtod.addParameter(toClassRecord, "inputRecord");
		mehtod.addParameter(String.class, "updateId");
		mehtod.addParameter(String.class, "comment");
		mehtod.returns(boolean.class);
		mehtod.addException(exception);
		mehtod.beginControlFlow("try");
		
		mehtod.addStatement("logger.trace(\"submit$NNoNull:\" + inputRecord)",classRecord);
		mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"submit$NNoNull\", null)",classRecord);
		mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
		mehtod.addStatement("$T updateRecord = dao.load$N(inputRecord.getId())",toClassRecord,classRecord);
		mehtod.beginControlFlow("if (updateRecord == null)");
			mehtod.addStatement("throw new Exception(\"MF-ERR-CA-RNFA104:Record not found\")");
		mehtod.endControlFlow();
		mehtod.beginControlFlow("if (!isValidStatusForSubmission(updateRecord.getCurrappstatus()))");
			mehtod.addStatement("throw new Exception(\"MF-ERR-CS-IS101:Cannot submit - Invalid Status for Submission\")");
		mehtod.endControlFlow();
		
	      
		mehtod.addStatement("updateRecord.setRstatus(\"1\")");
		mehtod.addStatement("updateRecord.setCheckerlastcmt(comment)");
		mehtod.addStatement("updateRecord.setCurrappstatus(\"4\")");
		mehtod.addStatement("updateRecord.setModifiedat($T.getCurrentDateTime())",dateUtils);
		mehtod.addStatement("updateRecord.setModifiedby(updateId)"); 
		mehtod.addStatement("updateRecord.setCheckedat($T.getCurrentDateTime())",dateUtils); 
		mehtod.addStatement("updateRecord.setCheckedby(updateId)"); 
		mehtod.addStatement("boolean result = dao.update$N(updateRecord)",classRecord);
		mehtod.addStatement("logger.trace(\"approve$N:Result:\" + result)",classRecord);
		
		mehtod.addStatement("createMakerCheckerAuditEntry(\"$N\", updateRecord.getId(), \"Submit\", updateId, comment)",nameClass);
		mehtod.addStatement("$T submitEventMap = callActionEvent(\"Event_OnApprovalOf_$N\", updateRecord.getId())",hashMap,classRecord);
		mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
		mehtod.addStatement("return result");
		
		mehtod.endControlFlow();
		mehtod.beginControlFlow("catch(Exception exception)");
	    mehtod.addStatement("logger.error(\"submit$N\" + getStackTrace(exception))",classRecord);
	    mehtod.addStatement("throw exception");
	    mehtod.endControlFlow();
	
	    mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
		
	}
	
	
	private static MethodSpec denyServiceRecordNoNullMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String nameClass)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);
		TypeName exception = ClassName.get("java.lang", "Exception");
		TypeName hashMap = ClassName.get("java.util", "HashMap");
		TypeName dateUtils = ClassName.get("com.mtreetech.sawc.utils", "DateUtils");
		TypeName stringUtils = ClassName.get("com.mtreetech.sawc.utils", "StringUtils");
		
		mehtod.addParameter(toClassRecord, "inputRecord");
		mehtod.addParameter(String.class, "updateId");
		mehtod.addParameter(String.class, "comment");
		mehtod.returns(boolean.class);
		mehtod.addException(exception);
		mehtod.beginControlFlow("try");
		
			mehtod.addStatement("logger.trace(\"deny$N:\" + inputRecord)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"deny$N\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("$T updateRecord = dao.load$N(inputRecord.getId())",toClassRecord,classRecord);
			mehtod.beginControlFlow("if (updateRecord == null)");
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-RNFA104:Record not found\")");
			mehtod.endControlFlow();
			mehtod.beginControlFlow("if (!isValidStatusForDeny(updateRecord.getCurrappstatus()))");
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-IS101:Cannot deny - Invalid Status for Deny\")");
			mehtod.endControlFlow();
			mehtod.beginControlFlow("if ($T.isSame(updateRecord.getMadeby(), updateId))",stringUtils);
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-MCS102:Cannot Deny. Maker Checker cannot be same\")");
			mehtod.endControlFlow();
		      
			mehtod.addStatement("updateRecord.setRstatus(\"1\")");
			mehtod.addStatement("updateRecord.setCheckerlastcmt(comment)");
			mehtod.addStatement("updateRecord.setCurrappstatus(\"5\")");
			mehtod.addStatement("updateRecord.setModifiedat($T.getCurrentDateTime())",dateUtils);
			mehtod.addStatement("updateRecord.setModifiedby(updateId)"); 
			mehtod.addStatement("updateRecord.setCheckedat($T.getCurrentDateTime())",dateUtils); 
			mehtod.addStatement("updateRecord.setCheckedby(updateId)"); 
			mehtod.addStatement("boolean result = dao.update$N(updateRecord)",classRecord);
			mehtod.addStatement("logger.trace(\"approve$N:Result:\" + result)",classRecord);
			
			mehtod.addStatement("createMakerCheckerAuditEntry(\"$N\", updateRecord.getId(), \"Deny\", updateId, comment)",nameClass);
			
			mehtod.addStatement("$T denyEventMap = callActionEvent(\"Event_OnDenyOf_$N\", updateRecord.getId())",hashMap,classRecord);
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
			mehtod.addStatement("return result");
			
		mehtod.endControlFlow();
		mehtod.beginControlFlow("catch(Exception exception)");
	    mehtod.addStatement("logger.error(\"deny$N\" + getStackTrace(exception))",classRecord);
	    mehtod.addStatement("throw exception");
	    mehtod.endControlFlow();

	    mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
		
	}
	
	
	private static MethodSpec denyPermanentServiceRecordNoNullMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String nameClass)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);
		TypeName exception = ClassName.get("java.lang", "Exception");
		TypeName hashMap = ClassName.get("java.util", "HashMap");
		TypeName dateUtils = ClassName.get("com.mtreetech.sawc.utils", "DateUtils");
		TypeName stringUtils = ClassName.get("com.mtreetech.sawc.utils", "StringUtils");
		
		mehtod.addParameter(toClassRecord, "inputRecord");
		mehtod.addParameter(String.class, "updateId");
		mehtod.addParameter(String.class, "comment");
		mehtod.returns(boolean.class);
		mehtod.addException(exception);
		mehtod.beginControlFlow("try");
		
			mehtod.addStatement("logger.trace(\"denyP$N:\" + inputRecord)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"denyP$N\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("$T updateRecord = dao.load$N(inputRecord.getId())",toClassRecord,classRecord);
			mehtod.beginControlFlow("if (updateRecord == null)");
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-RNFA104:Record not found\")");
			mehtod.endControlFlow();
			mehtod.beginControlFlow("if (!isValidStatusForDeny(updateRecord.getCurrappstatus()))");
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-IS101:Cannot deny - Invalid Status for Deny\")");
			mehtod.endControlFlow();
			mehtod.beginControlFlow("if ($T.isSame(updateRecord.getMadeby(), updateId))",stringUtils);
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-MCS102:Cannot Deny. Maker Checker cannot be same\")");
			mehtod.endControlFlow();
		      
			mehtod.addStatement("updateRecord.setRstatus(\"1\")");
			mehtod.addStatement("updateRecord.setCheckerlastcmt(comment)");
			mehtod.addStatement("updateRecord.setCurrappstatus(\"58\")");
			mehtod.addStatement("updateRecord.setModifiedat($T.getCurrentDateTime())",dateUtils);
			mehtod.addStatement("updateRecord.setModifiedby(updateId)"); 
			mehtod.addStatement("updateRecord.setCheckedat($T.getCurrentDateTime())",dateUtils); 
			mehtod.addStatement("updateRecord.setCheckedby(updateId)"); 
			mehtod.addStatement("boolean result = dao.update$N(updateRecord)",classRecord);
			mehtod.addStatement("logger.trace(\"approve$N:Result:\" + result)",classRecord);
			mehtod.addStatement("createMakerCheckerAuditEntry(\"$N\", updateRecord.getId(), \"DenyP\", updateId, comment)",nameClass);
			mehtod.addStatement("$T denyEventMap = callActionEvent(\"Event_OnDenyPOf_$N\", updateRecord.getId())",hashMap,classRecord);
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
			mehtod.addStatement("return result");
			
		mehtod.endControlFlow();
		mehtod.beginControlFlow("catch(Exception exception)");
	    mehtod.addStatement("logger.error(\"denyP$N\" + getStackTrace(exception))",classRecord);
	    mehtod.addStatement("throw exception");
	    mehtod.endControlFlow();

	    mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
		
	}
	
	private static MethodSpec remindServiceRecordNoNullMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String nameClass)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);
		TypeName exception = ClassName.get("java.lang", "Exception");
		TypeName hashMap = ClassName.get("java.util", "HashMap");
		TypeName dateUtils = ClassName.get("com.mtreetech.sawc.utils", "DateUtils");
		TypeName stringUtils = ClassName.get("com.mtreetech.sawc.utils", "StringUtils");
		
		mehtod.addParameter(toClassRecord, "inputRecord");
		mehtod.addParameter(String.class, "updateId");
		mehtod.addParameter(String.class, "comment");
		mehtod.returns(boolean.class);
		mehtod.addException(exception);
		mehtod.beginControlFlow("try");
		
			mehtod.addStatement("logger.trace(\"remindApproval$N:\" + inputRecord)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"remindApproval$N\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("$T updateRecord = dao.load$N(inputRecord.getId())",toClassRecord,classRecord);
			mehtod.beginControlFlow("if (updateRecord == null)");
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-RNFA104:Record not found\")");
			mehtod.endControlFlow();
			mehtod.beginControlFlow("if (!isValidStatusForApproval(updateRecord.getCurrappstatus()))");
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-IS101:Cannot Remind - Invalid Status for Reminder\")");
			mehtod.endControlFlow();
			/*mehtod.beginControlFlow("if ($T.isSame(updateRecord.getMadeby(), updateId))",stringUtils);
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-MCS102:Cannot Deny. Maker Checker cannot be same\")");
			mehtod.endControlFlow();
		      */
			/*mehtod.addStatement("updateRecord.setRstatus(\"1\")");
			mehtod.addStatement("updateRecord.setCheckerlastcmt(comment)");
			mehtod.addStatement("updateRecord.setCurrappstatus(\"58\")");
			mehtod.addStatement("updateRecord.setModifiedat($T.getCurrentDateTime())",dateUtils);
			mehtod.addStatement("updateRecord.setModifiedby(updateId)"); 
			mehtod.addStatement("updateRecord.setCheckedat($T.getCurrentDateTime())",dateUtils); 
			mehtod.addStatement("updateRecord.setCheckedby(updateId)"); 
			mehtod.addStatement("boolean result = dao.update$N(updateRecord)",classRecord);*/
			/*mehtod.addStatement("logger.trace(\"remind$N:Result:\" + result)",classRecord);*/
			mehtod.addStatement("createMakerCheckerAuditEntry(\"$N\", updateRecord.getId(), \"Approval Reminder\", updateId, comment)",nameClass);
			/*mehtod.addStatement("$T approveEventMap = callActionEvent(\"Event_OnDenyPOf_$N\", updateRecord.getId())",hashMap,classRecord);*/
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
			mehtod.addStatement("return true");
			
		mehtod.endControlFlow();
		mehtod.beginControlFlow("catch(Exception exception)");
	    mehtod.addStatement("logger.error(\"remindApproval$N\" + getStackTrace(exception))",classRecord);
	    mehtod.addStatement("throw exception");
	    mehtod.endControlFlow();

	    mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
		
	}
	
	
	private static MethodSpec resetServiceRecordNoNullMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String nameClass)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);
		TypeName exception = ClassName.get("java.lang", "Exception");
		TypeName hashMap = ClassName.get("java.util", "HashMap");
		TypeName dateUtils = ClassName.get("com.mtreetech.sawc.utils", "DateUtils");
		TypeName stringUtils = ClassName.get("com.mtreetech.sawc.utils", "StringUtils");
		
		mehtod.addParameter(toClassRecord, "inputRecord");
		mehtod.addParameter(String.class, "updateId");
		mehtod.addParameter(String.class, "comment");
		mehtod.returns(boolean.class);
		mehtod.addException(exception);
		mehtod.beginControlFlow("try");
		
			mehtod.addStatement("logger.trace(\"resetApproval$N:\" + inputRecord)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"resetApproval$N\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("$T updateRecord = dao.load$N(inputRecord.getId())",toClassRecord,classRecord);
			mehtod.beginControlFlow("if (updateRecord == null)");
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-RNFA104:Record not found\")");
			mehtod.endControlFlow();
			mehtod.beginControlFlow("if (!isValidStatusForDeny(updateRecord.getCurrappstatus()))");
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-IS101:Cannot submit - Invalid Status for Reset\")");
			mehtod.endControlFlow();
			/*mehtod.beginControlFlow("if ($T.isSame(updateRecord.getMadeby(), updateId))",stringUtils);
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-MCS102:Cannot Deny. Maker Checker cannot be same\")");
			mehtod.endControlFlow();*/
		      
			mehtod.addStatement("updateRecord.setRstatus(\"0\")");
			mehtod.addStatement("updateRecord.setCheckerlastcmt(comment)");
			mehtod.addStatement("updateRecord.setCurrappstatus(\"0\")");
			mehtod.addStatement("updateRecord.setModifiedat($T.getCurrentDateTime())",dateUtils);
			mehtod.addStatement("updateRecord.setModifiedby(updateId)"); 
			mehtod.addStatement("updateRecord.setCheckedat($T.getCurrentDateTime())",dateUtils); 
			mehtod.addStatement("updateRecord.setCheckedby(updateId)"); 
			mehtod.addStatement("boolean result = dao.update$N(updateRecord)",classRecord);
			mehtod.addStatement("logger.trace(\"approve$N:Result:\" + result)",classRecord);
			mehtod.addStatement("createMakerCheckerAuditEntry(\"$N\", updateRecord.getId(), \"Reset Approval\", updateId, comment)",nameClass);
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
			mehtod.addStatement("return result");
			
		mehtod.endControlFlow();
		mehtod.beginControlFlow("catch(Exception exception)");
	    mehtod.addStatement("logger.error(\"resetApproval$N\" + getStackTrace(exception))",classRecord);
	    mehtod.addStatement("throw exception");
	    mehtod.endControlFlow();

	    mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
		
	}
	
	/*
	 * Contorller Layer
	 */
	
	private static MethodSpec loadFormControllerRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);	
		TypeName exception = ClassName.get("java.lang", "Exception");
		TypeName arrayList = ClassName.get("java.util", "ArrayList");
		TypeName preparedStatement = ClassName.get("java.sql", "PreparedStatement");
		TypeName resultSet = ClassName.get("java.sql", "ResultSet");
		
		TypeName HttpServletRequest = ClassName.get("javax.servlet.http", "HttpServletRequest");
		TypeName HttpServletResponse = ClassName.get("javax.servlet.http", "HttpServletResponse");
		
		mehtod.addParameter(HttpServletRequest, "req");
		mehtod.addParameter(HttpServletResponse, "res");
		
		mehtod.returns(toClassRecord);
		//mehtod.addException(exception);
		
		mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"loadForm$N\", null)",classRecord);
		//mehtod.addStatement("logger.trace(\"load$Ns:\" + query)",classRecord);
		mehtod.addStatement("$T record = new $T()",toClassRecord,toClassRecord);
		
		Iterator keyIterator = columns.keySet().iterator();
		String firstCaps = null;
		String allCaps = "";
		String valueofQuery  = "";
		String valuesInsertScript = "";
		
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			
			String value = columns.get(key).toString();
			key = key.replaceAll("\\s","");
			
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();
			
			  mehtod.addStatement("record.set$N(getFormFieldValue(req, res, \"tf$N\"))",firstCaps,firstCaps);
			
		}
		
		mehtod.addStatement("logger.trace(\"loadForm$N\t\" + record + \"\t\")",classRecord);
		mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
		mehtod.addStatement("return record");
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	private static MethodSpec loadJSONFormFormControllerRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);	
		TypeName exception = ClassName.get("java.lang", "Exception");
		TypeName arrayList = ClassName.get("java.util", "ArrayList");
		TypeName preparedStatement = ClassName.get("java.sql", "PreparedStatement");
		TypeName resultSet = ClassName.get("java.sql", "ResultSet");
		
		TypeName HttpServletRequest = ClassName.get("javax.servlet.http", "HttpServletRequest");
		TypeName HttpServletResponse = ClassName.get("javax.servlet.http", "HttpServletResponse");
		
		mehtod.addParameter(HttpServletRequest, "req");
		mehtod.addParameter(HttpServletResponse, "res");
		
		mehtod.returns(toClassRecord);
		//mehtod.addException(exception);
		
		mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"loadJSONForm$N\", null)",classRecord);
		//mehtod.addStatement("logger.trace(\"load$Ns:\" + query)",classRecord);
		mehtod.addStatement("$T record = new $T()",toClassRecord,toClassRecord);
		
		Iterator keyIterator = columns.keySet().iterator();
		String firstCaps = null;
		String allCaps = "";
		String valueofQuery  = "";
		String valuesInsertScript = "";
		
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			
			String value = columns.get(key).toString();
			key = key.replaceAll("\\s","");
			
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();
			
			  mehtod.addStatement("record.set$N(getFormFieldValue(req, res, \"$N\"))",firstCaps,key);
			
		}
		
		mehtod.addStatement("logger.trace(\"loadJSONForm$N\t\" + record + \"\t\")",classRecord);
		mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
		mehtod.addStatement("return record");
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private static MethodSpec loadJSONFormFormEncodeControllerRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);	
		TypeName exception = ClassName.get("java.lang", "Exception");
		TypeName arrayList = ClassName.get("java.util", "ArrayList");
		TypeName preparedStatement = ClassName.get("java.sql", "PreparedStatement");
		TypeName resultSet = ClassName.get("java.sql", "ResultSet");
		
		TypeName HttpServletRequest = ClassName.get("javax.servlet.http", "HttpServletRequest");
		TypeName HttpServletResponse = ClassName.get("javax.servlet.http", "HttpServletResponse");
		
		mehtod.addParameter(HttpServletRequest, "req");
		mehtod.addParameter(HttpServletResponse, "res");
		
		mehtod.returns(toClassRecord);
		//mehtod.addException(exception);
		
		mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"loadJSONForm$NEncode\", null)",classRecord);
		//mehtod.addStatement("logger.trace(\"load$Ns:\" + query)",classRecord);
		mehtod.addStatement("$T record = new $T()",toClassRecord,toClassRecord);
		
		Iterator keyIterator = columns.keySet().iterator();
		String firstCaps = null;
		String allCaps = "";
		String valueofQuery  = "";
		String valuesInsertScript = "";
		
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			
			String value = columns.get(key).toString();
			key = key.replaceAll("\\s","");
			
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();
			
			  mehtod.addStatement("record.set$N(getFormFieldValueEncode(req, res, \"$N\"))",firstCaps,key);			
		}
		
		mehtod.addStatement("logger.trace(\"loadJSONForm$NEncode\t\" + record + \"\t\")",classRecord);
		mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
		mehtod.addStatement("return record");
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	private static MethodSpec loadMapControllerRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);	
		TypeName exception = ClassName.get("java.lang", "Exception");
		TypeName arrayList = ClassName.get("java.util", "ArrayList");
		TypeName hashMap = ClassName.get("java.util", "HashMap");
		TypeName preparedStatement = ClassName.get("java.sql", "PreparedStatement");
		TypeName resultSet = ClassName.get("java.sql", "ResultSet");
		
		TypeName HttpServletRequest = ClassName.get("javax.servlet.http", "HttpServletRequest");
		TypeName HttpServletResponse = ClassName.get("javax.servlet.http", "HttpServletResponse");
		
		mehtod.addParameter(hashMap, "inputMap");
		//mehtod.addParameter(HttpServletResponse, "res");
		
		mehtod.returns(toClassRecord);
		//mehtod.addException(exception);
		
		mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"loadMap$N\", null)",classRecord);
		//mehtod.addStatement("logger.trace(\"load$Ns:\" + query)",classRecord);
		mehtod.addStatement("$T record = new $T()",toClassRecord,toClassRecord);
		
		Iterator keyIterator = columns.keySet().iterator();
		String firstCaps = null;
		String allCaps = "";
		String valueofQuery  = "";
		String valuesInsertScript = "";
		
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			
			String value = columns.get(key).toString();
			key = key.replaceAll("\\s","");
			
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();
			
			  mehtod.addStatement("record.set$N(getMapValue(inputMap,\"$N\"))",firstCaps,key);			
		}
		
		mehtod.addStatement("logger.trace(\"loadMap$N\t\" + record + \"\t\")",classRecord);
		mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
		mehtod.addStatement("return record");
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	private static MethodSpec processInsertControllerRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String classNameService,String classNameR,boolean checkContainstoaddMethods)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		System.out.println("ClasssName ::::::::::::::::; "+classNameService);
		
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);
		TypeName  serviceClassRecord = ClassName.get("com.mtreetech.sawc.service", classNameService);
		TypeName exception = ClassName.get("java.lang", "Exception");
		TypeName arrayList = ClassName.get("java.util", "ArrayList");
		TypeName hashMap = ClassName.get("java.util", "HashMap");
		TypeName preparedStatement = ClassName.get("java.sql", "PreparedStatement");
		TypeName resultSet = ClassName.get("java.sql", "ResultSet");
			
		
		TypeName HttpServletRequest = ClassName.get("javax.servlet.http", "HttpServletRequest");
		TypeName HttpServletResponse = ClassName.get("javax.servlet.http", "HttpServletResponse");
		
		mehtod.addParameter(HttpServletRequest, "req");
		mehtod.addParameter(HttpServletResponse, "res");
		
		//mehtod.returns(toClassRecord);
		mehtod.addException(exception);
		
		mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"processInsert$N\", null)",classRecord);
		//mehtod.addStatement("logger.trace(\"load$Ns:\" + query)",classRecord);
		mehtod.addStatement("$T service = new $T()",serviceClassRecord,serviceClassRecord);
		
		mehtod.beginControlFlow("try");
			mehtod.addStatement("$N record = loadForm$N(req, res)",classRecord,classRecord);
			if(checkContainstoaddMethods) mehtod.addStatement("record.setCreatedby(getLoggedInUserId(req, res))");
			mehtod.addStatement("int resultId = service.insert$N(record)",classRecord);
			mehtod.addStatement("setActionMessageLn(req, res, \"AdminActionMessage\", \"RecordCreationSuccessful~~\" + resultId)",classRecord);
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
			mehtod.addStatement(" res.sendRedirect(\"$N.jsp\")",classNameR);
	   mehtod.endControlFlow();
	   mehtod.beginControlFlow("catch(Exception e)");
	   		mehtod.addStatement("setActionMessageLn(req, res, \"AdminActionMessage\", \"FailedtoCreate~~$N~~\")",classRecord);
	   		mehtod.addStatement("setActionMessage(req, res, \"AdminActionMessageException\", e)");
	   		mehtod.addStatement("logger.error(\"Failed to Create Customer \" + e)");
	   		mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
	   		mehtod.addStatement("res.sendRedirect(\"$N.jsp\")",classNameR);
	   mehtod.endControlFlow();
		
		
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	private static MethodSpec processUpdateControllerRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String classNameService,String classNameR,boolean checkContainstoaddMethods)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		System.out.println("ClasssName ::::::::::::::::; "+classNameService);
		
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);
		TypeName  serviceClassRecord = ClassName.get("com.mtreetech.sawc.service", classNameService);
		TypeName exception = ClassName.get("java.lang", "Exception");
		TypeName arrayList = ClassName.get("java.util", "ArrayList");
		TypeName hashMap = ClassName.get("java.util", "HashMap");
		TypeName preparedStatement = ClassName.get("java.sql", "PreparedStatement");
		TypeName resultSet = ClassName.get("java.sql", "ResultSet");
			
		
		TypeName HttpServletRequest = ClassName.get("javax.servlet.http", "HttpServletRequest");
		TypeName HttpServletResponse = ClassName.get("javax.servlet.http", "HttpServletResponse");
		
		mehtod.addParameter(HttpServletRequest, "req");
		mehtod.addParameter(HttpServletResponse, "res");
		
		//mehtod.returns(toClassRecord);
		mehtod.addException(exception);
		
		mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"processUpdate$N\", null)",classRecord);
		//mehtod.addStatement("logger.trace(\"load$Ns:\" + query)",classRecord);
		mehtod.addStatement("$T service = new $T()",serviceClassRecord,serviceClassRecord);
		
		mehtod.beginControlFlow("try");
			mehtod.addStatement("$N record = loadForm$N(req, res)",classRecord,classRecord);
			if(checkContainstoaddMethods) mehtod.addStatement("record.setCreatedby(getLoggedInUserId(req, res))");
			mehtod.addStatement("service.update$N(record)",classRecord);
			mehtod.addStatement("setActionMessageLn(req, res, \"AdminActionMessage\", \"RecordCreationSuccessful~~\")");
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
			mehtod.addStatement("res.sendRedirect(\"$N.jsp\")",classNameR);
	   mehtod.endControlFlow();
	   mehtod.beginControlFlow("catch(Exception e)");
	   		mehtod.addStatement("setActionMessageLn(req, res, \"AdminActionMessage\", \"FailedtoCreate~~$N~~\")",classRecord);
	   		mehtod.addStatement("setActionMessage(req, res, \"AdminActionMessageException\", e)");
	   		mehtod.addStatement("logger.error(\"Failed to Create Customer \" + e)");
	   		mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
	   		mehtod.addStatement("res.sendRedirect(\"$N.jsp\")",classNameR);
	   mehtod.endControlFlow();
		
		
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private static MethodSpec processDeleteControllerRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String classNameService,String classNameR,boolean checkContainstoaddMethods)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		System.out.println("ClasssName ::::::::::::::::; "+classNameService);
		
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);
		TypeName  serviceClassRecord = ClassName.get("com.mtreetech.sawc.service", classNameService);
		TypeName exception = ClassName.get("java.lang", "Exception");
		TypeName arrayList = ClassName.get("java.util", "ArrayList");
		TypeName hashMap = ClassName.get("java.util", "HashMap");
		TypeName preparedStatement = ClassName.get("java.sql", "PreparedStatement");
		TypeName resultSet = ClassName.get("java.sql", "ResultSet");
			
		
		TypeName HttpServletRequest = ClassName.get("javax.servlet.http", "HttpServletRequest");
		TypeName HttpServletResponse = ClassName.get("javax.servlet.http", "HttpServletResponse");
		
		mehtod.addParameter(HttpServletRequest, "req");
		mehtod.addParameter(HttpServletResponse, "res");
		
		//mehtod.returns(toClassRecord);
		mehtod.addException(exception);
		
		mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"processDelete$N\", null)",classRecord);
		//mehtod.addStatement("logger.trace(\"load$Ns:\" + query)",classRecord);
		mehtod.addStatement("$T service = new $T()",serviceClassRecord,serviceClassRecord);
		
		mehtod.beginControlFlow("try");
			mehtod.addStatement("$N record = loadForm$N(req, res)",classRecord,classRecord);
			if(checkContainstoaddMethods) mehtod.addStatement("record.setCreatedby(getLoggedInUserId(req, res))");
			mehtod.addStatement("service.delete$N(record)",classRecord);
			mehtod.addStatement("setActionMessageLn(req, res, \"AdminActionMessage\", \"RecordCreationSuccessful~~\")");
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
			mehtod.addStatement("res.sendRedirect(\"$N.jsp\")",classNameR);
	   mehtod.endControlFlow();
	   mehtod.beginControlFlow("catch(Exception e)");
	   		mehtod.addStatement("setActionMessageLn(req, res, \"AdminActionMessage\", \"FailedtoCreate~~$N~~\")",classRecord);
	   		mehtod.addStatement("setActionMessage(req, res, \"AdminActionMessageException\", e)");
	   		mehtod.addStatement("logger.error(\"Failed to Create Customer \" + e)");
	   		mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
	   		mehtod.addStatement("res.sendRedirect(\"$N.jsp\")",classNameR);
	   mehtod.endControlFlow();
		
		
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	private static MethodSpec processWebControllerRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String classNameService,String classNameR)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		System.out.println("ClasssName ::::::::::::::::; "+classNameService);
		String clasName = className.toString();
		String clasNameFirstCaps =StringUtils.convertFirstCharacterToUpperCase(clasName);
		
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get("com.mtreetech.sawc.to", classRecord);	
		TypeName  daoClassRecord = ClassName.get("com.mtreetech.sawc.dao", classNameDAO);
		TypeName  serviceClassRecord = ClassName.get("com.mtreetech.sawc.service", classNameService);
		TypeName exception = ClassName.get("java.lang", "Exception");
		TypeName arrayList = ClassName.get("java.util", "ArrayList");
		TypeName hashMap = ClassName.get("java.util", "HashMap");
		TypeName preparedStatement = ClassName.get("java.sql", "PreparedStatement");
		TypeName resultSet = ClassName.get("java.sql", "ResultSet");
			
		
		TypeName HttpServletRequest = ClassName.get("javax.servlet.http", "HttpServletRequest");
		TypeName HttpServletResponse = ClassName.get("javax.servlet.http", "HttpServletResponse");
		
		mehtod.addParameter(HttpServletRequest, "req");
		mehtod.addParameter(HttpServletResponse, "res");
		mehtod.addParameter(String.class, "actionType");
		
		//mehtod.returns(toClassRecord);
		mehtod.addException(exception);
		
		mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"processWebRequest\", null)",classRecord);
		//mehtod.addStatement("logger.trace(\"load$Ns:\" + query)",classRecord);
		mehtod.addStatement(" logger.trace(\"Action Type:\" + actionType + \"\")");
		mehtod.beginControlFlow("if (actionType.equals(\"Insert$NRecord\"))",clasNameFirstCaps);
			mehtod.addStatement("processInsert$N(req, res)",classRecord);
		mehtod.endControlFlow();
		mehtod.beginControlFlow("if (actionType.equals(\"Update$NRecord\"))",clasNameFirstCaps);
			mehtod.addStatement("processUpdate$N(req, res)",classRecord);
		mehtod.endControlFlow();
		mehtod.beginControlFlow("if (actionType.equals(\"Delete$NRecord\"))",clasNameFirstCaps);
			mehtod.addStatement("processDelete$N(req, res)",classRecord);
		mehtod.endControlFlow();
		
		mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
		
		
		
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	
	/**
	 * 
	 * 
	 *    
  
public void processWebRequest(HttpServletRequest req, HttpServletResponse res, String actionType)
     throws Exception
   {
     String beginMesssage = logger.generateFunctionBeginTimerMessage("processWebRequest", null);
     logger.trace("Action Type:" + actionType + "");
     
     if (actionType.equals("InsertCustomerRecord"))
     {
       processInsertMFCustomerRecord(req, res);
       return;
     }
     
     if (actionType.equals("UpdateCustomerRecord"))
     {
       processUpdateMFCustomerRecord(req, res);
       return;
     }
     
     if (actionType.equals("DeleteCustomerRecord"))
     {
       processDeleteMFCustomerRecord(req, res);
       return;
     }
     logger.generateFunctionEndTimerMessage(beginMesssage);
   }
   
   
	
}
   
	 */
	
	
}
