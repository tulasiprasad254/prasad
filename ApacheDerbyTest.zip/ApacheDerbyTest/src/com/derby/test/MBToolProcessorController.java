package com.derby.test;

import java.io.File;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import javax.lang.model.element.Modifier;

import com.derby.utils.StringUtils;
import com.squareup.javapoet.ClassName;
import com.squareup.javapoet.FieldSpec;
import com.squareup.javapoet.JavaFile;
import com.squareup.javapoet.MethodSpec;
import com.squareup.javapoet.TypeName;
import com.squareup.javapoet.TypeSpec;
import com.squareup.javapoet.MethodSpec.Builder;

public class MBToolProcessorController {
	
	//static TypeName globalstringUtils = ClassName.get("com.mtreetech.sawc.utils", "StringUtils");
	/*private final String recordClass = "MBService";
	private final String packagePath = "com.derby.common";	
	private final String utilsPackagePath = "com.derby.utils";
	private final String logUtilsClass = "LogUtils";
	private final String dateUtilsClass = "LogUtils";
	private final String stringUtilsClass = "StringUtils";
	private final String jsonPackagePath = "org.json.simple";
	private final String jSONObjectClass = "JSONObject";
	private final String javaUtilsPackagePath = "java.util";
	private final String hashMapClass = "HashMap";
	private final String arrayListClass = "ArrayList";
	private final String exceptionClass = "Exception";
	private final String exceptionPackage = "java.lang";
	private final String pojoPackagetoGeneratejavafiles="com.mb.to";
	private final String servicePackagetoGeneratejavafiles="com.mb.service";
	private final String daoPackagetoGeneratejavafiles="com.mb.dao";
	private final String preparedStatementClass = "PreparedStatement";
	private final String preparedStatementPackage = "java.sql";
	private final String resultSetClass = "ResultSet";
	private final String jSONArrayClass = "JSONArray";
	private final String daoClass = "MBDAO";
	private final String statementClass = "Statement";
	private final String controllerClass = "MBController";
	private final String controllerPackagetoGeneratejavafiles="com.mb.controller";*/
	private final String recordClass = "KBService";
	private final String packagePath = "com.key.mb.common";	
	private final String utilsPackagePath = "com.key.utils";
	private final String logUtilsClass = "LogUtils";
	private final String dateUtilsClass = "LogUtils";
	private final String stringUtilsClass = "StringUtils";
	private final String jsonPackagePath = "org.json.simple";
	private final String jSONObjectClass = "JSONObject";
	private final String javaUtilsPackagePath = "java.util";
	private final String hashMapClass = "HashMap";
	private final String arrayListClass = "ArrayList";
	private final String exceptionClass = "Exception";
	private final String exceptionPackage = "java.lang";
	private final String pojoPackagetoGeneratejavafiles="com.key.mb.to";
	private final String servicePackagetoGeneratejavafiles="com.key.mb.service";
	private final String daoPackagetoGeneratejavafiles="com.key.mb.dao";
	private final String preparedStatementClass = "PreparedStatement";
	private final String preparedStatementPackage = "java.sql";
	private final String resultSetClass = "ResultSet";
	private final String jSONArrayClass = "JSONArray";
	private final String daoClass = "KBDAO";
	private final String statementClass = "Statement";
	private final String controllerClass = "KBController";
	private final String controllerPackagetoGeneratejavafiles="com.key.mb.controller";
	private final String calssNameStartsKey="KB";
	
	public void controllerGenerator() throws SQLException, Exception
	{
		HashMap<String,String> columnList = new HashMap<String, String>();
		//ClassName superClassRecord = ClassName.get("com.mtreetech.sawc.common", "MFRecord");	
		ClassName superClassService = ClassName.get(packagePath, controllerClass);
		ArrayList<String> tablesData = Metadata.getTablesMetadata();		
		int countTables = tablesData.size();
		String className = null,classNameRecord= null,temp = null,originaltableName= null,classNameDAO= null,classNameService = null,classNameController = null;

		for (String string : tablesData) {
			
			columnList = Metadata.getColumnsMetadata(string) ;
			originaltableName = string.toLowerCase();
			className = StringUtils.replaceString(string, "_", "", true);
			temp = className;
			if("tmpesapendingtransactions".equalsIgnoreCase(className) || "statuscode".equalsIgnoreCase(className) || "sequencedata".equalsIgnoreCase(className)) continue;
			classNameDAO = calssNameStartsKey + StringUtils.convertFirstCharacterToUpperCase(className) + "DAO";
			classNameRecord = calssNameStartsKey + StringUtils.convertFirstCharacterToUpperCase(temp) + "Record";
			className = calssNameStartsKey + StringUtils.convertFirstCharacterToUpperCase(className) + "Controller";
			classNameService = calssNameStartsKey + StringUtils.convertFirstCharacterToUpperCase(temp) + "Service";
			generateControllerLayer(controllerPackagetoGeneratejavafiles,className,columnList,superClassService,classNameRecord,originaltableName,classNameDAO,classNameService);
			//break;
		}
		System.out.println("***********************Controllers Class Completed*********************");
		
	}
	
	private void generateControllerLayer(String packageName,String className,HashMap tableColumns,ClassName extendedClass,String classNameRecord,String originaltableName,String classNameDAO,String classNameService) throws Exception
	{
		File sourcePath = new File("src");
		TypeName LogUtils = ClassName.get(utilsPackagePath, logUtilsClass);
		TypeName stringUtils = ClassName.get(utilsPackagePath, stringUtilsClass);
		TypeName  JSONObject= ClassName.get(jsonPackagePath, jSONObjectClass);
		TypeName  hashMap= ClassName.get(javaUtilsPackagePath, hashMapClass);
		TypeName  arrayList= ClassName.get(javaUtilsPackagePath, arrayListClass);
		
		TypeName classNamelog = ClassName.get(packageName, StringUtils.convertFirstCharacterToUpperCase(className));
		TypeSpec.Builder classObject = TypeSpec.classBuilder(StringUtils.convertFirstCharacterToUpperCase(className))
			    .addModifiers(Modifier.PUBLIC)
			    .superclass(extendedClass);
		 FieldSpec fieldSpec = FieldSpec.builder(LogUtils, "logger")
		            .addModifiers(Modifier.PUBLIC, Modifier.STATIC)
		            .initializer("new $T($T.class.getName())",LogUtils,classNamelog)
		            .build();
		classObject.addField(fieldSpec);
		
		Iterator keyIterator = tableColumns.keySet().iterator();
		String firstCaps = null;
		String allCaps = null;
		boolean checkContainstoaddMethods = false;
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();	
		    if(firstCaps.equalsIgnoreCase("Createdby"))
		    	{
		    	//getCreatedby
		    	checkContainstoaddMethods = true;
		    		break;
		    	}
		
			
		}
		
		boolean idKey = false;
		Iterator keyIterator2 = tableColumns.keySet().iterator();
		
		while(keyIterator2.hasNext())
		{
			String key = keyIterator2.next().toString();
			if(key.equalsIgnoreCase("id")) 
			{
				idKey = true;
				break;
			}
			
		}
				
		classObject.addMethod(loadFormControllerRecordsMethodspec("loadForm"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO));
		classObject.addMethod(loadJSONFormFormControllerRecordsMethodspec("loadJSONForm"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO));
		classObject.addMethod(loadJSONFormFormEncodeControllerRecordsMethodspec("loadJSONForm"+classNameRecord+"Encode",classNamelog,tableColumns,classNameRecord,classNameDAO));
		classObject.addMethod(loadMapControllerRecordsMethodspec("loadMap"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO));
		if(idKey)
		{
		classObject.addMethod(processInsertControllerRecordsMethodspec("processInsert"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,classNameService,className,checkContainstoaddMethods));
		
		classObject.addMethod(processUpdateControllerRecordsMethodspec("processUpdate"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,classNameService,className,checkContainstoaddMethods));
		classObject.addMethod(processDeleteControllerRecordsMethodspec("processDelete"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,classNameService,className,checkContainstoaddMethods));
		classObject.addMethod(processWebControllerRecordsMethodspec("processWebRequest",classNamelog,tableColumns,classNameRecord,classNameDAO,classNameService,className));
		}
		
		
		JavaFile javaFile = JavaFile.builder(packageName, classObject.build())
				.build();
		javaFile.writeTo(sourcePath);
		/*classObject.addMethod(insertServiceRecordMethodspec("insert"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,className,checkContainstoaddMethods));
		classObject.addMethod(updateServiceRecordMethodspec("update"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,className,checkContainstoaddMethods));
		classObject.addMethod(updateServiceRecordNoNullMethodspec("update"+classNameRecord+"NoNull",classNamelog,tableColumns,classNameRecord,classNameDAO,className,checkContainstoaddMethods));
		classObject.addMethod(deleteServiceRecordNoNullMethodspec("delete"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,className,checkContainstoaddMethods));
		*/
	}
	
	/*
	 * Contorller Layer
	 */
	
	private MethodSpec loadFormControllerRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		TypeName arrayList = ClassName.get(javaUtilsPackagePath, arrayListClass);
		TypeName preparedStatement = ClassName.get(preparedStatementPackage, preparedStatementClass);
		TypeName resultSet = ClassName.get(preparedStatementPackage, resultSetClass);
		
		TypeName HttpServletRequest = ClassName.get("javax.servlet.http", "HttpServletRequest");
		TypeName HttpServletResponse = ClassName.get("javax.servlet.http", "HttpServletResponse");
		
		mehtod.addParameter(HttpServletRequest, "req");
		mehtod.addParameter(HttpServletResponse, "res");
		
		mehtod.returns(toClassRecord);
		//mehtod.addException(exception);
		
		mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"loadForm$N\", null)",classRecord);
		//mehtod.addStatement("logger.trace(\"load$Ns:\" + query)",classRecord);
		mehtod.addStatement("$T record = new $T()",toClassRecord,toClassRecord);
		
		Iterator keyIterator = columns.keySet().iterator();
		String firstCaps = null;
		String allCaps = "";
		String valueofQuery  = "";
		String valuesInsertScript = "";
		
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			
			String value = columns.get(key).toString();
			key = key.replaceAll("\\s","");
			
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();
			
			  mehtod.addStatement("record.set$N(getFormFieldValue(req, res, \"tf$N\"))",firstCaps,firstCaps);
			
		}
		
		mehtod.addStatement("logger.trace(\"loadForm$N\t\" + record + \"\t\")",classRecord);
		mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
		mehtod.addStatement("return record");
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	private MethodSpec loadJSONFormFormControllerRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		TypeName arrayList = ClassName.get(javaUtilsPackagePath, arrayListClass);
		TypeName preparedStatement = ClassName.get(preparedStatementPackage, preparedStatementClass);
		TypeName resultSet = ClassName.get(preparedStatementPackage, resultSetClass);
		
		TypeName HttpServletRequest = ClassName.get("javax.servlet.http", "HttpServletRequest");
		TypeName HttpServletResponse = ClassName.get("javax.servlet.http", "HttpServletResponse");
		
		mehtod.addParameter(HttpServletRequest, "req");
		mehtod.addParameter(HttpServletResponse, "res");
		
		mehtod.returns(toClassRecord);
		//mehtod.addException(exception);
		
		mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"loadJSONForm$N\", null)",classRecord);
		//mehtod.addStatement("logger.trace(\"load$Ns:\" + query)",classRecord);
		mehtod.addStatement("$T record = new $T()",toClassRecord,toClassRecord);
		
		Iterator keyIterator = columns.keySet().iterator();
		String firstCaps = null;
		String allCaps = "";
		String valueofQuery  = "";
		String valuesInsertScript = "";
		
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			
			String value = columns.get(key).toString();
			key = key.replaceAll("\\s","");
			
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();
			
			  mehtod.addStatement("record.set$N(getFormFieldValue(req, res, \"$N\"))",firstCaps,key);
			
		}
		
		mehtod.addStatement("logger.trace(\"loadJSONForm$N\t\" + record + \"\t\")",classRecord);
		mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
		mehtod.addStatement("return record");
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private MethodSpec loadJSONFormFormEncodeControllerRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		TypeName arrayList = ClassName.get(javaUtilsPackagePath, arrayListClass);
		TypeName preparedStatement = ClassName.get(preparedStatementPackage, preparedStatementClass);
		TypeName resultSet = ClassName.get(preparedStatementPackage, resultSetClass);
		
		TypeName HttpServletRequest = ClassName.get("javax.servlet.http", "HttpServletRequest");
		TypeName HttpServletResponse = ClassName.get("javax.servlet.http", "HttpServletResponse");
		
		mehtod.addParameter(HttpServletRequest, "req");
		mehtod.addParameter(HttpServletResponse, "res");
		
		mehtod.returns(toClassRecord);
		//mehtod.addException(exception);
		
		mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"loadJSONForm$NEncode\", null)",classRecord);
		//mehtod.addStatement("logger.trace(\"load$Ns:\" + query)",classRecord);
		mehtod.addStatement("$T record = new $T()",toClassRecord,toClassRecord);
		
		Iterator keyIterator = columns.keySet().iterator();
		String firstCaps = null;
		String allCaps = "";
		String valueofQuery  = "";
		String valuesInsertScript = "";
		
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			
			String value = columns.get(key).toString();
			key = key.replaceAll("\\s","");
			
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();
			
			  mehtod.addStatement("record.set$N(getFormFieldValueEncode(req, res, \"$N\"))",firstCaps,key);			
		}
		
		mehtod.addStatement("logger.trace(\"loadJSONForm$NEncode\t\" + record + \"\t\")",classRecord);
		mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
		mehtod.addStatement("return record");
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	private MethodSpec loadMapControllerRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		TypeName arrayList = ClassName.get(javaUtilsPackagePath, arrayListClass);
		TypeName preparedStatement = ClassName.get(preparedStatementPackage, preparedStatementClass);
		TypeName resultSet = ClassName.get(preparedStatementPackage, resultSetClass);			
		TypeName hashMap = ClassName.get(javaUtilsPackagePath, hashMapClass);
	
		
		TypeName HttpServletRequest = ClassName.get("javax.servlet.http", "HttpServletRequest");
		TypeName HttpServletResponse = ClassName.get("javax.servlet.http", "HttpServletResponse");
		
		mehtod.addParameter(hashMap, "inputMap");
		//mehtod.addParameter(HttpServletResponse, "res");
		
		mehtod.returns(toClassRecord);
		//mehtod.addException(exception);
		
		mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"loadMap$N\", null)",classRecord);
		//mehtod.addStatement("logger.trace(\"load$Ns:\" + query)",classRecord);
		mehtod.addStatement("$T record = new $T()",toClassRecord,toClassRecord);
		
		Iterator keyIterator = columns.keySet().iterator();
		String firstCaps = null;
		String allCaps = "";
		String valueofQuery  = "";
		String valuesInsertScript = "";
		
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			
			String value = columns.get(key).toString();
			key = key.replaceAll("\\s","");
			
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();
			
			  mehtod.addStatement("record.set$N(getMapValue(inputMap,\"$N\"))",firstCaps,key);			
		}
		
		mehtod.addStatement("logger.trace(\"loadMap$N\t\" + record + \"\t\")",classRecord);
		mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
		mehtod.addStatement("return record");
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	private MethodSpec processInsertControllerRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String classNameService,String classNameR,boolean checkContainstoaddMethods)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		System.out.println("ClasssName ::::::::::::::::; "+classNameService);
		
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
				
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);
		TypeName  serviceClassRecord = ClassName.get(servicePackagetoGeneratejavafiles, classNameService);
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		TypeName arrayList = ClassName.get(javaUtilsPackagePath, arrayListClass);
		TypeName preparedStatement = ClassName.get(preparedStatementPackage, preparedStatementClass);
		TypeName resultSet = ClassName.get(preparedStatementPackage, resultSetClass);			
		TypeName hashMap = ClassName.get(javaUtilsPackagePath, hashMapClass);
			
		
		TypeName HttpServletRequest = ClassName.get("javax.servlet.http", "HttpServletRequest");
		TypeName HttpServletResponse = ClassName.get("javax.servlet.http", "HttpServletResponse");
		
		mehtod.addParameter(HttpServletRequest, "req");
		mehtod.addParameter(HttpServletResponse, "res");
		
		//mehtod.returns(toClassRecord);
		mehtod.addException(exception);
		
		mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"processInsert$N\", null)",classRecord);
		//mehtod.addStatement("logger.trace(\"load$Ns:\" + query)",classRecord);
		mehtod.addStatement("$T service = new $T()",serviceClassRecord,serviceClassRecord);
		
		mehtod.beginControlFlow("try");
			mehtod.addStatement("$N record = loadForm$N(req, res)",classRecord,classRecord);
			if(checkContainstoaddMethods) mehtod.addStatement("record.setCreatedby(getLoggedInUserId(req, res))");
			mehtod.addStatement("int resultId = service.insert$N(record)",classRecord);
			mehtod.addStatement("setActionMessage(req, res, \"AdminActionMessage\", \"RecordCreationSuccessful~~\" + resultId)",classRecord);
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
			mehtod.addStatement(" res.sendRedirect(\"$N.jsp\")",classNameR);
	   mehtod.endControlFlow();
	   mehtod.beginControlFlow("catch(Exception e)");
	   		mehtod.addStatement("setActionMessageLn(req, res, \"AdminActionMessage\", \"FailedtoCreate~~$N~~\")",classRecord);
	   		mehtod.addStatement("setActionMessage(req, res, \"AdminActionMessageException\", e)");
	   		mehtod.addStatement("logger.error(\"Failed to Create Customer \" + e)");
	   		mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
	   		mehtod.addStatement("res.sendRedirect(\"$N.jsp\")",classNameR);
	   mehtod.endControlFlow();
		
		
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	private MethodSpec processUpdateControllerRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String classNameService,String classNameR,boolean checkContainstoaddMethods)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		System.out.println("ClasssName ::::::::::::::::; "+classNameService);
		
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);
		TypeName  serviceClassRecord = ClassName.get(servicePackagetoGeneratejavafiles, classNameService);
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		TypeName arrayList = ClassName.get(javaUtilsPackagePath, arrayListClass);
		TypeName preparedStatement = ClassName.get(preparedStatementPackage, preparedStatementClass);
		TypeName resultSet = ClassName.get(preparedStatementPackage, resultSetClass);			
		TypeName hashMap = ClassName.get(javaUtilsPackagePath, hashMapClass);
			
			
		
		TypeName HttpServletRequest = ClassName.get("javax.servlet.http", "HttpServletRequest");
		TypeName HttpServletResponse = ClassName.get("javax.servlet.http", "HttpServletResponse");
		
		mehtod.addParameter(HttpServletRequest, "req");
		mehtod.addParameter(HttpServletResponse, "res");
		
		//mehtod.returns(toClassRecord);
		mehtod.addException(exception);
		
		mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"processUpdate$N\", null)",classRecord);
		//mehtod.addStatement("logger.trace(\"load$Ns:\" + query)",classRecord);
		mehtod.addStatement("$T service = new $T()",serviceClassRecord,serviceClassRecord);
		
		mehtod.beginControlFlow("try");
			mehtod.addStatement("$N record = loadForm$N(req, res)",classRecord,classRecord);
			if(checkContainstoaddMethods) mehtod.addStatement("record.setCreatedby(getLoggedInUserId(req, res))");
			mehtod.addStatement("service.update$N(record)",classRecord);
			mehtod.addStatement("setActionMessage(req, res, \"AdminActionMessage\", \"RecordCreationSuccessful~~\")");
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
			mehtod.addStatement("res.sendRedirect(\"$N.jsp\")",classNameR);
	   mehtod.endControlFlow();
	   mehtod.beginControlFlow("catch(Exception e)");
	   		mehtod.addStatement("setActionMessage(req, res, \"AdminActionMessage\", \"FailedtoCreate~~$N~~\")",classRecord);
	   		mehtod.addStatement("setActionMessage(req, res, \"AdminActionMessageException\", e)");
	   		mehtod.addStatement("logger.error(\"Failed to Create Customer \" + e)");
	   		mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
	   		mehtod.addStatement("res.sendRedirect(\"$N.jsp\")",classNameR);
	   mehtod.endControlFlow();
		
		
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private MethodSpec processDeleteControllerRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String classNameService,String classNameR,boolean checkContainstoaddMethods)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		System.out.println("ClasssName ::::::::::::::::; "+classNameService);
		
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);
		TypeName  serviceClassRecord = ClassName.get(servicePackagetoGeneratejavafiles, classNameService);
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		TypeName arrayList = ClassName.get(javaUtilsPackagePath, arrayListClass);
		TypeName preparedStatement = ClassName.get(preparedStatementPackage, preparedStatementClass);
		TypeName resultSet = ClassName.get(preparedStatementPackage, resultSetClass);			
		TypeName hashMap = ClassName.get(javaUtilsPackagePath, hashMapClass);
			
			
		
		TypeName HttpServletRequest = ClassName.get("javax.servlet.http", "HttpServletRequest");
		TypeName HttpServletResponse = ClassName.get("javax.servlet.http", "HttpServletResponse");
		
		mehtod.addParameter(HttpServletRequest, "req");
		mehtod.addParameter(HttpServletResponse, "res");
		
		//mehtod.returns(toClassRecord);
		mehtod.addException(exception);
		
		mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"processDelete$N\", null)",classRecord);
		//mehtod.addStatement("logger.trace(\"load$Ns:\" + query)",classRecord);
		mehtod.addStatement("$T service = new $T()",serviceClassRecord,serviceClassRecord);
		
		mehtod.beginControlFlow("try");
			mehtod.addStatement("$N record = loadForm$N(req, res)",classRecord,classRecord);
			if(checkContainstoaddMethods) mehtod.addStatement("record.setCreatedby(getLoggedInUserId(req, res))");
			mehtod.addStatement("service.delete$N(record)",classRecord);
			mehtod.addStatement("setActionMessage(req, res, \"AdminActionMessage\", \"RecordCreationSuccessful~~\")");
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
			mehtod.addStatement("res.sendRedirect(\"$N.jsp\")",classNameR);
	   mehtod.endControlFlow();
	   mehtod.beginControlFlow("catch(Exception e)");
	   		mehtod.addStatement("setActionMessage(req, res, \"AdminActionMessage\", \"FailedtoCreate~~$N~~\")",classRecord);
	   		mehtod.addStatement("setActionMessage(req, res, \"AdminActionMessageException\", e)");
	   		mehtod.addStatement("logger.error(\"Failed to Create Customer \" + e)");
	   		mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
	   		mehtod.addStatement("res.sendRedirect(\"$N.jsp\")",classNameR);
	   mehtod.endControlFlow();
		
		
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	private MethodSpec processWebControllerRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String classNameService,String classNameR)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		System.out.println("ClasssName ::::::::::::::::; "+classNameService);
		String clasName = classRecord.toString();
		clasName = StringUtils.replaceString(clasName, calssNameStartsKey, "", false);
		String clasNameFirstCaps =StringUtils.convertFirstCharacterToUpperCase(clasName);
		
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);
		TypeName  serviceClassRecord = ClassName.get(servicePackagetoGeneratejavafiles, classNameService);
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		TypeName arrayList = ClassName.get(javaUtilsPackagePath, arrayListClass);
		TypeName preparedStatement = ClassName.get(preparedStatementPackage, preparedStatementClass);
		TypeName resultSet = ClassName.get(preparedStatementPackage, resultSetClass);			
		TypeName hashMap = ClassName.get(javaUtilsPackagePath, hashMapClass);
			
			
		
		TypeName HttpServletRequest = ClassName.get("javax.servlet.http", "HttpServletRequest");
		TypeName HttpServletResponse = ClassName.get("javax.servlet.http", "HttpServletResponse");
		
		mehtod.addParameter(HttpServletRequest, "req");
		mehtod.addParameter(HttpServletResponse, "res");
		mehtod.addParameter(String.class, "actionType");
		
		//mehtod.returns(toClassRecord);
		mehtod.addException(exception);
		
		mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"processWebRequest\", null)",classRecord);
		//mehtod.addStatement("logger.trace(\"load$Ns:\" + query)",classRecord);
		mehtod.addStatement(" logger.trace(\"Action Type:\" + actionType + \"\")");
		mehtod.beginControlFlow("if (actionType.equals(\"Insert$N\"))",clasNameFirstCaps);
			mehtod.addStatement("processInsert$N(req, res)",classRecord);
		mehtod.endControlFlow();
		mehtod.beginControlFlow("if (actionType.equals(\"Update$N\"))",clasNameFirstCaps);
			mehtod.addStatement("processUpdate$N(req, res)",classRecord);
		mehtod.endControlFlow();
		mehtod.beginControlFlow("if (actionType.equals(\"Delete$N\"))",clasNameFirstCaps);
			mehtod.addStatement("processDelete$N(req, res)",classRecord);
		mehtod.endControlFlow();
		
		mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
		
		
		
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}

}
