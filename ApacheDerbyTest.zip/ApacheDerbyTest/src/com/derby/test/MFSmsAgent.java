

package com.derby.test;

// Java imports
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;

import com.derby.common.MBDAO;
import com.derby.common.MBService;

import com.mb.service.MBSmsmesgService;
import com.mb.to.*;
import com.derby.utils.*;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MFSmsAgent implements Runnable
{
	/**
	 * The logger object instance for the classss
	 */
	private static LogUtils logger =
		new LogUtils(MFSmsAgent.class.getName());
	
	ArrayList jobList = new ArrayList();
	private String MIN_RANGE;
	private String MAX_RANGE;

	//Get Pending Task List
	public void loadPendingTasks()
	throws Exception
	{
		String maxmailretry=PropertyUtil.getProperty("maxmailretry"); 
		String query = "SELECT * FROM SMS_MESG WHERE (RSTATUS IN ('0','2')) AND (MRETRYCNT <= '" + maxmailretry + "') LIMIT #MIN_RANGE#,#MAX_RANGE#";
		query = StringUtils.replaceString(query, "#MIN_RANGE#", MIN_RANGE, false);
		query = StringUtils.replaceString(query, "#MAX_RANGE#", MAX_RANGE, false);
		System.out.println("Updated Query :"+query);
		MBSmsmesgService mesgService = new MBSmsmesgService();
		MBSmsmesgRecord[] records = mesgService.loadMBSmsmesgRecords(query);
		if (records == null) return;
		if (records.length < 1) return;
		for (int index = 0; index < records.length; index++)
		{
			jobList.add(records[index]);
		}
	}
	
	public void processMessagesInQueue()
	throws Exception
	{
		//if (jobList.size() > 0) return;
		logger.debug("Current SMS Job Size:" + jobList.size());

		loadPendingTasks();
		Iterator iterator = jobList.iterator();
		while(iterator.hasNext())
		{
			MBSmsmesgRecord record = (MBSmsmesgRecord)iterator.next();
			processSmsRecord(record);
		}
		jobList.clear();
	}
	
	public void processSmsRecord(MBSmsmesgRecord record)
	{
		try
		{
			//Send SMS Message
			System.out.println("Processing " + record);

			HashMap inputMap = new HashMap();
			inputMap.put("MessageId", record.getId());
			inputMap.put("MobileNumber", record.getMtoaddr());
			inputMap.put("Message", record.getMmessage());
			inputMap.put("Sender", PropertyUtil.getProperty("SMSSender"));
			
			String errorMessage = "";
			String successMessage = "";
			try
			{
				/*MFTransactionService transactionService = new MFTransactionService();
				HashMap outputMap = transactionService.sendSMS(inputMap);
				if (outputMap.containsKey("ErrorMessage"))
				{
					errorMessage = outputMap.get("ErrorMessage").toString();
				}
				else
				{
					successMessage = outputMap.get("ResultMessage").toString();
				}*/
			}
			catch(Exception exception)
			{
				errorMessage = exception.toString();
			}
			
			if (StringUtils.isNullOrEmpty(errorMessage))
			{
				record.setRstatus(MFConstants.SENT);
				record.setMesgqout(DateUtils.getCurrentDateTime());
				record.setMesgqerr(successMessage);
			}
			else
			{
				record.setRstatus(MFConstants.SENT_FAIL);
				record.setMesgqerr(errorMessage);
				String retryCountString = StringUtils.noNull(record.getMretrycnt(), "0");
				int retryCount = Integer.parseInt(retryCountString);
				retryCount++;
				record.setMretrycnt(retryCount + "");
				record.setMesgqerr(errorMessage);				
			}

			MBSmsmesgService smsService = new MBSmsmesgService();
			smsService.updateMBSmsmesgRecord(record);
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
		}
	}
	
	/*public static void main(String [] args)
	throws Exception
    {
		System.out.println("SMS Service Started....");		
		MFSmsAgent smsAgent = new MFSmsAgent();

		while(true)
		{
			smsAgent.processMessagesInQueue();
			try
			{
				Thread.sleep(60000);
			}
			catch(Exception e)
			{
				
			}
		}
    }*/

	public MFSmsAgent(String MIN_COUNT,String MAX_COUNT,String ThreadName)
	{
		this.MIN_RANGE = MIN_COUNT;
		this.MAX_RANGE = MAX_COUNT;
	}
	
	@Override
	public void run() {
		try {
			processMessagesInQueue();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	
	
}