package com.derby.test;

import java.io.File;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import javax.lang.model.element.Modifier;

import com.derby.utils.StringUtils;
import com.squareup.javapoet.ArrayTypeName;
import com.squareup.javapoet.ClassName;
import com.squareup.javapoet.FieldSpec;
import com.squareup.javapoet.JavaFile;
import com.squareup.javapoet.MethodSpec;
import com.squareup.javapoet.TypeName;
import com.squareup.javapoet.TypeSpec;
import com.squareup.javapoet.MethodSpec.Builder;

public class MBToolProcessorService {
	
	/*private final String recordClass = "MBService";
	private final String packagePath = "com.derby.common";	
	private final String utilsPackagePath = "com.derby.utils";
	private final String logUtilsClass = "LogUtils";
	private final String dateUtilsClass = "LogUtils";
	private final String stringUtilsClass = "StringUtils";
	private final String jsonPackagePath = "org.json.simple";
	private final String jSONObjectClass = "JSONObject";
	private final String javaUtilsPackagePath = "java.util";
	private final String hashMapClass = "HashMap";
	private final String arrayListClass = "ArrayList";
	private final String exceptionClass = "Exception";
	private final String exceptionPackage = "java.lang";
	private final String pojoPackagetoGeneratejavafiles="com.mb.to";
	private final String servicePackagetoGeneratejavafiles="com.mb.service";
	private final String daoPackagetoGeneratejavafiles="com.mb.dao";
	private final String preparedStatementClass = "PreparedStatement";
	private final String preparedStatementPackage = "java.sql";
	private final String resultSetClass = "ResultSet";
	private final String jSONArrayClass = "JSONArray";*/
	
	private final String recordClass = "KBService";
	private final String packagePath = "com.key.mb.common";	
	private final String utilsPackagePath = "com.key.utils";
	private final String logUtilsClass = "LogUtils";
	private final String dateUtilsClass = "DateUtils";
	private final String stringUtilsClass = "StringUtils";
	private final String jsonPackagePath = "org.json.simple";
	private final String jSONObjectClass = "JSONObject";
	private final String javaUtilsPackagePath = "java.util";
	private final String hashMapClass = "HashMap";
	private final String arrayListClass = "ArrayList";
	private final String exceptionClass = "Exception";
	private final String exceptionPackage = "java.lang";
	private final String pojoPackagetoGeneratejavafiles="com.key.mb.to";
	private final String servicePackagetoGeneratejavafiles="com.key.mb.service";
	private final String daoPackagetoGeneratejavafiles="com.key.mb.dao";
	private final String preparedStatementClass = "PreparedStatement";
	private final String preparedStatementPackage = "java.sql";
	private final String resultSetClass = "ResultSet";
	private final String jSONArrayClass = "JSONArray";
	private final String calssNameStartsKey="KB";
	public void serviceGenerator() throws SQLException, Exception
	{
		HashMap<String,String> columnList = new HashMap<String, String>();
		//ClassName superClassRecord = ClassName.get("com.mtreetech.sawc.common", "MFRecord");	
		ClassName superClassService = ClassName.get(packagePath, recordClass);
		ArrayList<String> tablesData = Metadata.getTablesMetadata();		
		int countTables = tablesData.size();
		String className = null,classNameRecord= null,temp = null,originaltableName= null,classNameDAO= null ;

		for (String string : tablesData) {
			
			columnList = Metadata.getColumnsMetadata(string) ;
			originaltableName = string.toLowerCase();
			className = StringUtils.replaceString(string, "_", "", true);
			temp = className;
			if("tmpesapendingtransactions".equalsIgnoreCase(className) || "statuscode".equalsIgnoreCase(className) || "sequencedata".equalsIgnoreCase(className) 
					|| "reportwalletaccountsummary".equalsIgnoreCase(className) || "reportwalletcustomersummary".equalsIgnoreCase(className)
					|| "reportsystemuserlist".equalsIgnoreCase(className) || "reportcustomeribactivelist".equalsIgnoreCase(className) 
					|| "reportcustomeribinactivelist".equalsIgnoreCase(className) || "reportcustomerlist".equalsIgnoreCase(className)) continue;
			classNameDAO = calssNameStartsKey + StringUtils.convertFirstCharacterToUpperCase(className) + "DAO";
			classNameRecord = calssNameStartsKey + StringUtils.convertFirstCharacterToUpperCase(temp) + "Record";
			className = calssNameStartsKey + StringUtils.convertFirstCharacterToUpperCase(className) + "Service";
			generateServiceLayer(servicePackagetoGeneratejavafiles,className,columnList,superClassService,classNameRecord,originaltableName,classNameDAO);
			//break;
		}
		System.out.println("***********************Service Class Completed*********************");
		
	}
	
	private void generateServiceLayer(String packageName,String className,HashMap tableColumns,ClassName extendedClass,String classNameRecord,String originaltableName,String classNameDAO) throws Exception
	{
		File sourcePath = new File("src");
	
		TypeName stringUtils = ClassName.get(utilsPackagePath, stringUtilsClass);		
		TypeName LogUtils = ClassName.get(utilsPackagePath, logUtilsClass);
		TypeName  JSONObject= ClassName.get(jsonPackagePath, jSONObjectClass);
		TypeName  hashMap= ClassName.get(javaUtilsPackagePath, hashMapClass);
		TypeName  arrayList= ClassName.get(javaUtilsPackagePath, arrayListClass);
		
		TypeName classNamelog = ClassName.get(packageName, StringUtils.convertFirstCharacterToUpperCase(className));
		TypeSpec.Builder classObject = TypeSpec.classBuilder(StringUtils.convertFirstCharacterToUpperCase(className))
			    .addModifiers(Modifier.PUBLIC)
			    .superclass(extendedClass);
		 FieldSpec fieldSpec = FieldSpec.builder(LogUtils, "logger")
		            .addModifiers(Modifier.PUBLIC, Modifier.STATIC)
		            .initializer("new $T($T.class.getName())",LogUtils,classNamelog)
		            .build();
		classObject.addField(fieldSpec);
		
		Iterator keyIterator = tableColumns.keySet().iterator();
		String firstCaps = null;
		String allCaps = null;
		boolean checkContainstoaddMethods = false;
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();	
		    if(firstCaps.equalsIgnoreCase("Madeby"))
		    	{
		    	//getCreatedby
		    	checkContainstoaddMethods = true;
		    		break;
		    	}
		
			
		}
		
		boolean idKey = false;
		Iterator keyIterator2 = tableColumns.keySet().iterator();
		
		while(keyIterator2.hasNext())
		{
			String key = keyIterator2.next().toString();
			if(key.equalsIgnoreCase("id")) 
			{
				idKey = true;
				break;
			}
			
		}
				
		classObject.addMethod(loadServiceRecordsMethodspec("load"+classNameRecord+"s",classNamelog,tableColumns,classNameRecord,classNameDAO));
		classObject.addMethod(loadServiceFirstRecordsMethodspec("loadFirst"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO));
		classObject.addMethod(searchServiceFirstRecordsMethodspec("searchFirst"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO));
		classObject.addMethod(searchServiceExactUpperRecordsMethodspec("search"+classNameRecord+"ExactUpper",classNamelog,tableColumns,classNameRecord,classNameDAO));
		classObject.addMethod(searchServiceArrayRecordsMethodspec("search"+classNameRecord+"s",classNamelog,tableColumns,classNameRecord,classNameDAO));
		classObject.addMethod(loadServiceRecordCountMethodspec("load"+classNameRecord+"Count",classNamelog,tableColumns,classNameRecord,classNameDAO));
		classObject.addMethod(loadServiceRecordCountTwoParametersMethodspec("load"+classNameRecord+"Count",classNamelog,tableColumns,classNameRecord,classNameDAO));
		classObject.addMethod(loadServiceRecordkeyParameterMethodspec("load"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO));
		classObject.addMethod(getJSONSearchResultByPageMethodspec("getJSON"+classNameRecord+"SearchResultByPage",classNamelog,tableColumns,classNameRecord,classNameDAO));
		classObject.addMethod(getJSONSearchResultByPageFirstMethodspec("getJSON"+classNameRecord+"SearchResultByPage",classNamelog,tableColumns,classNameRecord,classNameDAO));
		if(idKey)
		{
		classObject.addMethod(insertServiceRecordMethodspec("insert"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,className,checkContainstoaddMethods));
		classObject.addMethod(updateServiceRecordMethodspec("update"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,className,checkContainstoaddMethods));
		classObject.addMethod(updateServiceRecordNoNullMethodspec("update"+classNameRecord+"NonNull",classNamelog,tableColumns,classNameRecord,classNameDAO,className,checkContainstoaddMethods));
		classObject.addMethod(deleteServiceRecordNoNullMethodspec("delete"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,className,checkContainstoaddMethods));
		}
		if(checkContainstoaddMethods)
		{
		classObject.addMethod(approveServiceRecordNoNullMethodspec("approve"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,className));
		classObject.addMethod(submitServiceRecordNoNullMethodspec("submit"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,className));
		classObject.addMethod(denyServiceRecordNoNullMethodspec("deny"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,className));
		classObject.addMethod(denyPermanentServiceRecordNoNullMethodspec("denyPermanant"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,className));
		classObject.addMethod(remindServiceRecordNoNullMethodspec("remindApproval"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,className));
		classObject.addMethod(resetServiceRecordNoNullMethodspec("resetApproval"+classNameRecord,classNamelog,tableColumns,classNameRecord,classNameDAO,className));
		}
		
		
		
		
		JavaFile javaFile = JavaFile.builder(packageName, classObject.build())
				.build();
		javaFile.writeTo(sourcePath);
		
		
		
		
	}
	
	/***
	 * 
	 * Service Layer Method Implementations
	 * 
	 */
	
	private MethodSpec loadServiceRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);	
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		TypeName arrayList = ClassName.get(utilsPackagePath, arrayListClass);
		TypeName preparedStatement = ClassName.get(preparedStatementPackage, preparedStatementClass);
		TypeName resultSet = ClassName.get(preparedStatementPackage, resultSetClass);
		mehtod.addParameter(String.class, "query");
		mehtod.returns(ArrayTypeName.of(toClassRecord));
		mehtod.addException(exception);
		
		mehtod.beginControlFlow("try");
			mehtod.addStatement("logger.trace(\"load$Ns:\" + query)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"load$Ns\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("$T[] results = dao.load$Ns(query)",toClassRecord,classRecord);
			mehtod.addStatement("int resultRecordCount = 0");
				mehtod.beginControlFlow("if (results != null)");
					mehtod.addStatement("resultRecordCount = results.length");
				mehtod.endControlFlow();
			mehtod.addStatement("logger.trace(\"load$Ns:Fetched\" + resultRecordCount)",classRecord);
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)",classRecord);
			mehtod.addStatement("return results");
	    mehtod.endControlFlow();
	    mehtod.beginControlFlow("catch(Exception exception)");
	    	mehtod.addStatement("logger.error(\"load$Ns\" + getStackTrace(exception))",classRecord);
	    	mehtod.addStatement("throw new Exception(\"MFException:\" + getErrorMessage(exception))",classRecord);
	    mehtod.endControlFlow();
	
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private MethodSpec loadServiceFirstRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);	
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		TypeName arrayList = ClassName.get(utilsPackagePath, arrayListClass);
		TypeName preparedStatement = ClassName.get(preparedStatementPackage, preparedStatementClass);
		TypeName resultSet = ClassName.get(preparedStatementPackage, resultSetClass);
		mehtod.addParameter(String.class, "query");
		mehtod.returns(toClassRecord);
		mehtod.addException(exception);
		
		mehtod.beginControlFlow("try");
			mehtod.addStatement("logger.trace(\"load$Ns:\" + query)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"load$Ns\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("$T result = dao.loadFirst$N(query)",toClassRecord,classRecord);
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)",classRecord);
			mehtod.addStatement("return result");
	    mehtod.endControlFlow();
	    mehtod.beginControlFlow("catch(Exception exception)");
	    	mehtod.addStatement("logger.error(\"loadFirst$N\" + getStackTrace(exception))",classRecord);
	    	mehtod.addStatement("throw new Exception(\"MFException:\" + getErrorMessage(exception))",classRecord);
	    mehtod.endControlFlow();
	
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private  MethodSpec searchServiceFirstRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);	
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		TypeName arrayList = ClassName.get(utilsPackagePath, arrayListClass);
		TypeName preparedStatement = ClassName.get(preparedStatementPackage, preparedStatementClass);
		TypeName resultSet = ClassName.get(preparedStatementPackage, resultSetClass);
		mehtod.addParameter(toClassRecord, "record");
		mehtod.returns(toClassRecord);
		mehtod.addException(exception);
		
		mehtod.beginControlFlow("try");
			mehtod.addStatement("logger.trace(\"searchFirst$Ns:\" + record)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"searchFirst$Ns\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("$T[] records = dao.search$Ns(record)",toClassRecord,classRecord);
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)",classRecord);
			mehtod.beginControlFlow("if(records == null)");
			mehtod.addStatement("return null");
			mehtod.endControlFlow();
			mehtod.beginControlFlow("if(records.length < 1)");
			mehtod.addStatement("return null");
			mehtod.endControlFlow();
			mehtod.addStatement("return records[0]");
	    mehtod.endControlFlow();
	    mehtod.beginControlFlow("catch(Exception exception)");
	    	mehtod.addStatement("logger.error(\"searchFirst$Ns\" + getStackTrace(exception))",classRecord);
	    	mehtod.addStatement("throw new Exception(\"MFException:\" + getErrorMessage(exception))",classRecord);
	    mehtod.endControlFlow();
	
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private  MethodSpec searchServiceExactUpperRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);	
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		TypeName arrayList = ClassName.get(utilsPackagePath, arrayListClass);
		TypeName preparedStatement = ClassName.get(preparedStatementPackage, preparedStatementClass);
		TypeName resultSet = ClassName.get(preparedStatementPackage, resultSetClass);
		mehtod.addParameter(toClassRecord, "record");
		mehtod.returns(toClassRecord);
		mehtod.addException(exception);
		
		mehtod.beginControlFlow("try");
			mehtod.addStatement("logger.trace(\"searchFirst$NsExactUpper:\" + record)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"searchFirst$NsExactUpper\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("$T[] records = dao.search$NsExactUpper(record)",toClassRecord,classRecord);
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)",classRecord);
			mehtod.beginControlFlow("if(records == null)");
			mehtod.addStatement("return null");
			mehtod.endControlFlow();
			mehtod.beginControlFlow("if(records.length < 1)");
			mehtod.addStatement("return null");
			mehtod.endControlFlow();
			mehtod.addStatement("return records[0]");
	    mehtod.endControlFlow();
	    mehtod.beginControlFlow("catch(Exception exception)");
	    	mehtod.addStatement("logger.error(\"searchFirst$Ns\" + getStackTrace(exception))",classRecord);
	    	mehtod.addStatement("throw new Exception(\"MFException:\" + getErrorMessage(exception))",classRecord);
	    mehtod.endControlFlow();
	
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	private MethodSpec searchServiceArrayRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);	
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		TypeName arrayList = ClassName.get(utilsPackagePath, arrayListClass);
		TypeName preparedStatement = ClassName.get(preparedStatementPackage, preparedStatementClass);
		TypeName resultSet = ClassName.get(preparedStatementPackage, resultSetClass);
		mehtod.addParameter(toClassRecord, "record");
		mehtod.returns(ArrayTypeName.of(toClassRecord));
		mehtod.addException(exception);
		
		mehtod.beginControlFlow("try");
			mehtod.addStatement("logger.trace(\"search$Ns:\" + record)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"load$Ns\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("$T[] records = dao.search$Ns(record)",toClassRecord,classRecord);
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)",classRecord);	
			mehtod.addStatement("return records");
	    mehtod.endControlFlow();
	    mehtod.beginControlFlow("catch(Exception exception)");
	    	mehtod.addStatement("logger.error(\"search$Ns\" + getStackTrace(exception))",classRecord);
	    	mehtod.addStatement("throw new Exception(\"MFException:\" + getErrorMessage(exception))",classRecord);
	    mehtod.endControlFlow();
	
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private MethodSpec loadServiceRecordCountMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);	
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		
		mehtod.addParameter(toClassRecord, "record");
		mehtod.returns(int.class);
		mehtod.addException(exception);
		
		mehtod.addStatement("return load$NCount(record, null)",classRecord);
		
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	private MethodSpec loadServiceRecordCountTwoParametersMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);	
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		mehtod.addParameter(toClassRecord, "record");
		mehtod.addParameter(String.class, "customCondition");
		mehtod.returns(int.class);
		mehtod.addException(exception);
		mehtod.beginControlFlow("try");
			mehtod.addStatement("logger.trace(\"load$N:\" + record)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"load$NCount\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("dao.setCustomCondition(customCondition)");
			mehtod.addStatement("int resultcount = dao.load$NCount(record)",classRecord);
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)",classRecord);	
			mehtod.addStatement("return resultcount");
		mehtod.endControlFlow();
		mehtod.beginControlFlow("catch(Exception exception)");
    	mehtod.addStatement("logger.error(\"load$NCount\" + getStackTrace(exception))",classRecord);
    	mehtod.addStatement("throw new Exception(\"MFException:\" + getErrorMessage(exception))",classRecord);
    	mehtod.endControlFlow();

	  mehtod.addModifiers(Modifier.PUBLIC);
	  return mehtod.build(); 
	}
	
	private MethodSpec loadServiceRecordkeyParameterMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);	
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		mehtod.addParameter(String.class, "key");	
		mehtod.returns(toClassRecord);
		mehtod.addException(exception);
		mehtod.beginControlFlow("try");
			mehtod.addStatement("logger.trace(\"load$N:\" + key)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"load$NCount\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("$T result = dao.load$N(key)",toClassRecord,classRecord);
			mehtod.addStatement("logger.trace(\"load$N:\" + result)",classRecord);	
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)",classRecord);	
			mehtod.addStatement("return result");
		mehtod.endControlFlow();
		mehtod.beginControlFlow("catch(Exception exception)");
    	mehtod.addStatement("logger.error(\"load$N\" + getStackTrace(exception))",classRecord);
    	mehtod.addStatement("throw new Exception(\"MFException:\" + getErrorMessage(exception))",classRecord);
    	mehtod.endControlFlow();

	  mehtod.addModifiers(Modifier.PUBLIC);
	  return mehtod.build(); 
	}
	
	private MethodSpec getJSONSearchResultByPageMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);	
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		TypeName jsonObject = ClassName.get(jsonPackagePath, jSONObjectClass);
		mehtod.addParameter(toClassRecord, "record");
		mehtod.addParameter(String.class, "offset");
		mehtod.addParameter(String.class, "maxrows");
		mehtod.addParameter(String.class, "orderBy");
		mehtod.returns(jsonObject);
		mehtod.addException(exception);
		
		mehtod.addStatement("return getJSON$NSearchResultByPage(record, offset, maxrows, orderBy, null)",classRecord);
		
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	private MethodSpec getJSONSearchResultByPageFirstMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);	
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		TypeName jsonObject = ClassName.get(jsonPackagePath, jSONObjectClass);
		TypeName jsonArray = ClassName.get(jsonPackagePath, jSONArrayClass);
				
		
		mehtod.addParameter(toClassRecord, "record");
		mehtod.addParameter(String.class, "offset");
		mehtod.addParameter(String.class, "maxrows");
		mehtod.addParameter(String.class, "orderBy");
		mehtod.addParameter(String.class, "customCondition");
		
		mehtod.returns(jsonObject);
		mehtod.addException(exception);
		mehtod.beginControlFlow("try");
			mehtod.addStatement("logger.trace(\"getJSON$NSearchResultByPage:\" + record + \" Offset:\" + offset + \" Maxrows:\" + maxrows)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"getJSON$NSearchResult\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()", daoClassRecord,daoClassRecord);
			mehtod.addStatement("int totalCount = dao.load$NCount(record)", classRecord);
			mehtod.addStatement("dao.setLimits(offset, maxrows)");
			mehtod.addStatement("$N[] records = null", classRecord);
			mehtod.beginControlFlow("if (totalCount > 0)");
				mehtod.addStatement("dao.setOrderBy(orderBy)");
				mehtod.addStatement("records = dao.search$Ns(record)",classRecord);
			mehtod.endControlFlow();
			mehtod.addStatement("$T resultObject = new $T()",jsonObject,jsonObject);
			mehtod.addStatement("resultObject.put(\"total\",totalCount + \"\")");
			mehtod.addStatement("$T dataArray = new $T()",jsonArray,jsonArray);
			mehtod.addStatement("int recordCount = 0");
			mehtod.beginControlFlow("if (totalCount > 0)");
				mehtod.addStatement("recordCount = records.length");
			mehtod.endControlFlow(); 
			mehtod.beginControlFlow("for (int index = 0; index < recordCount; index++)");
				mehtod.addStatement("dataArray.add(records[index].getJSONObjectUI())");
			mehtod.endControlFlow(); 
			mehtod.addStatement("resultObject.put(\"rows\",dataArray)");
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
			mehtod.addStatement("return resultObject");
		mehtod.endControlFlow();
		mehtod.beginControlFlow("catch(Exception exception)");
    	mehtod.addStatement("logger.error(\"getJSON$NSearchResult\" + getStackTrace(exception))",classRecord);
    	mehtod.addStatement("throw new Exception(\"MFException:\" + getErrorMessage(exception))",classRecord);
    	mehtod.endControlFlow();
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private MethodSpec insertServiceRecordMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String nameClass,boolean checkContainstoaddMethods)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);	
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		mehtod.addParameter(toClassRecord, "record");
		mehtod.returns(int.class);
		mehtod.addException(exception);
		mehtod.beginControlFlow("try");
			mehtod.addStatement("logger.trace(\"insert$N:\" + record)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"insert$N\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("int result = dao.insert$N(record)",classRecord);
			mehtod.addStatement("logger.trace(\"insert$N:Result:\" + result)",classRecord);
			if(checkContainstoaddMethods)
			{
			     mehtod.addStatement("createMakerCheckerAuditEntry(\"$N\", record.getId() + \"\", \"Create\", record.getCreatedby(), \"Created\")",nameClass);
			}
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
			mehtod.addStatement("return result");
			mehtod.endControlFlow();
		mehtod.beginControlFlow("catch(Exception exception)");
	    mehtod.addStatement("logger.error(\"insert$N\" + getStackTrace(exception))",classRecord);
	    mehtod.addStatement("throw exception");
	    mehtod.endControlFlow();
		
		
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private MethodSpec updateServiceRecordMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String nameClass,boolean checkContainstoaddMethods)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);	
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		mehtod.addParameter(toClassRecord, "record");
		mehtod.returns(boolean.class);
		mehtod.addException(exception);
		mehtod.beginControlFlow("try");
			mehtod.addStatement("logger.trace(\"update$N:\" + record)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"update$N\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("boolean result = dao.update$N(record)",classRecord);
			mehtod.addStatement("logger.trace(\"update$N:Result:\" + result)",classRecord);
			if(checkContainstoaddMethods)
			{
				mehtod.addStatement("createMakerCheckerAuditEntry(\"$N\", record.getId() + \"\", \"Update\", record.getModifiedby(), \"Update\")",nameClass);
			}
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
			mehtod.addStatement("return result");
			mehtod.endControlFlow();
		mehtod.beginControlFlow("catch(Exception exception)");
	    mehtod.addStatement("logger.error(\"update$N\" + getStackTrace(exception))",classRecord);
	    mehtod.addStatement("throw exception");
	    mehtod.endControlFlow();
		
		
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	private MethodSpec updateServiceRecordNoNullMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String nameClass,boolean checkContainstoaddMethods)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);	
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		mehtod.addParameter(toClassRecord, "inputRecord");
		mehtod.returns(boolean.class);
		mehtod.addException(exception);
		mehtod.beginControlFlow("try");
			mehtod.addStatement("logger.trace(\"update$N:\" + inputRecord)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"update$NNoNull\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("$T dbRecord = dao.load$N(inputRecord.getId())",toClassRecord,classRecord);
			mehtod.beginControlFlow("if (dbRecord == null)"); ;
				mehtod.addStatement("throw new Exception(\"Record not found\")");		       
			mehtod.endControlFlow();
			mehtod.addStatement("dbRecord.loadNonNullContent(inputRecord)");
			//mehtod.addStatement("dbRecord.setActionSource(inputRecord.getActionSource())");
			mehtod.addStatement("boolean result = dao.update$N(inputRecord)",classRecord);
			if(checkContainstoaddMethods)
			{
				mehtod.addStatement("createMakerCheckerAuditEntry(\"$N\", inputRecord.getId() + \"\", \"Update\", inputRecord.getModifiedby(), \"UpdateNoNull\")",nameClass);
			}
			mehtod.addStatement("logger.trace(\"update$NNoNull:Result:\" + result)",classRecord);
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
			mehtod.addStatement("return result");
			mehtod.endControlFlow();
		mehtod.beginControlFlow("catch(Exception exception)");
	    mehtod.addStatement("logger.error(\"update$NNoNull\" + getStackTrace(exception))",classRecord);
	    mehtod.addStatement("throw exception");
	    mehtod.endControlFlow();
		
		
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private MethodSpec deleteServiceRecordNoNullMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String nameClass,boolean checkContainstoaddMethods)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);	
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		mehtod.addParameter(toClassRecord, "record");
		mehtod.returns(boolean.class);
		mehtod.addException(exception);
		mehtod.beginControlFlow("try");
			mehtod.addStatement("logger.trace(\"delete$N:\" + record)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"delete$N\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("boolean result = dao.delete$N(record)",classRecord);
			mehtod.addStatement("logger.trace(\"delete$N:Result:\" + result)",classRecord);
			if(checkContainstoaddMethods)
			{
				mehtod.addStatement("createMakerCheckerAuditEntry(\"$N\", record.getId(), \"Delete\", null, \"Deleted\")",nameClass);
			}
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
			mehtod.addStatement("return result");
			mehtod.endControlFlow();
		mehtod.beginControlFlow("catch(Exception exception)");
	    mehtod.addStatement("logger.error(\"delete$N\" + getStackTrace(exception))",classRecord);
	    mehtod.addStatement("throw exception");
	    mehtod.endControlFlow();
		
		
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	private MethodSpec approveServiceRecordNoNullMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String nameClass)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);	
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		TypeName hashMap= ClassName.get(javaUtilsPackagePath, hashMapClass);
		TypeName dateUtils = ClassName.get(utilsPackagePath, dateUtilsClass);
		TypeName stringUtils = ClassName.get(utilsPackagePath, stringUtilsClass);
		
		mehtod.addParameter(toClassRecord, "inputRecord");
		mehtod.addParameter(String.class, "updateId");
		mehtod.addParameter(String.class, "comment");
		mehtod.returns(boolean.class);
		mehtod.addException(exception);
		mehtod.beginControlFlow("try");
		
			mehtod.addStatement("logger.trace(\"approve$N:\" + inputRecord)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"approve$N\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("$T updateRecord = dao.load$N(inputRecord.getId())",toClassRecord,classRecord);
			mehtod.beginControlFlow("if (updateRecord == null)");
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-RNFA104:Record not found\")");
			mehtod.endControlFlow();
			mehtod.beginControlFlow("if (!isValidStatusForApproval(updateRecord.getCurrappstatus()))");
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-IS101:Cannot approve - Invalid Status for Approval\")");
			mehtod.endControlFlow();
			mehtod.beginControlFlow("if ($T.isSame(updateRecord.getMadeby(), updateId))",stringUtils);
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-MCS102:Cannot Approve. Maker Checker cannot be same\")");
			mehtod.endControlFlow();
		      
			mehtod.addStatement("updateRecord.setRstatus(\"1\")");
			mehtod.addStatement("updateRecord.setCheckerlastcmt(comment)");
			mehtod.addStatement("updateRecord.setCurrappstatus(\"1\")");
			mehtod.addStatement("updateRecord.setModifiedat($T.getCurrentDateTime())",dateUtils);
			mehtod.addStatement("updateRecord.setModifiedby(updateId)"); 
			mehtod.addStatement("updateRecord.setCheckedat($T.getCurrentDateTime())",dateUtils); 
			mehtod.addStatement("updateRecord.setCheckedby(updateId)"); 
			mehtod.addStatement("boolean result = dao.update$N(updateRecord)",classRecord);
			mehtod.addStatement("logger.trace(\"approve$N:Result:\" + result)",classRecord);
			
			mehtod.addStatement("createMakerCheckerAuditEntry(\"$N\", updateRecord.getId(), \"Approve\", updateId, comment)",nameClass);
			mehtod.addStatement("$T approveEventMap = callActionEvent(\"Event_OnApprovalOf_$N\", updateRecord.getId())",hashMap,classRecord);
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
			mehtod.addStatement("return result");
			
		mehtod.endControlFlow();
		mehtod.beginControlFlow("catch(Exception exception)");
	    mehtod.addStatement("logger.error(\"approve$N\" + getStackTrace(exception))",classRecord);
	    mehtod.addStatement("throw exception");
	    mehtod.endControlFlow();

	    mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private MethodSpec submitServiceRecordNoNullMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String nameClass)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);	
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		TypeName hashMap= ClassName.get(javaUtilsPackagePath, hashMapClass);
		TypeName dateUtils = ClassName.get(utilsPackagePath, dateUtilsClass);
		TypeName stringUtils = ClassName.get(utilsPackagePath, stringUtilsClass);
		
		mehtod.addParameter(toClassRecord, "inputRecord");
		mehtod.addParameter(String.class, "updateId");
		mehtod.addParameter(String.class, "comment");
		mehtod.returns(boolean.class);
		mehtod.addException(exception);
		mehtod.beginControlFlow("try");
		
		mehtod.addStatement("logger.trace(\"submit$NNoNull:\" + inputRecord)",classRecord);
		mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"submit$NNoNull\", null)",classRecord);
		mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
		mehtod.addStatement("$T updateRecord = dao.load$N(inputRecord.getId())",toClassRecord,classRecord);
		mehtod.beginControlFlow("if (updateRecord == null)");
			mehtod.addStatement("throw new Exception(\"MF-ERR-CA-RNFA104:Record not found\")");
		mehtod.endControlFlow();
		mehtod.beginControlFlow("if (!isValidStatusForSubmission(updateRecord.getCurrappstatus()))");
			mehtod.addStatement("throw new Exception(\"MF-ERR-CS-IS101:Cannot submit - Invalid Status for Submission\")");
		mehtod.endControlFlow();
		
	      
		mehtod.addStatement("updateRecord.setRstatus(\"1\")");
		mehtod.addStatement("updateRecord.setCheckerlastcmt(comment)");
		mehtod.addStatement("updateRecord.setCurrappstatus(\"4\")");
		mehtod.addStatement("updateRecord.setModifiedat($T.getCurrentDateTime())",dateUtils);
		mehtod.addStatement("updateRecord.setModifiedby(updateId)"); 
		mehtod.addStatement("updateRecord.setCheckedat($T.getCurrentDateTime())",dateUtils); 
		mehtod.addStatement("updateRecord.setCheckedby(updateId)"); 
		mehtod.addStatement("boolean result = dao.update$N(updateRecord)",classRecord);
		mehtod.addStatement("logger.trace(\"approve$N:Result:\" + result)",classRecord);
		
		mehtod.addStatement("createMakerCheckerAuditEntry(\"$N\", updateRecord.getId(), \"Submit\", updateId, comment)",nameClass);
		mehtod.addStatement("$T submitEventMap = callActionEvent(\"Event_OnApprovalOf_$N\", updateRecord.getId())",hashMap,classRecord);
		mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
		mehtod.addStatement("return result");
		
		mehtod.endControlFlow();
		mehtod.beginControlFlow("catch(Exception exception)");
	    mehtod.addStatement("logger.error(\"submit$N\" + getStackTrace(exception))",classRecord);
	    mehtod.addStatement("throw exception");
	    mehtod.endControlFlow();
	
	    mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
		
	}
	
	
	private MethodSpec denyServiceRecordNoNullMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String nameClass)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);	
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		TypeName hashMap= ClassName.get(javaUtilsPackagePath, hashMapClass);
		TypeName dateUtils = ClassName.get(utilsPackagePath, dateUtilsClass);
		TypeName stringUtils = ClassName.get(utilsPackagePath, stringUtilsClass);
		
		mehtod.addParameter(toClassRecord, "inputRecord");
		mehtod.addParameter(String.class, "updateId");
		mehtod.addParameter(String.class, "comment");
		mehtod.returns(boolean.class);
		mehtod.addException(exception);
		mehtod.beginControlFlow("try");
		
			mehtod.addStatement("logger.trace(\"deny$N:\" + inputRecord)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"deny$N\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("$T updateRecord = dao.load$N(inputRecord.getId())",toClassRecord,classRecord);
			mehtod.beginControlFlow("if (updateRecord == null)");
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-RNFA104:Record not found\")");
			mehtod.endControlFlow();
			mehtod.beginControlFlow("if (!isValidStatusForDeny(updateRecord.getCurrappstatus()))");
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-IS101:Cannot deny - Invalid Status for Deny\")");
			mehtod.endControlFlow();
			mehtod.beginControlFlow("if ($T.isSame(updateRecord.getMadeby(), updateId))",stringUtils);
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-MCS102:Cannot Deny. Maker Checker cannot be same\")");
			mehtod.endControlFlow();
		      
			mehtod.addStatement("updateRecord.setRstatus(\"1\")");
			mehtod.addStatement("updateRecord.setCheckerlastcmt(comment)");
			mehtod.addStatement("updateRecord.setCurrappstatus(\"5\")");
			mehtod.addStatement("updateRecord.setModifiedat($T.getCurrentDateTime())",dateUtils);
			mehtod.addStatement("updateRecord.setModifiedby(updateId)"); 
			mehtod.addStatement("updateRecord.setCheckedat($T.getCurrentDateTime())",dateUtils); 
			mehtod.addStatement("updateRecord.setCheckedby(updateId)"); 
			mehtod.addStatement("boolean result = dao.update$N(updateRecord)",classRecord);
			mehtod.addStatement("logger.trace(\"approve$N:Result:\" + result)",classRecord);
			
			mehtod.addStatement("createMakerCheckerAuditEntry(\"$N\", updateRecord.getId(), \"Deny\", updateId, comment)",nameClass);
			
			mehtod.addStatement("$T denyEventMap = callActionEvent(\"Event_OnDenyOf_$N\", updateRecord.getId())",hashMap,classRecord);
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
			mehtod.addStatement("return result");
			
		mehtod.endControlFlow();
		mehtod.beginControlFlow("catch(Exception exception)");
	    mehtod.addStatement("logger.error(\"deny$N\" + getStackTrace(exception))",classRecord);
	    mehtod.addStatement("throw exception");
	    mehtod.endControlFlow();

	    mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
		
	}
	
	
	private MethodSpec denyPermanentServiceRecordNoNullMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String nameClass)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);	
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		TypeName hashMap= ClassName.get(javaUtilsPackagePath, hashMapClass);
		TypeName dateUtils = ClassName.get(utilsPackagePath, dateUtilsClass);
		TypeName stringUtils = ClassName.get(utilsPackagePath, stringUtilsClass);
		
		mehtod.addParameter(toClassRecord, "inputRecord");
		mehtod.addParameter(String.class, "updateId");
		mehtod.addParameter(String.class, "comment");
		mehtod.returns(boolean.class);
		mehtod.addException(exception);
		mehtod.beginControlFlow("try");
		
			mehtod.addStatement("logger.trace(\"denyP$N:\" + inputRecord)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"denyP$N\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("$T updateRecord = dao.load$N(inputRecord.getId())",toClassRecord,classRecord);
			mehtod.beginControlFlow("if (updateRecord == null)");
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-RNFA104:Record not found\")");
			mehtod.endControlFlow();
			mehtod.beginControlFlow("if (!isValidStatusForDeny(updateRecord.getCurrappstatus()))");
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-IS101:Cannot deny - Invalid Status for Deny\")");
			mehtod.endControlFlow();
			mehtod.beginControlFlow("if ($T.isSame(updateRecord.getMadeby(), updateId))",stringUtils);
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-MCS102:Cannot Deny. Maker Checker cannot be same\")");
			mehtod.endControlFlow();
		      
			mehtod.addStatement("updateRecord.setRstatus(\"1\")");
			mehtod.addStatement("updateRecord.setCheckerlastcmt(comment)");
			mehtod.addStatement("updateRecord.setCurrappstatus(\"58\")");
			mehtod.addStatement("updateRecord.setModifiedat($T.getCurrentDateTime())",dateUtils);
			mehtod.addStatement("updateRecord.setModifiedby(updateId)"); 
			mehtod.addStatement("updateRecord.setCheckedat($T.getCurrentDateTime())",dateUtils); 
			mehtod.addStatement("updateRecord.setCheckedby(updateId)"); 
			mehtod.addStatement("boolean result = dao.update$N(updateRecord)",classRecord);
			mehtod.addStatement("logger.trace(\"approve$N:Result:\" + result)",classRecord);
			mehtod.addStatement("createMakerCheckerAuditEntry(\"$N\", updateRecord.getId(), \"DenyP\", updateId, comment)",nameClass);
			mehtod.addStatement("$T denyEventMap = callActionEvent(\"Event_OnDenyPOf_$N\", updateRecord.getId())",hashMap,classRecord);
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
			mehtod.addStatement("return result");
			
		mehtod.endControlFlow();
		mehtod.beginControlFlow("catch(Exception exception)");
	    mehtod.addStatement("logger.error(\"denyP$N\" + getStackTrace(exception))",classRecord);
	    mehtod.addStatement("throw exception");
	    mehtod.endControlFlow();

	    mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
		
	}
	
	private  MethodSpec remindServiceRecordNoNullMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String nameClass)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);	
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		TypeName hashMap= ClassName.get(javaUtilsPackagePath, hashMapClass);
		TypeName dateUtils = ClassName.get(utilsPackagePath, dateUtilsClass);
		TypeName stringUtils = ClassName.get(utilsPackagePath, stringUtilsClass);
		
		mehtod.addParameter(toClassRecord, "inputRecord");
		mehtod.addParameter(String.class, "updateId");
		mehtod.addParameter(String.class, "comment");
		mehtod.returns(boolean.class);
		mehtod.addException(exception);
		mehtod.beginControlFlow("try");
		
			mehtod.addStatement("logger.trace(\"remindApproval$N:\" + inputRecord)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"remindApproval$N\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("$T updateRecord = dao.load$N(inputRecord.getId())",toClassRecord,classRecord);
			mehtod.beginControlFlow("if (updateRecord == null)");
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-RNFA104:Record not found\")");
			mehtod.endControlFlow();
			mehtod.beginControlFlow("if (!isValidStatusForApproval(updateRecord.getCurrappstatus()))");
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-IS101:Cannot Remind - Invalid Status for Reminder\")");
			mehtod.endControlFlow();
			/*mehtod.beginControlFlow("if ($T.isSame(updateRecord.getMadeby(), updateId))",stringUtils);
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-MCS102:Cannot Deny. Maker Checker cannot be same\")");
			mehtod.endControlFlow();
		      */
			/*mehtod.addStatement("updateRecord.setRstatus(\"1\")");
			mehtod.addStatement("updateRecord.setCheckerlastcmt(comment)");
			mehtod.addStatement("updateRecord.setCurrappstatus(\"58\")");
			mehtod.addStatement("updateRecord.setModifiedat($T.getCurrentDateTime())",dateUtils);
			mehtod.addStatement("updateRecord.setModifiedby(updateId)"); 
			mehtod.addStatement("updateRecord.setCheckedat($T.getCurrentDateTime())",dateUtils); 
			mehtod.addStatement("updateRecord.setCheckedby(updateId)"); 
			mehtod.addStatement("boolean result = dao.update$N(updateRecord)",classRecord);*/
			/*mehtod.addStatement("logger.trace(\"remind$N:Result:\" + result)",classRecord);*/
			mehtod.addStatement("createMakerCheckerAuditEntry(\"$N\", updateRecord.getId(), \"Approval Reminder\", updateId, comment)",nameClass);
			/*mehtod.addStatement("$T approveEventMap = callActionEvent(\"Event_OnDenyPOf_$N\", updateRecord.getId())",hashMap,classRecord);*/
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
			mehtod.addStatement("return true");
			
		mehtod.endControlFlow();
		mehtod.beginControlFlow("catch(Exception exception)");
	    mehtod.addStatement("logger.error(\"remindApproval$N\" + getStackTrace(exception))",classRecord);
	    mehtod.addStatement("throw exception");
	    mehtod.endControlFlow();

	    mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
		
	}
	
	
	private MethodSpec resetServiceRecordNoNullMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String classNameDAO,String nameClass)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName  daoClassRecord = ClassName.get(daoPackagetoGeneratejavafiles, classNameDAO);	
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		TypeName hashMap= ClassName.get(javaUtilsPackagePath, hashMapClass);
		TypeName dateUtils = ClassName.get(utilsPackagePath, dateUtilsClass);
		TypeName stringUtils = ClassName.get(utilsPackagePath, stringUtilsClass);
		
		mehtod.addParameter(toClassRecord, "inputRecord");
		mehtod.addParameter(String.class, "updateId");
		mehtod.addParameter(String.class, "comment");
		mehtod.returns(boolean.class);
		mehtod.addException(exception);
		mehtod.beginControlFlow("try");
		
			mehtod.addStatement("logger.trace(\"resetApproval$N:\" + inputRecord)",classRecord);
			mehtod.addStatement("String beginMesssage = logger.generateFunctionBeginTimerMessage(\"resetApproval$N\", null)",classRecord);
			mehtod.addStatement("$T dao = new $T()",daoClassRecord,daoClassRecord);
			mehtod.addStatement("$T updateRecord = dao.load$N(inputRecord.getId())",toClassRecord,classRecord);
			mehtod.beginControlFlow("if (updateRecord == null)");
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-RNFA104:Record not found\")");
			mehtod.endControlFlow();
			mehtod.beginControlFlow("if (!isValidStatusForDeny(updateRecord.getCurrappstatus()))");
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-IS101:Cannot submit - Invalid Status for Reset\")");
			mehtod.endControlFlow();
			/*mehtod.beginControlFlow("if ($T.isSame(updateRecord.getMadeby(), updateId))",stringUtils);
				mehtod.addStatement("throw new Exception(\"MF-ERR-CA-MCS102:Cannot Deny. Maker Checker cannot be same\")");
			mehtod.endControlFlow();*/
		      
			mehtod.addStatement("updateRecord.setRstatus(\"0\")");
			mehtod.addStatement("updateRecord.setCheckerlastcmt(comment)");
			mehtod.addStatement("updateRecord.setCurrappstatus(\"0\")");
			mehtod.addStatement("updateRecord.setModifiedat($T.getCurrentDateTime())",dateUtils);
			mehtod.addStatement("updateRecord.setModifiedby(updateId)"); 
			mehtod.addStatement("updateRecord.setCheckedat($T.getCurrentDateTime())",dateUtils); 
			mehtod.addStatement("updateRecord.setCheckedby(updateId)"); 
			mehtod.addStatement("boolean result = dao.update$N(updateRecord)",classRecord);
			mehtod.addStatement("logger.trace(\"approve$N:Result:\" + result)",classRecord);
			mehtod.addStatement("createMakerCheckerAuditEntry(\"$N\", updateRecord.getId(), \"Reset Approval\", updateId, comment)",nameClass);
			mehtod.addStatement("logger.generateFunctionEndTimerMessage(beginMesssage)");
			mehtod.addStatement("return result");
			
		mehtod.endControlFlow();
		mehtod.beginControlFlow("catch(Exception exception)");
	    mehtod.addStatement("logger.error(\"resetApproval$N\" + getStackTrace(exception))",classRecord);
	    mehtod.addStatement("throw exception");
	    mehtod.endControlFlow();

	    mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
		
	}

}
