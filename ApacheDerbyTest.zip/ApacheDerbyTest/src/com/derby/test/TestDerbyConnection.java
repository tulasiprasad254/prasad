package com.derby.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.logging.ConsoleHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;





public class TestDerbyConnection {
	private static String dbURL = "jdbc:mysql://mb.cehnnnhwe8sx.eu-north-1.rds.amazonaws.com:3306/";//"jdbc:derby://localhost:1527/kbmb;user=root;password=root";
    private static String tableName = "FIRSTTABLE";
    private static String password = "Master123";
    private static String userid = "root";
    // jdbc Connection
    private static Connection conn = null;
    private static Statement stmt = null;

    public static void main(String[] args) throws SQLException
    {
    	 Logger mysqlLogger = Logger.getLogger("com.mysql.cj");
         ConsoleHandler consoleHandler  = new ConsoleHandler();
         consoleHandler.setFormatter(new SimpleFormatter());
         mysqlLogger.addHandler(consoleHandler);
         mysqlLogger.setLevel(Level.ALL);
        createConnection();
       
       // insertRestaurants(80, "LaValse");
      //  selectRestaurants();
        shutdown();
    }
    
    private static void createConnection() throws SQLException
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            System.out.println("Start");
            Properties props = new Properties();
            props.setProperty("user", userid);
            props.setProperty("password", password);
            props.setProperty("enableLogging", "true");
		    //Connection con = DriverManager.getConnection(dbURL,userid,password);
		    Connection con = DriverManager.getConnection(dbURL, props);
            //System.out.println(""+con.getSchema());
		   // ResultSet rs = con.getMetaData().getCatalogs();

		  //  while (rs.next()) {
		   //     System.out.println("TABLE_CAT = " + rs.getString("TABLE_CAT") );
		   // }
            //Get a connection
           // conn = DriverManager.getConnection(dbURL); 
        }
        catch (Exception except)
        {
            except.printStackTrace();
        }
        System.out.println("Connection sucessfull");
    }
    
    private static void insertRestaurants(int id, String restName)
    {
        try
        {
            stmt = conn.createStatement();
            stmt.execute("insert into " + tableName + " values (" +
                    id + ",'" + restName + "')");
            stmt.close();
        }
        catch (SQLException sqlExcept)
        {
            sqlExcept.printStackTrace();
        }
    }
    
    private static void selectRestaurants()
    {
        try
        {
            stmt = conn.createStatement();
            ResultSet results = stmt.executeQuery("select * from " + tableName);
            ResultSetMetaData rsmd = results.getMetaData();
            int numberCols = rsmd.getColumnCount();
            for (int i=1; i<=numberCols; i++)
            {
                //print Column Names
                System.out.print(rsmd.getColumnLabel(i)+"\t\t");  
            }

            System.out.println("\n-------------------------------------------------");

            while(results.next())
            {
                int id = results.getInt(1);
                String restName = results.getString(2);
                //String cityName = results.getString(3);
                System.out.println(id + "\t\t" + restName + "\t\t");
            }
            results.close();
            stmt.close();
        }
        catch (SQLException sqlExcept)
        {
            sqlExcept.printStackTrace();
        }
    }
    
    private static void shutdown()
    {
        try
        {
            if (stmt != null)
            {
                stmt.close();
            }
            if (conn != null)
            {
               // DriverManager.getConnection(dbURL + ";shutdown=true");
                conn.close();
            }           
        }
        catch (SQLException sqlExcept)
        {
            
        }

    }

}
