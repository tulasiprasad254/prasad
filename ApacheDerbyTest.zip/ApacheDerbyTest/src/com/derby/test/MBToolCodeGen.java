package com.derby.test;

import java.sql.SQLException;

public class MBToolCodeGen {
	
	public static void main(String[] args) throws SQLException, Exception
	{
		MBToolProcessorPojo pojoGenerator = new MBToolProcessorPojo();
		System.out.println(":::::::Calling POJO Generator:::::::");
		pojoGenerator.pojoGenerator();
		System.out.println(":::::::End POJO Generator:::::::");
		MBToolProcessorDAO daoGenerator = new MBToolProcessorDAO();
		System.out.println(":::::::Calling DAO Generator:::::::");
		daoGenerator.daoGenerator();
		System.out.println(":::::::End DAO Generator:::::::");
		MBToolProcessorService serviceGenerator = new MBToolProcessorService();
		System.out.println(":::::::Calling Service Generator:::::::");
		serviceGenerator.serviceGenerator();
		System.out.println(":::::::End Service Generator:::::::");
		MBToolProcessorController controllerGenerator = new MBToolProcessorController();
		System.out.println(":::::::Calling Controller Generator:::::::");
		controllerGenerator.controllerGenerator();
		System.out.println(":::::::End Controller Generator:::::::");
		
	}

}
