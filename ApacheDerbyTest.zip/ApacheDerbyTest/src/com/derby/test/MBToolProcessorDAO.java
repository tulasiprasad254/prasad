package com.derby.test;

import java.io.File;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import javax.lang.model.element.Modifier;

import com.derby.utils.StringUtils;
import com.squareup.javapoet.ArrayTypeName;
import com.squareup.javapoet.ClassName;
import com.squareup.javapoet.FieldSpec;
import com.squareup.javapoet.JavaFile;
import com.squareup.javapoet.MethodSpec;
import com.squareup.javapoet.TypeName;
import com.squareup.javapoet.TypeSpec;
import com.squareup.javapoet.MethodSpec.Builder;

public class MBToolProcessorDAO {
	
	/*private static final String utilsPackagePath = "com.derby.utils";
	static TypeName globalstringUtils = ClassName.get(utilsPackagePath, "StringUtils");
	private final String recordClass = "MBService";
	private final String packagePath = "com.derby.common";	
	
	private final String logUtilsClass = "LogUtils";
	private final String dateUtilsClass = "LogUtils";
	private final String stringUtilsClass = "StringUtils";
	private final String jsonPackagePath = "org.json.simple";
	private final String jSONObjectClass = "JSONObject";
	private final String javaUtilsPackagePath = "java.util";
	private final String hashMapClass = "HashMap";
	private final String arrayListClass = "ArrayList";
	private final String exceptionClass = "Exception";
	private final String exceptionPackage = "java.lang";
	private final String pojoPackagetoGeneratejavafiles="com.mb.to";
	private final String servicePackagetoGeneratejavafiles="com.mb.service";
	private final String daoPackagetoGeneratejavafiles="com.mb.dao";
	private final String preparedStatementClass = "PreparedStatement";
	private final String preparedStatementPackage = "java.sql";
	private final String resultSetClass = "ResultSet";
	private final String jSONArrayClass = "JSONArray";
	private final String daoClass = "MBDAO";
	private final String statementClass = "Statement";*/
	private static final String utilsPackagePath = "com.key.utils";
	static TypeName globalstringUtils = ClassName.get(utilsPackagePath, "StringUtils");
	private final String recordClass = "KBService";
	private final String packagePath = "com.key.mb.common";	
	
	private final String logUtilsClass = "LogUtils";
	private final String dateUtilsClass = "LogUtils";
	private final String stringUtilsClass = "StringUtils";
	private final String jsonPackagePath = "org.json.simple";
	private final String jSONObjectClass = "JSONObject";
	private final String javaUtilsPackagePath = "java.util";
	private final String hashMapClass = "HashMap";
	private final String arrayListClass = "ArrayList";
	private final String exceptionClass = "Exception";
	private final String exceptionPackage = "java.lang";
	private final String pojoPackagetoGeneratejavafiles="com.key.mb.to";
	private final String servicePackagetoGeneratejavafiles="com.key.mb.service";
	private final String daoPackagetoGeneratejavafiles="com.key.mb.dao";
	private final String preparedStatementClass = "PreparedStatement";
	private final String preparedStatementPackage = "java.sql";
	private final String resultSetClass = "ResultSet";
	private final String jSONArrayClass = "JSONArray";
	private final String daoClass = "KBDAO";
	private final String statementClass = "Statement";
	private final String calssNameStartsKey="KB";
	
	
	public void daoGenerator() throws SQLException, Exception
	{
		HashMap<String,String> columnList = new HashMap<String, String>();
		//ClassName superClassRecord = ClassName.get("com.mtreetech.sawc.common", "MFRecord");	
		ClassName superClassDAO = ClassName.get(packagePath, daoClass);
		ArrayList<String> tablesData = Metadata.getTablesMetadata();		
		int countTables = tablesData.size();
		String className = null,classNameRecord= null,temp = null,originaltableName= null;

		for (String string : tablesData) {
			
			columnList = Metadata.getColumnsMetadata(string) ;
			originaltableName = string.toLowerCase();
			className = StringUtils.replaceString(string, "_", "", true);
			temp = className;
			if("tmpesapendingtransactions".equalsIgnoreCase(className) || "statuscode".equalsIgnoreCase(className) || "sequencedata".equalsIgnoreCase(className)) continue;
			className = calssNameStartsKey + StringUtils.convertFirstCharacterToUpperCase(className) + "DAO";
			classNameRecord = calssNameStartsKey + StringUtils.convertFirstCharacterToUpperCase(temp) + "Record";
			generateDAOLayer(daoPackagetoGeneratejavafiles,className,columnList,superClassDAO,classNameRecord,originaltableName);
			
		}
		System.out.println("***********************DAO Class Completed*********************");
		
	}
	
	private void generateDAOLayer(String packageName,String className,HashMap tableColumns,ClassName extendedClass,String classNameRecord,String originaltableName) throws Exception
	{

		File sourcePath = new File("src");
		TypeName LogUtils = ClassName.get(utilsPackagePath, logUtilsClass);
		TypeName stringUtils = ClassName.get(utilsPackagePath, stringUtilsClass);
		TypeName  JSONObject= ClassName.get(jsonPackagePath, jSONObjectClass);
		TypeName  hashMap= ClassName.get(javaUtilsPackagePath, hashMapClass);
		TypeName  arrayList= ClassName.get(javaUtilsPackagePath, arrayListClass);
		
		TypeName classNamelog = ClassName.get(packageName, StringUtils.convertFirstCharacterToUpperCase(className));
		TypeSpec.Builder classObject = TypeSpec.classBuilder(StringUtils.convertFirstCharacterToUpperCase(className))
			    .addModifiers(Modifier.PUBLIC)
			    .superclass(extendedClass);
		 FieldSpec fieldSpec = FieldSpec.builder(LogUtils, "logger")
		            .addModifiers(Modifier.PUBLIC, Modifier.STATIC)
		            .initializer("new $T($T.class.getName())",LogUtils,classNamelog)
		            .build();
		 
		classObject.addField(fieldSpec);
		
		boolean idKey = false;
		Iterator keyIterator2 = tableColumns.keySet().iterator();
		
		while(keyIterator2.hasNext())
		{
			String key = keyIterator2.next().toString();
			if(key.equalsIgnoreCase("id")) 
			{
				idKey = true;
				break;
			}
			
		}
		
		classObject.addMethod(loadArrayRecordsMethodspec("load"+classNameRecord+"s",classNamelog,tableColumns,classNameRecord));
		classObject.addMethod(loadArrayRecordsFirstMethodspec("load"+classNameRecord+"s",classNamelog,tableColumns,classNameRecord));
		classObject.addMethod(loadFirstRecordMethodspec("loadFirst"+classNameRecord,classNamelog,tableColumns,classNameRecord));
		
		//$PK$
		if(idKey)
		{
			classObject.addMethod(loadRecordsMethodspec("load"+classNameRecord,classNamelog,tableColumns,classNameRecord,originaltableName));
		}
		else
		{
			classObject.addMethod(loadRecordsPKMethodspec("load"+classNameRecord,classNamelog,tableColumns,classNameRecord,originaltableName));
		}
		
		classObject.addMethod(loadRecordFirstMethodspec("load"+classNameRecord,classNamelog,tableColumns,classNameRecord));
		if(idKey)
		{
			classObject.addMethod(insertRecordsMethodspec("insert"+classNameRecord,classNamelog,tableColumns,classNameRecord,originaltableName));
			classObject.addMethod(insertRecordFirstMethodspec("insert"+classNameRecord,classNamelog,tableColumns,classNameRecord));
			classObject.addMethod(updateRecordsMethodspec("update"+classNameRecord,classNamelog,tableColumns,classNameRecord,originaltableName,stringUtils));
			classObject.addMethod(updateRecordFirstMethodspec("update"+classNameRecord,classNamelog,tableColumns,classNameRecord));
			classObject.addMethod(deleteRecordsMethodspec("delete"+classNameRecord,classNamelog,tableColumns,classNameRecord,originaltableName,stringUtils));
			classObject.addMethod(deleteRecordFirstMethodspec("delete"+classNameRecord,classNamelog,tableColumns,classNameRecord));
		}
		classObject.addMethod(searchRecordsMethodspec("search"+classNameRecord+"s",classNamelog,tableColumns,classNameRecord,originaltableName,stringUtils));
		classObject.addMethod(searchRecordsExactUpperMethodspec("search"+classNameRecord+"s",classNamelog,tableColumns,classNameRecord,originaltableName,stringUtils));
		classObject.addMethod(loadRecordsCountMethodspec("load"+classNameRecord,classNamelog,tableColumns,classNameRecord,originaltableName,stringUtils));
		
		
		classObject.addMethod(loadRecordsCountExactUpperMethodspec("load"+classNameRecord,classNamelog,tableColumns,classNameRecord,originaltableName,stringUtils));
		/*classObject.addMethod(loadContentMethodspec("loadContent",classNamelog,tableColumns));
		classObject.addMethod(loadNonNullContentMethodspec("loadNonNullContent",classNamelog,tableColumns));
		classObject.addMethod(getJSONObjectMethodspec("getJSONObject",JSONObject,tableColumns));
		classObject.addMethod(loadJSONObjectMethodspec("loadJSONObject",JSONObject,tableColumns));
		classObject.addMethod(getJSONObjectUIMethodspec("getJSONObjectUI",JSONObject,tableColumns));
		classObject.addMethod(getTableMapMethodspec("getTableMap",hashMap,tableColumns,arrayList));
		classObject.addMethod(toStringMethodspec("toString",tableColumns));	*/
		JavaFile javaFile = JavaFile.builder(packageName, classObject.build()).addFileComment("Author Tulasi Vara Prasad")
				.build();
		javaFile.writeTo(sourcePath);
		
	
	}
	
	/*
	 * DAO Layer
	 */
	
	private MethodSpec loadArrayRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);		
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		TypeName arrayList = ClassName.get(javaUtilsPackagePath, arrayListClass);
		TypeName preparedStatement = ClassName.get(preparedStatementPackage, preparedStatementClass);
		TypeName resultSet = ClassName.get(preparedStatementPackage, resultSetClass);
		

		
		mehtod.addParameter(String.class, "query");
		mehtod.addParameter(Connection.class, "con");
		mehtod.addParameter(boolean.class, "closeConnection");
		mehtod.returns(ArrayTypeName.of(toClassRecord));
		mehtod.addException(exception);
		mehtod.addStatement("$T ps = null",preparedStatement);
		mehtod.addStatement("$T rs = null",resultSet);
		
		mehtod.beginControlFlow("try");
		mehtod.beginControlFlow("if(con == null)");
		mehtod.addStatement("con = getCPDatabaseConnection()");
		mehtod.endControlFlow();
		mehtod.addStatement("query = query + MAX_RECORD_LIMIT_APPENDER");
		mehtod.addStatement("query = updateQuery(query)");
		mehtod.addStatement("logger.trace(\"load$Ns\t\" + closeConnection + \"\t\" + query)",classRecord);
		mehtod.addStatement("ps = con.prepareStatement(query)");
		mehtod.addStatement("rs = ps.executeQuery()");
		mehtod.addStatement("$T recordSet = new $T()",arrayList,arrayList);
		mehtod.beginControlFlow("while(rs.next())");
		mehtod.addStatement("$T record = new $T()",toClassRecord,toClassRecord);
		Iterator keyIterator = columns.keySet().iterator();
		String firstCaps = null;
		String allCaps = null;
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			key = key.replaceAll("\\s","");
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();			
			mehtod.addStatement("record.set$N(rs.getString($S))",firstCaps,allCaps);
			
		}
		mehtod.addStatement("recordSet.add(record)");
		mehtod.endControlFlow();
		mehtod.addStatement("logger.trace(\"load$Ns:Records Fetched:\" + recordSet.size())",classRecord);
		mehtod.addStatement("$N[] temp$Ns = new $N[recordSet.size()]",classRecord,classRecord,classRecord);
		mehtod.beginControlFlow("for (int index = 0; index < recordSet.size(); index++)");
		mehtod.addStatement("temp$Ns[index] = ($N)(recordSet.get(index))",classRecord,classRecord);
		mehtod.endControlFlow();
		mehtod.addStatement("ps.close()");
		mehtod.addStatement("releaseDatabaseConnection(con, closeConnection)");
		mehtod.addStatement("return temp$Ns",classRecord);	
		mehtod.endControlFlow();
		mehtod.beginControlFlow("finally");
		mehtod.addStatement("releaseDatabaseConnection(rs, ps, con, closeConnection)");	
		mehtod.endControlFlow();
	
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	} 
	private MethodSpec loadArrayRecordsFirstMethodspec(String methodName,TypeName className,HashMap columns,String classRecord)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		
		
		mehtod.addParameter(String.class, "query");
		mehtod.returns(ArrayTypeName.of(toClassRecord));
		mehtod.addException(exception);
		mehtod.addStatement("return load$Ns(query, null, true)",classRecord);
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private MethodSpec loadFirstRecordMethodspec(String methodName,TypeName className,HashMap columns,String classRecord)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);	
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		
		
		mehtod.addParameter(String.class, "query");
		mehtod.returns(toClassRecord);
		mehtod.addException(exception);
		mehtod.addStatement("$T[] results = load$Ts(query)",toClassRecord,toClassRecord);
		mehtod.beginControlFlow("if (results == null)");
		mehtod.addStatement("return null");	
		mehtod.endControlFlow();
		mehtod.beginControlFlow("if(results.length < 1)");
		mehtod.addStatement("return null");	
		mehtod.endControlFlow();
		mehtod.addStatement("return results[0]");	
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	private MethodSpec loadRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String originaltableName)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);		
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		TypeName arrayList = ClassName.get(javaUtilsPackagePath, arrayListClass);
		TypeName preparedStatement = ClassName.get(preparedStatementPackage, preparedStatementClass);
		TypeName resultSet = ClassName.get(preparedStatementPackage, resultSetClass);
		

		
		mehtod.addParameter(String.class, "id");
		mehtod.addParameter(Connection.class, "con");
		mehtod.addParameter(boolean.class, "closeConnection");
		mehtod.returns(toClassRecord);
		mehtod.addException(exception);
		mehtod.addStatement("$T ps = null",preparedStatement);
		mehtod.addStatement("$T rs = null",resultSet);
		

		mehtod.beginControlFlow("try");
		mehtod.beginControlFlow("if(con == null)");
		mehtod.addStatement("con = getCPDatabaseConnection()");
		mehtod.endControlFlow();
		mehtod.addStatement("String Query = \"SELECT * FROM $N WHERE (ID = ?)\"",originaltableName);
		mehtod.addStatement("Query = updateQuery(Query)");
		mehtod.addStatement("logger.trace(\"load$Ns\t\" + closeConnection + \"\t\" + id)",classRecord);
		mehtod.addStatement("ps = con.prepareStatement(Query)");
		mehtod.addStatement("ps.setString(1,id)");
		mehtod.addStatement("rs = ps.executeQuery()");
		
		mehtod.beginControlFlow("if (!rs.next())");
		mehtod.addStatement("ps.close()");
		mehtod.addStatement("releaseDatabaseConnection(con, closeConnection)");
		mehtod.addStatement("return null");
		mehtod.endControlFlow();
		
		mehtod.addStatement("$T record = new $T()",toClassRecord,toClassRecord);
		Iterator keyIterator = columns.keySet().iterator();
		String firstCaps = null;
		String allCaps = null;
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			key = key.replaceAll("\\s","");
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();
			/*firstCaps  = StringUtils.convertFirstCharacterToUpperCase(key);
			allCaps = key.toUpperCase();*/
			mehtod.addStatement("record.set$N(rs.getString($S))",firstCaps,allCaps);
			
		}
		
		mehtod.addStatement("ps.close()");
		mehtod.addStatement("logger.trace(\"load$N\t\" + record + \"\t\")",classRecord);
		mehtod.addStatement("releaseDatabaseConnection(con, closeConnection)");
		mehtod.addStatement("return record");	
		mehtod.endControlFlow();
		mehtod.beginControlFlow("finally");
		mehtod.addStatement("releaseDatabaseConnection(rs, ps, con, closeConnection)");	
		mehtod.endControlFlow();
	
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	} 
	
	private MethodSpec loadRecordsPKMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String originaltableName)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);		
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		TypeName arrayList = ClassName.get(javaUtilsPackagePath, arrayListClass);
		TypeName preparedStatement = ClassName.get(preparedStatementPackage, preparedStatementClass);
		TypeName resultSet = ClassName.get(preparedStatementPackage, resultSetClass);
		

		
		mehtod.addParameter(String.class, "$pk$");
		mehtod.addParameter(Connection.class, "con");
		mehtod.addParameter(boolean.class, "closeConnection");
		mehtod.returns(toClassRecord);
		mehtod.addException(exception);
		mehtod.addStatement("$T ps = null",preparedStatement);
		mehtod.addStatement("$T rs = null",resultSet);
		

		mehtod.beginControlFlow("try");
		mehtod.beginControlFlow("if(con == null)");
		mehtod.addStatement("con = getCPDatabaseConnection()");
		mehtod.endControlFlow();
		mehtod.addStatement("String Query = \"SELECT * FROM $N WHERE ($N = ?)\"",originaltableName,"$PK$");
		mehtod.addStatement("Query = updateQuery(Query)");
		mehtod.addStatement("logger.trace(\"load$Ns\t\" + closeConnection + \"\t\" + $S)",classRecord,"$PK$");
		mehtod.addStatement("ps = con.prepareStatement(Query)");
		mehtod.addStatement("ps.setString(1,$N)","$pk$");
		mehtod.addStatement("rs = ps.executeQuery()");
		
		mehtod.beginControlFlow("if (!rs.next())");
		mehtod.addStatement("ps.close()");
		mehtod.addStatement("releaseDatabaseConnection(con, closeConnection)");
		mehtod.addStatement("return null");
		mehtod.endControlFlow();
		
		mehtod.addStatement("$T record = new $T()",toClassRecord,toClassRecord);
		Iterator keyIterator = columns.keySet().iterator();
		String firstCaps = null;
		String allCaps = null;
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			key = key.replaceAll("\\s","");
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();
			/*firstCaps  = StringUtils.convertFirstCharacterToUpperCase(key);
			allCaps = key.toUpperCase();*/
			mehtod.addStatement("record.set$N(rs.getString($S))",firstCaps,allCaps);
			
		}
		
		mehtod.addStatement("ps.close()");
		mehtod.addStatement("logger.trace(\"load$N\t\" + record + \"\t\")",classRecord);
		mehtod.addStatement("releaseDatabaseConnection(con, closeConnection)");
		mehtod.addStatement("return record");	
		mehtod.endControlFlow();
		mehtod.beginControlFlow("finally");
		mehtod.addStatement("releaseDatabaseConnection(rs, ps, con, closeConnection)");	
		mehtod.endControlFlow();
	
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	} 
	
	
	private MethodSpec loadRecordFirstMethodspec(String methodName,TypeName className,HashMap columns,String classRecord)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);		
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		
		
		mehtod.addParameter(String.class, "id");
		mehtod.returns(toClassRecord);
		mehtod.addException(exception);
		mehtod.addStatement("return load$N(id, null, true)",classRecord);
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private MethodSpec insertRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String originaltableName)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);		
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		TypeName arrayList = ClassName.get(javaUtilsPackagePath, arrayListClass);
		TypeName preparedStatement = ClassName.get(preparedStatementPackage, preparedStatementClass);
		TypeName resultSet = ClassName.get(preparedStatementPackage, resultSetClass);
		TypeName Statement = ClassName.get(preparedStatementPackage, statementClass);
		

		
		mehtod.addParameter(toClassRecord, "record");
		mehtod.addParameter(Connection.class, "con");
		mehtod.addParameter(boolean.class, "closeConnection");
		mehtod.returns(int.class);
		mehtod.addException(exception);
		mehtod.addStatement("$T ps = null",preparedStatement);
		mehtod.addStatement("$T rs = null",resultSet);
		
		mehtod.beginControlFlow("try");
		
		Iterator keyIterator = columns.keySet().iterator();
		String firstCaps = null;
		String allCaps = "";
		String addingColumns  = "";
		String valuesInsertScript = "";
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			key = key.replaceAll("\\s","");
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();
			/*firstCaps  = StringUtils.convertFirstCharacterToUpperCase(key);
			allCaps = key.toUpperCase();*/
			if(addingColumns.length() < 1)
			{
				addingColumns  = allCaps;
				valuesInsertScript = "?";
			}
			else
			{
			    addingColumns  = addingColumns + "," + allCaps;
			    valuesInsertScript  = valuesInsertScript + "," + "?";
			}
			//mehtod.addStatement("record.set$N(rs.getString($S))",firstCaps,allCaps);
			
		}
		System.out.println("Query ::: "+addingColumns);
		System.out.println("Query2 ::: "+valuesInsertScript);
		
		
		mehtod.addStatement("String Query =\"INSERT INTO $N \"",originaltableName);
		mehtod.addStatement("Query +=$S","(");
		mehtod.addStatement("Query +=$S",addingColumns);
		mehtod.addStatement("Query +=$S",")");
		mehtod.addStatement("Query += $S "," VALUES ");
		mehtod.addStatement("Query +=$S","(");
		mehtod.addStatement("Query +=$S",valuesInsertScript);
		mehtod.addStatement("Query +=$S",")");
		
			mehtod.beginControlFlow("if (con == null)");
				mehtod.addStatement("con = getCPDatabaseConnection()");		
			mehtod.endControlFlow();
			
		mehtod.addStatement("Query = updateQuery(Query)");	
		mehtod.addStatement("logger.trace(\"insert$Ns\t\" + closeConnection + \"\t\" + Query)",classRecord);
		
			mehtod.beginControlFlow("if (isOracleDatabase())");
				mehtod.addStatement("ps = con.prepareStatement(Query,new String[]{\"ID\"})");		
			mehtod.endControlFlow();
			
			mehtod.beginControlFlow("else");
				mehtod.addStatement("ps = con.prepareStatement(Query,$T.RETURN_GENERATED_KEYS)",Statement);		
		    mehtod.endControlFlow();
		
	   Iterator keyIterator2 = columns.keySet().iterator();
	   int number = 1;
	   while(keyIterator2.hasNext())
	   {
		   String key = keyIterator2.next().toString();
		   key = key.replaceAll("\\s","");
		   String old  = StringUtils.replaceString(key, "_", "", true);
		   firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
		   
		  // firstCaps  = StringUtils.convertFirstCharacterToUpperCase(key);
		   if(firstCaps.equalsIgnoreCase("Createdat") || firstCaps.equalsIgnoreCase("Modifiedat"))  
			   mehtod.addStatement("setDateValue(ps, $N, fd.getSQLDateObject(record.get$N(), \"yyyyMMddHHmmss\"))",""+number,firstCaps);
		   else
		       mehtod.addStatement("setStringValue(ps, $N, record.get$N())",""+number,firstCaps);
		   number++;

	   }
	   mehtod.addStatement("boolean result = ps.execute()");
	   mehtod.addStatement("logger.trace(\"insert$N\t\" + result + \"\t\")",classRecord);
	   
	   mehtod.addStatement("int resultID = -1");
	   mehtod.addStatement("rs = ps.getGeneratedKeys()");
	   mehtod.beginControlFlow("if (rs.next())");
	   mehtod.addStatement("resultID = rs.getInt(1)");
	   mehtod.endControlFlow();
	   mehtod.addStatement("ps.close()");
	   mehtod.addStatement("releaseDatabaseConnection(con, closeConnection)");
	   mehtod.addStatement("return resultID");
	   
	   
				
		mehtod.endControlFlow();
		
		 mehtod.beginControlFlow("finally");
		   mehtod.addStatement("releaseDatabaseConnection(rs, ps, con, closeConnection)");
		 mehtod.endControlFlow();
		 
		
		mehtod.addModifiers(Modifier.PUBLIC);
		
		return mehtod.build(); 
		
	}
	
	
	private MethodSpec insertRecordFirstMethodspec(String methodName,TypeName className,HashMap columns,String classRecord)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);		
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		
		
		
		mehtod.addParameter(toClassRecord, "record");
		mehtod.returns(int.class);
		mehtod.addException(exception);
		mehtod.addStatement("return insert$N(record, null, true)",classRecord);
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	
	private MethodSpec updateRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String originaltableName,TypeName stringUtils)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);		
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		TypeName arrayList = ClassName.get(javaUtilsPackagePath, arrayListClass);
		TypeName preparedStatement = ClassName.get(preparedStatementPackage, preparedStatementClass);
		TypeName resultSet = ClassName.get(preparedStatementPackage, resultSetClass);
		TypeName Statement = ClassName.get(preparedStatementPackage, statementClass);
		

		
		mehtod.addParameter(toClassRecord, "record");
		mehtod.addParameter(Connection.class, "con");
		mehtod.addParameter(boolean.class, "closeConnection");
		mehtod.returns(boolean.class);
		mehtod.addException(exception);
		mehtod.addStatement("$T ps = null",preparedStatement);
		mehtod.addStatement("$T rs = null",resultSet);
		
		mehtod.beginControlFlow("try");
			mehtod.addStatement("$T currentRecord = load$T(record.getId())",toClassRecord,toClassRecord);
			mehtod.addStatement("String currentRecordContent = $T.noNull(currentRecord)",stringUtils);
			mehtod.addStatement("String Query = \"UPDATE $N SET \"",originaltableName);
			Iterator keyIterator = columns.keySet().iterator();
			String firstCaps = null;
			String allCaps = "";
			String valueofQuery  = "";
			String valuesInsertScript = "";
			
			while(keyIterator.hasNext())
			{
				String key = keyIterator.next().toString();
				key = key.replaceAll("\\s","");
				String old  = StringUtils.replaceString(key, "_", "", true);
				//firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
				allCaps = key.toUpperCase();
				
				allCaps = key.toUpperCase();
				if(allCaps.equals("ID")) continue;
				valueofQuery = valueofQuery + "Query += \""+allCaps+" = ?,\";\n";
				
				//mehtod.addStatement("Query += \"$N = ?, \"",allCaps);
				
			}
			valueofQuery = valueofQuery.substring(0, valueofQuery.length() - 5);
			valueofQuery = valueofQuery+"?\""; 
			//StringBuilder finalQuery = new StringBuilder(valueofQuery);
			//finalQuery.setCharAt(finalQuery.length()-11, ' ');
			
			//String partQuerytoreplace 
			//valueofQuery = StringUtils.trimLeadingSize(valueofQuery, valueofQuery.length()-1);
			mehtod.addStatement("$N",valueofQuery);
			mehtod.addStatement("Query += \" WHERE (ID = ?)\"");
			mehtod.beginControlFlow("if (con == null)");
				mehtod.addStatement("con = getCPDatabaseConnection()");
			mehtod.endControlFlow();
			mehtod.addStatement("Query = updateQuery(Query)");
			mehtod.addStatement("logger.trace(\"update$N\t\" + closeConnection + \"\t\" + record + \"\t\" + Query + \"\t\")",classRecord);
			mehtod.addStatement("ps = con.prepareStatement(Query)");
			
			Iterator keyIterator2 = columns.keySet().iterator();
			   int number = 1;
			   while(keyIterator2.hasNext())
			   {
				   String key = keyIterator2.next().toString();
				   key = key.replaceAll("\\s","");
				   String old  = StringUtils.replaceString(key, "_", "", true);
					firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
					allCaps = key.toUpperCase();
					if(allCaps.equals("ID")) continue;
				   //firstCaps  = StringUtils.convertFirstCharacterToUpperCase(key);
				   if(firstCaps.equalsIgnoreCase("Createdat") || firstCaps.equalsIgnoreCase("Modifiedat"))  
					   mehtod.addStatement("setDateValue(ps, $N, fd.getSQLDateObject(record.get$N(), \"yyyyMMddHHmmss\"))",""+number,firstCaps);
				   else 
				       mehtod.addStatement("setStringValue(ps, $N, record.get$N())",""+number,firstCaps);
				   number++;

			   }
			mehtod.addStatement("ps.setString($N, $T.noNull(record.getId()))",""+number,stringUtils);
			mehtod.addStatement("boolean result = ps.execute()");
			mehtod.addStatement("logger.trace(\"update$N\t\" + result + \"\t\")",classRecord);
			mehtod.addStatement("ps.close()");
			mehtod.addStatement("releaseDatabaseConnection(con, closeConnection)");
			mehtod.addStatement("return result");
				
		
		mehtod.endControlFlow();
		
		 mehtod.beginControlFlow("finally");
		   mehtod.addStatement("releaseDatabaseConnection(rs, ps, con, closeConnection)");
		 mehtod.endControlFlow();
		 
		
		mehtod.addModifiers(Modifier.PUBLIC);
		
		return mehtod.build(); 
		
	}
	
	
	private MethodSpec updateRecordFirstMethodspec(String methodName,TypeName className,HashMap columns,String classRecord)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);		
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		
		
		
		mehtod.addParameter(toClassRecord, "record");
		mehtod.returns(boolean.class);
		mehtod.addException(exception);
		mehtod.addStatement("return update$N(record, null, true)",classRecord);
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	
	private MethodSpec deleteRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String originaltableName,TypeName stringUtils)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);		
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		TypeName arrayList = ClassName.get(javaUtilsPackagePath, arrayListClass);
		TypeName preparedStatement = ClassName.get(preparedStatementPackage, preparedStatementClass);
		TypeName resultSet = ClassName.get(preparedStatementPackage, resultSetClass);
		TypeName Statement = ClassName.get(preparedStatementPackage, statementClass);
		

		
		mehtod.addParameter(toClassRecord, "record");
		mehtod.addParameter(Connection.class, "con");
		mehtod.addParameter(boolean.class, "closeConnection");
		mehtod.returns(boolean.class);
		mehtod.addException(exception);
		mehtod.addStatement("$T ps = null",preparedStatement);
		mehtod.addStatement("$T rs = null",resultSet);
		
		mehtod.beginControlFlow("try");
		mehtod.addStatement("String Query = \"DELETE FROM $N WHERE (ID = ?)\"", originaltableName);
		
			mehtod.beginControlFlow("if (con == null)");
			mehtod.addStatement("con = getCPDatabaseConnection()");
			mehtod.endControlFlow();
		mehtod.addStatement("Query = updateQuery(Query)");
		mehtod.addStatement("logger.trace(\"delete$N\t\" + closeConnection + \"\t\" + record + \"\t\" + Query + \"\t\")",classRecord);
		mehtod.addStatement("ps = con.prepareStatement(Query)");
		mehtod.addStatement("ps.setString(1, noNull(record.getId()))");
		mehtod.addStatement("boolean result = ps.execute()");
		mehtod.addStatement("logger.trace(\"delete$N\t\" + result + \"\t\")",classRecord);
		mehtod.addStatement("ps.close()");
		mehtod.addStatement("releaseDatabaseConnection(con, closeConnection)");
		mehtod.addStatement("return result");
		mehtod.endControlFlow();
		mehtod.beginControlFlow("finally");
		mehtod.addStatement("releaseDatabaseConnection(rs, ps, con, closeConnection)");
		mehtod.endControlFlow();
		
		mehtod.addModifiers(Modifier.PUBLIC);
		
		return mehtod.build(); 
	}
	
	
	private MethodSpec deleteRecordFirstMethodspec(String methodName,TypeName className,HashMap columns,String classRecord)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);		
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		
		
		
		mehtod.addParameter(toClassRecord, "record");
		mehtod.returns(boolean.class);
		mehtod.addException(exception);
		mehtod.addStatement("return delete$N(record, null, true)",classRecord);
		mehtod.addModifiers(Modifier.PUBLIC);
		return mehtod.build(); 
	}
	
	private MethodSpec searchRecordsMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String originaltableName,TypeName stringUtils)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName);
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);		
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		
		
		mehtod.addParameter(toClassRecord, "searchRecord");
		mehtod.addException(exception);
		mehtod.addStatement("String WhereCondition =  \" \"");
		
		
		Iterator keyIterator = columns.keySet().iterator();
		String firstCaps = null;
		String allCaps = "";
		String valueofQuery  = "";
		String valuesInsertScript = "";
		
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			
			String value = columns.get(key).toString();
			key = key.replaceAll("\\s","");
			
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();
			
			//firstCaps  = StringUtils.convertFirstCharacterToUpperCase(key);
			//allCaps  = key.toUpperCase();
			
			
			if(value.contains("INT")  || value.contains("VARCHAR 1") )
				mehtod.addStatement("WhereCondition = addSearchCondition(WhereCondition, \"($N)\", \"\", \"$N\", formatSearchField(searchRecord.get$N()))","$COLNAME$ = '$COLVAL$'",allCaps,firstCaps);
			else if(key.toUpperCase().contains("ID") || key.toUpperCase().contains("NUM")  || key.toUpperCase().contains("MOBILE") || key.toUpperCase().contains("MADE_BY") || key.toUpperCase().contains("CHECKED_BY")
					|| key.toUpperCase().contains("CURR_APP_STATUS") || key.toUpperCase().contains("RSTATUS") || key.toUpperCase().contains("CREATED_BY") || key.toUpperCase().contains("MODIFIED_BY")
					|| key.toUpperCase().contains("BLOCKED_FLAG")|| key.toUpperCase().contains("CUST_CAT")|| key.toUpperCase().contains("PIN") || key.toUpperCase().contains("PHONE")
					|| key.toUpperCase().contains("ACC") || key.toUpperCase().contains("CIF") || key.toUpperCase().contains("OTP") || key.toUpperCase().contains("CODE")
					|| key.toUpperCase().contains("REFBY") || key.toUpperCase().contains("NUM") || key.toUpperCase().contains("CUST") )
				mehtod.addStatement("WhereCondition = addSearchCondition(WhereCondition, \"($N)\", \"\", \"$N\", formatSearchField(searchRecord.get$N()))","$COLNAME$ = '$COLVAL$'",allCaps,firstCaps);
			else 
			    mehtod.addStatement("WhereCondition = addSearchCondition(WhereCondition, \"(UPPER($N) LIKE UPPER('$N'))\", \"\", \"$N\", formatSearchField(searchRecord.get$N()))","$COLNAME$","%$COLVAL$%",allCaps,firstCaps);
		}
		
		mehtod.beginControlFlow("if (isNull(WhereCondition))");
			mehtod.addStatement("WhereCondition += \"(1=1)\"");
		mehtod.endControlFlow();
		
		
		mehtod.beginControlFlow("if (!isNull(WhereCondition))");
			mehtod.addStatement("WhereCondition = \"WHERE \" + WhereCondition");
		mehtod.endControlFlow();
		
		mehtod.beginControlFlow("if (hasCustomCondition())");
			mehtod.addStatement("WhereCondition += getCustomCondition()");
		mehtod.endControlFlow();
		
		mehtod.addStatement("String Query = \"select * from $N \" + WhereCondition + \" order by \" + ORDERBYSTRING",originaltableName);
		
		mehtod.beginControlFlow("if (isMSSQL8())");
			mehtod.addStatement("Query = \"select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $N) as rownum FROM $N ) acvmfs \" + WhereCondition","$ORDERBYSTRING$",originaltableName);
			mehtod.addStatement("Query = $T.replaceString(Query, \"$N\", loadMSSQL8OrderByID(ORDERBYSTRING),true)",globalstringUtils,"$ORDERBYSTRING$");
		mehtod.endControlFlow();
		
		mehtod.beginControlFlow("if (isOracleDatabase())");
			mehtod.addStatement("Query = \"select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $N) R FROM (SELECT * FROM $N $N) C ) WHERE (1=1) $N\"","$ORDERBYSTRING$",originaltableName,"$WHERECONDITION$","$OUTERLIMITCONDITION$");
			mehtod.addStatement("Query = $T.replaceString(Query, \"$N\", WhereCondition,true)",globalstringUtils,"$WHERECONDITION$");
			mehtod.addStatement("Query = $T.replaceString(Query, \"$N\", getOuterLimitCondition(),true)",globalstringUtils,"$OUTERLIMITCONDITION$");
			mehtod.addStatement("Query = $T.replaceString(Query, \"$N\", loadOracleOrderByID(ORDERBYSTRING),true)",globalstringUtils,"$ORDERBYSTRING$");
		mehtod.endControlFlow();
		
		mehtod.addStatement("Query = updateQuery(Query)");
		mehtod.addStatement("logger.trace(\"Search Query	\" + Query + \"\t\")");
		mehtod.addStatement("return load$Ts(Query)",toClassRecord);
		mehtod.returns(ArrayTypeName.of(toClassRecord));
		mehtod.addModifiers(Modifier.PUBLIC);
		
		return mehtod.build(); 
		
	}
	
	
	private MethodSpec searchRecordsExactUpperMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String originaltableName,TypeName stringUtils)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName+"ExactUpper");
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);		
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		
		
		mehtod.addParameter(toClassRecord, "searchRecord");
		mehtod.addException(exception);
		mehtod.addStatement("String WhereCondition =  \" \"");
		
		
		Iterator keyIterator = columns.keySet().iterator();
		String firstCaps = null;
		String allCaps = "";
		String valueofQuery  = "";
		String valuesInsertScript = "";
		
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			
			String value = columns.get(key).toString();
			key = key.replaceAll("\\s","");
			
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();
			
			//firstCaps  = StringUtils.convertFirstCharacterToUpperCase(key);
			//allCaps  = key.toUpperCase();
			
			
			
			    mehtod.addStatement("WhereCondition = addSearchCondition(WhereCondition, \"(UPPER($N) = UPPER('$N'))\", \"\", \"$N\", formatSearchField(searchRecord.get$N()))","$COLNAME$","%$COLVAL$%",allCaps,firstCaps);
		}
		
		mehtod.beginControlFlow("if (isNull(WhereCondition))");
			mehtod.addStatement("WhereCondition += \"(1=1)\"");
		mehtod.endControlFlow();
		
		
		mehtod.beginControlFlow("if (!isNull(WhereCondition))");
			mehtod.addStatement("WhereCondition = \"WHERE \" + WhereCondition");
		mehtod.endControlFlow();
		
		mehtod.beginControlFlow("if (hasCustomCondition())");
			mehtod.addStatement("WhereCondition += getCustomCondition()");
		mehtod.endControlFlow();
		
		mehtod.addStatement("String Query = \"select * from $N \" + WhereCondition + \" order by \" + ORDERBYSTRING",originaltableName);
		
		mehtod.beginControlFlow("if (isMSSQL8())");
			mehtod.addStatement("Query = \"select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $N) as rownum FROM $N ) acvmfs \" + WhereCondition","$ORDERBYSTRING$",originaltableName);
			mehtod.addStatement("Query = $T.replaceString(Query, \"$N\", loadMSSQL8OrderByID(ORDERBYSTRING),true)",globalstringUtils,"$ORDERBYSTRING$");
		mehtod.endControlFlow();
		
		mehtod.beginControlFlow("if (isOracleDatabase())");
			mehtod.addStatement("Query = \"select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $N) R FROM (SELECT * FROM $N $N) C ) WHERE (1=1) $N\"","$ORDERBYSTRING$",originaltableName,"$WHERECONDITION$","$OUTERLIMITCONDITION$");
			mehtod.addStatement("Query = $T.replaceString(Query, \"$N\", WhereCondition,true)",globalstringUtils,"$WHERECONDITION$");
			mehtod.addStatement("Query = $T.replaceString(Query, \"$N\", getOuterLimitCondition(),true)",globalstringUtils,"$OUTERLIMITCONDITION$");
			mehtod.addStatement("Query = $T.replaceString(Query, \"$N\", loadOracleOrderByID(ORDERBYSTRING),true)",globalstringUtils,"$ORDERBYSTRING$");
		mehtod.endControlFlow();
		
		mehtod.addStatement("Query = updateQuery(Query)");
		mehtod.addStatement("logger.trace(\"Search Query	\" + Query + \"\t\")");
		mehtod.addStatement("return load$Ts(Query)",toClassRecord);
		mehtod.returns(ArrayTypeName.of(toClassRecord));
		mehtod.addModifiers(Modifier.PUBLIC);
		
		return mehtod.build(); 
		
	}
	
	private MethodSpec loadRecordsCountMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String originaltableName,TypeName stringUtils)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName+"Count");
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);		
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
				
		mehtod.addParameter(toClassRecord, "searchRecord");
		mehtod.addException(exception);
		mehtod.addStatement("String WhereCondition =  \" \"");
		
		
		Iterator keyIterator = columns.keySet().iterator();
		String firstCaps = null;
		String allCaps = "";
		String valueofQuery  = "";
		String valuesInsertScript = "";
		
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			
			String value = columns.get(key).toString();
			key = key.replaceAll("\\s","");
			
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();
			
			//firstCaps  = StringUtils.convertFirstCharacterToUpperCase(key);
			//allCaps  = key.toUpperCase();
			
			
			if(value.contains("INT")  || value.contains("VARCHAR 1") )
				mehtod.addStatement("WhereCondition = addSearchCondition(WhereCondition, \"($N)\", \"\", \"$N\", formatSearchField(searchRecord.get$N()))","$COLNAME$ = '$COLVAL$'",allCaps,firstCaps);
			else if(key.toUpperCase().contains("ID") || key.toUpperCase().contains("NUM")  || key.toUpperCase().contains("MOBILE") || key.toUpperCase().contains("MADE_BY") || key.toUpperCase().contains("CHECKED_BY")
					|| key.toUpperCase().contains("CURR_APP_STATUS") || key.toUpperCase().contains("RSTATUS") || key.toUpperCase().contains("CREATED_BY") || key.toUpperCase().contains("MODIFIED_BY")
					|| key.toUpperCase().contains("BLOCKED_FLAG")|| key.toUpperCase().contains("CUST_CAT")|| key.toUpperCase().contains("PIN") || key.toUpperCase().contains("PHONE")
					|| key.toUpperCase().contains("ACC") || key.toUpperCase().contains("CIF") || key.toUpperCase().contains("OTP") || key.toUpperCase().contains("CODE")
					|| key.toUpperCase().contains("REFBY") || key.toUpperCase().contains("NUM") || key.toUpperCase().contains("CUST") )
				mehtod.addStatement("WhereCondition = addSearchCondition(WhereCondition, \"($N)\", \"\", \"$N\", formatSearchField(searchRecord.get$N()))","$COLNAME$ = '$COLVAL$'",allCaps,firstCaps);
			else 
			    mehtod.addStatement("WhereCondition = addSearchCondition(WhereCondition, \"(UPPER($N) LIKE UPPER('$N'))\", \"\", \"$N\", formatSearchField(searchRecord.get$N()))","$COLNAME$","%$COLVAL$%",allCaps,firstCaps);
		}
		
		mehtod.beginControlFlow("if (isNull(WhereCondition))");
			mehtod.addStatement("WhereCondition += \"(1=1)\"");
		mehtod.endControlFlow();
		
		
		mehtod.beginControlFlow("if (!isNull(WhereCondition))");
			mehtod.addStatement("WhereCondition = \"WHERE \" + WhereCondition");
		mehtod.endControlFlow();
		
		mehtod.beginControlFlow("if (hasCustomCondition())");
			mehtod.addStatement("WhereCondition += getCustomCondition()");
		mehtod.endControlFlow();
		
		
		mehtod.addStatement("String Query = \"select count(*) from $N \" + WhereCondition",originaltableName);
		
		/*mehtod.beginControlFlow("if (isMSSQL8())");
			mehtod.addStatement("Query = \"select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $N) as rownum FROM $N ) acvmfs \" + WhereCondition","$ORDERBYSTRING$",originaltableName);
			mehtod.addStatement("Query = StringUtils.replaceString(Query, \"\", loadMSSQL8OrderByID(ORDERBYSTRING),true)","$ORDERBYSTRING$");
		mehtod.endControlFlow();
		
		mehtod.beginControlFlow("if (isOracleDatabase())");
			mehtod.addStatement("Query = \"select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $N) R FROM (SELECT * FROM $N $N) C ) WHERE (1=1) $N\"","$ORDERBYSTRING$",originaltableName,"$WHERECONDITION$","$OUTERLIMITCONDITION$");
			mehtod.addStatement("Query = StringUtils.replaceString(Query, \"$N\", WhereCondition,true)","$WHERECONDITION$");
			mehtod.addStatement("Query = StringUtils.replaceString(Query, \"\", getOuterLimitCondition(),true)","$OUTERLIMITCONDITION$");
			mehtod.addStatement("Query = StringUtils.replaceString(Query, \"\", loadOracleOrderByID(ORDERBYSTRING),true)","$ORDERBYSTRING$");
		mehtod.endControlFlow();*/
		
		mehtod.addStatement("Query = updateQuery(Query)");
		mehtod.addStatement("logger.trace(\"Search Count Query	\" + Query + \"\t\")");
		mehtod.addStatement("return loadCount(Query)",toClassRecord);
		mehtod.returns(int.class);
		mehtod.addModifiers(Modifier.PUBLIC);
		
		return mehtod.build(); 
		
	}
	
	
	private MethodSpec loadRecordsCountExactUpperMethodspec(String methodName,TypeName className,HashMap columns,String classRecord,String originaltableName,TypeName stringUtils)
	{
		Builder mehtod = MethodSpec.methodBuilder(methodName+"CountExact");
		System.out.println("ClasssName ::::::::::::::::; "+classRecord);
		//className = "MT" + StringUtils.convertFirstCharacterToUpperCase(className) + "Record";
		TypeName  toClassRecord = ClassName.get(pojoPackagetoGeneratejavafiles, classRecord);		
		TypeName exception = ClassName.get(exceptionPackage, exceptionClass);
		
		
		mehtod.addParameter(toClassRecord, "searchRecord");
		mehtod.addException(exception);
		mehtod.addStatement("String WhereCondition =  \" \"");
		
		
		Iterator keyIterator = columns.keySet().iterator();
		String firstCaps = null;
		String allCaps = "";
		String valueofQuery  = "";
		String valuesInsertScript = "";
		
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next().toString();
			
			String value = columns.get(key).toString();
			key = key.replaceAll("\\s","");
			
			String old  = StringUtils.replaceString(key, "_", "", true);
			firstCaps  = StringUtils.convertFirstCharacterToUpperCase(old);			
			allCaps = key.toUpperCase();
			
			//firstCaps  = StringUtils.convertFirstCharacterToUpperCase(key);
			//allCaps  = key.toUpperCase();
			
			
			
			    mehtod.addStatement("WhereCondition = addSearchCondition(WhereCondition, \"(UPPER($N) = UPPER('$N'))\", \"\", \"$N\", formatSearchField(searchRecord.get$N()))","$COLNAME$","%$COLVAL$%",allCaps,firstCaps);
		}
		
		mehtod.beginControlFlow("if (isNull(WhereCondition))");
			mehtod.addStatement("WhereCondition += \"(1=1)\"");
		mehtod.endControlFlow();
		
		
		mehtod.beginControlFlow("if (!isNull(WhereCondition))");
			mehtod.addStatement("WhereCondition = \"WHERE \" + WhereCondition");
		mehtod.endControlFlow();
		
		mehtod.beginControlFlow("if (hasCustomCondition())");
			mehtod.addStatement("WhereCondition += getCustomCondition()");
		mehtod.endControlFlow();
		
		
		mehtod.addStatement("String Query = \"select count(*) from $N \" + WhereCondition",originaltableName);
		
		/*mehtod.beginControlFlow("if (isMSSQL8())");
			mehtod.addStatement("Query = \"select * from ( SELECT *,ROW_NUMBER() OVER (ORDER BY $N) as rownum FROM $N ) acvmfs \" + WhereCondition","$ORDERBYSTRING$",originaltableName);
			mehtod.addStatement("Query = StringUtils.replaceString(Query, \"\", loadMSSQL8OrderByID(ORDERBYSTRING),true)","$ORDERBYSTRING$");
		mehtod.endControlFlow();
		
		mehtod.beginControlFlow("if (isOracleDatabase())");
			mehtod.addStatement("Query = \"select * from ( SELECT C.*,ROW_NUMBER() OVER (ORDER BY $N) R FROM (SELECT * FROM $N $N) C ) WHERE (1=1) $N\"","$ORDERBYSTRING$",originaltableName,"$WHERECONDITION$","$OUTERLIMITCONDITION$");
			mehtod.addStatement("Query = StringUtils.replaceString(Query, \"$N\", WhereCondition,true)","$WHERECONDITION$");
			mehtod.addStatement("Query = StringUtils.replaceString(Query, \"\", getOuterLimitCondition(),true)","$OUTERLIMITCONDITION$");
			mehtod.addStatement("Query = StringUtils.replaceString(Query, \"\", loadOracleOrderByID(ORDERBYSTRING),true)","$ORDERBYSTRING$");
		mehtod.endControlFlow();*/
		
		mehtod.addStatement("Query = updateQuery(Query)");
		mehtod.addStatement("logger.trace(\"Search Count Query	\" + Query + \"\t\")");
		mehtod.addStatement("return loadCount(Query)",toClassRecord);
		mehtod.returns(int.class);
		mehtod.addModifiers(Modifier.PUBLIC);
		
		return mehtod.build(); 
		
	}

}
