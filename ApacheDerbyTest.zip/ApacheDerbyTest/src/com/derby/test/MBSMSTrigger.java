package com.derby.test;

import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.management.Attribute;
import javax.management.AttributeList;

import com.derby.common.MBDAO;
import com.derby.utils.MFSecurityUtil;
import com.derby.utils.PropertyUtil;

public class MBSMSTrigger {
	
	public void processMessagesInPool() throws Exception
	{
		int taskCount = getCountOfTasks();
		if(taskCount < 1) return;
		int chunkSize = addjustingChunkSize(taskCount);
		System.out.println("ChunkSize::::"+chunkSize);
		processMessagesInPool(taskCount,chunkSize);
	}
	
	private void processMessagesInPool(int taskCount,int chunkSize) {
		
		int startIndex = 0;
		int endIndex = chunkSize;
		int threadsCount = 1;
		ExecutorService poolService = Executors.newFixedThreadPool(taskCount);
		while(startIndex < taskCount)
		{
			System.out.println("Limts::::"+startIndex+" Endindex::"+endIndex);
			Runnable chunkTask = new MFSmsAgent(""+startIndex, ""+endIndex, "Thread"+threadsCount);
			poolService.submit(chunkTask);
			startIndex += chunkSize;
			endIndex += chunkSize;
			if(endIndex > taskCount)
				endIndex = taskCount % endIndex;
			
		}
		
	}
	
	private int addjustingChunkSize(int taskCount)
	{
		if(taskCount < 10) return taskCount;
		if(taskCount <= 100 && taskCount >= 10) return 10;
		if(taskCount <= 500 && taskCount > 100) return 50;
		return 100;
	}

	public int getCountOfTasks() throws Exception
	{
		String maxmailretry=PropertyUtil.getProperty("maxmailretry"); 
		String query = "SELECT count(*) FROM SMS_MESG WHERE (RSTATUS IN ('0','2')) AND (MRETRYCNT <= '" + maxmailretry + "')";
		MBDAO dao = new MBDAO();
		return dao.loadCount(query);
	}
	
	public static void main(String [] args)
			throws Exception
		    {
				System.out.println("SMS Trigger Service Started....");		
				MBSMSTrigger smsAgent = new MBSMSTrigger();
				/*/smsAgent.processMessagesInPool();
				//System.out.println("SMS Trigger Service Started...."+smsAgent.getCountOfTasks());
				//System.out.println("Encrypt Password DB: "+new MFSecurityUtil().encrypt("Master123"));
				while(true)
				{
					smsAgent.processMessagesInPool();
					try
					{
						Thread.sleep(60000);
					}
					catch(Exception e)
					{
						e.printStackTrace();
					}
				}
		    */
				 // Example usage: Add data points every second
		        Timer timer = new Timer();
		        timer.scheduleAtFixedRate(new TimerTask() {
		            @Override
		            public void run() {
		                try {
		                    // Retrieve Tomcat thread pool metrics
		                	smsAgent.processMessagesInPool();
		                } catch (Exception e) {
		                    e.printStackTrace();
		                }
		            }
		        }, 0, 1000);  // Delay: 0ms, Period: 1000ms
		    }

}
