package com.derby.common;

import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.derby.utils.DateUtils;
import com.derby.utils.LogUtils;
import com.derby.utils.PropertyUtil;
import com.derby.utils.StringUtils;




public class MBService {
	static LogUtils logger = new LogUtils(MBService.class.getName());
	StringUtils utils = new StringUtils();

	public String getStackTrace(Exception e)
	{
		return StringUtils.getStackTrace(e);
	}
	
	public HashMap callService(String className, String methodName, HashMap input)
	throws Exception
	{
		try
		{
			Class c = Class.forName(className);
			Method m = c.getDeclaredMethod(methodName, new Class[] {java.util.HashMap.class });
			Object i = c.newInstance();
			Object r = m.invoke(i,new Object[] { input });
			HashMap outputMap = (HashMap)r;
			return outputMap;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			logger.log(StringUtils.getStackTrace(exception), LogUtils.ERROR);
			throw exception;
		}
	}
	
	/*public String applyGenericCodes(String message, MFCustomerviewRecord customerViewRecord)
	throws Exception
	{
		message = StringUtils.noNull(message);
		message = StringUtils.replaceString(message, "#CUSTOMERLOGINNAME#", customerViewRecord.getCif(), true);
		message = StringUtils.replaceString(message, "#CUSTOMERNAME#", customerViewRecord.getCname(), true);		
		message = StringUtils.replaceString(message, "#CUSTOMERPHONE#", customerViewRecord.getMobile(), true);
		message = StringUtils.replaceString(message, "#CUSTOMEREMAIL#", customerViewRecord.getEmail(), true);
		message = StringUtils.replaceString(message, "#CURRENTDATE#", DateUtils.getCurrentTime("dd-MMM-yyyy"), true);
		message = StringUtils.replaceString(message, "#CURRENTTIME#", DateUtils.getCurrentTime("HH:mm:ss"), true);

		String collectionDate = DateUtils.formatDate(DateUtils.addToDate(new java.util.Date(), Calendar.DAY_OF_MONTH, 7),"dd-MMM-yyyy");
		message = StringUtils.replaceString(message, "#CHQCLTNDATE#", collectionDate, true);
		return message;
	}
	
	public MFServicemapRecord loadServiceMap(String serviceCode)
	throws Exception
	{
		String integratedEnvironment = PropertyUtil.getProperty("IntegratedEnvironment");
		MFServicemapService service = new MFServicemapService();
		MFServicemapRecord searchServiceRecord = new MFServicemapRecord();
		searchServiceRecord.setIntenv(integratedEnvironment);
		searchServiceRecord.setRstatus("1");
		searchServiceRecord.setServicecode(serviceCode);
		MFServicemapRecord resultRecord = service.searchFirstMFServicemapRecord(searchServiceRecord);
		return resultRecord;
	}

	public String getCharges(String serviceCode, String amount)
	throws Exception
	{
		String query = " SELECT ID FROM charge_type_range_view ";
		query += " where (SERVICE_CODE = '#SERVICE_CODE#')";
		query += " AND (RANGE_FROM <= '#AMOUNT#')";
		query += " AND (RANGE_TO >= '#AMOUNT#')";
		query += " AND (CURR_APP_STATUS = '1')";
		query += " AND (CHARGE_TYPE_CODE <> 'None')";


		query = StringUtils.replaceString(query, "#SERVICE_CODE#",serviceCode , true);
		query = StringUtils.replaceString(query, "#AMOUNT#",amount , true);
		
		MBDAO dao = new MBDAO();
		ArrayList idList = dao.loadColumnList(query, "ID", false);
		if (idList == null) return "0";
		if (idList.isEmpty()) return "0";
		String chargeId = idList.get(0).toString();
		
		MFChargetyperangeService chargeTypeRecordService = new MFChargetyperangeService();
		MFChargetyperangeRecord chargeTypeResultRecord = chargeTypeRecordService.loadMFChargetyperangeRecord(chargeId);
		if (chargeTypeResultRecord == null) return "0";
		String resultCharge = chargeTypeResultRecord.getChargevalue();
		
		if (chargeTypeResultRecord.getChargetypecode().equalsIgnoreCase("Percentage"))
		{
			try
			{
				double percentageValue = Double.parseDouble(resultCharge)/100;
				double resultAmount = Double.parseDouble(amount);
				double result=resultAmount * percentageValue;
				resultCharge = result + "";
			}
			catch(Exception exception)
			{
				exception.printStackTrace();
				throw new Exception("Charge Calculation Failed");
			}
		}
		
		resultCharge = chargeTypeRecordService.formatAmountNoDecimal(resultCharge);		
		return resultCharge;
	}

	public String recordRequest(MFServicemapRecord serviceMapRecord, HashMap inputHashMap)
	throws Exception
	{
		MFIntfcalllogService callLogService = new MFIntfcalllogService();
		MFIntfcalllogRecord callLog = new MFIntfcalllogRecord();
		callLog.setServicecode(serviceMapRecord.getServicecode());
		callLog.setServicemapid(serviceMapRecord.getId());
		callLog.setRequestmap(inputHashMap.toString());
		callLog.setCharges(getHashMapValue(inputHashMap,"Charges"));		
		callLog.setRequestts(DateUtils.getCurrentDateTime());
		callLog.setCreatedat(DateUtils.getCurrentDateTime());
		callLog.setCreatedby(PropertyUtil.getProperty("autosystemuserid"));
		callLog.setRequestorid(getHashMapValue(inputHashMap,"RequestorID"));
		callLog.setRequestsource(getHashMapValue(inputHashMap,"RequestSource"));
		callLog.setInstitutionid(getHashMapValue(inputHashMap,"InstitutionId"));
		int callId = callLogService.insertMFIntfcalllogRecord(callLog);
		return callId + "";
	}

	public void recordResponse(String requestId, HashMap outputHashMap)
	throws Exception
	{
		MFIntfcalllogService callLogService = new MFIntfcalllogService();
		MFIntfcalllogRecord callLog = callLogService.loadMFIntfcalllogRecord(requestId);
		callLog.setResponsemap(outputHashMap.toString());
		callLog.setResponsets(DateUtils.getCurrentDateTime());
		callLog.setErrormesg(StringUtils.trimSize(getHashMapValue(outputHashMap,"ErrorMessage"),300));
		callLog.setModifiedat(DateUtils.getCurrentDateTime());
		callLog.setModifiedby(PropertyUtil.getProperty("autosystemuserid"));
		callLogService.updateMFIntfcalllogRecordNonNull(callLog);
	}	

	public HashMap callService(String serviceCode, HashMap inputHashMap)
	throws Exception
	{
		System.out.println("Request Service:" + serviceCode);
		System.out.println("Request Map:" + inputHashMap);
		MFServicemapRecord serviceMapRecord = loadServiceMap(serviceCode);
		if (serviceMapRecord == null)
		{
			throw new Exception("Service Configuration Error:Missing Configuration for:" + serviceCode);
		}

		String requestID = recordRequest(serviceMapRecord, inputHashMap);
		inputHashMap.put("AuditNumber", requestID);		
		if (!inputHashMap.containsKey("Charges"))
		{
			inputHashMap.put("Charges", "0");
		}

		try
		{
			HashMap outputMap= callService(serviceMapRecord.getServiceclass(), serviceMapRecord.getServicemethod(), inputHashMap);
			recordResponse(requestID, outputMap);
			return outputMap;
		}
		catch(Exception exception)
		{
			HashMap outputMap = new HashMap(inputHashMap);
			exception.printStackTrace();
			outputMap.put("ErrorMessage", "Could not process request at this time");
			recordResponse(requestID, outputMap);
			throw exception;
		}
	}*/

	public boolean isSuccessfulTransaction(HashMap inputHashMap)
	{
		if (inputHashMap ==null) inputHashMap = new HashMap();
		if (inputHashMap.containsKey("ErrorMessage"))
		{
			String errorMessage = StringUtils.noNull(inputHashMap.get("ErrorMessage"));
			if (!StringUtils.isNullOrEmpty(errorMessage))
			{
				return false;
			}
		}
		return true;
	}

	public String getHashMapValue(HashMap inputHashMap,String inputKey)
	{
		if (inputHashMap ==null) inputHashMap = new HashMap();
		if (!inputHashMap.containsKey(inputKey)) return "";
		String inputValue = StringUtils.noNull(inputHashMap.get(inputKey));
		return inputValue;
	}

	public boolean isValidStatusForDeny(String inputStatus)
	{
		if (StringUtils.isNull(inputStatus)) return false;
		inputStatus = inputStatus.trim();
		if (inputStatus.equals("4")) return true;
		return false;
	}

	public boolean isValidStatusForPasswordReset(String inputStatus)
	{
		if (StringUtils.isNull(inputStatus)) return false;
		inputStatus = inputStatus.trim();
		if (inputStatus.equals("1")) return true;
		return false;
	}

	public boolean isValidStatusForPinReset(String inputStatus)
	{
		if (StringUtils.isNull(inputStatus)) return false;
		inputStatus = inputStatus.trim();
		if (inputStatus.equals("1")) return true;
		return false;
	}	
	
	public boolean isValidStatusForBlock(String inputStatus)
	{
		if (StringUtils.isNull(inputStatus)) return false;
		inputStatus = inputStatus.trim();
		if (inputStatus.equals("1")) return true;
		return false;
	}

	public boolean isValidStatusForApproval(String inputStatus)
	{
		if (StringUtils.isNull(inputStatus)) return false;
		inputStatus = inputStatus.trim();
		if (inputStatus.equals("4")) return true;
		return false;
	}

	public boolean isValidStatusForReset(String inputStatus)
	{
		if (StringUtils.isNull(inputStatus)) return false;
		inputStatus = inputStatus.trim();
		if (inputStatus.equals("0")) return true;
		if (inputStatus.equals("1")) return true;
		if (inputStatus.equals("2")) return true;
		return false;		
	}

	public boolean isValidStatusForSubmission(String inputStatus)
	{
		if (StringUtils.isNull(inputStatus)) return true;
		inputStatus = inputStatus.trim();
		if (inputStatus.equals("-1")) return true;
		if (inputStatus.equals("3")) return true;
		if (inputStatus.equals("5")) return true;
		return false;
	}		
	
    public String getErrorMessage(Exception e)
    {
    	e.printStackTrace();
    	String message = e.toString();
    	message = message.toLowerCase();
    	
    	if (message.indexOf("sqlintegrityconstraintviolation") > -1)
    	{
			return "Duplicate Record";    		
    	}
    	return message;
    }
    
    public String getTableNameDescription(String tableName)
    {
    	if (StringUtils.isNull(tableName)) return tableName;
    	if (tableName.equalsIgnoreCase("CUSTOMER_CATG")) return "Customer Category";
    	if (tableName.equalsIgnoreCase("customer_info")) return "Customer";
    	if (tableName.equalsIgnoreCase("account")) return "Account";
    	if (tableName.equalsIgnoreCase("institution_info")) return "Institution";
    	if (tableName.equalsIgnoreCase("user_info")) return "User";
    	return tableName;    	
    }
    
    
	/*public void createMakerCheckerAuditEntry(String tableName, String recordId, String actionName, String createID, String comments)
	throws Exception
	{
		try
		{
			processSendNotifications(tableName, recordId, actionName, createID, comments);
			String tableNamedescription = getTableNameDescription(tableName);
			MFMakercheckerauditService service = new  MFMakercheckerauditService();
			MFMakercheckerauditRecord record = new MFMakercheckerauditRecord();
			record.setRecid(recordId);
			record.setTabname(tableName);
			record.setActionname(actionName);
			record.setTablelabel(tableNamedescription);
			record.setCreatedat(DateUtils.getCurrentDateTime());
			record.setCreatedby(createID);
			record.setComments(comments);
			service.insertMFMakercheckerauditRecord(record);
		}
		catch(Exception exception)
		{
			logger.error("createMakerCheckerAuditEntry" + getStackTrace(exception));
			throw exception;
		}
	}
	
	public void processSendNotifications(String tableName, String recordId, String actionName, String createID, String comments)
	{
		try
		{
			MFNotificationService notificationService = new MFNotificationService();
//			MFUserinfoService userService = new MFUserinfoService();
//			if (tableName.equals("user_info"))
//			{
//				if (actionName.equals("Approve"))
//				{
//					MFUserinfoRecord userRecord = userService.loadMFUserinfoRecord(recordId);
//					if (userRecord == null) return;
//					notificationService.sendPassword(userRecord.getEmail(), true);
//				}
//			}
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			logger.error("processSendNotifications" + getStackTrace(exception));
		}
	}*/
	
	public boolean isCurrentSessionValid(String sessionId, String userId)
	{
		try
		{
			String query = "";
			query += "SELECT SERVICE, TIMESTAMPDIFF(MINUTE,MODIFIED_AT,NOW()) DT FROM WEB_ACCESS_LOG ";
			query += "WHERE (SESSIONID = '" + sessionId + "') ";
			query += "AND (USER_ID = '" + userId + "') ";			
			query += "ORDER BY CREATED_AT DESC ";
			query += "LIMIT 1		 ";
			
			MBDAO dao = new MBDAO();
			Map inputMap = dao.loadMap(query, "SERVICE", "DT", false);
			if (inputMap.isEmpty()) return true;

			if (inputMap.containsKey("Log Off")) return false;

			Iterator iterator = inputMap.keySet().iterator();
	
			int timeDiff = 0;
			while(iterator.hasNext())
			{
				String key = iterator.next().toString();
				timeDiff = Integer.parseInt(inputMap.get(key).toString());
			}
	
			int maxTimeDiff = Integer.parseInt(PropertyUtil.getProperty("websessiontimeout"));
			if (timeDiff > maxTimeDiff)
			{
				return false;
			}	
			return true;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			logger.error("isCurrentSessionValid" + getStackTrace(exception));			
			return false;
		}
	}

	public boolean isDuplicateSession(String userId)
	{
		try
		{
			String query = "";
			int maxTimeDiff = Integer.parseInt(PropertyUtil.getProperty("websessiontimeout"));

			query +="SELECT count(*) CNT FROM WEB_SESSION ";
			query +="WHERE (TIMESTAMPDIFF(MINUTE,LASTACC,NOW()) < '" + maxTimeDiff + "') ";
			query +="AND (UPPER(USER_ID) = UPPER('" + userId + "')) ";
			MBDAO dao = new MBDAO();
			int count = dao.loadCount(query);
			return (count > 0);
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			logger.error("isDuplicateSession" + getStackTrace(exception));			
			return false;
		}
	}
	
	public boolean isValidSession(String userId, String sessionId)
	{
		try
		{
			String query = "";
			int maxTimeDiff = Integer.parseInt(PropertyUtil.getProperty("websessiontimeout"));

			query +="SELECT count(*) CNT FROM WEB_SESSION ";
			query +="WHERE (TIMESTAMPDIFF(MINUTE,LASTACC,NOW()) < '" + maxTimeDiff + "') ";
			query +="AND (UPPER(USER_ID) = UPPER('" + userId + "')) ";
			query +="AND (UPPER(SESSIONID) = UPPER('" + sessionId + "')) ";

			MBDAO dao = new MBDAO();
			int count = dao.loadCount(query);
			return (count > 0);
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			logger.error("isValidSession" + getStackTrace(exception));			
			return false;
		}
	}	
	
	public void clearOldWebSessions(String userId)
	{
		try
		{
			String query = "DELETE FROM WEB_SESSION ";
			query +="WHERE (UPPER(USER_ID) = UPPER('" + userId + "')) ";
			MBDAO dao = new MBDAO();
			dao.executeUpdateQuery(query);
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			logger.error("clearOldWebSessions" + getStackTrace(exception));			
		}
	}
	
	public static String formatAmountNoDecimal(String inputAmount)
	{
		String result = formatAmount(inputAmount);
		result = StringUtils.replaceString(result, ".", "", true);
		return result;
	}

	public static String formatAmount(String inputAmount)
	{
		try
		{
			double amount = Double.parseDouble(inputAmount);
		    DecimalFormat df = new DecimalFormat("##.00");
		    return df.format(amount);
		}
		catch(Exception exception)
		{
			//exception.printStackTrace();
			return inputAmount;
		}
	}
	
	public static String addDecimalToCurrentAmount(String inputAmount)
	{
		String mainValue = inputAmount.substring(0,inputAmount.length() - 2);
		String decimalValue = inputAmount.substring(inputAmount.length() - 2);
		return mainValue + "." + decimalValue;
	}
	
	/*public static void main(String[] args)
	throws Exception
	{
		MBService service = new MBService();
		System.out.println("=>" + service.getCharges("GET_ACCOUNT_DETAIL", "1000"));
		System.out.println("=>" + service.getCharges("GET_TREASURY_RATES", "1000"));
		System.out.println("=>" + service.getCharges("SEND_SMS", "1000"));
		System.out.println("=>" + service.getCharges("FT_TO_OTHER_BANK_ACCOUNT", "1000"));
		System.out.println("=>" + service.getCharges("FT_TO_OTHER_BANK_ACCOUNT", "2000"));
		System.out.println("=>" + service.getCharges("PAY_BILL", "2000"));
		
		System.out.println(service.addDecimalToCurrentAmount("00"));
		System.out.println(service.addDecimalToCurrentAmount("232311"));
		System.out.println(service.addDecimalToCurrentAmount("23231121"));
		System.out.println(service.addDecimalToCurrentAmount("23231123"));
		
//		MFService service = new MFService();
//		service.createMakerCheckerAuditEntry("user_info","1096", "Approve","","");
//		MFPrimeBankTransactionService service = new MFPrimeBankTransactionService();
//		String balanceEnquiry = service.processBalanceEnquiry("0010010051002");
//		System.out.println("Balance Enquiry:" + balanceEnquiry);
//		
//		MFService service = new MFService();
//		System.out.println(service.isDuplicateSession("7E1CEAA52F32F8DC8BF8ABBE3C1E62C0", "globaladmin"));
	}*/
}
