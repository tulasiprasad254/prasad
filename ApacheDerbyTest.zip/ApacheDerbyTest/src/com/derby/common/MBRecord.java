package com.derby.common;

import com.derby.common.MBRecord;
import com.derby.utils.LogUtils;

public class MBRecord {
	static LogUtils logger = new LogUtils(MBRecord.class.getName());

	private boolean noNullFlag = false;

	public void enableNoNull()
	{
		noNullFlag = true;
	}
	
	public void disableNoNull()
	{
		noNullFlag = false;
	}
	
	public boolean isNoNullEnabled()
	{
		return noNullFlag;
	}
	
	private boolean noNullHTMLFlag = false;

	public void enableNoNullHTML()
	{
		noNullHTMLFlag = true;
	}
	
	public void disableNoNullHTML()
	{
		noNullHTMLFlag = false;
	}
	
	public boolean isNoNullForHTMLEnabled()
	{
		return noNullHTMLFlag;
	}	


}
