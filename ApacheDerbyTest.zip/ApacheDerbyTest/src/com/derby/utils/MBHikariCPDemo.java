package com.derby.utils;

/**
 * Java JDBC Connection pool using HikariCP example program
 * 
 * @author pankaj
 */

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class MBHikariCPDemo {

	private static HikariDataSource dataSource = null;
	
	/*static
	 {
	  
	  configureConnPoolConnectionManager();

	 }*/

	static {
		HikariConfig config = new HikariConfig();
		config.setJdbcUrl(PropertyUtil.getDburl());
		config.setUsername(PropertyUtil.getDbuid());
		try {
			config.setPassword(new MFSecurityUtil().decrypt(PropertyUtil.getDbpwd()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		config.addDataSourceProperty("minimumIdle", "5");
		config.addDataSourceProperty("maximumPoolSize", "25");

		dataSource = new HikariDataSource(config);
	}

	public static void main(String[] args) throws SQLException {
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			connection = dataSource.getConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery("select * from sms_mesg");
			while (resultSet.next()) {
				System.out.println("MFROMADDR:" +  resultSet.getString("MFROMADDR"));
				System.out.println("MMESSAGE:" + resultSet.getString("MMESSAGE"));
		}
		} finally {
			resultSet.close();
			statement.close();
			connection.close();
		}
	}
}