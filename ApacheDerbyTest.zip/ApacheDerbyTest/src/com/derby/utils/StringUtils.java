package com.derby.utils;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.derby.common.MBDAO;
import com.derby.utils.DateUtils;
import com.derby.utils.StringUtils;

public class StringUtils {
    /**
     * Returns boolean Y/N Code
     * @param flag input boolean value
     * @return Y if input is true else returns N
     */
    public static String getStringValue(boolean flag)
    {
        if (flag)
        {
            return "Y";
        }
        else
        {
            return "N";
        }
    }
    
    
    public static boolean stringEquals(String oldS, String newS)
    {
    	oldS = StringUtils.noNull(oldS);
    	newS = StringUtils.noNull(newS);
    	return oldS.equals(newS);
    }
    
    public static boolean stringEqualsIC(String oldS, String newS)
    {
    	oldS = StringUtils.noNull(oldS);
    	newS = StringUtils.noNull(newS);
    	return oldS.equalsIgnoreCase(newS);
    }
    
	public static boolean isNonNullStringInRange(String value, int min, int max)
	throws Exception
	{
		if (StringUtils.isNullOrEmpty(value)) return false;
		if (value.length() < min) return false;
		if (value.length() > max) return false;
		return true;
	}    
    
    public static boolean hasDigits(String message)
    {
    	message = noNull(message);
		boolean hasDigitInOutput = false;
		char[] messageChars = message.toCharArray();
		
		for (int index = 0;index < messageChars.length; index++)
		{
			if (Character.isDigit(messageChars[index])) return true;
		}
		return false;    	
    }

    /**
     * This method converts given value(Y/N) to boolean.
     * This method throws exception if input value is not
     * Y or N.
     * @param inputValue Input Value(Valid values are Y and N)
     * @param nullOK Is null accepted? if null is accepted and
     * and if input value is null, this method returns false
     * @return Equivalent boolean value of input
     * @throws Exception incase of any exception
     */
    public static boolean getBooleanValue(String inputValue,
        boolean nullOK)
        throws Exception
    {
        //Is input value null
        if (StringUtils.isNullOrEmpty(inputValue))
        {
            //If null not accepted throw exception
            if (!nullOK)
            {
                throw new Exception("Input value cannot be empty " +
                "in StringUtils.getBooleanValue");
            }
            else
            {
                //Return default value if null
                return false;
            }
        }

        //Convert input value to upper case for comparision
        inputValue = inputValue.toUpperCase();

        //If input value is Yes return true
        if (StringUtils.isSame(inputValue, "Y"))
        {
            return true;
        }
        //If input value if No return false
        else if (StringUtils.isSame(inputValue, "N"))
        {
            return false;
        }
        //If input valud is invalid throws exception
        else
        {
            throw new Exception("Invalid input value:" + inputValue +
            "in StringUtils.getBooleanValue");
        }
    }

    /**
     * This method compares two strings with equals method.
     * This method considers null as empty string.
     * @param firstValue First String to compare;
     * Considers null as empty string for comparision
     * @param secondValue Second String to compare;
     * Considers null as empty string for comparision
     * @return true - if equals; else - false
     */
    public static boolean isSame(String firstValue,
        String secondValue)
    {
        if (firstValue == null)
        {
            firstValue = "";
        }

        if (secondValue == null)
        {
            secondValue = "";
        }

        return firstValue.equals(secondValue);
    }

    /**
     * This method converts object as a string value.  If input object
     * is null this method then returns default value
     * @param object Object
     * @param defaultValue Default Value
     * @return Returns object as string; if object is null returns
     * defaultValue
     */
    public static String getStringValue(Object object,
        String defaultValue)
    {
        //If input object is null return default value
        if (object == null)
        {
            return defaultValue;
        }
        return object.toString();
    }

    /**
     * This method converts object as an integer value. If input object
     * is null or invalid this method then returns default value
     * @param object Object
     * @param defaultValue Default Value
     * @return Returns object as integer; if object is null or invalid
     * returns defaultValue
     */
    public static int getIntegerValue(Object object,
        int defaultValue)
    {
        String stringValue = getStringValue(object,"");
        try
        {
            return Integer.parseInt(stringValue);
        }
        catch(Exception exception)
        {
            return defaultValue;
        }
    }
    
    

    /**
     * Appends spaces to given string to meet maximum length
     * @param inputValue Input string to which spaces needs to be
     * added.
     * @param maxLength Maximum Length of string.
     * @return input value with spaces appended
     * @throws IllegalArgumentException for Invalid input
     */
    public static String appendSpaces(String inputValue,
        int maxLength)
    throws IllegalArgumentException
    {
        int spacesToAdd = 0;

        //Validate input value
        if (inputValue == null)
        {
            throw new IllegalArgumentException("Input value cannot " +
                "be null in StringUtils.appendSpace method");
        }

        //Validate Maximum length
        if (maxLength < 0)
        {
            throw new IllegalArgumentException("Invalid maximum " +
                "length be null in StringUtils.appendSpace method");
        }

        spacesToAdd = maxLength - inputValue.length();

        if (spacesToAdd <= 0)
        {
            return inputValue;
        }

        for (int spaceIndex = 0; spaceIndex < spacesToAdd;
            spaceIndex++)
        {
            //append space
            inputValue = inputValue + " ";
        }

        return inputValue;
    }

    /**
     * Checks if input value is null or empty string
     * @param inputValue Input Value
     * @return true - if null or empty string; false - otherwise
     */
    public static boolean isNullOrEmpty(String inputValue)
    {
        if (inputValue == null) return true;
        if (inputValue.trim().length() < 1) return true;
        return false;
    }

    /**
    * Converts object to string. Returns null if object is null
    * else casts object as String
    *
    * @param inputObject Input Object
    * @return          Returns null if input object is null;
    * else casts object as String
    */
    public static String getStringValue(Object inputObject)
    {
        if (inputObject == null)
        {
            return null;
        }

        return (String) inputObject;
    }

    /**
    * Parses input value based on delimiter and returns desired token
    *
    * @param inputValue String to be parsed
    * @param delimiter  Delimiter for parsing
    * @param tokenNumber  Desired token number(0 for First token,
    * 1 for Second token etc)
    * @return          Returns desired token
    * @throws IllegalArgumentException for Invalid input
    * @throws Exception for all others
    */
    public static String getToken(
        String inputValue,
        String delimiter,
        int tokenNumber)
        throws IllegalArgumentException, Exception
    {
        String resultValue = null;

        //Validate Input Value
        if (inputValue == null)
        {
            throw new IllegalArgumentException("Input value cannot" +
                "be null in StringUtils.getToken method");
        }

        //Validate Delimiter
        if (delimiter == null)
        {
            throw new IllegalArgumentException("Delimiter cannot be" +
                " null in StringUtils.getToken method");
        }

        //Validate token number
        if (tokenNumber < 0)
        {
            throw new IllegalArgumentException("Invalid token number" +
                " in StringUtils.getToken method");
        }

        StringTokenizer st = new StringTokenizer(inputValue, delimiter);
        for (int tokenIndex = 0; tokenIndex < tokenNumber;
            tokenIndex++)
        {
            st.nextToken();
        }

        if (st.hasMoreTokens())
        {
            resultValue = st.nextToken();
        }

        return resultValue;
    }
    /**
     * This method is used to capitalize the first character
     * of a String to upper case.
     * 
     * @param inputValue The string whose first character has to be
     * 					 capitalized
     * @return 			The input String with the first character
     * 					capitalized.
     */
    
    public static String convertFirstCharacterToUpperCase(String inputValue)
    {
		//Get the character representation of the 
		char [] inputValueCharArray = inputValue.toCharArray();
		//Convert the first character to Upper Case
		inputValueCharArray[0] = Character.toUpperCase(inputValueCharArray[0]);
		//return the new String
		return String.copyValueOf(inputValueCharArray);
		
    }
    
    

    /**
     * Parses given string and returns array of tokens
     * @param inputValue String to be parsed
     * @param delimiter  Delimiter for parsing
     * @return Array of tokens
     * @throws IllegalArgumentException for Invalid input
     * @throws Exception for all others
     */
    public static String[] parseString(String inputValue,
        String delimiter)
    throws IllegalArgumentException, Exception
    {
        //Validate Input Value
        if (inputValue == null)
        {
            throw new IllegalArgumentException("Input value cannot" +
                "be null in StringUtils.parseString method");
        }

        //Validate delimiter
        if (delimiter == null)
        {
            throw new IllegalArgumentException("Delimiter cannot" +
                "be null in StringUtils.parseString method");
        }

        //Validate delimiter
        if (delimiter.length() < 1)
        {
            throw new IllegalArgumentException("Invalid Delimiter " +
                " in StringUtils.parseString method");
        }

        //Parse
        StringTokenizer tokenizer =
            new StringTokenizer(inputValue, delimiter);

        //Create an array for tokens
        String[] result = new String[tokenizer.countTokens()];

        int tokenIndex = 0;
        while(tokenizer.hasMoreTokens())
        {
            result[tokenIndex] = tokenizer.nextToken();
            tokenIndex++;
        }

        //Return result array
        return result;
    }

    /**
    * A method that uses a stringtokenizer to parse a NameValue pair
    * and returns a map.
    * A NameValue Pair is in the following format:
    * OrderNo=Y100089&EnterpriseCode=Bestbuy&ShiptoID=493848234
    *
    * @param inputValue String to be parsed
    * @return          Map object that contains name value pairs
    * @throws IllegalArgumentException for Invalid input
    * @throws Exception for all others
    */
    public static java.util.Map getMap(String inputValue)
        throws IllegalArgumentException, Exception
    {
        //Validate Input Value
        if (inputValue == null)
        {
            throw new IllegalArgumentException("Input value cannot" +
                "be null in StringUtils.getMap method");
        }

        //Validate Input Value
        if (inputValue.indexOf("&") <= -1)
        {
            throw new IllegalArgumentException("Invalid Input value" +
                " in StringUtils.getMap method");
        }

        //Validate Input Value
        {
        if (inputValue.indexOf("=") <= -1)
            throw new IllegalArgumentException("Invalid Input value" +
                " in StringUtils.getMap method");
        }

        Map map = Collections.synchronizedMap(new HashMap());
        StringTokenizer st = new StringTokenizer(inputValue, "&");
        while (st.hasMoreTokens())
        {
            String nameValuePair = st.nextToken();
            map.put(getToken(nameValuePair, "=", 0),
                getToken(nameValuePair, "=", 1));
        }
        return map;
    }

    /**
    * Constructs name value pair string in the following format
    * from Map object
    * OrderNo=Y100089&EnterpriseCode=Bestbuy&ShiptoID=493848234
    *
    * @param map   Input Map object
    * @return      Name value pair string
    * @throws IllegalArgumentException for Invalid input
    * @throws Exception for all others
    */
    public static String getMapContent(java.util.Map map)
        throws IllegalArgumentException, Exception
    {
        //Validate map
        if (map == null)
        {
            throw new IllegalArgumentException("Input value cannot" +
                " be null in StringUtils.getMap method");
        }

        String result = "";
        Object[] keyList = map.keySet().toArray();
        for (int index = 0; index < keyList.length; index++)
        {
            String name = getStringValue(keyList[index]);
            String value = getStringValue(map.get(keyList[index]));
            if (result.length() > 1)
                result = result + "&";
            result = result + name + "=" + value;
        }
        return result;
    }

    public static String toInitCap(String value)
    {
        char[] cArray = value.toCharArray();
        cArray[0] = (("" + cArray[0]).toUpperCase()).charAt(0);
        return (new String(cArray));
    }
    
    /*public boolean isUserLoggedIn(HttpServletRequest req, HttpServletResponse res,String sendersession)
    {
    	
        HttpSession session = req.getSession(true);
        Object recordObject = session.getAttribute("LoginUserRecord");
        System.out.println("Session Check 1 ::"+recordObject);
        if (recordObject == null) return false;

        System.out.println("Session Check 2 ::");
        MFUserdetailsRecord userRecord = (MFUserdetailsRecord)recordObject;
        String userID = userRecord.getUserid();
        System.out.println("Session Check 3 ::");
        if (userID == null) return false;
        System.out.println("Session Check 4 ::");
        if (userID.trim().length() < 1) return false;
        System.out.println("Session Check 5 ::");
        if(!userID.equalsIgnoreCase(sendersession))return false;
        System.out.println("Session Check 6 ::");
        return true;
    }
    
    public boolean createSession(HttpServletRequest req, HttpServletResponse res,MFMobilejsonrequestRecord requestRecord)
    {
    	LogUtils.println("Create New Session");
    	HttpSession httpsession = req.getSession(true);	
    	MFSessionRecord sessionRecord=new MFSessionRecord();
    	try
    	{
    		requestRecord.setSessionid(generateSessionId());
    		String modified=DateUtils.getCurrentDateTime();  		
    		sessionRecord.setSession(requestRecord.getSessionid());	    
    		sessionRecord.setUserid(requestRecord.getId());
    		sessionRecord.setCreatedat(modified);			
    		if(!insertSessionRecord(sessionRecord)) return false;
    		return true;
    	}catch (Exception e) {
    		e.printStackTrace();
			return false;
		}
    	
    }
    public boolean isUserLoggedInCheck(HttpServletRequest req, HttpServletResponse res,MFMobilejsonrequestRecord requestRecord)
    {
    	try
    	{
    		//HttpSession sessionhtpp = req.getSession(true);
	    	String sessionsender=(String)requestRecord.getSessionid();
	    	if(sessionsender==null) return false;
	    	if(!sessionRecordMatch(req,res,requestRecord)) return false;
	    	return true; 	
    	}catch (Exception e) {
    		e.printStackTrace();
    		 return false;
		}
    }
    */
    
   /* public boolean isUserLoggedIn(HttpServletRequest req, HttpServletResponse res,MFMobilejsonrequestRecord sendersession)
    {
    	try
    	{
    		HttpSession sessionhtpp = req.getSession(true);
	    	String sessionsender=(String)sendersession.getSessionid();
	    	
	    	if(sessionsender==null)
	    		return false;
	    	if(sessionsender.equalsIgnoreCase("0"))
	    	{
	    		String sess=generateSessionId();
	    		sendersession.setSessionid(sess);
	    		LogUtils.println("Session initial setting :: "+sendersession);
	    		String modified=DateUtils.getCurrentDateTime();
	    		MFSessionRecord record=new MFSessionRecord();
	    		record.setSession(sendersession.getSessionid());	    
	    		record.setUserid(sendersession.getId());
	    		record.setCreatedat(modified);
	    		MFUserdetailsRecord recorde=fetchingrecord(sendersession.getId());
	    		sendersession.setCustrecord(recorde);
	    		record.setModifiedat(modified);
	    		closeAllSessions(record);
	    		if(!insertingSessionRecord(record))
	    			return false;
	    		return true;
	    	}
	    	
	        if(!SessionrecordMatch(req,res,sendersession))
	        	return false;
	        return true;
    	}catch (Exception e) {
    		e.printStackTrace();
    		 return false;
		}
    	
    }*/
    /*public boolean createSession(MFMobilejsonrequestRecord requestRecord) throws Exception
    {
    	try
    	{
	    	String sess=generateSessionId();
	    	requestRecord.setSessionid(sess);
	    	LogUtils.println("Passing UserID :: "+requestRecord.getId());
	    	if(!insertSessionRecord(requestRecord)) return false;
			LogUtils.println("Session initial setting :: "+sess);
			return true;
    	}catch (Exception e) {
			e.printStackTrace();
			return false;
		}
    }
    public boolean insertSessionRecord(MFMobilejsonrequestRecord requestRecord)
    {
    	try
    	{
    		    String modified=DateUtils.getCurrentDateTime();
		    	MFSessionRecord record=new MFSessionRecord();
		    	LogUtils.println("Inserting the User ID :: "+requestRecord.getId());
				record.setSession(requestRecord.getSessionid());	    
				record.setUserid(requestRecord.getId());
				record.setCreatedat(modified);	
				record.setLastlogin(modified);
				String sessioncheckguestuser = null;
				if(requestRecord.getId().equalsIgnoreCase(PropertyUtil.getProperty("GUESTUSER")))//"tulasi.prasad254@gmail.com"
					 sessioncheckguestuser = checkguestUserSession(requestRecord.getId());
				if(isNull(sessioncheckguestuser))
				{
					closeAllSessions(requestRecord.getId());
					if(!insertSessionRecord(record)) return false;
					return true;
				}
				requestRecord.setSessionid(sessioncheckguestuser);
		    	return true;
		
    	}catch (Exception e) {
    		e.printStackTrace();
    		return false;
		}
    }
    public MFMobilejsonrequestRecord insertingCustomerRecord(MFMobilejsonrequestRecord requestRecord)
    {
    	try
    	{
	    	MFUserdetailsRecord custrecord=fetchingrecord(requestRecord.getId());
	    	requestRecord.setCustrecord(custrecord);
	    	return requestRecord;
    	}catch (Exception e) {
    		e.printStackTrace();
    		return null;
		}
    }
    
    public MFUserdetailsRecord fetchingrecord(String userid) throws Exception
    {
    	LogUtils.println("Check Session : 2 Session Record User ID ****** "+userid);
    	MFUserdetailsService service=new MFUserdetailsService();
    	MFUserdetailsRecord record=new MFUserdetailsRecord();
    	//record.setUserid(userid); A1 jan 1st 2017 3:25 PM
    	record.setEmail(userid);
    	record.setAcctstatus("1");
    	MFUserdetailsRecord Userrecord=service.searchFirstMFUserdetailsRecord(record);
		return Userrecord;
    	
    }*/
    public void closeAllSessions(String userId) throws Exception
    {
    	try
    	{
    		
    		LogUtils.println("Previous Session Deletion");
    		String Query="DELETE FROM session WHERE USERID = '#USERID#'";
    		Query=replaceString(Query, "#USERID#", userId, true);
    		MBDAO dao=new MBDAO();
    		dao.executeUpdateQuery(Query);
    		LogUtils.println("Previous Session CHECK : 1");
    	}catch (Exception e) {
			
		}
    }
    /*public boolean insertSessionRecord(MFSessionRecord record)
    {
    	MFSessionService service=new MFSessionService();
    	try
    	{
	    	int resukr=service.insertMFSessionRecord(record);
	    	
	    	LogUtils.println("Retured value :: "+resukr);
	    	return true;
    	}catch (Exception e) {
    		e.printStackTrace();
    		return false;
		}
    }
    
    public String checkguestUserSession(String userId)
    {
    	String Query="SELECT * FROM session WHERE USERID = '"+userId+"'";
    	try
    	{
	    	MFSessionService service=new MFSessionService();
			MFSessionRecord record=service.loadFirstMFSessionRecord(Query);
			
			if(record==null) return null;
			
			return record.getSession();
				
    	}catch (Exception e) {
			e.printStackTrace();
			return null;
		}
    }*/
    
    
    /*public boolean sessionRecordMatch(HttpServletRequest req, HttpServletResponse res,MFMobilejsonrequestRecord sendersession) throws Exception
    {  
    	LogUtils.println("Checking SessionrecordMatch Check1 :: ");
    	String sessionsender=(String)sendersession.getSessionid();
    	String Query="SELECT * FROM session WHERE session='#sessionsender#'";
        Query=replaceString(Query, "#sessionsender#", sessionsender, true);
    	long diffseconds;
    		MFSessionService service=new MFSessionService();
    		MFSessionRecord record=service.loadFirstMFSessionRecord(Query);
    		if(record==null)
    			return false;
    		String createdsession=record.getLastlogin();
    		//String UserId=record.getUserid();
    		String lastUsageTime = StringUtils.noNull(createdsession);
    		String currentTime = DateUtils.getCurrentDateTime();
    		
    		diffseconds = DateUtils.getDifferenceInSeconds(
    					lastUsageTime, 
    					DateUtils.getLongDateFormat(), 
    					currentTime, 
    					DateUtils.getLongDateFormat());   	
    		int timeOutInterval = Integer.parseInt(PropertyUtil.getProperty("mobilesessiontimeout"));
    		
    		if (diffseconds > timeOutInterval)
    		{
    			LogUtils.println("Session Difference : : "+diffseconds+"/timeout : :"+timeOutInterval+"Entered");
    			service.deleteMFSessionRecord(record);
    			return false;
    		}	
    		LogUtils.println("Check Session : 1.1 Session Record User ID ****** "+record.getUserid());
    		MFUserdetailsRecord recorde=fetchingrecord(record.getUserid());
    		sendersession.setCustrecord(recorde);
    		//MFSessionService serviceSession=new MFSessionService();
    		record.setLastlogin(currentTime);
    		updateLastlogin(record);
    		//serviceSession.updateMFSessionRecord(record);
    		
    		//setSessionRecord(req,res,UserId);
	        return true;

    }
    
    public void updateLastlogin(MFSessionRecord record)
    {
    	try
    	{
    		String recordLastLogin=record.getLastlogin();
    		String recordUserId=record.getUserid();
    		LogUtils.println("Session Updation");
    		LogUtils.println("Check Session : 1 Session Record User ID ****** "+recordUserId);
    		String Query="UPDATE SESSION SET LASTLOGIN='#SESSION#' WHERE USERID='#USERID#'";
    		Query=replaceString(Query, "#SESSION#", recordLastLogin, true);
    		Query=replaceString(Query, "#USERID#", recordUserId, true);
    		MFDAO dao=new MFDAO();
    		dao.executeUpdateQuery(Query);
    		LogUtils.println("Session Updation CHECK : 1");
    	}catch (Exception e) {
			
		}
    	
    }
    public void setSessionRecord(HttpServletRequest req, HttpServletResponse res,String UserId) throws Exception
    {
    	 HttpSession sessionhtpp = req.getSession(true);
    	 Object recordObject = sessionhtpp.getAttribute("LoginUserRecord");
         System.out.println("Session Check 1 ::"+recordObject);
         if (recordObject !=null) return;
         HttpSession session = req.getSession(true);        		
         session.setAttribute("LoginUserRecord", null);
         session.invalidate();
         
		MFUserdetailsRecord Userrecord=new MFUserdetailsRecord();
		MFUserdetailsRecord Userrecordtwo=new MFUserdetailsRecord();
		MFUserdetailsService UserService=new MFUserdetailsService();
		Userrecord.setUserid(UserId);
		Userrecord.setAcctstatus("1");
		Userrecordtwo=UserService.searchFirstMFUserdetailsRecord(Userrecord);
		sessionhtpp.setAttribute("LoginUserRecord",Userrecordtwo);
    }*/
    public void logOffUser(HttpServletRequest req, HttpServletResponse res)
    {
        HttpSession session = req.getSession(true);
		//session.setAttribute("AuthenticateActionMessage", "");	        		
        session.setAttribute("LoginUserRecord", null);
        session.invalidate();
    }
    
    public static String loadFileToString(String FileName)
    throws IOException
    {
        StringBuffer sb = new StringBuffer("");

        FileInputStream fis = new  FileInputStream(FileName);
        BufferedReader br = new BufferedReader(new InputStreamReader(fis));
        while(true)
        {
            String line = br.readLine();
            if (line == null) break;
            sb.append(line + "\n");
        }
        br.close();
        fis.close();
        return sb.toString();
    }
    
    public static ArrayList loadFileAsArrayList(String FileName)
    throws IOException
    {
    	ArrayList arrayList = new ArrayList();
        FileInputStream fis = new  FileInputStream(FileName);
        BufferedReader br = new BufferedReader(new InputStreamReader(fis));
        while(true)
        {
            String line = br.readLine();
            if (line == null) break;
            arrayList.add(line);
        }
        br.close();
        fis.close();
        return arrayList;
    }    
    
    public static void writeStringToFile(String Data, String FileName)
    throws IOException
    {
        FileOutputStream fos = new FileOutputStream(FileName);
        DataOutputStream dos = new DataOutputStream(fos);
        dos.writeBytes(Data);
        dos.close();
        fos.close();
    }

    public static String replaceString(String Source, String Old, String New, boolean repeat)
	{
		if (Source == null) return "";
		if (Old == null) return Source;
		if (New == null) return Source;
		if (Old.equals(New)) return Source;

		int index = Source.indexOf(Old);
		if (index < 0) return Source;

		String firstPart = Source.substring(0,index);
		String finalPart = Source.substring(index + Old.length());

		if (repeat)
		{
			if ((finalPart != null)&&(finalPart.length() > 0))
				return (firstPart + New + replaceString(finalPart, Old, New, repeat));
		}
		return (firstPart + New + finalPart);
	}
	
    public static String stripEnd(String value, String stripValue)
    {
        if (value.endsWith(stripValue))
        return value.substring(0, value.lastIndexOf(stripValue) + 1);
        else
        return value;
    }
    
    public static String noNull(Object value)
    {
    	if (value == null) return "";
    	return value.toString();
    }
    
    public static String noNullForHTML(Object value)
    {
    	return noNull(value, "&nbsp;");
    }    
    
    public static String noNull(Object value, String defaultValue)
    {
    	if (value == null) return defaultValue;
    	if (value.toString().trim().length() < 1) return defaultValue;
    	return value.toString();
    }    

    public static String noNullString(String value)
    {
    	if (value == null) return "";
    	return value.toString();
    }    

    public static boolean isNull(String value)
    {
        if (value == null) return true;
        if (value.length() < 1) return true;
        if (value.trim().length() < 1) return true;
        return false;
    }

    public static String getValueFromJSONObject(JSONObject obj, String attributeName)
    throws Exception
    {
    	if (obj == null) return "";
    	if (attributeName == null) return "";
    	try
    	{
    		return obj.get(attributeName).toString();
    	}
    	catch(Exception e)
    	{
    		return "";
    	}
    }

    public static String trimSize(String mesg, int maxSize)
    {
    	if (mesg == null) return mesg;
    	if (mesg.length() < maxSize) return mesg;
    	return mesg.substring(0,maxSize);
    }
    
    public static String getStackTrace(Throwable aThrowable)
    {
        final Writer result = new StringWriter();
        final PrintWriter printWriter = new PrintWriter(result);
        aThrowable.printStackTrace(printWriter);
        return result.toString();
    }
    
    public static String getProcessedErrorMessage(Throwable aThrowable)
    {
    	String errorMessage = getStackTrace(aThrowable);
    	if (errorMessage.contains("CIF_UNIQUE")) return "Duplicate Customer ID";
    	if (errorMessage.contains("EMAIL_UNIQUE")) return "Duplicate EMail ID";
    	if (errorMessage.contains("ACC_NUM_UNIQUE")) return "Duplicate Account Number";
    	if (errorMessage.contains("MOBILE_UNIQUE")) return "Duplicate Mobile Number";
    	return errorMessage;
    }

    public static String trimLeadingSize(String value, int size)
    {
    	if (value == null) return value;
    	value = "0000000" + value;
    	value = value.substring(value.length() - size);
    	return value;
    }

    public static String generateReportSessionId()
    throws Exception
    {
    	int randomNumber = (new Random()).nextInt(999999);
    	String formattedRandomNumber = trimLeadingSize(randomNumber + "", 4);
    	String currentDateTime = DateUtils.getCurrentTime("yyyyMMddHHmmss");
    	return "1" + currentDateTime + formattedRandomNumber;
    }
    
    public static String generateSessionId()
    throws Exception
    {
    	int randomNumber = (new Random()).nextInt(999999);
    	String formattedRandomNumber = trimLeadingSize(randomNumber + "", 4);
    	String currentDateTime = DateUtils.getCurrentTime("MMddHHmmss");
    	return "1" + currentDateTime + formattedRandomNumber;
    }
    
    public static String generateVoucherId(String prefix1)
    throws Exception
    {
    	int randomNumber = (new Random()).nextInt(999999999);
    	String formattedRandomNumber = trimLeadingSize(randomNumber + "", 9);
    	String currentDateTime = DateUtils.getCurrentTime("MMddHHmmss");
    	return "1" + currentDateTime + prefix1 + formattedRandomNumber;
    }
    
    public static int getRandomNumber(int Low, int High)
    {
    	Random r = new Random();
    	int R = r.nextInt(High-Low) + Low;
    	return R;
    }
    
    public static String getCurrencyEquivalent(String inputAmount)
    throws Exception
    {
    	try
    	{
    		double amount = Double.parseDouble(inputAmount);
            DecimalFormat df = new DecimalFormat("#############.00");
            String formattedValue = df.format(amount);
            return formattedValue;
    	}
    	catch(Exception exception)
    	{
    		return inputAmount;
    	}
    }    
    
	public static boolean isValidPhoneNumber(String phoneNumber)
	{
		phoneNumber = StringUtils.noNull(phoneNumber);
		
		if (phoneNumber.trim().length() < 8) return false;

		for (int index = 0; index < phoneNumber.length(); index++)
		{
			if (!Character.isDigit(phoneNumber.charAt(index))) return false;
		}
		return true;
	}

	public static boolean isValidNumber(String inputNumber)
	{
		inputNumber = StringUtils.noNull(inputNumber);
		
		if (inputNumber.trim().length() < 5) return false;

		for (int index = 0; index < inputNumber.length(); index++)
		{
			if (!Character.isDigit(inputNumber.charAt(index))) return false;
		}
		return true;
	}
	
	public static boolean isValidAmount(String inputNumber)
	{
		try
		{
			double amount = Double.parseDouble(inputNumber);
			return true;
		}
		catch(Exception exception)
		{
			return false;
		}
	}	
	
	public static boolean isValidShortNumber(String inputNumber)
	{
		inputNumber = StringUtils.noNull(inputNumber);
		
		for (int index = 0; index < inputNumber.length(); index++)
		{
			if (!Character.isDigit(inputNumber.charAt(index))) return false;
		}
		return true;
	}  		

	public static String getLastCharacters(String inputValue, int last)
	{
		inputValue = StringUtils.noNull(inputValue).trim();
		int len = inputValue.length();
		int idx = len - last;
		if (idx < 0) return inputValue;
		String result = inputValue.substring(idx);
		return result;
	}
	
	public static String getMapValue(HashMap map, String inputKey)
	{
		if (map == null) return "";
		if (inputKey == null) return "";
		if (!map.containsKey(inputKey)) return "";
		if (map.get(inputKey) == null) return "";
		return map.get(inputKey).toString();
	}
	
	public static String getMapValueWT(HashMap map, String inputKey)
	{
		String result = getMapValue(map, inputKey);
		result = StringUtils.noNull(result).trim();
		return result;
	}
	
	public static String getMapValue(Map map, String inputKey)
	{
		if (map == null) return "";
		if (inputKey == null) return "";
		if (!map.containsKey(inputKey)) return "";
		if (map.get(inputKey) == null) return "";
		return map.get(inputKey).toString();
	}	
	
	public static boolean isValidEMail(String email)
	{
		if (email == null) return false;
		if (!email.contains("@")) return false;
		return true;
	}	
	
	public static String loadFileAsString(String fileName)
	throws Exception
	{
		FileInputStream fis = new FileInputStream(fileName);
		DataInputStream dis = new DataInputStream(fis);
		String content = "";
		while(true)
		{
			String line = dis.readLine();
			if (line == null) break;
			content = content + line + "\n";
		}
		dis.close();
		fis.close();
		return content;
	}

    public static String loadURLContent(String inputURL)
    throws Exception
    {
    	URL url = new URL(inputURL);
    	BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));

    	StringBuffer sb = new StringBuffer();

    	String inputLine;
    	while ((inputLine = in.readLine()) != null)
    	{
    		sb.append(inputLine + "\n");
    	}
    	in.close();    	

    	return sb.toString();
    }
    

	
    public static String[] parseStringOwn(String inputValue,
            String delimiter)
        throws IllegalArgumentException, Exception
        {
            
    		//Parse
            StringTokenizer tokenizer =
                new StringTokenizer(inputValue, delimiter);

            //Create an array for tokens
            String[] result = new String[tokenizer.countTokens()];

            int tokenIndex = 0;
            while(tokenizer.hasMoreTokens())
            {
                result[tokenIndex] = tokenizer.nextToken();
                tokenIndex++;
            }

            //Return result array
            return result;
        }	
    
    public static String getNextToken(String inputValue, String delimiter)
    {
    	int index = inputValue.indexOf(delimiter);
    	if (index == -1) return inputValue;
    	if (index == 0) return "";
    	return (inputValue.substring(0, index + delimiter.length() -1));
    }

    public static String clearNextToken(String inputValue, String delimiter)
    {
    	int index = inputValue.indexOf(delimiter);
    	if (index == -1) return "";
    	return (inputValue.substring(index + delimiter.length()));
    }
    
    public static String[] parseToTokens(String data, String delimiter)
    {
    	ArrayList tokenList = new ArrayList();
    	while(true)
    	{
    		String token = StringUtils.getNextToken(data, delimiter);
	    	tokenList.add(token);

	    	data = StringUtils.clearNextToken(data, delimiter);
//	    	if (!data.contains("delimiter"))
//	    	{
//	    		tokenList.add(data);
//	    		break;
//	    	}
	    	if (StringUtils.isNullOrEmpty(data)) break;
    	}

    	
    	String tokenArray[] = new String[tokenList.size()];
    	for (int index = 0; index < tokenList.size(); index++)
    	{
    		tokenArray[index] = tokenList.get(index).toString();
    	}
    	
    	return tokenArray;    	
    }
    
	public static String pushToStack(String currentStack, String newElement)
	{
		if (StringUtils.isNullOrEmpty(currentStack))
		{
			currentStack = newElement;
			return currentStack;
		}

		currentStack = newElement + "," + currentStack;
		return currentStack;
	}

	public static String peekFromStack(String currentStack)
	{
		if (StringUtils.isNullOrEmpty(currentStack))
		{
			return "";
		}

		int commaIndex =  currentStack.indexOf(",");
		if (commaIndex == -1) return currentStack;

		String peekElement = currentStack.substring(0, commaIndex);
		return peekElement;
	}

	public static String popFromStack(String currentStack)
	{
		if (StringUtils.isNullOrEmpty(currentStack))
		{
			return "";
		}

		int commaIndex =  currentStack.indexOf(",");
		if (commaIndex == -1) return "";

		String popElement = currentStack.substring(commaIndex + 1);
		return popElement;
	}
	
	public static boolean inStack(String currentStack, String element)
	throws Exception
	{
		if (StringUtils.isNullOrEmpty(currentStack))
		{
			return false;
		}
		
		String[] tokens = StringUtils.parseString(currentStack, ",");

		for (int index = 0; index < tokens.length; index++)
		{
			if (tokens[index].equals(element))
			{
				return true;
			}
		}
		return false;
	}
	
	public static boolean hasChanged(String s1, String s2)
	{
		s1 = StringUtils.noNull(s1);
		s2 = StringUtils.noNull(s2);

		if (!StringUtils.isNullOrEmpty(s1))
		{
			if (StringUtils.isNullOrEmpty(s2))
			{
				return false;
			}
		}

		return (!s1.equals(s2));
	}
	
	public static boolean isLicenseValid() 
	throws Exception
	{
		String enccode =PropertyUtil.getProperty("enckey");
		if (!enccode.startsWith("M0deIsPb")) return true;

		String defaultLicenseDate = DateUtils.getCurrentTime(DateUtils.getLongDateFormat());
		java.util.Date expDate = DateUtils.convertDate("20140509");
		java.util.Date currDate = new java.util.Date();
		return (expDate.after(currDate));
	}
	
	public static HashMap convertJSONToMap(String jsonInput)
	throws Exception
	{
		if (StringUtils.isNullOrEmpty(jsonInput)) return (new HashMap());

		JSONParser parser = new JSONParser();
		JSONObject jsonObject = (org.json.simple.JSONObject)parser.parse(jsonInput);
		return convertJSONToMap(jsonObject);
	}
	
	public static HashMap convertJSONToMap(JSONObject jsonObject)
	throws Exception	
	{
		HashMap resultMap = new HashMap();
		Iterator iterator = jsonObject.keySet().iterator();
		while(iterator.hasNext())
		{
			String key = StringUtils.noNull(iterator.next());
			String value = StringUtils.noNull(jsonObject.get(key));
			resultMap.put(key, value);
		}
		return resultMap;		
	}		
	
	public static String convertMapToJSONString(HashMap map)
	throws Exception	
	{
		JSONObject json = new JSONObject(map);
		return json.toJSONString();
	}
	
	/**
	 * Compute the hash value to check for "real person" submission.
	 * 
	 * @param  value  the entered value
	 * @return  its hash value
	 */
	public static String rpHash(String value) {
		int hash = 5381;
		value = value.toUpperCase();
		for(int i = 0; i < value.length(); i++) {
			hash = ((hash << 5) + hash) + value.charAt(i);
		}
		return String.valueOf(hash);
	}	
	
    public static void main(String[] args) throws IllegalArgumentException, Exception
    {
    	/*String currentDateTime = DateUtils.getCurrentTime("yyyyMMddHHmmss");
    	System.out.println("Data and Time : : "+currentDateTime);*/
    	//sendersession.setSessionid(StringUtils.generateSessionId());
    	
    	  /*long ONE_MINUTE_IN_MILLIS=60000;//millisecs

    	Calendar date = Calendar.getInstance();
    	long t= date.getTimeInMillis();
    	Date afterAddingTenMins=new Date(t + (1440 * ONE_MINUTE_IN_MILLIS));
    	System.out.println("Date *** "+DateUtils.formatDate(afterAddingTenMins, "yyyyMMddHHmmss"));*/
    	/*LogUtils.println(StringUtils.getRandomNumber(1, 5));
    	LogUtils.println(StringUtils.getRandomNumber(1, 5));
    	LogUtils.println(StringUtils.getRandomNumber(1, 5));
    	LogUtils.println(StringUtils.getRandomNumber(1, 5));
    	LogUtils.println(StringUtils.getRandomNumber(1, 5));*/
    }
    
    
    /**
     * Generates Session ID with cif
     * @param input String (cif)
     * @return String value of session ID with cif as a value in session
     */
    
    public static String generateSessionId(String cif)
    throws Exception
    {
    	if(StringUtils.isNullOrEmpty(cif))
    		return generateSessionId();
    	int randomNumber = (new Random()).nextInt(999999);
    	String formattedRandomNumber = trimLeadingSize(randomNumber + "", 4);
    	int randomNumber2 = (new Random()).nextInt(999999);
    	String formattedRandomNumber2 = trimLeadingSize(randomNumber2 + "", 4);
    	String sessionID = formattedRandomNumber2+ cif + formattedRandomNumber;
    	sessionID = sessionID.replaceAll("-", "");
    	sessionID = sessionID.replaceAll("_", "");
    	sessionID = sessionID.replaceAll("[^\\d.]", "");
    	if (sessionID.length()>20)
    		sessionID = sessionID.substring(0, 19);
    	
    	return sessionID;
    }
    
    /**
     * Appends String to file content
     * @param input string (Data), String (FileName)
     * @return No Return
     */

    public static void appendStringToFile(String Data, String FileName)
    throws IOException
    {
        FileOutputStream fos = new FileOutputStream(FileName,true);
        DataOutputStream dos = new DataOutputStream(fos);
        dos.writeBytes(Data);
        dos.close();
        fos.close();
    }
   
}
