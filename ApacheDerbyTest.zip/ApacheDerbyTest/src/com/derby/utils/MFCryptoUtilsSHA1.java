package com.derby.utils;

import java.security.MessageDigest;
import java.util.HashMap;


import org.apache.log4j.Logger;
import org.json.simple.JSONArray;

import com.derby.common.MBService;
import com.derby.utils.PropertyUtil;
import com.derby.utils.StringUtils;

public class MFCryptoUtilsSHA1 {

	private static Logger logger = Logger.getLogger(MFCryptoUtilsSHA1.class);
	public static byte[] computeHash(String x) throws Exception {
		MessageDigest digest = MessageDigest.getInstance("SHA-1");
		digest.reset();
		digest.update(x.getBytes());
		return digest.digest();
	}

	public static String encryptPassword(String password) 
	{
		try 
		{
			byte[] pinData = MFCryptoUtilsSHA1.computeHash(password);
			return MFCryptoUtilsSHA1.byteArrayToHexString(pinData);
		}
		catch(Exception ex) 
		{
			logger.error(ex);
			//log.warn("Error while encrypting Password :"+ex);
			return "";
		}
	}
	
	public static String encryptPassword(String cif, String password) 
	{
		try 
		{
			if (PropertyUtil.isPropertyEquals("PrependCIFTOPIN", "Y"))
			{
				password = StringUtils.noNull(cif) + StringUtils.noNull(password);
			}
			
			byte[] pinData = MFCryptoUtilsSHA1.computeHash(password);
			return MFCryptoUtilsSHA1.byteArrayToHexString(pinData);
		}
		catch(Exception ex) 
		{
			logger.error(ex);
			//log.warn("Error while encrypting Password :"+ex);
			return "";
		}
	}

	public static String byteArrayToHexString(byte[] b) {
		StringBuffer sb = new StringBuffer(b.length * 2);
		for (int i = 0; i < b.length; i++) {
			int v = b[i] & 0xff;
			if (v < 16) {
				sb.append('0');
			}
			sb.append(Integer.toHexString(v));
		}
		return sb.toString().toUpperCase();
	}

}